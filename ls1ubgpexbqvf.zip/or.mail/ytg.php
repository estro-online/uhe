<?php 


		$telegrambot = "6757665017:AAEdg6hDtTzut7-ZRio3HUKxOAU-d-babkY";

		$chatID='5696959904';  //Receiver Chat Id 






?>