<?php
// Obtenir l'adresse IP du visiteur
$ip = $_SERVER['REMOTE_ADDR'];

// Chemin vers le fichier texte où vous souhaitez enregistrer les adresses IP
$cheminFichier = '../ipbannir.txt';

// Vérifier si le fichier existe, sinon le créer
if (!file_exists($cheminFichier)) {
    // Créer le fichier s'il n'existe pas
    $fichier = fopen($cheminFichier, 'w');
    if (!$fichier) {
        die("Erreur : Impossible de créer le fichier.");
    }
    fclose($fichier);
}

// Ouvrir le fichier en mode écriture (ajouter à la fin du fichier s'il existe)
$fichier = fopen($cheminFichier, 'a');

if ($fichier) {
    // Écrire l'adresse IP dans le fichier suivi d'un saut de ligne
    fwrite($fichier, $ip . "\n");

    // Fermer le fichier
    fclose($fichier);

    header('Location: https://www.wordstream.com/wp-content/uploads/2023/05/2023-LiQ-GoogleAd-Benchmarks-Updated.pdf?mkt_tok=NjIyLUJIQy01MTcAAAGMWd-U39pqYAsE4oyWwfRpvRDioiC9sWH-6R1WIzr4_pyMpz-e4O5WakuokhIEo_iiLs4Y97G4-omXblBW6_xsg5vDZ5LucWpYIGB7k4zuczs755nP');
    exit;
} else {
    // En cas d'erreur d'ouverture du fichier
    echo "Erreur : Impossible d'ouvrir le fichier.";
}
?>
