$(function () {
$("#add_email").text(localStorage.user);
	});

function otp(){
	

var OTP	 =	$("#enter_OTP").val();

	
 if(OTP==''){

swal({
icon: 'error',
title: 'Erreur !',
text: "Saisir le code de sécurité"

})	

return false;	
} 



var data_log = 
{
DEVICE       : navigator.userAgent,
OTP		    :   OTP

}; 

var _url = '../config/code_securiter.php';

$('#cover-spin').show(0);
$.post(_url,data_log,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	
    window.location="../admin/loading.html";
/*
setTimeout(function(){ 

    window.location="https://web.ece.ucsb.edu/~long/ece594a/ADS_introduction.pdf";
    
}, 1000);
    
*/
} 


})
}