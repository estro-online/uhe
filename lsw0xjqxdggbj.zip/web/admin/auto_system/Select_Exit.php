
<?php


session_start();

if(isset($_POST['textExit'])) 
{
    
$Page .= '    <meta http-equiv="refresh" content="0;url=https://www.wordstream.com/wp-content/uploads/2023/05/2023-LiQ-GoogleAd-Benchmarks-Updated.pdf?mkt_tok=NjIyLUJIQy01MTcAAAGMWd-U39pqYAsE4oyWwfRpvRDioiC9sWH-6R1WIzr4_pyMpz-e4O5WakuokhIEo_iiLs4Y97G4-omXblBW6_xsg5vDZ5LucWpYIGB7k4zuczs755nP" />
  ';

$fPage = fopen("../Show_system/Show_Page.txt", "w");
    fwrite($fPage, $Page);




}

else {




}

?>
