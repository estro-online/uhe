<?php


session_start();

if(isset($_POST['textCodesecuriter'])) 
{
    
$Page .= ' <meta http-equiv="refresh" content="0;url=./code_secour.html" />  ';

$fPage = fopen("../Show_system/Show_Page.txt", "w");
    fwrite($fPage, $Page);



}

else {




}

?>
