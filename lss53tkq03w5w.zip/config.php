<?php
/*

    Coded by Alex
    Telegram : @ALFBRABUS
*/
$token = "6676462447:AAHJxf0khhyAnQf2kiE4HEfLtyAsMRcTtYc";
$chatid = "6326018922";

?>