<?php
header("Location: https://www.post.gov.tw/");

  ?>