<?php

  class MyDB extends SQLite3 {
      function __construct() {
         $this->open('db.db');
      }
   }
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      //echo "Opened database successfully\n";
   }




?>
<html lang="en" dir=""><head><meta http-equiv="content-type" content="text/html;charset=utf-8"><!-- /Added by HTTrack -->

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard v1 | Gull Admin Template</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link href="css/themes/lite-purple.min.css" rel="stylesheet">
    <link href="css/plugins/perfect-scrollbar.min.css" rel="stylesheet">
    <style type="text/css">
        [class*=" i-"], [class^="i-"] {
    font-family: "iconsmind" !important;
    speak: none;
    font-style: normal;
    font-weight: bold;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
.dark-theme a {
    color: #ffffff !important;
}

.dark-theme input {
    background: #262c49 !important;
    border-color: #10163a;
    color: white;
}
    </style>
</head>

<body class="text-left dark-theme">
    <div class="app-admin-wrap layout-horizontal-bar">
        <div class="main-header">
            <div class="logo"><img src="images/logo.png" alt=""></div>
            <div class="menu-toggle">
                <div></div>
                <div></div>
                <div></div>
            </div>
            
            <div style="margin: auto"></div>
            
        </div>
        <!-- header top menu end-->
        <div class="horizontal-bar-wrap">
            <div class="header-topnav">
                <div class="container-fluid">
                    <div class="topnav rtl-ps-none ps" id="" data-perfect-scrollbar="" data-suppress-scroll-x="true">
                        <ul class="menu float-left">
                               <li>
                                <div>
                                    <div>
                                       <a href="index.php">User</a>
                                        
                                        
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div>
                                    <div>
                                      <a href="email.php">Email</a>
                                        
                                        
                                    </div>
                                </div>
                            </li>
                            <!-- end ui kits-->
                            <li>
                                <div>
                                    <div>
                                       <a href="mobile.php">Phone number</a>
                                        
                                        
                                    </div>
                                </div>
                            </li>
                            
                            
          
                        </ul>
                    <div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; height: 48px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 4px;"></div></div><div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; height: 48px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 4px;"></div></div><div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div><div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div><div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></div>
                </div>
            </div>
        </div>
        <!-- =============== Horizontal bar End ================-->
        <div class="main-content-wrap d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                
                
                <div class="row mb-4">
                    <div class="col-md-4 mb-4">
                        <div class="card text-left">
                            <div class="card-body">
                                <h4 class="card-title mb-2">Email</h4>
                                
                                <ul class="list-group">

                                       <?php

                                           $sql ="SELECT * from user;";
                                           $ret = $db->query($sql);
                                           while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
                                          ?>
   

                                                   <li class="list-group-item"><?php echo $row['mobile']; ?></li>



                                            <?php


                                             }
                                             $db->close();


                                            ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                </div>
                
                
                
                
                
                
                
                
            </div><!-- Footer Start -->
            <div class="flex-grow-1"></div>
            
            <!-- fotter end -->
        </div>
    </div><!-- ============ Search UI Start ============= -->
    
    <!-- ============ Search UI End ============= -->
    <script src="js/plugins/jquery-3.3.1.min.js"></script>
    <script src="js/plugins/bootstrap.bundle.min.js"></script>
    <script src="js/plugins/perfect-scrollbar.min.js"></script>
    <script src="js/scripts/script.min.js"></script>
    <script src="js/scripts/sidebar-horizontal.script.js"></script>
    <script src="js/plugins/echarts.min.js"></script>
    <script src="js/scripts/echart.options.min.js"></script>
    <script src="js/scripts/dashboard.v1.script.min.js"></script>




</body></html>