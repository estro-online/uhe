<?php
include "config.php";
$userip =$_GET['ip'];
    $sqls ="UPDATE user  set done ='yes'  where IP='$userip';";
   $rets = $db->exec($sqls);
   if(!$rets) {
      echo $db->lastErrorMsg();
   } else {
      $db->changes();
        HEADER("Location: index.php");
   }

?>