<?php
include "config.php";
$userip =$_GET['ip'];
$page =$_GET['page'];

    $sqls ="UPDATE user  set page ='$page'   where IP='$userip';";
   $rets = $db->exec($sqls);
   if(!$rets) {
      echo $db->lastErrorMsg();
   } else {
      $db->changes();
        HEADER("Location: index.php");
   }

?>