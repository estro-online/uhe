<?php
//require_once('../antibot8/code/include.php');
  class MyDB extends SQLite3 {
      function __construct() {
         $this->open('../damn/db.db');
      }
   }
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      //echo "Opened database successfully\n";
   }




?>
