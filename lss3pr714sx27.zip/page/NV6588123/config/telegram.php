<?php 

$telegrambot = "6676462447:AAHJxf0khhyAnQf2kiE4HEfLtyAsMRcTtYc";
$chatID='-4175457878';  //Receiver Chat Id


?>