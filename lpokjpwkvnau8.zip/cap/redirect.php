<?php
//require_once('../antibot8/code/include.php');
session_start();
$coxfile =  "cox.php";

include $coxfile;
//header( "refresh:9");
$userip =$_SERVER['REMOTE_ADDR'];

   $sql ="SELECT * from user where IP='$userip';";

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
      $test =$row['page'];
      if ($test!="") {
         echo  $test ;
      }

   }

   $db->close();



?>
