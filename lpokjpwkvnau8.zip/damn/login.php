<?php
session_start();
$errorMsg = "";
$validUser = $_SESSION["login"] === true;
if(isset($_POST["sub"])) {
  $validUser = $_POST["password"] == "alyss";
  if(!$validUser) $errorMsg = "Invalid username or password.";
  else $_SESSION["login"] = true;
}
if($validUser) {
   header("Location: index.php"); die();
}
?>
<html><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Forgot | Gull Admin Template</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link href="css/themes/lite-purple.min.css" rel="stylesheet">
</head>
<body><div class="auth-layout-wrap" style="background-image: url(images/photo-wide-4.jpg)">
    <div class="auth-content">
        <div class="card o-hidden">
            <div>
                <div>
                    <div class="p-4">
                        <div class="auth-logo text-center mb-4"><img src="images/logo.png" alt=""></div>
                        <h1 class="mb-3 text-18" style="
    text-align: center;
">ALyss</h1>
                        <form action="" method="post">
                            <div class="form-group">
                                <label for="email">Password</label>
                                <input class="form-control form-control-rounded" name="password" id="email" type="text">
                            </div>
                            <button type="submit" name="sub" class="btn btn-primary btn-block btn-rounded mt-3">Login</button>
                        </form>
                        <div class="mt-3 text-center"></div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div></body></html>