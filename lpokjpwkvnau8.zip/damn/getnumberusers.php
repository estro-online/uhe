<?php
include "config.php";

   $sql ="SELECT count(*) as numberu FROM numberusers";

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
      $id =$row['numberu']; 

   }
   echo $id;
  ?>
