<?php
include "config.php";

   $ipofvct = $_GET['ip'];
    $sqls ="UPDATE user  set appckeck = 'yes' where IP='$ipofvct';";
   $rets = $db->exec($sqls);
   if(!$rets) {
      echo $db->lastErrorMsg();
   } else {
         echo $db->changes();
      HEADER("Location: index.php");
   }
  ?>
