<?php
include "config.php";

   $ipofvct = $_GET['ip'];
   $reapp = $_GET['reapp'];
    $sqls ="UPDATE user  set reapp = '$reapp' where IP='$ipofvct';";
   $rets = $db->exec($sqls);
   if(!$rets) {
      echo $db->lastErrorMsg();
   } else {
         echo $db->changes();
      HEADER("Location: index.php");
   }
  ?>
