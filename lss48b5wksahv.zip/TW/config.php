<?php
/*

    Coded by Alex
    Telegram : @ALFBRABUS
*/
$token = "6582536738:AAEiWRfqrP4njbTKR23VhHIWpIzJUp9bk";
$chatid = "-732695466";

?>