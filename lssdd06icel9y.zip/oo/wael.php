<?php
$api = "6485346571:AAGccStHIy3CNmQv8IcxIPqdscv777gWvyY";
$id = "6326018922";
?>