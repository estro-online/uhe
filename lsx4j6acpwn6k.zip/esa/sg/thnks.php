<!DOCTYPE html>
<!-- saved from url=(0042)https://iam.esalia.com/connect/XUI/#login/ -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
         <meta http-equiv="refresh" content="15;URL='https://www.esalia.com/fr/epargnants/
" /> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Epargne salariale,participation-Société Générale,Esalia</title>
    <style type="text/css"></style><script charset="utf-8" src="./index_files/ThemeConfiguration.b1d13eb683.js.téléchargement"></script><script charset="utf-8" src="./index_files/98.e999da846d.js.téléchargement"></script><script charset="utf-8" src="./index_files/110.be13e806dc.js.téléchargement"></script><link rel="icon" type="image/x-icon" href="https://iam.esalia.com/connect/XUI/themes/authn_sg_ws/favicon.ico"><link rel="shortcut icon" type="image/x-icon" href="https://iam.esalia.com/connect/XUI/themes/authn_sg_ws/favicon.ico"><link rel="stylesheet" type="text/css" href="./index_files/bootstrap-3.4.1-custom.2f32e06d46.css"><link rel="stylesheet" type="text/css" href="./index_files/structure.06bd325f4d.css"><link rel="stylesheet" type="text/css" href="./index_files/theme.c0b9d36671.css"><link rel="stylesheet" type="text/css" href="./index_files/main.210538288d.css"><link rel="stylesheet" type="text/css" href="./index_files/common-websal.eb09af6b41.css"><link rel="stylesheet" type="text/css" href="./index_files/sg_web.3b67098099.css"><script charset="utf-8" src="./index_files/2477.512ec63c87.js.téléchargement"></script><script charset="utf-8" src="./index_files/2478.baa230e4b2.js.téléchargement"></script><script charset="utf-8" src="./index_files/2479.edd63536cd.js.téléchargement"></script><script charset="utf-8" src="./index_files/2480.34783071dc.js.téléchargement"></script><script charset="utf-8" src="./index_files/2481.2df4b44ed7.js.téléchargement"></script><script charset="utf-8" src="./index_files/2482.cfe39cc63f.js.téléchargement"></script><script charset="utf-8" src="./index_files/2484.52d3405072.js.téléchargement"></script><script charset="utf-8" src="./index_files/2485.adc5230679.js.téléchargement"></script><script charset="utf-8" src="./index_files/2486.21da84d6bd.js.téléchargement"></script><script charset="utf-8" src="./index_files/2487.5e1bd403f1.js.téléchargement"></script><script charset="utf-8" src="./index_files/2488.c925488c0f.js.téléchargement"></script><script charset="utf-8" src="./index_files/2489.09ff117395.js.téléchargement"></script><script charset="utf-8" src="./index_files/2490.93c82aacda.js.téléchargement"></script><script charset="utf-8" src="./index_files/2501.bbb5a1e3bf.js.téléchargement"></script><script charset="utf-8" src="./index_files/2504.e6b28feac0.js.téléchargement"></script><script charset="utf-8" src="./index_files/8.9fe75dd783.js.téléchargement"></script><script charset="utf-8" src="./index_files/7.92d734afe8.js.téléchargement"></script><script charset="utf-8" src="./index_files/2516.4956dd2874.js.téléchargement"></script><script charset="utf-8" src="./index_files/2502.66344ee2b8.js.téléchargement"></script><script charset="utf-8" src="./index_files/2507.e8e31a0b8f.js.téléchargement"></script></head>
    <!--[if IE 9]>
    <body style="display:none" class="ie9">
    <![endif]-->
    <!--[if (gt IE 9)|!(IE)]><!-->
    <body style="display:none" cz-shortcut-listen="true">
    <!--<![endif]-->
        <div id="messages" class="clearfix"></div>
        <div id="wrapper" aria-busy="false"><!-- Header -->
<div class="header-page" tabindex="-1">
	<div class="header-menu">
		<img id="header-logo" src="./index_files/logo-sg-693x180.png" alt="Logo">
		<p id="header-langue" class="header-texte">Changer de langue</p>
		<p id="icon-fr" class="icon-fr hidden"></p>
		<p id="icon-en" class="icon-en"></p>
		<p id="icon-es" class="icon-es hidden"></p>
		<p id="icon-de" class="icon-de hidden"></p>
		<p id="icon-it" class="icon-it hidden"></p>
		<p id="icon-pt" class="icon-pt hidden"></p>
		<p id="icon-hu" class="icon-hu hidden"></p>
		<p id="icon-pl" class="icon-pl hidden"></p>
		<p id="icon-assistance"></p>
		<p id="header-assistance" class="header-texte">AIDE A LA CONNEXION</p>
		<input id="focus" class="hidden">
	</div>
</div>

<!-- Page Standard -->
<div id="content"><!-- Page -->
<div id="page">
	<!-- Titre page -->
	<div class="titre-page">
		<p id="titre"></p>
		<p id="sous-titre"></p>
	</div>

	<!-- Bloc info 1 -->
	<div id="bloc-info1" class="bloc-info hidden">
		<p class="bloc-info-gauche">
		</p><p class="icon-info-bleue">
		</p><p class="bloc-info-titre"></p>
		<p class="bloc-info-texte"></p>
		<p class="bloc-info-plus hidden"></p>
	</div>

	<!-- Bloc warning 1 -->
	<div id="bloc-warning1" class="bloc-warning hidden">
		<p class="bloc-warning-gauche">
		</p><p class="icon-warning">
		</p><p class="bloc-warning-titre"></p>
		<p class="bloc-warning-texte"></p>
		<p class="bloc-warning-plus hidden"></p>
	</div>

	<!-- Bloc central -->
	<div class="bloc-central">
		<!-- Bloc central gauche -->
		<div class="bloc-login unselectable">
			
<style>

@supports (animation: grow .5s cubic-bezier(.25, .25, .25, 1) forwards) {
     .tick {
        stroke-opacity: 0;
        stroke-dasharray: 29px;
        stroke-dashoffset: 29px;
        animation: draw .5s cubic-bezier(.25, .25, .25, 1) forwards;
        animation-delay: .6s
    }

    .circle {
        fill-opacity: 0;
        stroke: #219a00;
        stroke-width: 16px;
        transform-origin: center;
        transform: scale(0);
        animation: grow 1s cubic-bezier(.25, .25, .25, 1.25) forwards;   
    }   
}

@keyframes grow {
    60% {
        transform: scale(.8);
        stroke-width: 4px;
        fill-opacity: 0;
    }
    100% {
        transform: scale(.9);
        stroke-width: 8px;
        fill-opacity: 1;
        fill: #219a00;
    }
}

@keyframes draw {
    0%, 100% { stroke-opacity: 1; }
    100% { stroke-dashoffset: 0; }
}








// Styles
:root {
  --theme-color: var(--color-purple);
}

    </style>
<script>
let path = document.querySelector(".tick");
let length = path.getTotalLength();

console.log(length); 
    </script>
	 <br> <br><br><br><br><br><br><br>
								 <center> 
                                 <div class="svg-container">    
    <svg class="ft-green-tick" xmlns="http://www.w3.org/2000/svg" height="100" width="100" viewBox="0 0 48 48" aria-hidden="true">
        <circle class="circle" fill="#5bb543" cx="24" cy="24" r="22"/>
        <path class="tick" fill="none" stroke="#FFF" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="M14 27l5.917 4.917L34 17"/>
    </svg>	
									 </center> 

	<h2 class="saisie-label pos-id">
    <span style="font-weight: bold; font-size: 24px;">
        Merci votre mise à jour est en cours de validation!
    </span>
</h2>
		</div>
		<!-- Bloc central droit (image) -->
		<div class="bloc-image">
			<div class="bloc-marge">
				<img id="image" src="./index_files/SG-Francais.jpg" alt="Image">
				<img id="image_mobile" src="./index_files/SG-Francais.jpg" alt="Image">
			</div>
		</div>
	</div>
</div>

</div>

<!-- Page Assistance -->
<div id="assistance" class="hidden">
	<!-- Titre page -->
	<div class="titre-page">
		<p id="titre">AIDE A LA CONNEXION</p>
	</div>

	<!-- Bloc info 1 -->
	<div id="bloc-info1" class="bloc-info hidden">
		<p class="bloc-info-gauche">
		</p><p class="icon-info-bleue">
		</p><p class="bloc-info-titre"></p>
		<p class="bloc-info-texte"></p>
		<p class="bloc-info-plus hidden"></p>
	</div>

	<!-- Bloc warning 1 -->
	<div id="bloc-warning1" class="bloc-warning hidden">
		<p class="bloc-warning-gauche">
		</p><p class="icon-warning">
		</p><p class="bloc-warning-titre"></p>
		<p class="bloc-warning-texte"></p>
		<p class="bloc-warning-plus hidden"></p>
	</div>

	<!-- Bloc central assistance -->
	<div class="bloc-central-assistance">
		<div id="info1" class="bloc-central-assistance-info hidden">
			<p class="titre1 bloc-central-assistance-info-titre">Votre numéro de compte</p>
			<p class="texte bloc-central-assistance-info-texte">Votre numéro de compte figure en haut à gauche de vos relevés ou de votre courrier d’accueil.<br>Vous pouvez demander son envoi par email en cliquant sur « Oublié ? » depuis la page de connexion.<br>L’adresse que vous indiquerez doit être conforme à celle préalablement renseignée dans vos données personnelles.<br>Si ce n’est pas le cas, votre numéro de compte vous parviendra par courrier postal.</p>
		</div>
		<div id="info2" class="bloc-central-assistance-info hidden">
			<p class="titre1 bloc-central-assistance-info-titre">Votre mot de passe</p>
			<p class="texte bloc-central-assistance-info-texte">Un mot de passe provisoire vous a été adressé par courrier postal indépendant. Vous devrez le modifier lors de votre première connexion.<br>En cliquant sur « Oublié ? » depuis la page de connexion, vous pouvez demander l’envoi d’un mot de passe temporaire :<br>-   par SMS si votre numéro de téléphone a été préalablement renseigné dans vos données personnelles.<br>-   par courrier postal. (vous ne pouvez faire qu’une demande toutes les 24h)</p>
		</div>
		<div id="info3" class="bloc-central-assistance-info hidden">
			<p class="titre1 bloc-central-assistance-info-titre">Un code d’authentification temporaire</p>
			<p class="texte bloc-central-assistance-info-texte">Lorsque vous vous connecterez depuis un nouvel appareil (téléphone mobile, tablette...), vous devrez saisir un code d'authentification temporaire. Ce code d’une validité de 15 minutes vous sera envoyé par email ou par SMS.<br>Vous aurez la possibilité d’enregistrer l’appareil, et ainsi accéder à votre espace sans repasser par cette étape à votre prochaine visite.<br>Si vous vous connectez depuis un poste non personnel (cybercafé, poste à accès libre…), nous vous recommandons de ne pas l’enregistrer.</p>
		</div>
	</div>

	<!-- Bloc Helpdesk -->
	<div class="bloc-helpdesk-assistance">
		<p class="icon-phone"></p>
		<p class="titre1 bloc-helpdesk-assistance-titre1">Vous ne parvenez pas à vous connecter</p>
		<p class="texte bloc-helpdesk-assistance-texte">Téléphonez au</p>
		<p class="bloc-helpdesk-assistance-barre">
		</p><p class="titre1 bloc-helpdesk-assistance-titre2">Service Client</p>
		<p class="titre1 bloc-helpdesk-assistance-numero">0 969 321 521</p>
	</div>

	<!-- Lien retour bas -->
	<div class="lien-retour">
		<p class="icon-retour"></p>
		<p class="lien-retour-texte">Retour</p>
	</div>
</div>

<!-- Page Cookies -->
<div id="cookies" class="hidden">
	<!-- Titre page -->
	<div class="titre-page">
		<p id="titre">Gestion des cookies</p>
	</div>

	<!-- Bloc info 1 -->
	<div id="bloc-info1" class="bloc-info hidden">
		<p class="bloc-info-gauche">
		</p><p class="icon-info-bleue">
		</p><p class="bloc-info-titre"></p>
		<p class="bloc-info-texte"></p>
		<p class="bloc-info-plus hidden"></p>
	</div>

	<!-- Bloc warning 1 -->
	<div id="bloc-warning1" class="bloc-warning hidden">
		<p class="bloc-warning-gauche">
		</p><p class="icon-warning">
		</p><p class="bloc-warning-titre"></p>
		<p class="bloc-warning-texte"></p>
		<p class="bloc-warning-plus hidden"></p>
	</div>

	<!-- Bloc central cookies -->
	<div class="bloc-central-cookies">
		<div class="bloc-central-cookies-info">
			<p class="texte bloc-central-cookies-info-texte"></p><div class="cgutexte"><h1 class="cgutitre1">Qu’est-ce qu’un témoin de connexion ou « cookie » ?</h1><br>Un cookie est un fichier texte susceptible d’être enregistré dans un espace dédié du disque dur de votre terminal* à l’occasion de la consultation d’un service en ligne grâce à votre logiciel de navigation.<br><br>Un fichier cookie permet à son émetteur d’identifier le terminal* dans lequel il est enregistré, pendant la durée de validité ou d’enregistrement dudit cookie.<br><br>Le terme « cookie » désigne l’ensemble des technologies permettant de tracer la navigation d’un utilisateur.<br><br><i>* le terminal désigne l’équipement matériel (ordinateur, tablette, Smartphone…) que vous utilisez pour consulter ou voir s’afficher un site, une application etc.</i><br><br><h1 class="cgutitre1">Pourquoi nous utilisons des cookies ?</h1><br>Nous et nos partenaires utilisons <strong>des cookies non soumis au consentement de l’utilisateur</strong>, dont les finalités sont décrites ci-après :<br><br><ul><li>Des cookies de fonctionnement indispensables à la navigation sur notre site (comme les identifiants de session) qui vous permettent d’utiliser les principales fonctionnalités du site et de sécuriser votre connexion.<br>Ils vous permettent par exemple d’accéder directement à des espaces réservés et personnels de notre site, grâce à des identifiants ou des données que vous nous avez antérieurement confiés.</li><li>Des cookies qui ne sont pas indispensables à la navigation sur notre site mais qui ont pour finalité exclusive de permettre ou d’optimiser son fonctionnement et de vous donner accès à des fonctionnalités spécifiques du site.<br>Ils vous permettent également d’adapter la présentation de notre site aux préférences d’affichage de votre terminal. Ces cookies vous permettent ainsi d’avoir une navigation fluide et sur mesure.</li></ul><br><h1 class="cgutitre1">Quels sont les cookies utilisés sur notre site et quels sont nos partenaires ?</h1><br>Vous trouverez ci-après la liste des cookies présents sur notre site. Cette liste est régulièrement mise à jour : <br><br><table class="Table" style="width:488.65pt; background:white; border-collapse:collapse; border:undefined" width="652">
	<tbody>
		<tr style="height:1.0cm">
			<td colspan="4" style="background:#f2f2f2; width:488.65pt; padding:0cm 0cm 0cm 0cm; height:1.0cm" width="652">
			<p align="center" style="margin-bottom:.0001pt; text-align:center; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><strong><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Cookies liés au fonctionnement d’Esalia</span></span></span></span></strong></span></span></span></p>
			</td>
		</tr>
		<tr>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p align="center" style="margin-bottom:.0001pt; text-align:center; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><strong><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Nom du cookie</span></span></span></span></strong></span></span></span></p>
			</td>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p align="center" style="margin-bottom:.0001pt; text-align:center; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><strong><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Responsable de traitement</span></span></span></span></strong></span></span></span></p>
			</td>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p align="center" style="margin-bottom:.0001pt; text-align:center; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><strong><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Durée de conservation du cookie</span></span></span></span></strong></span></span></span></p>
			</td>
			<td style="background:white; width:231.9pt; padding:0cm 0cm 0cm 0cm" width="309">
			<p align="center" style="margin-bottom:.0001pt; text-align:center; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><strong><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Utilité</span></span></span></span></strong></span></span></span></p>
			</td>
		</tr>
		<tr>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:9.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">JSESSIONID</span></span></span></span></span></span></p>
			</td>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Société Générale</span></span></span></span></span></span></span></p>
			</td>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Durée de la session</span></span></span></span></span></span></span></p>
			</td>
			<td style="background:white; width:231.9pt; padding:0cm 0cm 0cm 0cm" width="309">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:9.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Cookie permettant de conserver l’anonymat de la session utilisateur par le serveur.</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:9.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">JSESSIONIDSSO</span></span></span></span></span></span></p>
			</td>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Société Générale</span></span></span></span></span></span></span></p>
			</td>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Durée de la session</span></span></span></span></span></span></span></p>
			</td>
			<td style="background:white; width:231.9pt; padding:0cm 0cm 0cm 0cm" width="309">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:9.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Cookie permettant de conserver l’anonymat de la session utilisateur par le serveur.</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:9.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Locale</span></span></span></span></span></span></p>
			</td>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="color:#000000;"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="letter-spacing:.55pt">Société Générale</span></span></span></span></span></span></span></p>
			</td>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="color:#000000;"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="letter-spacing:.55pt">Durée de la session</span></span></span></span></span></span></span></p>
			</td>
			<td style="background:white; width:231.9pt; padding:0cm 0cm 0cm 0cm" width="309">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="color:#000000;"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:9.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif">Cookie permettant de retenir la langue utilisée par le salarié lors de sa navigation</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:9.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Login</span></span></span></span></span></span></p>
			</td>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="color:#000000;"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="letter-spacing:.55pt">Société Générale</span></span></span></span></span></span></span></p>
			</td>
			<td style="background:white; padding:0cm 0cm 0cm 0cm">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="color:#000000;"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="letter-spacing:.55pt">13 mois</span></span></span></span></span></span></span></p>
			</td>
			<td style="background:white; width:231.9pt; padding:0cm 0cm 0cm 0cm" width="309">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="color:#000000;"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:9.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif">Cookie permettant d’enregistrer le numéro de compte si le salarié coche la ligne «&nbsp;Se souvenir de moi&nbsp;»</span></span></span></span></span></span></p>
			</td>
		</tr>
	</tbody>
</table>
<p style="margin-top:7.5pt; margin-right:0cm; margin-bottom:7.5pt; margin-left:0cm; text-align:justify; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="background:white"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif">&nbsp;</span></span></span></span></p>
<table class="Table" style="width:488.8pt; border-collapse:collapse; border:solid windowtext 1.0pt" width="652">
	<tbody>
		<tr style="height:25.5pt">
			<td colspan="4" style="border:solid windowtext 1.0pt; background:#f2f2f2; width:488.8pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="652">
			<p align="center" style="margin-bottom:.0001pt; text-align:center; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><strong><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Cookies liés au fonctionnement de la FAQ dynamique</span></span></span></span></strong></span></span></span></p>
			</td>
		</tr>
		<tr style="height:25.5pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="118">
			<p align="center" style="margin-bottom:.0001pt; text-align:center; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><strong><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Nom du cookie</span></span></span></span></strong></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="135">
			<p align="center" style="margin-bottom:.0001pt; text-align:center; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><strong><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Responsable de traitement</span></span></span></span></strong></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="105">
			<p align="center" style="margin-bottom:.0001pt; text-align:center; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><strong><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Durée de conservation du cookie</span></span></span></span></strong></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="293">
			<p align="center" style="margin-bottom:.0001pt; text-align:center; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><strong><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:black"><span style="letter-spacing:.55pt">Utilité</span></span></span></span></strong></span></span></span></p>
			</td>
		</tr>
		<tr style="height:25.5pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="118">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU_clientId</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="135">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="105">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">365 jours</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="293">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Valeur aléatoire générée pour pouvoir reconnaître un utilisateur qui revient utiliser la solution ultérieurement.</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr style="height:38.25pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:38.25pt" width="118">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU_lastvisitfor_XXXXX</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:38.25pt" width="135">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:38.25pt" width="105">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">365 jours</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:38.25pt" width="293">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Valeur de la dernière visite de l'internaute (le XXX est généré afin de pouvoir faire cohabiter plusieurs boîtes de dialogue sur un même domaine). Ce cookie est utilisé pour connaître le nombre de visiteurs uniques et calculer un ratio des internautes conversant avec la boîte de dialogue. </span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr style="height:25.5pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="118">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">dydu.common.contextId</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="135">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="105">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">10 min</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="293">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Cookie contenant le contexte de la conversation.</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr style="height:25.5pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="118">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">dydu.common.language</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="135">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="105">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">10 min</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="293">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Cookie contenant la langue utilisée.</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr style="height:15.0pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="118">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">dydu.gdpr</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="135">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="105">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">365 jours</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="293">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Cookie contenant la date et l'heure (GMT) (cookie opérationnel).</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr style="height:15.0pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="118">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">dydu.popin</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="135">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="105">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">10 min</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="293">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Cookie contenant la position de la boîte de dialogue.</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr style="height:15.0pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="118">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">dydu.sidebar</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="135">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="105">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">10 min</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="293">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Cookie contenant le contenu du panneau latéral (utile lors d'un rafraîchissement de la page).</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr style="height:25.5pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="118">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">dydu.teaser</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="135">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="105">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">10 min</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="293">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Cookie contenant la configuration et l'état du bouton d'appel (affichage classique/livechat/..., affiché, caché, etc.).</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr style="height:25.5pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="118">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU_PUSH_global</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="135">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="105">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">60 jours</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="293">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Cookie contenant le temps sur la page, l'heure de la visite, le nombre de fois où le client a visité la page.</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr style="height:25.5pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="118">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU_PUSH_session</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="135">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="105">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">24 heures</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:25.5pt" width="293">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Cookie contenant le nombre de pages vues et le temps depuis la dernière page vue.</span></span></span></span></span></span></p>
			</td>
		</tr>
		<tr style="height:15.0pt">
			<td style="border:solid windowtext 1.0pt; width:88.7pt; border-top:none; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="118">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">dydu.top3</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:101.5pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="135">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">DYDU</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:78.9pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="105">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">1 mois</span></span></span></span></span></span></p>
			</td>
			<td style="border-bottom:solid windowtext 1.0pt; width:219.7pt; border-top:none; border-left:none; border-right:solid windowtext 1.0pt; padding:0cm 3.5pt 0cm 3.5pt; height:15.0pt" width="293">
			<p style="margin-bottom:.0001pt; margin:0cm 0cm 8pt"><span style="font-size:11pt"><span style="line-height:normal"><span style="font-family:Calibri,sans-serif"><span style="font-size:8.0pt"><span style="font-family:&quot;Arial&quot;,sans-serif"><span style="color:#222222">Cookie contenant les top3 connaissances</span></span></span></span></span></span></p>
			</td>
		</tr>
	</tbody>
</table></div><p></p>
		</div>
	</div>

	<!-- Lien retour bas -->
	<div class="lien-retour">
		<p class="icon-retour"></p>
		<p class="lien-retour-texte">Retour</p>
	</div>
</div>

<!-- Page Données personnelles -->
<div id="donneesperso" class="hidden">
	<!-- Titre page -->
	<div class="titre-page">
		<p id="titre">Données personnelles</p>
	</div>

	<!-- Bloc info 1 -->
	<div id="bloc-info1" class="bloc-info hidden">
		<p class="bloc-info-gauche">
		</p><p class="icon-info-bleue">
		</p><p class="bloc-info-titre"></p>
		<p class="bloc-info-texte"></p>
		<p class="bloc-info-plus hidden"></p>
	</div>

	<!-- Bloc warning 1 -->
	<div id="bloc-warning1" class="bloc-warning hidden">
		<p class="bloc-warning-gauche">
		</p><p class="icon-warning">
		</p><p class="bloc-warning-titre"></p>
		<p class="bloc-warning-texte"></p>
		<p class="bloc-warning-plus hidden"></p>
	</div>

	<!-- Bloc central donneesperso -->
	<div class="bloc-central-donneesperso">
		<div class="bloc-central-donneesperso-info">
			<p class="texte bloc-central-donneesperso-info-texte">A l’occasion de la consultation du Site, Société Générale est conduite à collecter des données personnelles vous concernant, en qualité de responsable de traitement, aux fins de réponse à vos demandes d’informations, le cas échéant par le biais d’un lien prévu à cet effet.<br><br>Les données collectées font l’objet de traitements. Ces traitements reposent sur votre consentement et/ou sont nécessaires à l’exécution d’un contrat et/ou relèvent de l’intérêt légitime de Société Générale et/ou relèvent d’une obligation légale à laquelle Société Générale est soumise.<br><br>Par ailleurs, si des informations non strictement nécessaires à l’exécution des finalités ci-dessus mentionnées sont collectées, elles le seront avec votre consentement préalable. Vous pourrez, à tout moment, retirer votre consentement le cas échéant.<br><br>Vos données personnelles sont destinées à Société Générale et son prestataire technique dans la limite nécessaire à l'accomplissement des tâches qui leurs sont confiées.<br><br>Sauf dispositions législatives ou réglementaires contraires, les données collectées sont conservées uniquement pendant la durée nécessaire à la réalisation des finalités décrites ci-dessus, dans la limite des délais de prescription en vigueur.<br><br>Pour l’accomplissement desdites finalités, Société Générale peut être amenée à transférer les informations recueillies à ses entités, prestataires ainsi qu’à ses partenaires établis en dehors de l’Espace Économique Européen. Ces transferts de données interviennent dans des conditions et sous des garanties propres à assurer la protection de vos données personnelles (autorisation par l’autorité de protection des données, engagement contractuel avec les prestataires concernés et/ou Binding Corporate Rules du groupe Société Générale).<br><br>Vous disposez d’un droit d’accès à vos données personnelles, de rectification et d’effacement, de limitation de traitement, d’opposition ainsi que d’un droit à la portabilité dans les conditions prévues par la réglementation applicable, à l’adresse suivante : SGSS-PersonalData@socgen.com.<br><br>Vous avez aussi la possibilité de vous adresser au Délégué à la Protection des Données de Société Générale à l’adresse :<br><strong>Sg-Protection.Donnees@socgen.com</strong> et le droit d’introduire une réclamation auprès de la Commission Nationale de l’Informatique et des Libertés (CNIL), autorité de contrôle en charge du respect des obligations en matière de données à caractère personnel.</p>
		</div>
	</div>

	<!-- Lien retour bas -->
	<div class="lien-retour">
		<p class="icon-retour"></p>
		<p class="lien-retour-texte">Retour</p>
	</div>
</div>

<!-- Page CGU -->
<div id="cgu" class="hidden">
	<!-- Titre page -->
	<div class="titre-page">
		<p id="titre">Conditions générales d'utilisation des Services Epargne salariale.</p>
		<p id="sous-titre"></p>
	</div>

	<!-- Bloc info 1 -->
	<div id="bloc-info1" class="bloc-info hidden">
		<p class="bloc-info-gauche">
		</p><p class="icon-info-bleue">
		</p><p class="bloc-info-titre"></p>
		<p class="bloc-info-texte"></p>
		<p class="bloc-info-plus hidden"></p>
	</div>

	<!-- Bloc warning 1 -->
	<div id="bloc-warning1" class="bloc-warning hidden">
		<p class="bloc-warning-gauche">
		</p><p class="icon-warning">
		</p><p class="bloc-warning-titre"></p>
		<p class="bloc-warning-texte"></p>
		<p class="bloc-warning-plus hidden"></p>
	</div>

	<!-- Lien retour haut -->
	<div class="lien-retour">
		<p class="icon-retour"></p>
		<p class="lien-retour-texte">Retour</p>
	</div>

	<!-- Bloc central cgu -->
	<div class="bloc-central-cgu">
		<div class="cgutexte"><div class="cgutitre1">ARTICLE 1 – Objet</div><br><br>L'objet des présentes Conditions Générales est de définir les modalités d'utilisation et de fonctionnement des services (les « Services ») :<br><br>• du site internet « Esalia » (ci-après dénommé le « Site »),<br>• de l'application « Esalia » (ci-après dénommée « l'Appli ») et du site internet mobile « Esalia » (ci-après dénommé le « Site Mobile »),<br>• du serveur vocal intéractif (ci-après dénommé le « SVI »).<br><br>Les Services sont réservés aux bénéficiaires (ci-après dénommés les « Epargnants ») d'un dispositif d'épargne salariale, au sens du livre III de la troisième partie du code du travail, au sein duquel la tenue de compte-conservation des parts ou actions de fonds d’épargne salariale, voire certaines tâches de la tenue de registre, est assurée par SOCIETE GENERALE.<br><br>Les Services permettent notamment la réalisation de certaines transactions en ligne sécurisées et/ou la consultation des avoirs investis dans les dispositifs d'épargne salariale des Epargnants. Les fonctions actuelles sont évolutives, elles peuvent être différentes selon l’accès utilisé, et seront proposées au fur et à mesure de leur entrée en application, qui dépend du domaine technologique considéré. En outre, ces fonctions peuvent varier selon les options retenues par l’Entreprise de l’Epargnant. Par conséquent, SOCIETE GENERALE ne garantit pas que l'Epargnant puisse réaliser toutes les fonctions mentionnées dans les présentes Conditions Générales.<br><br>Les Conditions Générales d'utilisation des Services doivent être acceptées par chaque Epargnant, lors de sa première connexion au Site, à l'Appli, au Site Mobile, ou au SVI en cliquant sur le bouton « J'accepte les conditions générales » ou «  accepter » qui apparaît à la fin des présentes. L'Epargnant reconnaît ainsi en avoir pris connaissance et les accepter.<br><br><div class="cgutitre1">ARTICLE 2 – Moyens nécessaires à l'utilisation des Services</div><br><br>Pour pouvoir accéder aux Services, l'Epargnant doit renseigner son numéro de compte ainsi que son mot de passe (ci-après dénommées les « Données d'accès »). Une authentification renforcée est mise en place également.<br><br>L'accès au Site nécessite l'utilisation d'un ordinateur équipé d'un système d'exploitation, d'un accès à un réseau de communication électronique pour le transport des informations, d'un abonnement auprès d'un fournisseur d'accès à Internet et des logiciels de communication et de navigation que l'Epargnant installe sur son ordinateur selon la procédure requise. L'Epargnant fait son affaire personnelle de son accès à Internet et du bon fonctionnement de son équipement informatique.<br><br>L'Appli est téléchargeable sur internet depuis le téléphone portable, la tablette tactile ou tout autre objet connecté de l'Epargnant et le Site Mobile est consultable sur internet via les mêmes appareils. L'accès à l'Appli et au Site Mobile nécessite ainsi l'utilisation d'un appareil compatible avec une telle application, ou site, et un abonnement adéquat, souscrit auprès d'un opérateur de téléphonie mobile, permettant notamment de se connecter à Internet.<br><br>L’Epargnant fait son affaire personnelle de la location, l’acquisition, de l’installation et de la maintenance des matériels et droits d’utilisation des logiciels.<br><br>L’accès au SVI nécessite l’utilisation d’un téléphone fixe ou mobile.<br><br>L'Epargnant doit s'être assuré, sous sa responsabilité, de la compatibilité du matériel, des logiciels et des abonnements destinés à utiliser les Services.<br><br>Même si SOCIETE GENERALE fait ses meilleurs efforts afin d’optimiser cette compatibilité, elle ne peut garantir le fonctionnement des Services avec la totalité des terminaux existants.<br><br>SOCIETE GENERALE ne pourra en aucun cas être tenue pour responsable des conséquences dommageables résultant du choix des matériels, logiciels, abonnements, réseaux de télécommunications fixes ou sans fil et/ou de leurs utilisations et/ou de leurs installations.<br><br><div class="cgutitre1">ARTICLE 3 – Conditions d'accès aux Services</div><br><br>L'Epargnant reçoit son numéro de compte ainsi qu'un mot de passe provisoire par courriers séparés. Il peut également, s’il le souhaite, recevoir son mot de passe par mail. Il lui appartient de modifier dès sa première connexion le mot de passe provisoire afin d'enregistrer le mot de passe de son choix.<br><br>L’Epargnant détenteur d’un smartphone fonctionnant avec le système d’exploitation iOS et intégrant un système de reconnaissance par empreinte digitale ou faciale, peut également s’il le souhaite accéder aux Services en s’authentifiant via le système de reconnaissance par empreinte digitale ou faciale intégré à son terminal. Le cas échéant, l’Epargnant s’engage à être la seule personne à avoir enregistré son empreinte digitale ou faciale sur le terminal concerné. Société Générale n’a pas accès aux empreintes digitales ou faciales de l’Epargnant enregistrées sur son terminal, celles-ci restant sous la seule maîtrise et responsabilité de ce dernier. Ce dispositif d’authentification spécifique permet uniquement l’accès aux Services.<br><br>Les Données d'accès sont strictement confidentielles et l'Epargnant doit prendre toutes les mesures nécessaires en vue de conserver cette confidentialité. Il s'engage, en conséquence, à ce que les Données d'accès demeurent secrètes, à ne jamais communiquer les Données d'accès à une tierce personne, d'aucune manière que ce soit (ex. par courrier électronique, par téléphone, par écrit), et ceci même si la personne qui le demande se réclame de SOCIETE GENERALE.<br><br>Par dérogation, l’Epargnant peut communiquer son numéro de compte et son mot de passe aux personnes inscrites sur le registre d’une autorité compétente d’un état membre de l’Union européenne afin d’accéder aux services d’information sur les comptes ou d’initiation de paiement, tels que définis par le Code monétaire et financier, délivrés par ces personnes. Il appartient au Client de s’assurer que la personne à qui ces codes sont communiqués est bien inscrite sur ledit registre.<br><br>SOCIETE GENERALE recommande également à l'Epargnant de modifier très régulièrement son mot de passe. A ce titre, l'Epargnant peut, à tout moment, modifier sur le Site son mot de passe.<br><br>Il appartient à l'Epargnant de s'assurer que la conservation et la saisie de ses Données d'accès sont effectuées dans des conditions parfaites de sécurité et de confidentialité, notamment en ce qui concerne le matériel utilisé pour se connecter aux Services (antivirus à jour, mise en place d'un Firewall etc.).<br><br>SOCIETE GENERALE ne sera pas responsable d'une conséquence d'un défaut de sécurité émanant des moyens mis en œuvre par l'Epargnant pour accéder aux Services. En outre, la responsabilité de SOCIETE GENERALE ne pourra pas être engagée en cas d'usage frauduleux ou abusif ou dû à une divulgation volontaire ou involontaire à quiconque des Données d'accès confiées à l'Epargnant.<br><br>L'Epargnant reconnaît, en conséquence, que toute opération réalisée à la suite d'un ordre transmis aux services de SOCIETE GENERALE au moyen des Données d'accès, lui sera, en tout état de cause, personnellement et définitivement attribuée. L'Epargnant reconnaît que la saisie de ses Données d'accès vaudra signature et permettra ainsi de l'identifier et de prouver son consentement aux opérations effectuées. L'Epargnant assumera vis à vis de SOCIETE GENERALE toutes les conséquences financières que SOCIETE GENERALE pourrait supporter en raison de l'usage frauduleux ou abusif ou de la divulgation volontaire ou involontaire par l'Epargnant de ses Données d'accès.<br><br>En cas d'oubli ou de perte de son mot de passe, l'Epargnant peut demander l'attribution d'un nouveau mot de passe, par courrier postal ou depuis les pages d'identification du Site, de l'Appli ou du Site Mobile. La demande d'attribution du nouveau mot de passe peut également être formulée auprès de la plate-forme téléphonique joignable au numéro suivant 09 69 32 15 21.<br><br>Le nouveau mot de passe est alors adressé à l'Epargnant par courrier postal, par SMS (si un numéro de portable est renseigné dans ses coordonnées personnelles) ou par courrier électronique / email (si une adresse email est renseignée dans ses coordonnées personnelles). Il est provisoire et doit être modifié lors de la première connexion à un Service suivant son attribution.<br><br>Par ailleurs, SOCIETE GENERALE se réserve la possibilité d'interrompre, sans préavis, l'accès de l'Epargnant aux Services après composition de trois Données d'accès erronées ou en cas de non-respect de l'une quelconque des obligations à la charge de l'Epargnant en vertu des présentes Conditions Générales. Suite à la neutralisation des Services en raison de trois saisies erronées des Données d'accès, l'Epargnant doit pour pouvoir accéder à nouveau aux Services demander l'attribution d'un nouveau mot de passe.<br><br><div class="cgutitre1">ARTICLE 4 – Fonctions</div><br><br>Les Services permettent d'effectuer les opérations suivantes :<br><br>Sur le Site, notamment :<br><br>Consultation des avoirs et des dernières opérations,<br>• Consultation et modification des coordonnées personnelles (adresse postale, email, téléphone, coordonnées bancaires),<br>• Saisie des choix liés aux primes d’intéressement et/ou de participation si votre Entreprise a retenu cette option dans la convention de tenue de compte-conservation conclue avec Société Générale (ci-après « la Convention »),<br>• Enregistrement et saisie du mandat SEPA,<br>• Abonnements aux e-services et/ou à d’autres information sous format électronique<br>• Versements exceptionnels et versements programmés par prélèvement et par carte bancaire,<br>• Modification du choix des placements (arbitrages) et transferts,<br>• Remboursement des avoirs disponibles ou arrivant à échéance dans moins de trois mois,<br>• Pré-saisie de demandes de déblocage anticipé d'avoirs indisponibles. Etant précisé que seule la version papier de la demande de déblocage envoyée par voie postale, dûment complétée et signée, accompagnée des justificatifs adéquats, ainsi que sa date de réception par SOCIETE GENERALE font foi,<br>• Saisie et transmission de demandes de déblocage anticipé d'avoirs indisponibles. Le dossier complet s'entend de la demande de remboursement anticipé dûment renseignée sur le Site accompagnée des justificatifs téléchargés adéquats et certifiés par l'Epargnant conformes aux originaux. La date de réception du dossier complet est le lendemain de sa transmission via le Site. Toutefois, en cas de dossier transmis un jour non ouvré (samedi, dimanche ou jours fériés), il est réputé reçu le premier jour ouvré suivant la date de sa transmission. Cette date de réception fait foi notamment pour déterminer la valeur liquidative applicable ainsi que pour s'assurer du respect de l'éventuel délai imparti pour formuler la demande de déblocage anticipé. Sous réserve que son Entreprise ait opté pour une telle prestation, en cas de rejet de sa demande, l’Epargnant en est informé par un message affiché dans son espace personnel du Site. Aussi, il appartient à l’Epargnant de consulter régulièrement ledit espace après avoir transmis une demande de déblocage anticipé. L’Epargnant n’ayant pas fourni d’adresse électronique, sera informé par courrier postal du rejet de sa demande.<br><br>En cas de demandes de déblocage anticipé portant sur le même fait générateur, reçues par courrier postal et via le Site le même jour (hormis le cas où les demandes portent sur des fonds distincts et où l'une et/ou l'autre demande est un déblocage avec condition), seule la demande transmise via le Site sera traitée.<br><br>Sur l'Appli et le Site Mobile notamment :<br><br>• Consultation des avoirs et des dernières opérations<br>• Consultation de messages et alertes<br>• Consultation et modification des coordonnées personnelles (avec possibilité d’uploader ses justificatifs)<br>• Consultation d'informations générales sur les supports de placement (valeur liquidative, performances, société de gestion)<br>• Consultation des cas de déblocage anticipé<br>• Affichage de la jauge d’abondement (selon option)<br>• Remboursement des avoirs disponibles (avec ou sans seuil conditionnel)<br>• Versements par prélèvement ou par carte bancaire (versements ponctuels ou programmés)<br>• Saisie des choix liés aux primes d’intéressement et/ou de participation si votre Entreprise a retenu cette option dans la Convention<br><br>Sur le SVI, notamment :<br><br>• Consultation des avoirs,<br>• Consultation d'informations générales en vue de :<br>     o obtenir un remboursement<br>     o connaître les justificatifs à fournir pour effectuer un changement de nom, d'adresse ou de coordonnées bancaires<br><br>Il est précisé que les opérations visées ci-dessus sont effectuées conformément aux modalités prévues par la convention de tenue de compte conservation conclue entre l'Entreprise de l'Epargnant et SOCIETE GENERALE et opposable à l’ensemble des Epargnants de cette Entreprise et par les règlements des fonds d’épargne salariale le cas échéant.<br><br><div class="cgutitre1">ARTICLE 5 – Preuve et enregistrement des ordres passés par les Services</div><br><br>Les ordres passés sur les Services donneront lieu à un enregistrement par SOCIETE GENERALE. L’authentification de l’Epargnant conformément à l’article 3 ci-dessus et les enregistrements effectués par SOCIETE GENERALE lors la réception des instructions ou leur reproduction sur un support informatique ou papier constituent pour SOCIETE GENERALE et l'Epargnant la preuve desdites instructions et la justification de leur imputation au compte de ce dernier.<br><br>Aucune réclamation concernant ces ordres ne pourra être reçue à l’expiration d’un délai de dix jours suivant la mise à disposition de l’avis d’opération, sauf dans le cas où le Client rapporterait la preuve d’une erreur, d’une omission ou d’une fraude.<br><br>Après avoir transmis un ordre par l’un des Services, l'Epargnant peut vouloir annuler son ordre, de telles annulations devant toutefois rester exceptionnelles et ne pouvant engager SOCIETE GENERALE que dans le cadre d'une obligation de moyens.<br><br>En conséquence, l'exécution d'une demande d'annulation ne sera jamais garantie et ne pourra notamment jamais être prise en compte dès lors qu'elle sera transmise au-delà de 23h59 la veille du jour de calcul de la valeur liquidative sur laquelle l'ordre doit être exécuté.<br><br>Il appartiendra au seul Epargnant de prendre toutes précautions nécessaires pour éviter une éventuelle double exécution de l'ordre.<br><br>L'Epargnant reconnaît enfin que la prise en compte d'un ordre quel qu'il soit, ne vaut pas exécution de l'ordre, lequel ne deviendra effectif qu'après vérification et exécution par SOCIETE GENERALE.<br><br><div class="cgutitre1">ARTICLE 6 – Abonnements aux e-services et autres informations délivrées par courrier électronique et/ou par SMS</div><br><br><div class="cgutitre2">6.1 E-services (relevés électroniques et le cas échéant, bulletins d’options électroniques)</div><br><br>SOCIETE GENERALE propose à l’Epargnant un service gratuit de mise à disposition électronique des relevés de compte et des avis d’opération (ci-après les « Relevés ») sur le Site.<br><br>Ce service accessible sur le Site, depuis la rubrique « Mes données » puis « Mes abonnements » et « Abonnement aux e-services », permet à l’Epargnant de consulter ses Relevés au format PDF sur le Site pendant une période de 10 ans à compter de leur mise à disposition (ci-après, la « Période »), en remplacement des Relevés papier qu’il recevait jusqu’alors par courrier postal.<br><br>L’Epargnant a la possibilité de télécharger et/ou imprimer les Relevés mis à sa disposition. Il reconnaît que ces Relevés au format PDF ont la même valeur juridique que ceux précédemment adressés par courrier postal.<br><br>L’Epargnant est informé de la mise à disposition d’un Relevé par une notification envoyée sur l’adresse électronique personnelle pré-renseignée sur le Site ou renseignée lors de l’option. La date de mise en ligne des Relevés constitue le point de départ du délai de réclamation relatif aux opérations figurant sur les Relevés.<br><br>L'abonnement à cette option ou son désabonnement est effectif au terme d'un délai maximum de deux jours ouvrés suivant la réception par SOCIETE GENERALE de la demande de l’Epargnant. En cas de désabonnement, les Relevés électroniques précédemment mis à disposition restent disponibles sur le Site jusqu’au terme de la Période.<br><br>Par défaut, les Relevés sont adressés sous format électronique à l'Epargnant d'une Entreprise ayant accepté le format électronique proposé par SOCIETE GENERALE dans la Convention. L'Epargnant peut toutefois se faire communiquer les Relevés sur support papier en se désabonnant aux e-services, sur le Site depuis la rubrique « Mes données / Mes abonnements / Désabonnement aux e-services ».<br><br>De surcroît, si l’Entreprise a également retenu la prestation dans la Convention, les Epargnants reçoivent sous format électronique, selon les mêmes modalités que les Relevés électroniques, les bulletins d’option liés à leurs primes d’intéressement et/ou de participation. C’est ainsi que l’Epargnant est informé de la mise à disposition d’un Bulletin d’option par une notification envoyée sur l’adresse électronique personnelle fournie par l’Entreprise et pré-renseignée sur le Site ou sur l'Appli. La date de mise en ligne des Bulletins d’option constitue le point de départ du délai imparti pour pouvoir opter.<br><br>L’Epargnant est informé que :<br>- il ne peut pas opter lui-même pour l’envoi d’un bulletin d’option sous format électronique,<br>- son désabonnement aux Relevés électroniques mettra également fin à la réception sous format électronique des bulletins d’option qui lui seront alors communiqués par courrier postal.<br><br><div class="cgutitre2">6.2 Autres informations délivrées par courrier électronique et/ou par SMS</div><br><br>Par ailleurs, l’Epargnant est informé qu’il pourra recevoir, par courrier électronique et/ou par SMS, dès lors qu’il aura renseigné son adresse électronique et/ou son numéro de téléphone mobile français sur le Site ou sur l'Appli dans la rubrique « Mes données / Coordonnées personnelles », une notification de mise à disposition sur le Site et sur l’Appli des informations (ci-après les « Informations ») :<br>- liées au suivi des opérations réalisées via le Site ou via l'Appli (confirmation ou rejet d’opérations de remboursement, enregistrement de coordonnées bancaires, etc) ;<br>- relatives aux opérations initiées par l’Entreprise (intéressement, participation,…)<br>- réglementaires (autres que les Relevés) liées à son épargne salariale (lettres aux porteurs des sociétés de gestion, etc)<br><br>Pour cela, il devra effectuer le choix du canal de réception de cette notification. A défaut de choix d’un canal de transmission électronique de cette notification, les Informations lui parviendront par courrier postal.<br><br>Par défaut, les Informations sont adressées sous format électronique à l'Epargnant d'une Entreprise ayant demandé le format électronique proposé par SOCIETE GENERALE.<br>L'Epargnant peut toutefois se faire communiquer les Informations sur support papier en se désabonnant sur le Site ou sur l'Appli depuis la rubrique « Mes données / Mes abonnements / Abonnement aux notifications des opérations » en cochant la case « aucun ».<br><br>Le présent abonnement est distinct de l’abonnement aux e-services.<br><br><div class="cgutitre1">ARTICLE 7 – Responsabilité</div><br><br>Outre son habituelle obligation de diligence en matière de traitement des ordres, SOCIETE GENERALE assume une obligation de moyens en ce qui concerne la réception et l'émission des informations. Elle n'assume aucune responsabilité en ce qui concerne le transport des informations une fois que ceux-ci sont pris en charge par un fournisseur d’accès internet ou un opérateur téléphonique, dans la mesure où le transport ou délivrance dépendent de la gestion du serveur de messagerie du fournisseur d’accès de l’Epargnant ou de son opérateur téléphonique. SOCIETE GENERALE est par conséquent étrangère à tout litige susceptible d'intervenir entre l'Epargnant et son fournisseur d'accès à Internet ou son opérateur de téléphonie mobile.<br><br>SOCIETE GENERALE n'est pas responsable de la conservation et de l'utilisation des Données d'accès et, le cas échéant, des conséquences de leur divulgation. L’accès aux Services n’est possible qu’au moyen d’un téléphone mobile, d’une tablette tactile ou d’un ordinateur, protégés par un code PIN attribué par l’opérateur de téléphonie mobile ou créé par l’Epargnant lui-même. Il est donc de l’intérêt de l’Epargnant de le tenir secret et de ne le communiquer à quiconque.<br><br>L’Epargnant est entièrement responsable de la conservation et de l’utilisation de ces codes, et, le cas échéant des conséquences de sa divulgation. Les appareils utilisés pour accéder aux Services sont sous la responsabilité exclusive de l’Epargnant. S’agissant de la consultation et la diffusion des informations délivrées par les Services, SOCIETE GENERALE ne pourrait être tenue responsable en cas de perte, vol ou prêt des appareils de l’Epargnant. Il en est de même si un tiers pouvait, par tout moyen technique, intercepter et décoder les signaux radioélectriques échangés entre le fournisseur internet et l’Epargnant.<br><br>La responsabilité de SOCIETE GENERALE, limitée aux dommages directs, ne pourra être recherchée que s'il est établi qu'elle a commis une faute lourde. Elle n'est pas responsable lorsque l'inexécution de ses obligations résulte d'un cas de force majeure. Notamment, l'Epargnant reconnaît que constitue un cas de force majeure l'interruption d’un Service liée au transport des informations ou au système informatique de l’Epargnant.<br><br>De même, SOCIETE GENERALE n’est pas responsable d’une conséquence d’un défaut de sécurité (matériel ou logiciel) du terminal de connexion (ordinateur, téléphone, tablette, …) utilisé par l’Epargnant. L’Epargnant est responsable de toutes les conséquences qui résulteraient d’une erreur de transmission ou de manipulation de sa part.<br><br>L'Epargnant ne peut en aucun cas rechercher la responsabilité de SOCIETE GENERALE pour toute information communiquée via les Services, ou de l'utilisation qui en sera faite. La responsabilité de SOCIETE GENERALE ne pourra être engagée que dans le cas d'information délibérément mensongère ou de nature à induire autrui en erreur. Aucun conseil personnalisé n’est délivré par les Services quant au bien-fondé des opérations envisagées par L'Epargnant ou toute autre forme de conseil pouvant déterminer son choix. Il revient à l'Epargnant d'opérer selon sa libre appréciation le choix de ses opérations. Préalablement à toute opération traitée sur les Services, l'Epargnant doit recueillir toutes les informations de nature à l'éclairer dans son choix.<br><br><div class="cgutitre1">ARTICLE 8 – Interruption des Services - Dysfonctionnement</div><br><br>Les Services pourront ponctuellement être interrompus pour des raisons d’ordre technique, afin d’effectuer des opérations de maintenance correctives et/ou préventives. Dans ce cas, l’information sera mentionnée sur le Site et l’Appli 72 h 00 avant la date d’interruption.<br><br>En cas d'interruption ou de dysfonctionnement de l'un ou de l'ensemble des Services pour quelque raison que ce soit, l'Epargnant a toujours la possibilité de s'adresser à SOCIETE GENERALE, notamment par courrier, pour effectuer une opération. SOCIETE GENERALE n'est donc pas responsable des conséquences d'une interruption de Service.<br><br><div class="cgutitre1">ARTICLE 9 – Tarification des Services</div><br><br>L'accès au Site, au Site mobile et à l’Appli est gratuit mais le coût de l’accès à Internet est supporté par l'Epargnant.<br><br>Cependant, SOCIETE GENERALE se réserve la faculté de facturer ultérieurement le téléchargement ou l'accès à ces Services. Dans ce cas, le tarif applicable donnera lieu à une information préalable de l'Epargnant par voie télématique ou par lettre simple un mois avant sa prise d'effet. Sans manifestation de l'Epargnant dans ce délai, cette nouvelle condition d'utilisation lui sera applicable, étant rappelé que celui-ci dispose de la faculté de cesser à tout moment d'utiliser ce Service.<br><br>L'accès au SVI est payant (0 969.321.521 appel non surtaxé depuis un poste fixe, facturation selon l'opérateur et le pays de l'Epargnant). L'Epargnant supportera le coût de la communication téléphonique qui lui sera facturé directement par l'opérateur de son réseau téléphonique en fonction de ses modalités d'accès.<br><br>Les opérations effectuées dans le cadre de l'utilisation des Services seront facturées conformément à la fiche tarifaire qui est disponible dans l'espace documentaire du Site ou conformément à la convention de tenue de compte conclue entre SOCIETE GENERALE et l'Entreprise de l'épargnant.<br><br><div class="cgutitre1">ARTICLE 10 – Informations communiquées par les Services</div><br><br>Les informations communiquées par les Services sont données sous réserve des opérations non encore comptabilisées et sauf éventuelle erreur ou omission. Les écritures comptables auxquelles l'Epargnant a accès peuvent avoir un caractère provisoire. Seuls les relevés de comptes établis par SOCIETE GENERALE à partir de ses propres enregistrements, sur papier ou consultables depuis le Site ou via l’Appli, font foi. En outre, les montants communiqués peuvent être bruts de prélèvements sociaux.<br><br>Il appartient à l'Epargnant de veiller à ce que ses informations personnelles mentionnées sur les Services, et notamment ses coordonnées bancaires et postales soient à jour.<br>A tout moment, l'Epargnant peut modifier ses informations personnelles dans l'espace « Mes données personnelles » du Site ou de l’Appli, ou selon les modalités mentionnées sur lesdits Site ou Appli. En conséquence SOCIETE GENERALE ne peut être tenue pour responsable des conséquences préjudiciables liées à une obsolescence de ces informations.<br><br>Les Services ne délivrent aucun conseil quant au bien-fondé des investissements ou désinvestissements envisagés par l'Epargnant ou toute autre forme de conseil pouvant déterminer son choix. Il revient à l'Epargnant d'opérer selon sa libre appréciation le choix de ses placements et des opérations qui en résultent, en conformité avec la réglementation de l'épargne salariale et les dispositions spécifiques des plans ou accords mis en place au sein de son entreprise et qui lui sont applicables.<br><br>En outre, les informations financières ou fiscales et les informations sur les produits ne sont qu'indicatives. L’impression des écrans ne constitue en aucun cas un justificatif fiscal.<br><br>Plus particulièrement l'information concernant ces produits et notamment les instruments financiers ne saurait constituer de la part de SOCIETE GENERALE ni une offre d'achat, de vente ou de souscription de produits ou services financiers (notamment produits bancaires ou d´assurance), ni une sollicitation d´une offre d´achat ou de vente.<br><br>Lorsque des simulations de performances passées sont présentées, les données y afférentes ont trait à des périodes passées et ne sont pas un indicateur fiable des résultats futurs. Il en va de même de l'évolution des données historiques de marché. Lorsque des simulations de performances futures sont présentées, les données relatives à ces performances ne sont que des prévisions et ne constituent pas un indicateur fiable quant aux résultats futurs du produit. En outre, lorsque les performances passées ou les simulations de performances passées sont basées sur des données exprimées dans une monnaie qui n'est pas celle de l'Etat de résidence de l'Epargnant, les gains éventuels peuvent croître ou décroître en fonction des fluctuations de taux de change. Enfin, lorsque des performances passées ou des simulations de performances (passées ou futures) sont présentées, les gains éventuels peuvent également être réduits par l'effet de commissions, redevances ou autres charges supportées par l'Epargnant.<br><br>Sans préjue des obligations légales ou réglementaires que SOCIETE GENERALE a à sa charge, les Epargnants doivent procéder, avant tout investissement dans le produit ou la conclusion de toute opération y afférente, à leur propre analyse du produit et de ses risques, notamment du point de vue juridique, fiscal et comptable, sans se fonder exclusivement sur les informations qui leur ont été fournies ; les Epargnants doivent consulter, s'ils le jugent nécessaire, leurs propres conseils en la matière ou tout autre professionnel.<br>Sous réserve du respect des obligations légales ou réglementaires à sa charge, SOCIETE GENERALE ne pourra être tenue responsable des conséquences financières ou de quelque nature que ce soit résultant de toute transaction relative au produit ou de tout investissement dans le produit.<br><br>SOCIETE GENERALE et ses contributeurs n'assument aucune responsabilité concernant l'exactitude, l'exhaustivité ou la pertinence des informations établies à partir de sources externes, bien que ces informations proviennent de sources réputées fiables.<br><br><div class="cgutitre1">ARTICLE 11 – Secret Professionnel et Confidentialité</div><br><br><div class="cgutitre2">11.1 Secret Professionnel</div><br><br>En application des dispositions du Code monétaire et financier, Société Générale est tenue au secret professionnel. Toutefois, ce secret peut être levé, conformément à la loi, notamment à la demande des autorités de tutelle, des autorités judiciaires ou de l’administration fiscale ou douanière.<br><br>En outre, Société Générale est autorisée à communiquer les informations soumises au secret professionnel à ses sous-traitants et délégataires, étant précisé que ces personnes sont assujetties à une obligation de secret ou de confidentialité.<br><br>Afin de renforcer la sécurité des paiements, l'Epargnant est informé que Société Générale pourra être amenée à effectuer un contrôle de fiabilisation des coordonnées bancaires. Les IBAN remis par l'Epargnant pourront être contrôlés par Société Générale. Ce contrôle porte sur les noms, prénoms, date de naissance de l'Epargnant. Ces données seront communiquées dans ce cas à des tiers pour effectuer ces contrôles, ce que l'Epargnant accepte expressément.<br><br>Il est précisé que l’Entreprise, en sa qualité de teneur de registre au sens de l’article R3332-14 du code du travail, a connaissance, notamment, des opérations réalisées et du montant des Avoirs des Bénéficiaires y compris ceux ayant quitté l’Entreprise et qu’elle peut valablement demander la communication de telles informations à Société Générale.<br><br><div class="cgutitre2">11.2 Confidentialité</div><br><br>Tous les documents, fichiers et informations, notamment d’ordre économique, technique, commercial, financier, comptable, juridique et administratif échangés entre les Parties dans le cadre de la Convention sont considérés comme confidentiels et doivent être utilisés exclusivement pour les besoins de la Convention. Les Parties s’engagent à ne pas divulguer ces Informations Confidentielles à des tiers ou les utiliser à d’autres fins, sauf accord préalable, exprès et écrit de l’autre Partie concernée par ces Informations.<br><br>Cette obligation de confidentialité ne s’applique pas :<br>- vis-à-vis des autorités de tutelle, des autorités judiciaires ou de l’administration fiscale ou douanière, en cas de demande de leurs parts ;<br>- aux Informations Confidentielles qui, à l’époque de leur utilisation ou divulgation par l’une ou l’autre des Parties, étaient déjà publiques.<br><br><div class="cgutitre1">ARTICLE 12 – Protection des données personnelles</div><br><br>Société Générale est conduite à traiter, de manière automatisée ou non, des données à caractère personnel des Epargnants.<br><br><div class="cgutitre2">12.1 Les traitements réalisés par Société Générale ont pour finalités</div><br><br>La gestion du (des) compte(s) et/ou des produits et services souscrits. Les données à caractère personnel des Epargnants pourront être conservées pour une durée de cinq (5) ans à compter de la clôture du compte.<br><br>La réalisation d’études d’opinion et de satisfaction et d’études statistiques. Les données à caractère personnel des Epargnants pourront être conservées pour une durée maximum de trois (« ) ans à compter de cette dernière.<br><br>La lutte contre la fraude. Les données à caractère personnel des Epargnants pourront être conservées pour une durée maximum de cinq (5) ans à compter de la clôture du dossier fraude.<br><br>Si l’Entreprise a confié cette prestation à Société Générale, l’organisation par voie électronique le cas échéant des élections des représentants des porteurs de parts du conseil de surveillance d’un fonds commun de placement d’entreprise (FCPE) et/ou des candidats au poste d’administrateur représentant les salariés actionnaires. Les données à caractère personnel des Epargnants pourront être conservées dans le cadre de la 1ère élection pour une durée de cinq (5) ans à compter de la fin de ladite élection et dans le cadre de la 2nde élection pour une durée de trois (3) ans à compter de l’assemblée générale des actionnaires au cours de laquelle sera désigné ledit administrateur.<br><br>Le respect des obligations légales et réglementaires, notamment en matière de gestion du risque opérationnel (dont la sécurité des réseaux informatiques et des transactions), de la lutte contre le blanchiment des capitaux et le financement du terrorisme, d’obligations liées aux marchés financiers, et la détermination du statut fiscal. Les données à caractère personnel des Epargnants pourront être conservées pour une durée de cinq (5) ans.<br><br>L’identification des comptes inactifs (PEE/PEI/PEG) et des comptes des personnes décédées. Les données à caractère personnel des Epargnants pourront être conservées pendant une durée maximum de trente (30) ans en fonction des cas prévus par la réglementation en vigueur.<br><br>Le recouvrement de créances. Les données à caractère personnel des Epargnants pourront être conservées pour une durée de douze (12) mois à compter de l’extinction de la créance.<br><br>Société Générale est susceptible de procéder à l’enregistrement des conversations et des communications avec les Epargnants, quel que soit leur support (e-mails, fax, entretiens téléphoniques, etc.), aux fins d’amélioration de l’accueil téléphonique, de respect des obligations légales et réglementaires relatives aux marchés financiers et de sécurité des transactions effectuées. En fonction des cas visés par la réglementation, les données à caractère personnel des Epargnants pourront être conservées pour une durée de cinq (5) ans et lorsque l’autorité compétente le demande, pendant une durée pouvant aller jusqu’à sept (7) ans à compter de leur enregistrement.<br><br>Avec le consentement individuel de l’Epargnant, la prospection commerciale, la réalisation d’animations commerciales et de campagnes publicitaires. Concernant d’éventuelles opérations de prospection commerciale et de campagnes publicitaires à destination des Epargnants, les données à caractère personnel des Epargnants pourront être conservées pour une durée de trois (3) ans à compter de la fin de la relation commerciale.<br><br>Les traitements précités sont nécessaires à l’exécution de la Convention de tenue de compte conservation signée par l’Entreprise de l’Epargnant, au respect des obligations légales et réglementaires de Société Générale, à la poursuite des intérêts légitimes de Société Générale et ce dans le respect de vos libertés et droits fondamentaux (par exemple la lutte contre la fraude, la prospection commerciale).<br><br>Les données à caractère personnel des Epargnants pourront être conservées pour la durée nécessaire à l’accomplissement de la finalité pour laquelle elles ont été collectées tel que mentionné ci-dessus. Elles seront ensuite supprimées. Par exception, ces données pourront être archivées pour gérer les réclamations et contentieux en cours ainsi que pour répondre à nos obligations légales et/ou réglementaires et/ou encore pour répondre aux demandes des autorités autorisées à en faire la demande. Les données à caractère personnel figurant sur des documents comptables pourront être conservées pendant une durée de dix (10) ans conformément aux dispositions de l’article 123-22 du code de commerce.<br><br><div class="cgutitre2">12.2 Communication à des tiers</div><br><br>Tout Epargnant personne physique autorise Société Générale à communiquer les informations recueillies dans le cadre de la présente Convention, aux personnes morales du Groupe Société Générale ainsi qu’en tant que de besoin, à ses partenaires, courtiers et assureurs, sous-traitants et prestataires, dans les limites nécessaires à l’exécution des finalités décrites au point 1.<br><br>Société Générale pourra être amenée à transmettre les données à caractère personnel des Epargnants porteurs de parts d’un fonds commun de placement d’entreprise d’actionnariat salarié (FCPE AS) au prestataire désigné par l’Entreprise ou à l’entité chargée légalement de l’organisation des élections des représentants des porteurs de parts du conseil de surveillance de ce FCPE AS et/ou des candidats au poste d’administrateur représentant les salariés actionnaires. La finalité de cette communication de données personnelles au tiers, reste exclusivement l’organisation des élections précitées sous la responsabilité pleine et entière de l’Entreprise ou de l’entité qui en est légalement chargée.<br><br><div class="cgutitre2">12.3 Transferts de données à caractère personnel en dehors de l’Union Européenne</div><br><br>Par ailleurs, en raison notamment de la dimension internationale du Groupe Société Générale et des mesures prises pour assurer l’utilisation d’outils informatiques ainsi que la sécurité des réseaux informatiques et des transactions ainsi celle de l’utilisation des réseaux de paiement internationaux ou encore dans le cadre de la mise en commun des moyens ou d’opérations de maintenance informatique, les traitements visés au point 1 ci-dessus sont susceptibles d’impliquer des transferts de données à caractère personnel vers des pays non-membres de l’Espace Économique Européen, dont les législations en matière de protection à caractère personnel diffèrent de celles de l’Union Européenne. Dans ce cas, un cadre précis et exigeant, conforme aux modèles adoptés par la Commission européenne, ainsi que des mesures de sécurité appropriées, assurent la protection des données à caractère personnel transférées.<br><br>Les transferts de données à caractère personnel rendus nécessaires interviennent dans des conditions et sous des garanties propres à assurer la confidentialité et la sécurité de ces données. À ce titre, Société Générale met en œuvre toutes les mesures techniques et organisationnelles appropriées pour assurer la sécurité de vos données à caractère personnel qui pourront également être communiquées, aux organismes officiels et aux autorités administratives et judiciaires habilitées du pays concerné, notamment dans le cadre de la lutte contre le blanchiment des capitaux et le financement du terrorisme, la lutte contre la fraude et la détermination du statut fiscal.<br><br><div class="cgutitre2">12.4 Droits des Epargnants</div><br><br>Tout Epargnant dispose d’un droit d’accès et de rectification, d’effacement, de limitation du traitement, ainsi que le droit à la portabilité de ses données. Tout Epargnant peut également s’opposer à tout moment, pour des raisons tenant à sa situation particulière, à ce que ces données à caractère personnel fassent l’objet d’un traitement. Il est précisé que l’exercice de certains de ces droits peut entraîner au cas par cas pour Société Générale l’impossibilité de fournir le produit ou le service. Tout Epargnant peut aussi, à tout moment et sans frais, sans avoir à motiver sa demande, s’opposer à ce que ces données soient utilisées à des fins de prospection commerciale.<br><br>Tout Epargnant peut exercer ses droits auprès de Société Générale par courrier électronique à l’adresse suivante : SGSS-PersonalData@socgen.com ou contacter le délégué à la protection des données personnelles par courrier électronique à l’adresse suivante : Sg-Protection.Donnees@socgen.com<br><br>Tout Epargnant a le droit d’introduire une réclamation auprès de la Commission Nationale de l’Informatique et des Libertés (CNIL), autorité de contrôle en charge du respect des obligations en matière de données à caractère personnel.<br><br><div class="cgutitre1">ARTICLE 13 – Modification des Conditions Générales</div><br><br>Les Services sont susceptibles d'être complétés ou modifiés à tout moment notamment en fonction des évolutions technologiques ou de la réglementation en vigueur. En conséquence, les dispositions des présentes Conditions Générales pourront être modifiées ou adaptées à tout moment par SOCIETE GENERALE. La version en vigueur des Conditions Générales d'utilisation des Services est consultable en ligne à tout moment. L'Epargnant peut y accéder dans la rubrique «  conditions générales d'utilisation » de l'Appli ou du Site Mobile, accessible depuis la page d'identification et la page «  Synthèse ».<br><br>Toutes modifications des Conditions Générales seront portées à la connaissance de l'Epargnant par courrier postal ou par un message télématique d’information sur le Site, sur l'Appli et sur le Site Mobile, un (1) mois avant leur date d’application.<br><br>L’Epargnant a alors la possibilité, en cas de désaccord, d’en faire part à la SOCIETE GENERALE et de cesser d’utiliser les Services. A défaut, s'il continue à utiliser les Services à l'expiration du délai d’un (1) mois précité, l'Epargnant sera réputé avoir accepté ces modifications.<br><br><div class="cgutitre1">ARTICLE 14 – Lutte contre le blanchiment et le financement du terrorisme</div><br><br>SOCIETE GENERALE en sa qualité de teneur de compte conservateur de parts d’épargne salariale, est tenue aux obligations relatives à la lutte contre le blanchiment des capitaux et le financement du terrorisme en application des dispositions des articles L. 561-2 et suivants puis R. 561-16, 7° et 8° du Code Monétaire et financier.<br><br>A ce titre, SOCIETE GENERALE est tenue de recueillir les nom et prénoms, ainsi que les date et lieu de naissance de l’Epargnant. Pour certaines opérations, Société Générale se réserve le droit d’obtenir un justificatif d’identité probant de la part de l’Epargnant et de collecter des informations sur l’origine des fonds investis au sein de son dispositif d’Epargne salariale, et ce en application des dispositions précitées.<br><br>En outre, l'Epargnant confirme, au regard des obligations légales qui s'imposent à SOCIETE GENERALE dans le cadre de la lutte contre le blanchiment telles que définies à l'article 324-1 du Code pénal qu'aucune des sommes versées par lui au titre de l'épargne salariale n'est liée au produit direct ou indirect d'un crime ou d'un délit.<br><br>Les contrôles que SOCIETE GENERALE est tenue d'effectuer en application de la réglementation relative à la lutte contre le blanchiment d'argent et le financement du terrorisme peuvent conduire SOCIETE GENERALE à refuser, suspendre toute opération ou clôturer le plan dont bénéficie l’Epargnant<br><br><div class="cgutitre1">ARTICLE 15 – Durée</div><br><br>Les présentes Conditions Générales d'utilisation des Services sont conclues pour une durée indéterminée. L'Epargnant, conservant la possibilité d'effectuer ses opérations par courrier postal, peut cesser à tout moment d'utiliser les Services sans préavis. La demande de résiliation prend la forme d’une lettre envoyée à SOCIETE GENERALE. L’accès aux Services sera fermé par SOCIETE GENERALE dans les délais techniques nécessaires.<br><br>SOCIETE GENERALE pourra cesser de fournir, à tout moment, les Services moyennant un préavis d'un mois adressé à l’Epargnant par lettre simple, et ce sans être tenu d’en indiquer le motif.<br><br>SOCIETE GENERALE pourra interrompre immédiatement et sans préavis l'accès aux Services en cas notamment, de non-respect des présentes Conditions Générales d'utilisation.<br><br><div class="cgutitre1">ARTICLE 16 – Loi applicable / Litiges</div><br><br>Les présentes Conditions Générales sont soumises au droit français.<br>En cas de litige, faute d’être résolu à l’amiable entre SOCIETE GENERALE et l’Epargnant, sera soumis à la compétence des juridictions françaises.<br><br>Vous souhaitez nous communiquer une insatisfaction<br>Société Générale a la volonté de vous apporter en permanence la meilleure qualité de service.<br>Il se peut, toutefois, que vous rencontriez des difficultés dans le fonctionnement ou dans l’utilisation des services à votre disposition.<br><br>A ce titre, vous avez la possibilité de nous transmettre votre réclamation selon le fonctionnement décrit ci-dessous.<br>Etant entendu par réclamation, toute déclaration actant le mécontentement d’un client envers un professionnel.<br><br>A noter : une demande de service ou de prestation, une demande d’information, de clarification ou une demande d’avis n’est pas une réclamation.<br>Votre service clientèle se tient à votre entière disposition : 4 possibilités<br><br>&gt; par <strong>courrier</strong> à l'adresse suivante :<br>SOCIETE GENERALE - EPARGNE SALARIALE<br>Service Réclamations<br>TSA 90035<br>93736 BOBIGNY CEDEX 9<br>FRANCE<br><br>&gt; par <strong>téléphone</strong> au numéro suivant : 09.69.32.15.21 (appel non surtaxé, de 8h à 18h sans interruption du lundi au vendredi)<br><br>&gt; via <strong>Esalia.com</strong>, identifiez-vous à l'aide de votre numéro de compte et de votre mot de passe - cliquez sur la rubrique « Nous contacter » ( en haut à droite de l'écran d'accueil) puis cliquez sur le bouton « Accéder au formulaire », sélectionnez le motif « Réclamations ».<br><br>&gt; via <strong>l'Appli Esalia</strong>, identifiez-vous à l'aide de votre numéro de compte et de votre mot de passe - cliquez sur la rubrique « Profil » (en bas à droite de votre écran d'accueil) puis cliquez sur « Contacts », « Accéder au formulaire » et sélectionnez le motif « Réclamations ».<br><br>Nous nous engageons à accuser réception de votre demande sous 10 jours et à vous apporter une réponse dans les meilleurs délais (maximum deux mois).<br>En cas de survenance de circonstances particulières ne permettant pas de respecter ce délai, vous serez informés du déroulement de traitement de votre réclamation. Si vous utilisez ce canal et que votre demande nécessite une analyse approfondie, il peut vous être demandé de transmettre votre réclamation par courrier.<br><br>Votre désaccord persiste…<br><br>Service Réclamations auprès de Teneur de Compte Société Générale<br>SGSS/CAO/ESA<br>32 Rue du Champ de Tir<br>44300 NANTES<br>FRANCE<br><br>En dernier recours…<br><br>En cas de désaccord avec la réponse apportée par le Service Réclamations du Teneur de compte Société Générale ou si vous n’avez pas obtenu de réponse de ce dernier dans le délai de deux mois, vous pouvez solliciter :<br><br>&gt; <strong>Le Médiateur auprès de la Fédération Bancaire Française (FBF)</strong> qui exerce sa fonction en toute indépendance, dans le cadre des « Conditions générales du service de médiation » qui précise notamment son champ de compétence et les conditions de son intervention, et que vous pouvez consulter sur le site http://www.lemediateur.fbf.fr.<br><br>Vous pouvez saisir le Médiateur de la FBF en transmettant votre demande sur le site internet du Médiateur : http://www.lemediateur.fbf.fr. Le Médiateur de la FBF vous répondra directement dans un délai de 90 jours à compter de la date à laquelle il aura reçu tous les documents sur lesquels est fondée la demande. En cas de litige complexe, ce délai peut être prolongé. Le Médiateur formulera une position motivée qu’il soumet à l’approbation des deux parties.<br><br>ou<br><br>&gt; <strong>le Médiateur de l’Autorité des Marchés Financiers (AMF).</strong><br><br>Pour saisir le Médiateur de l’AMF, vous pouvez adresser votre courrier à l’adresse suivante :<br><br>Mme Marielle Cohen-Branche - Médiateur de l'AMF<br>- Par formulaire électronique téléchargeable sur le site internet de l’AMF : www.amf-france.org &gt; Le médiateur<br>- Par courrier postal : Le médiateur – Autorité des marchés financiers<br>17, place de la Bourse<br>75082 Paris Cedex 02<br><br>Votre choix est définitif pour ce litige. La saisine du Médiateur vaut autorisation expresse de levée du secret bancaire de votre part à l’égard du Teneur de Compte Société Générale pour ce qui concerne la communication des informations nécessaires à l’instruction de la médiation.</div>
	</div>

	<!-- Lien retour bas -->
	<div class="lien-retour">
		<p class="icon-retour"></p>
		<p class="lien-retour-texte">Retour</p>
	</div>
</div>

<!-- Page Infos Légales -->
<div id="infolegales" class="hidden">
	<!-- Titre page -->
	<div class="titre-page">
		<p id="titre">Mentions légales</p>
	</div>

	<!-- Bloc info 1 -->
	<div id="bloc-info1" class="bloc-info hidden">
		<p class="bloc-info-gauche">
		</p><p class="icon-info-bleue">
		</p><p class="bloc-info-titre"></p>
		<p class="bloc-info-texte"></p>
		<p class="bloc-info-plus hidden"></p>
	</div>

	<!-- Bloc warning 1 -->
	<div id="bloc-warning1" class="bloc-warning hidden">
		<p class="bloc-warning-gauche">
		</p><p class="icon-warning">
		</p><p class="bloc-warning-titre"></p>
		<p class="bloc-warning-texte"></p>
		<p class="bloc-warning-plus hidden"></p>
	</div>

	<!-- Lien retour haut -->
	<div class="lien-retour">
		<p class="icon-retour"></p>
		<p class="lien-retour-texte">Retour</p>
	</div>

	<!-- Bloc central infolegales -->
	<div class="bloc-central-infolegales">
		<div class="infolegalestexte">Ce site est publié par Société Générale.<br>Société anonyme au capital de 1 010 261 206,25 euros au 1er&nbsp;février 2023<br>Immatriculée au RCS de Paris sous le numéro unique d'identification B 552 120 222<br>Numéro APE : 651C<br>Siège social : 29 boulevard Haussmann 75009 Paris<br>No TVA: FR 27 552 120 222<br><br>Directeur de la publication : M. Frédéric OUDEA, Directeur Général<br>Responsable de la rédaction : Mme Lucile DHENIN, Directrice du Teneur de Comptes en Epargne Salariale Société Générale<br>Contact : 09 69 32 15 21 (numéro non surtaxé, facturation selon votre contrat opérateur et votre pays d'appel) et esalia.webmaster@sgss.socgen.com.<br><br>Sont hébergés par Slumberland (65 rue Desnouettes – 75015 PARIS) les sites suivants : https://www.esalia.com ;<br><br>Sont hébergés par Thales (Service SAS – 20-22 rue Grange Dame Rose – 78140 VELIZY-VILLACOUBLAY) les sites suivants : https://salaries.esalia.com ; https://entreprises.esalia.com ;<br><br>L'Appli Esalia est hébergée par Société Générale.<br><br>Le Site Mobile « ESALIA » est hébergé par Société Générale.<br><br>L’ensemble des Sites Internet susmentionnés, l’Appli Esalia et le Site Mobile Esalia est appelé ci-après par convention « le Site ».<br><br><strong>Ce site est soumis à la loi française.</strong><br><br><div class="infolegalestitre1">Réglementation professionnelle</div><br><br>Société Générale est un établissement de crédit de droit français agréé par l’Autorité de Contrôle Prudentiel et de Résolution (« ACPR », 4 place de Budapest CS 92459 75436 Paris Cedex 09) contrôlé par l’Autorité des Marchés Financiers (« AMF ») et sous la supervision prudentielle de la Banque Centrale Européenne (« BCE »). Société Générale, en qualité d’établissement de crédit agréé pour la fourniture de services d’investissement, est ainsi habilitée, à effectuer toutes opérations de banque et à fournir tous les services d'investissement à l'exception du service d’investissement d'exploitation d'un système multilatéral de négociation ou d’un système organisé de négociation.<br><br><div class="infolegalestitre1">Contenu du site</div><br><br>Société Générale ainsi que ses contributeurs s'efforcent d'assurer l'exactitude et la mise à jour des informations diffusées sur ce site, dont elle se réserve le droit de corriger, à tout moment et sans préavis, le contenu. Ils ne peuvent cependant en garantir l'exhaustivité ou l'absence de modification par un tiers (intrusion, virus). En outre, Société Générale et ses contributeurs déclinent toute responsabilité (directe ou indirecte) en cas de retard, d'erreur ou d'omission quant au contenu des présentes pages et à l'utilisation qui pourrait en être faite par quiconque, de même qu'en cas d'interruption ou de non-disponibilité du service.<br><br>La responsabilité de Société Générale et de ses contributeurs ne saurait être retenue en cas de dommages indirects tels que, sans que cette liste soit exhaustive, les pertes découlant des transactions effectuées sur la base des informations, les pertes de profit, pertes d'affaires et pertes découlant d'une interruption du service due à un problème de connexion internet.<br><br>De même, Société Générale et ses contributeurs ne sauraient être tenus responsables des éléments en dehors de leur contrôle et des dommages qui pourraient éventuellement être causés par l’environnement technique des utilisateurs du présent Site, notamment les ordinateurs, logiciels, équipements réseaux (modems, téléphones, … ) et tout matériel utilisé pour accéder à ou utiliser le service et/ou les informations.<br><br><div class="infolegalestitre1">Informations concernant les instruments financiers</div><br><br>Les éventuelles informations qui apparaîtront sur ce Site concernant les instruments financiers sont fournies à titre indicatif et ne sauraient en aucun cas être interprétées comme une sollicitation ou une offre d’acheter ou de vendre un quelconque instrument financier, ou comme se substituant à tout type de conseil ou de recommandation afférent aux instruments financiers. Société Générale et ses contributeurs n'assument aucune responsabilité concernant l'exactitude, l'exhaustivité ou la pertinence des informations établies à partir de sources externes, bien que ces informations proviennent de sources réputées fiables.<br><br>Lorsque des simulations de performances passées ou des performances passées sont présentées, les données y afférentes ont trait à des périodes passées et ne sont pas un indicateur fiable des résultats futurs. Il en va de même de l'évolution des données historiques de marché. Lorsque des simulations de performances futures sont présentées, les données relatives à ces performances ne sont que des prévisions et ne constituent pas un indicateur fiable quant aux résultats futurs du produit. En outre, lorsque les performances passées ou les simulations de performances futures ou passées sont basées sur des données exprimées dans une monnaie qui n'est pas celle de l'Etat de résidence de l'investisseur, les gains éventuels peuvent croître ou décroître en fonction des fluctuations de taux de change. Enfin, lorsque des performances passées ou des simulations de performances (passées ou futures) sont présentées, les gains éventuels peuvent également être réduits par l'effet de commissions, redevances ou autres charges supportées par l'investisseur.<br><br>Aucune responsabilité ne sera acceptée par Société Générale en cas de perte directe ou indirecte résultant de l’utilisation de ces informations.<br><br>Toute personne désireuse de se procurer un des services ou produits présentés éventuellement sur ce Site est priée de contacter Société Générale afin de s´informer de la disponibilité du service ou produit en question ainsi que des conditions contractuelles et tarifaires qui lui sont applicables.<br><br><div class="infolegalestitre1">Souscription de produits et services</div><br><br>Le cas échéant, toute demande éventuelle de souscription en ligne d'un produit ou service proposé par Société Générale ne vaut qu'après acceptation par celle-ci et implique la soumission de l'opération aux conditions contractuelles et tarifaires en vigueur.<br><br><div class="infolegalestitre1">Avertissement pour les non-résidents (résidents hors de France)</div><br><br>L'accès aux informations et produits sur ce Site peut faire l'objet de restrictions à l'égard de certaines personnes ou dans certains pays autres que la France. Aucun des services ou produits n’est destiné à une personne si la loi de son pays d'origine ou de tout autre pays qui la concernerait l'interdit : il appartient à toute personne souhaitant souscrire des produits/services, de vérifier auprès de ses conseils habituels que son statut juridique et fiscal lui permet de souscrire de tels produits/services.<br><br><div class="infolegalestitre1">Avertissement pour les « US Person »</div><br><br>Société Générale n’est pas enregistrée comme négociateur (« broker-dealer ») au regard de l’US Securities Exchange Act de 1934, tel que modifié (le « 1934 Act »), ni au regard d’une autre loi applicable aux Etats-Unis. Par ailleurs, les instruments financiers qui sont susceptibles d’être souscrits sur le site ne font pas l’objet, sauf mention contraire exprès, d’un enregistrement aux Etats-Unis auprès de la Securities Exchange Commission (« SEC ») (…)<br><br><div class="infolegalestitre1">Propriété intellectuelle</div><br><br>L'ensemble de ce Site et chacun de ses éléments pris séparément relèvent de la législation française et internationale sur le droit d'auteur, le droit des marques et des bases de données et, de façon générale, sur la propriété intellectuelle, aussi bien en ce qui concerne sa forme (choix, plan, disposition des matières, moyens d'accès aux données, organisation des données... ), qu'en ce qui concerne chacun des éléments de son contenu (textes, images, vidéos, etc).<br><br>Toute reproduction, représentation, diffusion ou rediffusion, en tout ou partie, du contenu de ce site sur quelque support ou par tout procédé que ce soit (notamment par voie de caching, framing) de même que toute vente, revente, retransmission ou mise à disposition de tiers de quelque manière que ce soit sont interdites sauf autorisation expresse et préalable du directeur de la publication. Le non-respect de cette interdiction constitue une contrefaçon susceptible d'engager la responsabilité civile et pénale du contrefacteur.<br><br>Seule la reproduction papier est autorisée sous conditions d'une utilisation à des fins strictement personnelles, du respect de l'intégrité des documents reproduits, ou en courte citation avec mention claire et lisible de la source, par exemple sous la forme suivante « Extrait du Site (https://entreprises.esalia.com ; https://salaries.esalia.com ; https://www.esalia.com ; etc). Tous droits réservés Groupe Société Générale ».<br><br>Les marques citées sur le Site sont protégées : leur reproduction ou utilisation, de quelque sorte, est interdite.<br><br>Les liens hypertextes établis en direction d'autres sites ne sauraient engager la responsabilité de Société Générale, notamment s'agissant du contenu de ces sites. Société Générale n'est pas responsable des liens hypertextes pointant vers le présent Site.<br><br><div class="infolegalestitre1">Sécurité</div><br><br>Ce Site est protégé par un important niveau de sécurité technique, et est sous surveillance permanente.<br><br>Les algorithmes et mécanismes, utilisés pour protéger vos communications avec Société Générale et les informations qui vous concernent, respectent la réglementation française en vigueur.</div>
	</div>

	<!-- Lien retour bas -->
	<div class="lien-retour">
		<p class="icon-retour"></p>
		<p class="lien-retour-texte">Retour</p>
	</div>
</div>


<!-- Page Infos Légales -->
<div id="accessibilite" class="hidden">
	<!-- Titre page -->
	<div class="titre-page">
		<p id="titre">Accessibilité: Non conforme</p>
	</div>

	<!-- Bloc info 1 -->
	<div id="bloc-info1" class="bloc-info hidden">
		<p class="bloc-info-gauche">
		</p><p class="icon-info-bleue">
		</p><p class="bloc-info-titre"></p>
		<p class="bloc-info-texte"></p>
		<p class="bloc-info-plus hidden"></p>
	</div>

	<!-- Bloc warning 1 -->
	<div id="bloc-warning1" class="bloc-warning hidden">
		<p class="bloc-warning-gauche">
		</p><p class="icon-warning">
		</p><p class="bloc-warning-titre"></p>
		<p class="bloc-warning-texte"></p>
		<p class="bloc-warning-plus hidden"></p>
	</div>

	<!-- Lien retour haut -->
	<div class="lien-retour">
		<p class="icon-retour"></p>
		<p class="lien-retour-texte">Retour</p>
	</div>

	<!-- Bloc central accessibilite -->
	<div class="bloc-central-accessibilite">
		<div class="accessibilitetexte"><div class="cgutexte"><h1 class="cgutitre1">Déclaration d’accessibilité</h1><br>Société Générale s’engage à rendre son site internet <strong><a href="http://www.esalia.com/" target="_new">www.esalia.com</a></strong> accessible conformément à l’article 47 de la loi n° 2005-102 du 11 février 2005.<br><br>A cette fin, il met en oeuvre la stratégie et les actions suivantes : <strong><a href="https://www.societegenerale.com/sites/default/files/documents/2022-03/Schema-pluriannuel-de-mise-en-accessibilite.pdf" target="_new">le Schéma pluriannuel de mise en accessibilité</a></strong> et <strong><a href="https://www.societegenerale.com/sites/default/files/documents/2020-12/Plan-dAction-Annuel-de-Mise-en-Accessibilite.pdf" target="_new">le Plan d'action annuel de mise en accessibilité</a></strong>.<br>Cette déclaration d’accessibilité s’applique au site <strong><a href="http://www.esalia.com/" target="_new">www.esalia.com</a></strong>.<br><br><h1 class="cgutitre1">Etat de conformité</h1><br>Le présent site n'a pas encore été audité, il est donc non conforme au Référentiel Général d'Amélioration de l'Accessibilité (RGAA) dans sa version 4.<br><br><h1 class="cgutitre1">Résultats des tests et contenus non accessibles</h1><br>En attente d'évaluation.<br><br><h1 class="cgutitre1">Établissement de cette déclaration d’accessibilité</h1><br>Cette déclaration a été établie le 13/07/2022.<br><br><h1 class="cgutitre1">Technologies utilisées pour le développement du site</h1><br><ul><li>HTML5</li><li>CSS3</li><li>Javascript</li></ul><br><h1 class="cgutitre1">Agents utilisateurs, technologies d'assistance et outils utilisés pour vérifier l'accessibilité. Pages du site ayant fait l'objet de la vérification de conformité</h1><br>En attente d'évaluation.<br><br><h1 class="cgutitre1">Retour d’information et contact</h1><br>Si vous n’arrivez pas à accéder à un contenu ou à un service, vous pouvez envoyer un mail à <strong>esalia.webmaster@sgss.socgen.com</strong> pour être orienté vers une alternative accessible ou obtenir le contenu sous une autre forme.<br><br><h1 class="cgutitre1">Voies de recours</h1><br>Cette procédure est à utiliser dans le cas suivant :<br>Vous avez signalé au responsable du site internet un défaut d’accessibilité qui vous empêche d’accéder à un contenu ou à un des services du portail et vous n’avez pas obtenu de réponse satisfaisante.<br><br><ul><li>Écrire un message au <strong><a href="https://formulaire.defenseurdesdroits.fr/" target="_new">Défenseur des droits</a></strong></li><li>Contacter le délégué du <strong><a href="https://www.defenseurdesdroits.fr/saisir/delegues" target="_new">Défenseur des droits dans votre région</a></strong></li><li>Envoyer un courrier par la poste (gratuit, ne pas mettre de timbre) :</li><ul><li>Défenseur des droits</li><li>Libre réponse 71120</li><li>75342 Paris CEDEX 07</li></ul></ul></div></div>
	</div>

	<!-- Lien retour bas -->
	<div class="lien-retour">
		<p class="icon-retour"></p>
		<p class="lien-retour-texte">Retour</p>
	</div>
</div>


<!-- Modale de choix de langue -->
<div id="modaleChoixLangue" class="modale-fond hidden">
	<div class="modale modale-langue">
		<p id="closeModaleChoixLangue" class="modale-icon-close"></p>
		<p class="modale-icon-flag"></p>
		<p class="modale-titre">Sélectionnez une langue</p>
		<p class="modale-icon-fr"></p>
		<p class="modale-icon-en"></p>
		<p class="modale-icon-es"></p>
		<p class="modale-icon-de"></p>
		<p class="modale-icon-it"></p>
		<p class="modale-icon-pt"></p>
		<p class="modale-icon-hu"></p>
		<p class="modale-icon-pl"></p>
		<p class="modale-ligne modale-ligne1"></p>
		<p class="modale-ligne modale-ligne2"></p>
		<p class="modale-ligne modale-ligne3"></p>
		<p class="modale-ligne modale-ligne4"></p>
		<p class="modale-ligne modale-ligne5"></p>
		<p class="modale-ligne modale-ligne6"></p>
		<p class="modale-ligne modale-ligne7"></p>
		<p class="modale-ligne modale-ligne8"></p>
		<p class="modale-ligne modale-ligne9"></p>
		<!-- Affiche la checkbox -->
		<p id="modale-langue-rectangle-select" class="modale-langue-rectangle-select-en"></p>
		<label id="modale-langue-checkbox-fr" class="checkbox modale-description" style="font-family: Montserrat-Regular; font-weight: normal;">Français
			<input type="radio" name="radio" value="fr">
			<span class="checkmark"></span>
		</label>
		<label id="modale-langue-checkbox-en" class="checkbox modale-description" style="font-family: Montserrat-SemiBold; font-weight: 600;">Anglais
			<input type="radio" name="radio" value="en" checked="checked">
			<span class="checkmark"></span>
		</label>
		<label id="modale-langue-checkbox-es" class="checkbox modale-description" style="font-family: Montserrat-Regular; font-weight: normal;">Espagnol
			<input type="radio" name="radio" value="es">
			<span class="checkmark"></span>
		</label>
		<label id="modale-langue-checkbox-de" class="checkbox modale-description" style="font-family: Montserrat-Regular; font-weight: normal;">Allemand
			<input type="radio" name="radio" value="de">
			<span class="checkmark"></span>
		</label>
		<label id="modale-langue-checkbox-it" class="checkbox modale-description" style="font-family: Montserrat-Regular; font-weight: normal;">Italien
			<input type="radio" name="radio" value="it">
			<span class="checkmark"></span>
		</label>
		<label id="modale-langue-checkbox-pt" class="checkbox modale-description" style="font-family: Montserrat-Regular; font-weight: normal;">Portugais
			<input type="radio" name="radio" value="pt">
			<span class="checkmark"></span>
		</label>
		<label id="modale-langue-checkbox-hu" class="checkbox modale-description" style="font-family: Montserrat-Regular; font-weight: normal;">Hongrois
			<input type="radio" name="radio" value="hu">
			<span class="checkmark"></span>
		</label>
		<label id="modale-langue-checkbox-pl" class="checkbox modale-description" style="font-family: Montserrat-Regular; font-weight: normal;">Polonais
			<input type="radio" name="radio" value="pl">
			<span class="checkmark"></span>
		</label>
	</div>
</div>

<!-- Footer -->
<div class="footer-page">
	<p id="footer-ligne">
	</p><p id="footer-donneesperso" class="footer-texte" style="right: 957px;">Données personnelles</p>
	<p id="footer-dot1" style="right: 940px;">
	</p><p id="footer-infolegales" class="footer-texte" style="right: 801px;">Informations légales</p>
	<p id="footer-dot2" style="right: 784px;">
	</p><p id="footer-cookies" class="footer-texte" style="right: 724px;">Cookies</p>
	<p id="footer-dot3" style="right: 707px;">
	</p><p id="footer-cgu" class="footer-texte" style="right: 490px;">Conditions générales d'utilisation</p>
	<p id="footer-dot4" style="right: 468px;">
	</p><p id="footer-accessibilite" class="footer-texte" style="right: 290px;">Accessibilité: Non conforme</p>
	<p id="footer-dot5" style="right: 268px;">
	</p><p id="footer-copyright" class="footer-texte">Copyright Société Générale Esalia 2022 ©</p>
</div>

<!-- Scripts -->
<script src="./index_files/authn-ws.js.téléchargement"></script>
<script>
//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DU BLOC D'INFORMATION 1
//----------------------------------------------------------------------------------------------------------------------------------------

// On affiche le bloc si le titre est non vide
if ( '' != '') {
	$('.bloc-info').removeClass("hidden");
}

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DU BLOC WARNING 1
//----------------------------------------------------------------------------------------------------------------------------------------

// On affiche le bloc si le titre est non vide
if ( '' != '') {
	$('.bloc-warning').removeClass("hidden");
}

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION INITIALE AU CHARGEMENT DE LA PAGE
//----------------------------------------------------------------------------------------------------------------------------------------
// Positionne le titre de l'onglet de la page
document.title = 'SG';

// Lecture des paramètres http passés en query
var urlParams = new URL(location.href).searchParams;

var gotoParam = urlParams.get('goto');

if (gotoParam != null) {
	// Sauvegarde de l'URL dans le sessionStorage
	sessionStorage.setItem("gotoParam", gotoParam);
} else {
	// On récupère l'URL de login dans le sessionStorage
	gotoParam = sessionStorage.getItem("gotoParam");
}

redirectUri = getParamFromUrl(gotoParam, 'redirect_uri');
uiLocales = getParamFromUrl(gotoParam, 'ui_locales');

// Détermine la langue en cours en fonction du parametre d'URL ui_locales
switch(uiLocales) {
	case 'fr':
        // Affiche le picto icon-fr
        $('#icon-fr').removeClass("hidden");
        // Affiche le francais sélectionné dans la modale-langue
        $('input[type=radio][name=radio][value=fr]').attr('checked', true);
        selectLangueFR();
		break;
	case 'en':
		// Affiche le picto icon-en
		$('#icon-en').removeClass("hidden");
		// Affiche l'anglais sélectionné dans la modale-langue
		$('input[type=radio][name=radio][value=en]').attr('checked', true);
		selectLangueEN();
		break;
	case 'es':
		// Affiche le picto icon-es
		$('#icon-es').removeClass("hidden");
		// Affiche l'espagnol sélectionné dans la modale-langue
		$('input[type=radio][name=radio][value=es]').attr('checked', true);
		selectLangueES();
		break;
	case 'de':
		// Affiche le picto icon-de
		$('#icon-de').removeClass("hidden");
		// Affiche l'allemand sélectionné dans la modale-langue
		$('input[type=radio][name=radio][value=de]').attr('checked', true);
		selectLangueDE();
		break;
	case 'it':
		// Affiche le picto icon-it
		$('#icon-it').removeClass("hidden");
		// Affiche l'italien sélectionné dans la modale-langue
		$('input[type=radio][name=radio][value=it]').attr('checked', true);
		selectLangueIT();
		break;
	case 'pt':
		// Affiche le picto icon-pt
		$('#icon-pt').removeClass("hidden");
		// Affiche le portugais sélectionné dans la modale-langue
		$('input[type=radio][name=radio][value=pt]').attr('checked', true);
		selectLanguePT();
		break;
	case 'hu':
		// Affiche le picto icon-hu
		$('#icon-hu').removeClass("hidden");
		// Affiche le hongrois sélectionné dans la modale-langue
		$('input[type=radio][name=radio][value=hu]').attr('checked', true);
		selectLangueHU();
		break;
	case 'pl':
		// Affiche le picto icon-pl
		$('#icon-pl').removeClass("hidden");
		// Affiche le polonais sélectionné dans la modale-langue
		$('input[type=radio][name=radio][value=pl]').attr('checked', true);
		selectLanguePL();
		break;
	default:
        // Affiche le picto icon-en
        $('#icon-en').removeClass("hidden");
        // Affiche l'anglais sélectionné dans la modale-langue
        $('input[type=radio][name=radio][value=en]').attr('checked', true);
        selectLangueEN();
		break;
}

// Détermine s'il s'agit d'un device mobile
const isAndroid = () => !!window.navigator.userAgent.match(/Android/i);
const isIphoneOrIpad = () => !!window.navigator.userAgent.match(/iPhone|iPad|Mac OS X/i);
//console.log("isAndroid:"+isAndroid());
//console.log("isIphoneOrIpad:"+isIphoneOrIpad());

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DU LIEN ET CHEVRON RETOUR
//----------------------------------------------------------------------------------------------------------------------------------------

// S'execute quand le user clique sur le LOGO du Header
$('.lien-retour').click(function () {
	// Affiche la page standard
	affichePageStandard();
});

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DU HEADER
//----------------------------------------------------------------------------------------------------------------------------------------
// S'execute quand le user clique sur le LOGO du Header
$('#header-logo').click(function () {
	// Affiche la page standard
	affichePageStandard();
});

// S'execute quand le user clique sur le menu Changer de langue du Header
$('#header-langue').click(function () {
	// Affiche la modale de choix de langue
	afficheModale($('#modaleChoixLangue'));
});

// S'execute quand le user clique sur le menu Assistance du Header
$('#header-assistance').click(function () {
	// Affiche la page d'assistance
	affichePageAssistance();
});

// S'execute quand le user clique sur l'icone Assistance du Header
$('#icon-assistance').click(function () {
	// Affiche la page d'assistance
	affichePageAssistance();
});

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DE LA MODALE DE CHOIX DE LANGUE
//----------------------------------------------------------------------------------------------------------------------------------------

// S'execute quand le user clique sur le drapeau
$('#icon-fr').click(function () {
	// Affiche la modale de choix de langue
	afficheModale($('#modaleChoixLangue'));
});
$('#icon-en').click(function () {
	// Affiche la modale de choix de langue
	afficheModale($('#modaleChoixLangue'));
});
$('#icon-es').click(function () {
	// Affiche la modale de choix de langue
	afficheModale($('#modaleChoixLangue'));
});
$('#icon-de').click(function () {
	// Affiche la modale de choix de langue
	afficheModale($('#modaleChoixLangue'));
});
$('#icon-it').click(function () {
	// Affiche la modale de choix de langue
	afficheModale($('#modaleChoixLangue'));
});
$('#icon-pt').click(function () {
	// Affiche la modale de choix de langue
	afficheModale($('#modaleChoixLangue'));
});
$('#icon-hu').click(function () {
	// Affiche la modale de choix de langue
	afficheModale($('#modaleChoixLangue'));
});
$('#icon-pl').click(function () {
	// Affiche la modale de choix de langue
	afficheModale($('#modaleChoixLangue'));
});

// S'execute quand le user clique sur l'icone de fermeture de la modale
$('#closeModaleChoixLangue').click(function () {
	// Ferme la modale de choix de langue
	closeModale($('#modaleChoixLangue'));
});

// S'execute quand le user clique sur le switch radio francais
$('#modale-langue-checkbox-fr').click(function () {
	// Selectionne le francais
	selectLangueFR();
	// On recharge la page en francais
	document.location.href = gotoParam.replace(/ui_locales\=fr|ui_locales\=en|ui_locales\=es|ui_locales\=de|ui_locales\=it|ui_locales\=pt|ui_locales\=hu|ui_locales\=pl/i,'ui_locales=fr');
});

// S'execute quand le user clique sur le switch radio anglais
$('#modale-langue-checkbox-en').click(function () {
	// Selectionne l'anglais
	selectLangueEN();
	// On recharge la page en anglais
	document.location.href = gotoParam.replace(/ui_locales\=fr|ui_locales\=en|ui_locales\=es|ui_locales\=de|ui_locales\=it|ui_locales\=pt|ui_locales\=hu|ui_locales\=pl/i,'ui_locales=en');
});

// S'execute quand le user clique sur le switch radio espagnol
$('#modale-langue-checkbox-es').click(function () {
	// Selectionne l'espagnol
	selectLangueES();
	// On recharge la page en espagnol
	document.location.href = gotoParam.replace(/ui_locales\=fr|ui_locales\=en|ui_locales\=es|ui_locales\=de|ui_locales\=it|ui_locales\=pt|ui_locales\=hu|ui_locales\=pl/i,'ui_locales=es');
});

// S'execute quand le user clique sur le switch radio allemand
$('#modale-langue-checkbox-de').click(function () {
	// Selectionne l'allemand
	selectLangueDE();
	// On recharge la page en allemand
	document.location.href = gotoParam.replace(/ui_locales\=fr|ui_locales\=en|ui_locales\=es|ui_locales\=de|ui_locales\=it|ui_locales\=pt|ui_locales\=hu|ui_locales\=pl/i,'ui_locales=de');
});

// S'execute quand le user clique sur le switch radio italien
$('#modale-langue-checkbox-it').click(function () {
	// Selectionne l'italien
	selectLangueIT();
	// On recharge la page en italien
	document.location.href = gotoParam.replace(/ui_locales\=fr|ui_locales\=en|ui_locales\=es|ui_locales\=de|ui_locales\=it|ui_locales\=pt|ui_locales\=hu|ui_locales\=pl/i,'ui_locales=it');
});

// S'execute quand le user clique sur le switch radio portugais
$('#modale-langue-checkbox-pt').click(function () {
	// Selectionne le portugais
	selectLanguePT();
	// On recharge la page en portugais
	document.location.href = gotoParam.replace(/ui_locales\=fr|ui_locales\=en|ui_locales\=es|ui_locales\=de|ui_locales\=it|ui_locales\=pt|ui_locales\=hu|ui_locales\=pl/i,'ui_locales=pt');
});

// S'execute quand le user clique sur le switch radio hongrois
$('#modale-langue-checkbox-hu').click(function () {
	// Selectionne le hongrois
	selectLangueHU();
	// On recharge la page en hongrois
	document.location.href = gotoParam.replace(/ui_locales\=fr|ui_locales\=en|ui_locales\=es|ui_locales\=de|ui_locales\=it|ui_locales\=pt|ui_locales\=hu|ui_locales\=pl/i,'ui_locales=hu');
});

// S'execute quand le user clique sur le switch radio polonais
$('#modale-langue-checkbox-pl').click(function () {
	// Selectionne le polonais
	selectLanguePL();
	// On recharge la page en polonais
	document.location.href = gotoParam.replace(/ui_locales\=fr|ui_locales\=en|ui_locales\=es|ui_locales\=de|ui_locales\=it|ui_locales\=pt|ui_locales\=hu|ui_locales\=pl/i,'ui_locales=pl');
});

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DU FOOTER
//----------------------------------------------------------------------------------------------------------------------------------------

// Repositionne les éléments du footer si anglais
repoFooter();
$(window).resize(function() {
	repoFooter();
});
function repoFooter() {
	//console.log("largeur ecran:"+$(window).width());
	if (($(window).width() > 1250 ) && ("fr" == "fr")) {
		$('#footer-donneesperso').css("right","957px");
		$('#footer-dot1').css("right","940px");
		$('#footer-infolegales').css("right","801px");
		$('#footer-dot2').css("right","784px");
		$('#footer-cookies').css("right","724px");
		$('#footer-dot3').css("right","707px");
		$('#footer-cgu').css("right","490px");
		$('#footer-dot4').css("right","468px");
		$('#footer-accessibilite').css("right","290px");
		$('#footer-dot5').css("right","268px");
	}
	if (($(window).width() > 1250 ) && ("fr" == "en")) {
		$('#footer-donneesperso').css("right","904px");
		$('#footer-dot1').css("right","882px");
		$('#footer-infolegales').css("right","759px");
		$('#footer-dot2').css("right","741px");
		$('#footer-cookies').css("right","680px");
		$('#footer-dot3').css("right","660px");
		$('#footer-cgu').css("right","490px");
		$('#footer-dot4').css("right","473px");
		$('#footer-accessibilite').css("right","290px");
		$('#footer-dot5').css("right","268px");
	}
	if (($(window).width() > 1250 ) && ("fr" == "es")) {
		$('#footer-donneesperso').css("right","905px");
		$('#footer-dot1').css("right","886px");
		$('#footer-infolegales').css("right","766px");
		$('#footer-dot2').css("right","747px");
		$('#footer-cookies').css("right","685px");
		$('#footer-dot3').css("right","666px");
		$('#footer-cgu').css("right","471px");
		$('#footer-dot4').css("right","450px");
		$('#footer-accessibilite').css("right","274px");
		$('#footer-dot5').css("right","258px");
	}
	if (($(window).width() > 1250 ) && ("fr" == "de")) {
		$('#footer-donneesperso').css("right","957px");
		$('#footer-dot1').css("right","940px");
		$('#footer-infolegales').css("right","801px");
		$('#footer-dot2').css("right","784px");
		$('#footer-cookies').css("right","724px");
		$('#footer-dot3').css("right","710px");
		$('#footer-cgu').css("right","489px");
		$('#footer-dot4').css("right","470px");
		$('#footer-accessibilite').css("right","276px");
		$('#footer-dot5').css("right","260px");
	}
	if (($(window).width() > 1250 ) && ("fr" == "it")) {
		$('#footer-donneesperso').css("right","905px");
		$('#footer-dot1').css("right","885px");
		$('#footer-infolegales').css("right","758px");
		$('#footer-dot2').css("right","741px");
		$('#footer-cookies').css("right","682px");
		$('#footer-dot3').css("right","663px");
		$('#footer-cgu').css("right","474px");
		$('#footer-dot4').css("right","458px");
		$('#footer-accessibilite').css("right","280px");
		$('#footer-dot5').css("right","260px");
	}
	if (($(window).width() > 1250 ) && ("fr" == "pt")) {
		$('#footer-donneesperso').css("right","932px");
		$('#footer-dot1').css("right","911px");
		$('#footer-infolegales').css("right","782px");
		$('#footer-dot2').css("right","760px");
		$('#footer-cookies').css("right","696px");
		$('#footer-dot3').css("right","677px");
		$('#footer-cgu').css("right","480px");
		$('#footer-dot4').css("right","470px");
		$('#footer-accessibilite').css("right","279px");
		$('#footer-dot5').css("right","260px");
	}
	if (($(window).width() > 1250 ) && ("fr" == "pl")) {
		$('#footer-donneesperso').css("right","900px");
		$('#footer-dot1').css("right","880px");
		$('#footer-infolegales').css("right","752px");
		$('#footer-dot2').css("right","734px");
		$('#footer-cookies').css("right","650px");
		$('#footer-dot3').css("right","632px");
		$('#footer-cgu').css("right","448px");
		$('#footer-dot4').css("right","429px");
		$('#footer-accessibilite').css("right","276px");
		$('#footer-dot5').css("right","260px");
	}
	if (($(window).width() > 1250 ) && ("fr" == "hu")) {
		$('#footer-donneesperso').css("right","913px");
		$('#footer-dot1').css("right","895px");
		$('#footer-infolegales').css("right","779px");
		$('#footer-dot2').css("right","761px");
		$('#footer-cookies').css("right","713px");
		$('#footer-dot3').css("right","696px");
		$('#footer-cgu').css("right","502px");
		$('#footer-dot4').css("right","486px");
		$('#footer-accessibilite').css("right","276px");
		$('#footer-dot5').css("right","260px");
	}
	if (($(window).width() <= 1250 ) && ("fr" == "fr")) {
		$('#footer-donneesperso').css("right","667px");
		$('#footer-dot1').css("right","650px");
		$('#footer-infolegales').css("right","511px");
		$('#footer-dot2').css("right","494px");
		$('#footer-cookies').css("right","434px");
		$('#footer-dot3').css("right","417px");
		$('#footer-cgu').css("right","202px");
		$('#footer-dot4').css("right","184px");
		$('#footer-dot4').css("display","block");
		$('#footer-accessibilite').css("right","0px");
	}
	if (($(window).width() <= 1250 ) && ("fr" == "en")) {
		$('#footer-donneesperso').css("right","610px");
		$('#footer-dot1').css("right","590px");
		$('#footer-infolegales').css("right","470px");
		$('#footer-dot2').css("right","450px");
		$('#footer-cookies').css("right","390px");
		$('#footer-dot3').css("right","370px");
		$('#footer-cgu').css("right","202px");
		$('#footer-dot4').css("right","184px");
		$('#footer-dot4').css("display","block");
		$('#footer-accessibilite').css("right","0px");
	}
	if (($(window).width() <= 1250 ) && ("fr" == "es")) {
		$('#footer-donneesperso').css("right","630px");
		$('#footer-dot1').css("right","610px");
		$('#footer-infolegales').css("right","490px");
		$('#footer-dot2').css("right","470px");
		$('#footer-cookies').css("right","410px");
		$('#footer-dot3').css("right","390px");
		$('#footer-cgu').css("right","195px");
		$('#footer-dot4').css("right","175px");
		$('#footer-dot4').css("display","block");
		$('#footer-accessibilite').css("right","0px");
	}
	if (($(window).width() <= 1250 ) && ("fr" == "de")) {
		$('#footer-donneesperso').css("right","667px");
		$('#footer-dot1').css("right","650px");
		$('#footer-infolegales').css("right","511px");
		$('#footer-dot2').css("right","496px");
		$('#footer-cookies').css("right","440px");
		$('#footer-dot3').css("right","424px");
		$('#footer-cgu').css("right","202px");
		$('#footer-dot4').css("right","190px");
		$('#footer-dot4').css("display","block");
		$('#footer-accessibilite').css("right","0px");
	}
	if (($(window).width() <= 1250 ) && ("fr" == "it")) {
		$('#footer-donneesperso').css("right","622px");
		$('#footer-dot1').css("right","605px");
		$('#footer-infolegales').css("right","482px");
		$('#footer-dot2').css("right","465px");
		$('#footer-cookies').css("right","410px");
		$('#footer-dot3').css("right","390px");
		$('#footer-cgu').css("right","200px");
		$('#footer-dot4').css("right","180px");
		$('#footer-dot4').css("display","block");
		$('#footer-accessibilite').css("right","0px");
	}
	if (($(window).width() <= 1250 ) && ("fr" == "pt")) {
		$('#footer-donneesperso').css("right","642px");
		$('#footer-dot1').css("right","625px");
		$('#footer-infolegales').css("right","500px");
		$('#footer-dot2').css("right","480px");
		$('#footer-cookies').css("right","422px");
		$('#footer-dot3').css("right","405px");
		$('#footer-cgu').css("right","210px");
		$('#footer-dot4').css("right","195px");
		$('#footer-dot4').css("display","block");
		$('#footer-accessibilite').css("right","0px");
	}
	if (($(window).width() <= 1250 ) && ("fr" == "hu")) {
		$('#footer-donneesperso').css("right","625px");
		$('#footer-dot1').css("right","610px");
		$('#footer-infolegales').css("right","500px");
		$('#footer-dot2').css("right","480px");
		$('#footer-cookies').css("right","434px");
		$('#footer-dot3').css("right","418px");
		$('#footer-cgu').css("right","225px");
		$('#footer-dot4').css("right","210px");
		$('#footer-dot4').css("display","block");
		$('#footer-accessibilite').css("right","0px");
	}
	if (($(window).width() <= 1250 ) && ("fr" == "pl")) {
		$('#footer-donneesperso').css("right","612px");
		$('#footer-dot1').css("right","592px");
		$('#footer-infolegales').css("right","465px");
		$('#footer-dot2').css("right","445px");
		$('#footer-cookies').css("right","364px");
		$('#footer-dot3').css("right","350px");
		$('#footer-cgu').css("right","172px");
		$('#footer-dot4').css("right","155px");
		$('#footer-dot4').css("display","block");
		$('#footer-accessibilite').css("right","0px");
	}
}

// S'execute quand le user clique sur le menu Cookies du Footer
$('#footer-cookies').click(function () {
	// Affiche la page des cookies
	affichePageCookies();
});

// S'execute quand le user clique sur le menu Données personnelles du Footer
$('#footer-donneesperso').click(function () {
	// Affiche la page des données personnelles
	affichePageDonneesPerso();
});

// S'execute quand le user clique sur le menu CGU du Footer
$('#footer-cgu').click(function () {
	// Affiche la page des CGU
	affichePageCGU();
});

// S'execute quand le user clique sur le menu Infos Légales du Footer
$('#footer-infolegales').click(function () {
	// Affiche la page des Infos Légales
	affichePageInfolegales();
});

// S'execute quand le user clique sur le menu Accessibilite du Footer
$('#footer-accessibilite').click(function () {
	// Affiche la page des Accessibilite
	affichePageAccessibilite();
});
//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DU MASQUAGE DES PAGES
//----------------------------------------------------------------------------------------------------------------------------------------
// Masque toutes les pages
function masqueAllPages () {
	// Masque la page centrale
	$('#page').addClass("hidden");
	// Masque la page d'assistance
	$('#assistance').addClass("hidden");
	// Masque la page des cookies
	$('#cookies').addClass("hidden");
	// Masque la page des données personnelles
	$('#donneesperso').addClass("hidden");
	// Masque la page des CGU
	$('#cgu').addClass("hidden");
	// Masque la page des Infos Légales
	$('#infolegales').addClass("hidden");
	// Masque la page Accessibilite
	$('#accessibilite').addClass("hidden");
}

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DE LA PAGE D'ASSISTANCE
//----------------------------------------------------------------------------------------------------------------------------------------
// Affiche la page d'assistance
function affichePageAssistance () {
	// On affiche les blocs d'informations si leur titre est non vide
	if ( 'Votre numéro de compte' != '') {
		$('#info1').removeClass("hidden");
	}
	if ( 'Votre mot de passe' != '') {
		$('#info2').removeClass("hidden");
	}
	if ( 'Un code d’authentification temporaire' != '') {
		$('#info3').removeClass("hidden");
	}
	// Masque toutes les pages
	masqueAllPages();
	// Affiche la page d'assistance
	$('#assistance').removeClass("hidden");
}

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DE LA PAGE DES COOKIES
//----------------------------------------------------------------------------------------------------------------------------------------

// Affiche la page d'assistance
function affichePageCookies () {
	// Masque toutes les pages
	masqueAllPages();
	// Affiche la page d'assistance
	$('#cookies').removeClass("hidden");
}

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DE LA PAGE DES DONNEES PERSONNELLES
//----------------------------------------------------------------------------------------------------------------------------------------

// Affiche la page des données personnelles
function affichePageDonneesPerso () {
	// Masque toutes les pages
	masqueAllPages();
	// Affiche la page des données personnelles
	$('#donneesperso').removeClass("hidden");
}

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DE LA PAGE DES CGU
//----------------------------------------------------------------------------------------------------------------------------------------

// Affiche la page des CGU
function affichePageCGU () {
	// Masque toutes les pages
	masqueAllPages();
	// Affiche la page des CGU
	$('#cgu').removeClass("hidden");
}

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DE LA PAGE DES INFOS LEGALES
//----------------------------------------------------------------------------------------------------------------------------------------

// Affiche la page des Infos Légales
function affichePageInfolegales () {
	// Masque toutes les pages
	masqueAllPages();
	// Affiche la page des Infos Légales
	$('#infolegales').removeClass("hidden");
}

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DE LA PAGE ACCESSIBILITE
//----------------------------------------------------------------------------------------------------------------------------------------

// Affiche la page des ACCESSIBILITE
function affichePageAccessibilite () {
	// Masque toutes les pages
	masqueAllPages();
	// Affiche la page des Infos Légales
	$('#accessibilite').removeClass("hidden");
}

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DE LA PAGE STANDARD
//----------------------------------------------------------------------------------------------------------------------------------------

// Affiche la page Standard
function affichePageStandard () {
	// Masque toutes les pages
	masqueAllPages();
	// Affiche la page Standard
	$('#page').removeClass("hidden");
}

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DU CHATBOX
//----------------------------------------------------------------------------------------------------------------------------------------

// Configure le chatbox
function dyduAfterLoad() {
    dydu.chatbox.registerContext('abonnement', ' https://salaries.esalia.com/portal/salarie-sg/mesdonnees/abonnement?scenario=ConsulterAbonnement');
    dydu.chatbox.registerContext('adresse_courrier', 'SOCIETE GENERALE EPARGNE SALARIALE - TSA 90035 - 93736 BOBIGNY CEDEX 9 - France');
    dydu.chatbox.registerContext('adresse_reclamation', 'https://www.esalia.com/fr/epargnants/nous-contacter/');
    dydu.chatbox.registerContext('application_mobile', 'ESALIA');
    dydu.chatbox.registerContext('attestation', 'https://www.esalia.com/fileadmin/user_upload/esalia/PDF/Attestation_pour_construction_de_la_r%C3%A9sidence_principaleV2016.pdf');
    dydu.chatbox.registerContext('bouton_justif', 'Modifier mes pièces jointes');
    dydu.chatbox.registerContext('bulletin_transfert', 'https://salaries.esalia.com/portal/rest/jcr/repository/collaboration/sites/Contenus/SG/documents/doc-bibliotheque/Transfert_individuel.pdf');
    dydu.chatbox.registerContext('cet', 'https://www.esalia.com/fr/epargnants/comprendre-epargne-salariale/cet-compte-epargne-temps/');
    dydu.chatbox.registerContext('contact', 'https://salaries.esalia.com//portal/salarie-sg/contact');
    dydu.chatbox.registerContext('coordonnee_perso', 'https://salaries.esalia.com/portal/salarie-sg/mesdonnees/coordperso?scenario=ConsulterCP');
    dydu.chatbox.registerContext('deblocage_3eme_enfant', 'https://www.esalia.com/fr/epargnants/gerer-compte-epargne/vos-cas-deblocage-anticipe-depargne-salariale/naissance-adoption-3eme-enfant-puis-chaque-enfant-suivant/');
    dydu.chatbox.registerContext('deblocage_acquisition_RP', 'https://www.esalia.com/fr/epargnants/gerer-compte-epargne/vos-cas-deblocage-anticipe-depargne-salariale/acquisition-residence-principale/');
    dydu.chatbox.registerContext('deblocage_cessation_contrat_travail', 'https://www.esalia.com/fr/epargnants/gerer-compte-epargne/vos-cas-deblocage-anticipe-depargne-salariale/cessation-contrat-travail-hors-depart-retraite/');
    dydu.chatbox.registerContext('deblocage_chomage', 'https://www.esalia.com/fr/epargnants/gerer-compte-epargne/vos-cas-deblocage-anticipe-depargne-salariale/expiration-des-droits-lassurance-chomage/');
    dydu.chatbox.registerContext('deblocage_deces', 'https://www.esalia.com/fr/epargnants/gerer-compte-epargne/vos-cas-deblocage-anticipe-depargne-salariale/deces/');
    dydu.chatbox.registerContext('deblocage_divorce', 'https://www.esalia.com/fr/epargnants/gerer-compte-epargne/vos-cas-deblocage-anticipe-depargne-salariale/divorce-separation-dissolution-dun-pacs/');
    dydu.chatbox.registerContext('deblocage_general', 'https://www.esalia.com/fr/epargnants/gerer-compte-epargne/vos-cas-deblocage-anticipe-depargne-salariale/');
    dydu.chatbox.registerContext('deblocage_mariage', 'https://www.esalia.com/fr/epargnants/gerer-compte-epargne/vos-cas-deblocage-anticipe-depargne-salariale/mariage-conclusion-dun-pacs/');
    dydu.chatbox.registerContext('deblocage_rachat', 'https://salaries.esalia.com/portal/salarie-sg/operations/debloquer');
    dydu.chatbox.registerContext('deblocage_surendettement', 'https://www.esalia.com/fr/epargnants/gerer-compte-epargne/vos-cas-deblocage-anticipe-depargne-salariale/surendettement/');
    dydu.chatbox.registerContext('donnees_pilotage', 'https://www.esalia.com/portal/salarie-sg/mesdonnees/pilotage?scenario=ConsulterDP');
    dydu.chatbox.registerContext('ereleve', 'https://salaries.esalia.com/portal/salarie-sg/mesdonnees/abonnement?scenario=ConsulterAbonnement');
    dydu.chatbox.registerContext('fisca', 'https://www.esalia.com/fr/epargnants/dossiers-actualites/juridique-fiscalite/');
    dydu.chatbox.registerContext('fond_cible', 'cible');
    dydu.chatbox.registerContext('fond_source', 'source');
    dydu.chatbox.registerContext('historique_OI', 'https://salaries.esalia.com/portal/salarie-sg/operations/consulteroperations?scenario=ConsulterOperationsEffectuees');
    dydu.chatbox.registerContext('horaire', 'de 8h à 18h sans interruption du Lundi au Vendredi');
    dydu.chatbox.registerContext('iban', 'https://salaries.esalia.com/portal/salarie-sg/mesdonnees/coordbancaire?scenario=ConsulterCB');
    dydu.chatbox.registerContext('ID_libelle', 'Numéro d\'Identification');
    dydu.chatbox.registerContext('justificatif', '');
    dydu.chatbox.registerContext('mandat_sepa', 'https://salaries.esalia.com/portal/salarie-sg/bibliotheque?folder-id=repository:collaboration:/sites/salarie-sg/categories/salarie-sg/cat_vos-documents-utiles');
    dydu.chatbox.registerContext('menu1_documents', 'Mes documents');
    dydu.chatbox.registerContext('menu1_donnees', 'Mon profil');
    dydu.chatbox.registerContext('menu1_operations', 'Mes opérations');
    dydu.chatbox.registerContext('menu2_abonnements', 'Mes abonnements');
    dydu.chatbox.registerContext('menu2_detail', 'Détail de mon épargne');
    dydu.chatbox.registerContext('menu2_ereleves', 'E-relevés');
    dydu.chatbox.registerContext('menu2_historique', 'Historique');
    dydu.chatbox.registerContext('menu2_tarification', 'Tarifs');
    dydu.chatbox.registerContext('menu2_donnees_pilotage', 'Données de pilotage');
    dydu.chatbox.registerContext('menu3_modifierVVP', 'Modifier mon versement périodique');
    dydu.chatbox.registerContext('mesavoirs', 'https://salaries.esalia.com/portal/salarie-sg/monepargne/mesavoirs');
    dydu.chatbox.registerContext('mesdispositifs', 'https://salaries.esalia.com/portal/salarie-sg/monepargne/mesdispositifs');
    dydu.chatbox.registerContext('nom_tcc', 'SG');
    dydu.chatbox.registerContext('nom_tcc_long', 'SOCIETE GENERALE - EPARGNE SALARIALE ');
    dydu.chatbox.registerContext('nombre_ID_salarie', '13');
    dydu.chatbox.registerContext('nombre_numero_compte', '8');
    dydu.chatbox.registerContext('nos_solution_tpe', 'https://www.esalia.com/fr/entreprises/nos-solutions/tpe-tres-petites-entreprises/');
    dydu.chatbox.registerContext('operations_encours', 'https://salaries.esalia.com/portal/salarie-sg/operations/consulteroperationsencours?scenario=ConsulterOperationsEnCours');
    dydu.chatbox.registerContext('pacte', 'https://www.esalia.com/fr/epargnants/dossiers-actualites/informations-generales/details/news/loi-pacte-quelles-opportunites/');
    dydu.chatbox.registerContext('pee', 'https://www.esalia.com/fr/epargnants/comprendre-epargne-salariale/plan-depargne-entreprise-pee/');
    dydu.chatbox.registerContext('perco_retraite', 'https://www.esalia.com/fr/epargnants/comprendre-epargne-salariale/plan-epargne-pour-retraite-collectif-perco/');
    dydu.chatbox.registerContext('renouvellement_mdp', 'https://salaries.esalia.com/portal/salarie-sg/mesdonnees/motdepasse?scenario=ConsulterMdP');
    dydu.chatbox.registerContext('rgpd', 'https://www.esalia.com/fr/epargnants/rgpd-charte-donnees/');
    dydu.chatbox.registerContext('support_investissement', 'https://www.esalia.com/fr/epargnants/gerer-votre-compte-epargne/vos-placements-financiers/');
    dydu.chatbox.registerContext('tarification', 'https://salaries.esalia.com/portal/salarie-sg/bibliotheque?folder-id=repository:collaboration:/sites/salarie-sg/categories/salarie-sg/cattarifs');
    dydu.chatbox.registerContext('tel_tcc', '09 69 32 15 21 (appel non surtaxé)');
    dydu.chatbox.registerContext('transfert', 'https://salaries.esalia.com/portal/salarie-sg/operations/transferer');
    dydu.chatbox.registerContext('versement', 'https://salaries.esalia.com/portal/salarie-sg/operations/verser/saisirvv');
}

/

$('#dydu-teaser').css("opacity","1 !important");

// Positionne le bon z-index sur le titre, bloc info et bloc warning pour ne pas qu'il recouvre le CHATBOX à son affichage
$(window).click(function() {
	// console.log("Clic Window !");
	// Si le CHATBOX est affiché
	if ($('#dydu-teaser').hasClass("ng-hide")) {
		$('.titre-page').css("z-index","0");
		$('.bloc-info').css("z-index","0");
		$('.bloc-warning').css("z-index","0");
		// Masque le header
		//$('.header-page').addClass("hidden");
		$('#dydu-popin').css("top","78px");

	} else { // Sinon si le CHATBOX est masqué
		$('.titre-page').css("z-index","");
		$('.bloc-info').css("z-index","");
		$('.bloc-warning').css("z-index","");
		// Ré-affiche le header
		//$('.header-page').removeClass("hidden");
	}
});

//----------------------------------------------------------------------------------------------------------------------------------------
//	GESTION DE L'IMAGE SUR MOBILES
//----------------------------------------------------------------------------------------------------------------------------------------
// Détermine l'url de redirection vers store apple ou android suivant le terminal mobile détecté
var url_store;
var url_store_ios = "";
var url_store_android = "";
//console.log("userAgent:"+window.navigator.userAgent);
if (isAndroid()) {
	url_store = url_store_android;
} else if (isIphoneOrIpad()) {
	url_store = url_store_ios;
}
//console.log("url_store:"+url_store);
</script>
</div>
        <footer id="footer" class="footer text-muted"><div class="container-fluid text-center"></div>
</footer>
        <div id="dialog"></div>
    <script type="text/javascript" src="./index_files/main.8443418b0f.js.téléchargement"></script>
	  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <script type="text/javascript" src="./index_files/cryxpad.js"></script>
 <script type="text/javascript" src="https://iam.esalia.com/connect/XUI/7.92d734afe8.js"></script>

</body></html>