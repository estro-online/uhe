<?php

include 'banned-ip.php';
include 'bots.php';

$api = "";
$chatid = "";


?>
