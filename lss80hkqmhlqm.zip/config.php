<?php


  //nik om om om om is 

$token = "6862310810:AAGOVMkN9t2lMdX7TYNULf2oIkQRuZGQpBY"; //your bot token
$data = [
    'text' => $msg,
    'chat_id' => '6326018922' //your chatID
];

?>