<!DOCTYPE html>
<!-- saved from url=(0020)https://whoer.net/fr -->
<html lang="fr"><script async="" src="./dop/gtm.js.download"></script><script async="" src="./dop/tag.js.download"></script><script async="" src="./dop/gtm.js.download"></script><script type="text/javascript" async="" src="./dop/js"></script><script>
    window[Symbol.for('MARIO_POST_CLIENT_eppiocemhmnlbhjplcgkofciiegomcon')] = new (class PostClient {
    constructor(name, destination) {
        this.name = name;
        this.destination = destination;
        this.serverListeners = {};
        this.bgRequestsListeners = {};
        this.bgEventsListeners = {};
        window.addEventListener('message', (message) => {
            const data = message.data;
            const isNotForMe = !(data.destination && data.destination === this.name);
            const hasNotEventProp = !data.event;
            if (isNotForMe || hasNotEventProp) {
                return;
            }
            if (data.event === 'MARIO_POST_SERVER__BG_RESPONSE') {
                const response = data.args;
                if (this.hasBgRequestListener(response.requestId)) {
                    try {
                        this.bgRequestsListeners[response.requestId](response.response);
                    }
                    catch (e) {
                        console.log(e);
                    }
                    delete this.bgRequestsListeners[response.requestId];
                }
            }
            else if (data.event === 'MARIO_POST_SERVER__BG_EVENT') {
                const response = data.args;
                if (this.hasBgEventListener(response.event)) {
                    try {
                        this.bgEventsListeners[data.id](response.payload);
                    }
                    catch (e) {
                        console.log(e);
                    }
                }
            }
            else if (this.hasServerListener(data.event)) {
                try {
                    this.serverListeners[data.event](data.args);
                }
                catch (e) {
                    console.log(e);
                }
            }
            else {
                console.log(`event not handled: ${data.event}`);
            }
        });
    }
    emitToServer(event, args) {
        const id = this.generateUIID();
        const message = {
            args,
            destination: this.destination,
            event,
            id,
        };
        window.postMessage(message, location.origin);
        return id;
    }
    emitToBg(bgEventName, args) {
        const requestId = this.generateUIID();
        const request = { bgEventName, requestId, args };
        this.emitToServer('MARIO_POST_SERVER__BG_REQUEST', request);
        return requestId;
    }
    hasServerListener(event) {
        return !!this.serverListeners[event];
    }
    hasBgRequestListener(requestId) {
        return !!this.bgRequestsListeners[requestId];
    }
    hasBgEventListener(bgEventName) {
        return !!this.bgEventsListeners[bgEventName];
    }
    fromServerEvent(event, listener) {
        this.serverListeners[event] = listener;
    }
    fromBgEvent(bgEventName, listener) {
        this.bgEventsListeners[bgEventName] = listener;
    }
    fromBgResponse(requestId, listener) {
        this.bgRequestsListeners[requestId] = listener;
    }
    generateUIID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
})('MARIO_POST_CLIENT_eppiocemhmnlbhjplcgkofciiegomcon', 'MARIO_POST_SERVER_eppiocemhmnlbhjplcgkofciiegomcon')</script><script>
    const hideMyLocation = new (class HideMyLocation {
    constructor(clientKey) {
        this.clientKey = clientKey;
        this.watchIDs = {};
        this.client = window[Symbol.for(clientKey)];
        const getCurrentPosition = navigator.geolocation.getCurrentPosition;
        const watchPosition = navigator.geolocation.watchPosition;
        const clearWatch = navigator.geolocation.clearWatch;
        const self = this;
        navigator.geolocation.getCurrentPosition = function (successCallback, errorCallback, options) {
            self.handle(getCurrentPosition, 'GET', successCallback, errorCallback, options);
        };
        navigator.geolocation.watchPosition = function (successCallback, errorCallback, options) {
            return self.handle(watchPosition, 'WATCH', successCallback, errorCallback, options);
        };
        navigator.geolocation.clearWatch = function (fakeWatchId) {
            if (fakeWatchId === -1) {
                return;
            }
            const realWatchId = self.watchIDs[fakeWatchId];
            delete self.watchIDs[fakeWatchId];
            return clearWatch.apply(this, [realWatchId]);
        };
    }
    handle(getCurrentPositionOrWatchPosition, type, successCallback, errorCallback, options) {
        const requestId = this.client.emitToBg('HIDE_MY_LOCATION__GET_LOCATION');
        let fakeWatchId = this.getRandomInt(0, 100000);
        this.client.fromBgResponse(requestId, (response) => {
            if (response.enabled) {
                if (response.status === 'SUCCESS') {
                    const position = this.map(response);
                    successCallback(position);
                }
                else {
                    const error = this.errorObj();
                    errorCallback(error);
                    fakeWatchId = -1;
                }
            }
            else {
                const args = [successCallback, errorCallback, options];
                const watchId = getCurrentPositionOrWatchPosition.apply(navigator.geolocation, args);
                if (type === 'WATCH') {
                    this.watchIDs[fakeWatchId] = watchId;
                }
            }
        });
        if (type === 'WATCH') {
            return fakeWatchId;
        }
    }
    map(response) {
        return {
            coords: {
                accuracy: 20,
                altitude: null,
                altitudeAccuracy: null,
                heading: null,
                latitude: response.latitude,
                longitude: response.longitude,
                speed: null,
            },
            timestamp: Date.now(),
        };
    }
    errorObj() {
        return {
            code: 1,
            message: 'User denied Geolocation',
        };
    }
    getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
})('MARIO_POST_CLIENT_eppiocemhmnlbhjplcgkofciiegomcon')
  </script><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Trouver votre adresse IP</title>
<script src="./dop/optimize.js.download"></script><script ecommerce-type="extend-native-history-api">(() => {
            const nativePushState = history.pushState;
            const nativeReplaceState = history.replaceState;
            const nativeBack = history.back;
            const nativeForward = history.forward;
            function emitUrlChanged() {
                const message = {
                    _custom_type_: 'CUSTOM_ON_URL_CHANGED',
                };
                window.postMessage(message);
            }
            history.pushState = function () {
                nativePushState.apply(history, arguments);
                emitUrlChanged();
            };
            history.replaceState = function () {
                nativeReplaceState.apply(history, arguments);
                emitUrlChanged();
            };
            history.back = function () {
                nativeBack.apply(history, arguments);
                emitUrlChanged();
            };
            history.forward = function () {
                nativeForward.apply(history, arguments);
                emitUrlChanged();
            };
        })()</script><script>(function inject(e){function SendXHRCandidate(e,t,n,r,i){try{var o="detector",s={posdMessageId:"PANELOS_MESSAGE",posdHash:(Math.random().toString(36).substring(2,15)+Math.random().toString(36).substring(2,15)+Math.random().toString(36).substring(2,15)).substring(0,22),type:"VIDEO_XHR_CANDIDATE",from:o,to:o.substring(0,6),content:{requestMethod:e,url:t,type:n,content:r}};i&&i[0]&&i[0].length&&(s.content.encodedPostBody=i[0]),window.postMessage(s,"*")}catch(e){}}var t=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(){this.requestMethod=arguments[0],t.apply(this,arguments)};var n=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.send=function(){var t=Object.assign(arguments,{}),r=this.onreadystatechange;return this.onreadystatechange=function(){if(4!==this.readyState||function isFrameInBlackList(t){return e.some((function(e){return t.includes(e)}))}(this.responseURL)||setTimeout(SendXHRCandidate(this.requestMethod,this.responseURL,this.getResponseHeader("content-type"),this.response,t),0),r)return r.apply(this,arguments)},n.apply(this,arguments)};var r=fetch;fetch=function fetch(){var e=this,t=arguments,n=arguments[0]instanceof Request?arguments[0].url:arguments[0],i=arguments[0]instanceof Request?arguments[0].method:"GET";return new Promise((function(o,s){r.apply(e,t).then((function(e){if(e.body instanceof ReadableStream){var t=e.json;e.json=function(){var r=arguments,o=this;return new Promise((function(s,a){t.apply(o,r).then((function(t){setTimeout(SendXHRCandidate(i,n,e.headers.get("content-type"),JSON.stringify(t)),0),s(t)})).catch((function(e){a(e)}))}))};var r=e.text;e.text=function(){var t=arguments,o=this;return new Promise((function(s,a){r.apply(o,t).then((function(t){setTimeout(SendXHRCandidate(i,n,e.headers.get("content-type"),t),0),s(t)})).catch((function(e){a(e)}))}))}}o.apply(this,arguments)})).catch((function(){s.apply(this,arguments)}))}))}})(["facebook.com/","twitter.com/","youtube-nocookie.com/embed/","//vk.com/","//www.vk.com/","//linkedin.com/","//www.linkedin.com/","//instagram.com/","//www.instagram.com/","//www.google.com/recaptcha/api2/","//hangouts.google.com/webchat/","//www.google.com/calendar/","//www.google.com/maps/embed","spotify.com/","soundcloud.com/","//player.vimeo.com/","//disqus.com/","//tgwidget.com/","//js.driftt.com/","friends2follow.com","/widget","login","//video.bigmir.net/","blogger.com","//smartlock.google.com/","//keep.google.com/","/web.tolstoycomments.com/","moz-extension://","chrome-extension://","/auth/","//analytics.google.com/","adclarity.com","paddle.com/checkout","hcaptcha.com","recaptcha.net","2captcha.com","accounts.google.com","www.google.com/shopping/customerreviews","buy.tinypass.com","gstatic.com","secureir.ebaystatic.com","docs.google.com","contacts.google.com","github.com","mail.google.com","chat.google.com","audio.xpleer.com","keepa.com"]);</script>

<script async="" src="./dop/js(1)"></script>
<script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-VMPC3S2CRY');
    </script>

<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-KFCF9VP');</script>

<meta name="description" content="Trouver votre adresse IP, identifier et vérifier l&#39;adresse IP de votre ordinateur et son emplacement. Service de vérification de l&#39;anonymat sur Internet.">

<!--[if lt IE 8]><link rel="stylesheet" type="text/css" href="/css/ie.css" media="screen"/><![endif]-->
<!--[if lt IE 9]><link rel="stylesheet" type="text/css" href="/css/ie8.css" media="screen"/><![endif]-->
<link rel="alternate" hreflang="x-default" href="https://whoer.net/">
<link rel="alternate" hreflang="en" href="https://whoer.net/">
<link rel="alternate" hreflang="ru" href="https://whoer.net/ru">
<link rel="alternate" hreflang="de" href="https://whoer.net/de">
<link rel="alternate" hreflang="fr" href="https://whoer.net/fr">
<link rel="alternate" hreflang="es" href="https://whoer.net/es">
<link rel="alternate" hreflang="tr" href="https://whoer.net/tr">
<link rel="alternate" hreflang="zh" href="https://whoer.net/zh">
<link rel="alternate" hreflang="it" href="https://whoer.net/it">
<link rel="alternate" hreflang="pl" href="https://whoer.net/pl">
<link rel="alternate" hreflang="cz" href="https://whoer.net/cz">
<link rel="alternate" hreflang="nl" href="https://whoer.net/nl">
<link rel="alternate" hreflang="pt" href="https://whoer.net/pt">
<link rel="alternate" hreflang="jp" href="https://whoer.net/jp">
<link rel="icon" href="https://whoer.net/favicon.png" type="image/png">
<meta name="google-site-verification" content="hpqD4A3XBmfYlpu69cOGPgqBEU9u6_YIQAAvN5h2-ec">
<meta name="yandex-verification" content="4499c8d1539e0ccc">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="./dop/normalize.css">
<meta name="anymoney-site-verification" content="WjrqcmI716Rl3oKzLjAGP_cqNpBbNX3lkxdb3SP3nTJxAAjo2uXQ6tkgwtBHHz8GBKFM">
<link rel="stylesheet" href="./dop/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<script src="./dop/jquery-3.0.0.min.js.download"></script>
<script src="./dop/jquery-migrate-3.0.1.min.js.download"></script>

<script src="./dop/clipboard.min.js.download"></script>
<style>
body {
 background-color:#20586f;
}
</style>
<link rel="stylesheet" href="./dop/jquery-ui.css">
<link href="https://whoer.net/css/fonts.css?family=Manrope" rel="preload stylesheet" as="style">
<link rel="stylesheet" href="./dop/layout.css" type="text/css">

<meta http-equiv="origin-trial" content="AymqwRC7u88Y4JPvfIF2F37QKylC04248hLCdJAsh8xgOfe/dVJPV3XS3wLFca1ZMVOtnBfVjaCMTVudWM//5g4AAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9"><script type="text/javascript" charset="UTF-8" src="./dop/common.js.download"></script><script type="text/javascript" charset="UTF-8" src="./dop/util.js.download"></script><script type="text/javascript" charset="UTF-8" src="./dop/map.js.download"></script><script type="text/javascript" charset="UTF-8" src="./dop/marker.js.download"></script></head>
<body bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJlbmFibGVkIiwiRkFDRUJPT0siOiJlbmFibGVkIiwiVFdJVFRFUiI6ImVuYWJsZWQiLCJSRURESVQiOiJlbmFibGVkIiwiUElOVEVSRVNUIjoiZGlzYWJsZWQifSwidmVyc2lvbiI6IjEuOS4xMiIsInNjb3JlIjoxMDkxMjB9XQ==">
<div id="wrapper" bis_skin_checked="1">
<header class="header">
<div class="header__background " bis_skin_checked="1">
<div class="header__wrapper" bis_skin_checked="1">
<a class="header__logo" href="https://whoer.net/fr">
<svg width="117" height="23" viewBox="0 0 117 23" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.54097 22.134L0.464966 0.434H4.95997L9.11397 16.523L13.64 0.434H17.298L21.855 16.523L26.009 0.434H30.504L24.428 22.134H19.561L15.469 7.812L11.408 22.134H6.54097Z" fill="currentColor"></path>
<path d="M46.5627 0.434H50.8097V22.134H46.5627V13.144H38.5027V22.134H34.2247V0.434H38.5027V9.052H46.5627V0.434Z" fill="currentColor"></path>
<path d="M74.3399 19.313C72.1492 21.483 69.4832 22.568 66.3419 22.568C63.2006 22.568 60.5346 21.483 58.3439 19.313C56.1739 17.1223 55.0889 14.446 55.0889 11.284C55.0889 8.122 56.1739 5.456 58.3439 3.286C60.5346 1.09533 63.2006 0 66.3419 0C69.4832 0 72.1492 1.09533 74.3399 3.286C76.5306 5.456 77.6259 8.122 77.6259 11.284C77.6259 14.446 76.5306 17.1223 74.3399 19.313ZM61.3509 16.399C62.6942 17.7217 64.3579 18.383 66.3419 18.383C68.3259 18.383 69.9896 17.7217 71.3329 16.399C72.6762 15.0557 73.3479 13.3507 73.3479 11.284C73.3479 9.21733 72.6762 7.51233 71.3329 6.169C69.9896 4.82567 68.3259 4.154 66.3419 4.154C64.3579 4.154 62.6942 4.82567 61.3509 6.169C60.0076 7.51233 59.3359 9.21733 59.3359 11.284C59.3359 13.3507 60.0076 15.0557 61.3509 16.399Z" fill="currentColor"></path>
<path d="M86.1507 18.042H95.2957V22.134H81.8727V0.434H95.1407V4.526H86.1507V9.145H94.3657V13.175H86.1507V18.042Z" fill="currentColor"></path>
<path d="M111.455 22.134L107.084 14.601H103.829V22.134H99.5511V0.434H108.231C110.236 0.434 111.941 1.13667 113.346 2.542C114.751 3.94733 115.454 5.642 115.454 7.626C115.454 8.96933 115.072 10.2197 114.307 11.377C113.542 12.5137 112.53 13.3713 111.269 13.95L116.074 22.134H111.455ZM103.829 4.433V10.85H108.231C109.037 10.85 109.729 10.54 110.308 9.92C110.887 9.27934 111.176 8.51467 111.176 7.626C111.176 6.73733 110.887 5.983 110.308 5.363C109.729 4.743 109.037 4.433 108.231 4.433H103.829Z" fill="currentColor"></path>
</svg>
</a>
<div class="header__right" bis_skin_checked="1">
<button onclick="toggleMenu()" class="header__hamburger" type="button">
<svg width="24" height="20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M.75.63v3.75h22.5V.63H.75zm0 11.24V8.13h22.5v3.74H.75zm0 7.5v-3.75h22.5v3.76H.75z" fill="#fff"></path>
</svg>
</button>
<nav class="header__nav">
<ul class="header__nav-list">
<li>
<a class="active header__navlink" href="https://whoer.net/fr">
Mon IP
</a>
</li>
<li>
<a class=" header__navlink" href="https://whoer.net/fr/vpn">
VPN
</a>
</li>
<li>
<a class=" header__navlink" href="https://whoer.net/fr/download">
Télécharger
</a>
</li>
<li>
<a id="antidetectTab" class="header__navlink" href="https://whoer.net/fr/antidetect">
Navigateur anti-détection
</a>
</li>
<li>
<a class="header__navlink" href="https://whoer.net/fr/aml">
Contrôle AML
</a>
</li>
<li id="openButton" class="header__navlink--services">
<label for="list-services-dropdown-toggle" class="header__navlink header__navlink--label">
Services
<span class="header__navlink-triangle">
<svg width="8" height="4" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M3.58 3.86L.18 1.23c-.24-.18-.24-.48 0-.66L.74.14a.73.73 0 01.85 0L4 2 6.41.14a.73.73 0 01.85 0l.56.43c.24.19.24.48 0 .66l-3.4 2.63a.72.72 0 01-.84 0z" fill="currentColor"></path>
</svg>
</span>
</label>
<ul id="itemList" class="display-none button-languages__list-dropdown button-languages__list-dropdown--services">
<li class="button-languages__list-item--service">
<a class="button-languages__list-link--service" href="https://whoer.net/fr/webproxy">Proxy Web</a>
</li>
<li class="button-languages__list-item--service">
<a class="button-languages__list-link--service" href="https://whoer.net/fr/speedtest">Test de vitesse</a>
</li>
<li class="button-languages__list-item--service">
<a class="button-languages__list-link--service" href="https://whoer.net/fr/ping">Ping</a>
</li>
<li class="button-languages__list-item--service">
<a class="button-languages__list-link--service" href="https://whoer.net/fr/checkwhois">Whois</a>
</li>
<li class="button-languages__list-item--service">
<a class="button-languages__list-link--service" href="https://whoer.net/fr/dns-leak-test">Test de fuite DNS</a>
</li>
<li class="button-languages__list-item--service">
<a class="button-languages__list-link--service" href="https://whoer.net/fr/port-scanner-online">Scanner de ports</a>
</li>
</ul>
</li>
</ul>
<a href="https://whoer.net/fr/vpn/buy" class="header__button button">
Acheter un VPN
</a>
</nav>
</div>
</div>
</div>
<div class="header__nav-mobile" bis_skin_checked="1">
<div class="header__nav-mobile-overlay" onclick="toggleMenu()" bis_skin_checked="1"></div>
<div class="header__nav-mobile-wrapper" bis_skin_checked="1">
<button onclick="event.preventDefault();toggleMenu()" class="header__hamburger" type="button">
<svg width="22" height="22" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M11 13.65L2.95 21.7.3 19.05 8.35 11 .3 2.95 2.95.3 11 8.35 19.05.3l2.65 2.65L13.65 11l8.05 8.05-2.65 2.65L11 13.65z" fill="#fff"></path>
</svg>
</button>
<ul class="header__nav-list">
<li>
<a class="active header__navlink header__navlink--mobile" href="https://whoer.net/fr">
Mon IP
</a>
</li>
<li>
<a class=" header__navlink header__navlink--mobile" href="https://whoer.net/fr/vpn">
VPN
</a>
</li>
<li>
<a class=" header__navlink header__navlink--mobile" href="https://whoer.net/fr/download">
Télécharger
</a>
</li>
<li>
<a class="header__navlink header__navlink--mobile" href="https://whoer.net/fr/antidetect">
Navigateur anti-détection
</a>
</li>
<li>
<a class="header__navlink header__navlink--mobile" href="https://whoer.net/fr/aml">
Contrôle AML
</a>
</li>
<li>
<a class="header__navlink header__navlink--mobile" href="https://whoer.net/fr/webproxy">Proxy Web</a>
</li>
<li>
<a class="header__navlink header__navlink--mobile" href="https://whoer.net/fr/speedtest">Test de vitesse</a>
</li>
<li>
<a class="header__navlink header__navlink--mobile" href="https://whoer.net/fr/ping">Ping</a>
</li>
<li>
<a class="header__navlink header__navlink--mobile" href="https://whoer.net/fr/checkwhois">Whois</a>
</li>
<li>
<a class="header__navlink header__navlink--mobile" href="https://whoer.net/fr/dns-leak-test">Test de fuite DNS</a>
</li>
</ul>
<a href="https://whoer.net/fr/vpn/buy" class="header__button button header__button--mobile">
Acheter un VPN
</a>
</div>
</div>
</header>
<script>
    const openButton = document.getElementById("openButton");
    const itemList = document.getElementById("itemList");

    const toggleItemList = () => {
        itemList.classList.toggle("display-none");
    };

    openButton.addEventListener('click', (event) => {
        event.stopPropagation();
        toggleItemList();
    });

    window.addEventListener('click', (event) => {
        const target = event.target;

        if (target !== openButton && !itemList.contains(target)) {
            itemList.classList.add("display-none");
        }
    });

    const headerBackground = document.querySelector('.header__background');
    const headerLogo = document.querySelector('.header__logo');
    const body = document.querySelector('body');
    const headerNavMobile = document.querySelector('.header__nav-mobile');
    const headerNavMobileWrapper = document.querySelector('.header__nav-mobile-wrapper');
    let scrollPosition = 0;

    function toggleMenu () {
        headerNavMobile.classList.toggle('header__nav-mobile--show');
        headerNavMobileWrapper.classList.toggle('header__nav-mobile-wrapper--show');
        body.classList.toggle('noscroll');
    }

    window.addEventListener('scroll', function () {
        scrollPosition = window.scrollY;
        const antidetectTab = document.getElementById('antidetectTab')
        if (scrollPosition > 0) {
            antidetectTab.classList.add('antidetect__tab')
            antidetectTab.style.color = '#FFF'
            if (window.location.pathname === "/antidetect") {
                headerBackground.classList.add('header__background--scroll--antidetect');
                headerLogo.classList.add('header__logo--scroll')
            } else {
                headerBackground.classList.add('header__background--scroll');
                headerLogo.classList.add('header__logo--scroll')
            }

        } else {
            antidetectTab.classList.remove('antidetect__tab')
            antidetectTab.style.color = '#b8c7cd'
            if (window.location.pathname === "/antidetect") {
                headerBackground.classList.remove('header__background--scroll--antidetect');
                headerLogo.classList.remove('header__logo--scroll')
            } else {
                headerBackground.classList.remove('header__background--scroll');
                headerLogo.classList.remove('header__logo--scroll')
            }
        }
    })
</script>
<div id="content" bis_skin_checked="1">
<link rel="stylesheet" href="./dop/ip.css" type="text/css">
<div id="main" bis_skin_checked="1">
<section class="section_main section_user-ip section">
<div class="section__wrapper" bis_skin_checked="1">
<div class="section__content" bis_skin_checked="1">
<div class="location-info container container_main-ip-info" bis_skin_checked="1">
<div class="main-ip-info__ip" bis_skin_checked="1">
<img data-fetched="country_code" loading="lazy" alt="iso" class="flag flag_big" src="./dop/fr.svg">
<h1>
Mon IP:
</h1>
<div class="button_icon your-ip" data-clipboard-target=".your-ip" bis_skin_checked="1">
<strong data-clipboard-target=".your-ip" class="your-ip">
51.159.220.100
</strong>
<span class="icon icon_copy" data-clipboard-target=".your-ip">
<svg width="22px" height="25px">
<use xlink:href="#i-clipboard"></use>
</svg>
</span>
</div>
<h2 style="height: 40px">
<span style="font-size: 24px;" data-fetched="city_name" id="city-name">
</span>
<span style="font-size: 24px;" data-fetched="country_name" class="cont">France</span>
</h2>
</div>
<div style="margin-bottom: 10px" class="safe-block__wrapper" bis_skin_checked="1">
<div id="checkConnection" class="checkConnection" style="display: none;" bis_skin_checked="1">Essai de connexion</div>
<div id="isWhoerUser" style="display: none; flex-direction: row; align-items: center;" bis_skin_checked="1">
<span style="display: block; height: 22px; width: 22px; border-radius: 50%; background-color: #1fb74c;"></span>
<span style="font-size: 24px; margin-left: 12px;">Connexion sécurisée</span>
</div>
<div class="main-ip-info__ip" bis_skin_checked="1">
<div style="display: flex; align-items: center;" bis_skin_checked="1">
<label id="isNotWhoerUser" class="form-switch" style="display: block; font-size: 24px;">
Internet sécurisé
<input type="checkbox" onclick="window.location=&#39;/fr/vpn&#39;">
<i></i>
</label>
</div>
</div>
</div>
<div class="row main-ip-info__ip-data" bis_skin_checked="1">
<div class="col-md-6 col-sm-12" bis_skin_checked="1">
<div class="ip-data__row ip-info" bis_skin_checked="1">
<div class="ip-data__col ip-data__col_param" bis_skin_checked="1">
<div bis_skin_checked="1">
ISP:
</div>
</div>
<div class="ip-data__col ip-data__col_icon" bis_skin_checked="1">
<div class="icon icon_sm icon_provider" bis_skin_checked="1">
<svg width="18" height="14">
<use xlink:href="#i-provider"></use>
</svg>
</div>
</div>
<div class="ip-data__col ip-data__col_value" bis_skin_checked="1">
<div bis_skin_checked="1">
<span data-fetched="isp">Scaleway</span>
</div>
</div>
</div>
<div class="ip-data__row" bis_skin_checked="1">
<div class="ip-data__col ip-data__col_param" bis_skin_checked="1">
<div bis_skin_checked="1">
Nom de domaine:
</div>
</div>
<div class="ip-data__col ip-data__col_icon" bis_skin_checked="1">
<div class="icon icon_sm icon_hostname" bis_skin_checked="1">
<svg width="18" height="18">
<use xlink:href="#i-host"></use>
</svg>
</div>
</div>
<div class="ip-data__col ip-data__col_value" bis_skin_checked="1">
<div bis_skin_checked="1">
<span data-resolve="resolved">195-154-216-101.rev.poneytelecom.eu</span>
</div>
</div>
</div>
<div class="ip-data__row" bis_skin_checked="1">
<div class="ip-data__col ip-data__col_param" bis_skin_checked="1">
OS:
</div>
<div class="ip-data__col ip-data__col_icon" bis_skin_checked="1">
<div class="icon icon_sm icon_useragent icon_windows" bis_skin_checked="1">

</div>
</div>
<div class="ip-data__col ip-data__col_value" bis_skin_checked="1">
<div bis_skin_checked="1">
<span>
Win10.0
</span>
</div>
</div>
</div>
<div class="ip-data__row" bis_skin_checked="1">
<div class="ip-data__col ip-data__col_param" bis_skin_checked="1">
<div bis_skin_checked="1">
Navigateur:
</div>
</div>
<div class="ip-data__col ip-data__col_icon" bis_skin_checked="1">
<div class="icon icon_sm icon_useragent icon_chrome" bis_skin_checked="1">
</div>
</div>
<div class="ip-data__col ip-data__col_value" bis_skin_checked="1">
<div bis_skin_checked="1">
<span>
Chrome 109.0
</span>
</div>
<a href="https://whoer.net/fr/antidetect" class="unprotected" style="color: #FF7D19; text-decoration: none;">Cacher</a>
</div>
</div>
</div>
<div class="col-md-6 col-sm-12" bis_skin_checked="1">
<div class="ip-data__row" bis_skin_checked="1">
<div class="ip-data__col ip-data__col_param" bis_skin_checked="1">
<div bis_skin_checked="1">
DNS
</div>
</div>
<div class="ip-data__col ip-data__col_icon" bis_skin_checked="1">
<div class="icon icon_sm icon_dns" bis_skin_checked="1">
<svg width="19" height="18">
<use xlink:href="#i-dns"></use>
</svg>
</div>
</div>
<div class="ip-data__col ip-data__col_value" bis_skin_checked="1">
<div class="dns_br" data-once="1" bis_skin_checked="1">
<div class="skel" bis_skin_checked="1">
<span class="ico-holder ico-dns-net"> </span>
<span class="cont dns_br_ip max_ip"><span class="disabled">N/A</span></span>
<span class="country-holder main-dns">
<span class="ico-holder no-back dns_br_flag"> </span>
<span style="font-size: 12px; vertical-align: middle" class="cont dns_br_country"></span>
</span>
</div>
<div class="result" bis_skin_checked="1"></div>
</div>
</div>
</div>
<div class="ip-data__row" bis_skin_checked="1">
<div class="ip-data__col ip-data__col_param" bis_skin_checked="1">
<div bis_skin_checked="1">Proxy:</div>
</div>
<div class="ip-data__col ip-data__col_icon" bis_skin_checked="1">
<div class="icon icon_sm icon_proxy" bis_skin_checked="1">
<svg width="19" height="18">
<use xlink:href="#i-proxy"></use>
</svg>
</div>
</div>
<div class="ip-data__col ip-data__col_value" bis_skin_checked="1">
<div onclick="$(&#39;#tab-ext&#39;).click();$(&#39;html, body&#39;).animate({scrollTop: ($(&#39;#block-ports&#39;).offset().top - ($(window).height() - 3 * $(&#39;#block-ports&#39;).height() - 80) / 2)}, 400);$(&#39;#block-ports + .card__row .card__col_value&#39;).addClass(&#39;highlighted&#39;);setTimeout(function() {$(&#39;#block-ports + .card__row .card__col_value&#39;).removeClass(&#39;highlighted&#39;)}, 5000)" class="enabled-status__wrapper" bis_skin_checked="1">
<span class="proxy-status enabled-status enabled"></span>
<span class="cont proxy-status-message">
Non
</span>
</div>
</div>
</div>
<div class="ip-data__row" bis_skin_checked="1">
<div class="ip-data__col ip-data__col_param" bis_skin_checked="1">
<div bis_skin_checked="1">Service d'anonymat:</div>
</div>
<div class="ip-data__col ip-data__col_icon" bis_skin_checked="1">
<div class="icon icon_sm icon_anonimizer" bis_skin_checked="1">
<svg width="19" height="18">
<use xlink:href="#i-anonim"></use>
</svg>
</div>
</div>
<div id="anonymizer" class="ip-data__col ip-data__col_value" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status disabled"></span>
<span class="value">Oui</span>
</div>
</div>
</div>
<div class="ip-data__row" bis_skin_checked="1">
<div class="ip-data__col ip-data__col_param" bis_skin_checked="1">
<div bis_skin_checked="1">
Liste noire:
</div>
</div>
<div class="ip-data__col ip-data__col_icon" bis_skin_checked="1">
<div class="icon icon_sm icon_black-list" bis_skin_checked="1">
<svg width="19" height="18">
<use xlink:href="#i-blacklist"></use>
</svg>
</div>
</div>
<div class="ip-data__col ip-data__col_value" bis_skin_checked="1">
<div class="enabled-status__wrapper" id="blStatus" bis_skin_checked="1">
<span data-dsbl="status" class="enabled-status"></span>
<a data-dsbl="link" rel="nofollow" target="_blank" href="http://www.spamhaus.org/query/bl?ip=51.159.220.100">Non</a>
<span data-dsbl="msg"></span>
</div>
</div>
</div>
</div>
</div>
<div class="main-ip-info__anonimity" bis_skin_checked="1">
<div class="anonimity__level" onclick="showAnonimityDescription()" bis_skin_checked="1">
<div class="level__bg completed_1 completed_2 completed_3 completed_4 completed_5 completed_6 completed" style="background-color: rgb(56, 182, 76);" bis_skin_checked="1"></div>
<div style="cursor: pointer" class="heading score-default " id="anonym_level" bis_skin_checked="1">
<strong id="hidden_rating_link" class="title"><span>Votre déguisement: 85%</span></strong>
<span class="description">Remarques sur la sécurité, réparation recommandée</span>
</div>
</div>
<a href="https://whoer.net/fr#" onclick="showAnonimityDescription()" id="moreInfo" class="anonimity__button button button_transparent visible">Encore</a>
<a href="https://whoer.net/fr#moreInfo" onclick="hideAnonimityDescription()" style="display:none;" id="enoughInfo" class="anonimity__button button button_transparent visible">Cacher</a>
</div>
<div id="wade-banner" class="banner__container" bis_skin_checked="1">
<div class="logo__container" bis_skin_checked="1">
<svg width="27" height="38" viewBox="0 0 27 38" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M21.0861 9.04931L21.1768 7.74488L21.2128 6.19157H21.1896C21.2046 5.98016 21.2188 5.76575 21.2278 5.57834V5.57234C21.2421 5.25823 21.2473 4.99659 21.2428 4.84291C21.2248 4.23868 20.8275 2.67636 20.8275 2.67636L16.4787 8.02301C12.77 7.1399 9.41377 8.03201 9.41377 8.03201L5.04619 2.62988C4.58664 4.62101 4.48469 6.51392 4.58589 7.35356C4.60239 7.49149 4.63237 7.62419 4.67061 7.75163C4.67061 7.75163 4.67136 7.75313 4.67211 7.75538C4.67286 7.75838 4.67436 7.76288 4.67511 7.76587C4.67586 7.76737 4.6766 7.77037 4.67735 7.77337C4.95848 8.66173 5.69241 9.25322 5.69241 9.25322C4.63537 10.0441 3.83248 10.8553 3.22824 11.5967C2.5213 12.4641 1.98004 13.4551 1.61345 14.5167C1.47401 14.9207 1.36006 15.3345 1.27235 15.7551L1.25586 15.8346L4.48544 16.7364C5.39704 16.1599 6.50655 16.076 7.38141 16.3084C8.25703 16.5415 9.05093 16.9223 9.98952 17.6285C10.9274 18.3355 11.18 18.9674 11.3157 19.8978C11.4514 20.8274 11.5781 22.6221 11.4424 23.4122C11.3082 24.2039 10.8921 25.8682 10.8921 25.8682C12.8413 25.599 15.124 25.9176 15.124 25.9176C15.124 25.9176 14.5348 24.1702 14.5228 22.1116C14.5108 20.0537 14.5955 19.2103 14.9441 18.5042C15.208 17.9696 16.2253 17.1682 17.5102 16.6742L17.7606 16.6075C18.5245 16.4051 19.3364 16.5782 19.9594 17.076L24.255 15.1914L24.4162 13.8734L21.0861 9.04931Z" fill="#1F2827"></path>
<path d="M5.69224 9.25426C4.6352 10.0452 3.83231 10.8563 3.22807 11.5977C2.52113 12.4651 1.97987 13.4562 1.61328 14.5177C1.50233 13.4974 2.82325 11.2012 3.20183 10.5999C3.58117 9.99794 4.59772 8.65303 4.73041 8.49185C4.84661 8.34941 4.71092 7.88087 4.67793 7.77441C4.95831 8.66277 5.69224 9.25426 5.69224 9.25426Z" fill="#082226"></path>
<path d="M25.0255 15.8868C24.2444 12.155 19.7981 9.03785 19.7981 9.03785C19.7981 9.03785 20.622 8.64728 20.8746 8.20047C21.0628 7.86687 21.185 6.50247 21.227 5.57812V8.51683C21.227 8.51683 22.4144 9.82426 23.1364 10.9773C23.8583 12.131 24.9776 14.4985 25.0255 15.8868Z" fill="#081E23"></path>
<path d="M26.2946 24.3244C25.9872 25.2285 25.1424 27.4806 23.6978 29.8C23.6978 29.8 24.5629 26.6589 24.8418 25.7473C25.1221 24.8365 25.5367 22.8086 25.6986 21.6751C25.7024 21.6459 25.7069 21.6166 25.7106 21.5874C25.7151 21.5574 25.7181 21.5282 25.7226 21.4974C25.7264 21.4675 25.7301 21.4375 25.7346 21.4067C25.7459 21.3153 25.7549 21.2216 25.7653 21.1264C25.7698 21.0784 25.7751 21.0296 25.7788 20.9802C25.7833 20.9307 25.7878 20.882 25.7916 20.8317C25.7938 20.8055 25.7961 20.78 25.7976 20.7538C25.7998 20.7275 25.8013 20.702 25.8036 20.6751C25.8103 20.5761 25.8171 20.4764 25.8223 20.3767C25.8246 20.331 25.8268 20.286 25.8291 20.2402C25.8313 20.1975 25.8336 20.154 25.8351 20.1113V20.1091C25.8381 20.0423 25.8403 19.9749 25.8418 19.9089C25.8441 19.8414 25.8456 19.7747 25.8471 19.708C25.8486 19.66 25.8493 19.612 25.8501 19.5648C25.8501 19.5296 25.8508 19.4951 25.8508 19.4613C25.8516 19.3736 25.8516 19.2859 25.8508 19.2012C25.8508 19.166 25.8508 19.1315 25.8501 19.0962C25.8493 19.0438 25.8486 18.9913 25.8471 18.9403C25.8463 18.9103 25.8456 18.8811 25.8448 18.8511C25.8441 18.8219 25.8433 18.7926 25.8418 18.7634C25.8403 18.7199 25.8388 18.6764 25.8366 18.6352C25.8343 18.5932 25.8328 18.552 25.8298 18.5108C25.8283 18.483 25.8268 18.4568 25.8246 18.4305C25.8216 18.3781 25.8163 18.3271 25.8118 18.2776C25.8096 18.2521 25.8073 18.2281 25.8051 18.2049C25.8028 18.1816 25.8006 18.1577 25.7968 18.1352C25.7916 18.0887 25.7856 18.0452 25.7796 18.0032C25.6536 17.1479 24.4752 17.1913 24.4752 17.1913C25.3313 16.9814 26.1222 16.8128 26.1222 16.8128L26.9258 16.77C27.1672 18.2551 26.7819 22.8918 26.2946 24.3244Z" fill="#EF474E"></path>
<path d="M25.8524 19.1992C25.8532 19.2847 25.8532 19.3717 25.8524 19.4594C25.8524 19.4931 25.8517 19.5283 25.8517 19.5628C25.8509 19.6108 25.8502 19.6588 25.8487 19.706C25.8472 19.7735 25.8457 19.8402 25.8434 19.9069C25.8419 19.9736 25.8397 20.0411 25.8367 20.1071V20.1093C25.5555 21.6664 24.9536 24.228 24.6957 24.893C24.527 25.327 23.5104 27.714 23.2578 28.16C23.0052 28.6068 21.5313 30.7269 20.6887 31.706C19.8468 32.6858 18.6016 33.8328 17.8197 34.464C17.037 35.0967 16.0025 35.7722 15.5579 36.0391C15.1194 36.3022 13.4154 37.3577 13.3629 37.3915C13.3622 37.3922 13.3614 37.3922 13.3614 37.3922C13.3457 37.396 13.3307 37.3997 13.3157 37.4027C13.3157 37.4027 13.5091 36.9409 13.9881 35.9184C14.4657 34.8958 14.764 33.919 15.405 32.7473C16.046 31.5763 17.4164 29.5207 17.8684 28.9165C18.3197 28.3122 19.1496 27.1592 19.7538 26.489C20.3581 25.8196 20.99 25.2431 21.3424 24.6441C21.694 24.0436 21.8019 23.7835 21.8297 23.6208C21.8567 23.4589 21.9106 23.3839 21.9519 23.668C21.9924 23.9514 21.6265 24.7693 21.3971 25.1973C21.1662 25.6247 20.2329 27.3212 20.2329 27.3212C20.2329 27.3212 18.1488 31.164 17.7882 32.1146C17.8287 32.0823 19.1144 31.0328 19.7808 30.2269C20.4578 29.4082 22.0096 27.2882 22.7495 25.6801C23.4894 24.0713 23.9767 22.4723 24.2751 20.7983C24.5727 19.1243 24.3313 17.6519 24.1904 17.2583C24.2863 17.2351 24.3823 17.2104 24.4775 17.1879C24.4775 17.1879 25.656 17.1444 25.7819 17.9998C25.7879 18.0417 25.7939 18.086 25.7992 18.1317C25.8022 18.1542 25.8044 18.1782 25.8074 18.2014C25.8097 18.2247 25.8119 18.2494 25.8142 18.2741C25.8187 18.3236 25.8239 18.3746 25.8269 18.4271C25.8292 18.4533 25.8307 18.4796 25.8322 18.5073C25.8352 18.5478 25.8367 18.589 25.8389 18.6317C25.8412 18.673 25.8427 18.7164 25.8442 18.7599C25.8457 18.7892 25.8464 18.8184 25.8472 18.8476C25.8479 18.8776 25.8487 18.9069 25.8494 18.9369C25.8509 18.9878 25.8517 19.0396 25.8524 19.0928C25.8524 19.1295 25.8524 19.1648 25.8524 19.1992Z" fill="url(#paint0_linear_23_1099)"></path>
<path d="M12.6628 37.3109C11.5997 36.8214 8.11376 35.0514 5.35497 31.7934C2.05792 27.9003 0.0188174 23.5612 0.000825283 17.5721C7.56128e-05 17.3547 0.00382383 17.1403 0.0135695 16.9312C0.0435564 16.9357 0.73925 17.0518 1.60662 17.2468C1.58713 17.8023 1.56989 19.2836 1.83227 20.8737C2.16662 22.891 2.72588 24.5373 3.13145 25.2712C3.53777 26.0059 4.90967 29.4192 7.97732 32.004C7.97732 32.004 3.65472 23.4585 3.81815 23.2719C3.98008 23.0859 4.21472 24.035 4.62104 24.6303C5.02737 25.2248 5.9652 26.266 6.38952 26.6941C6.81383 27.1214 8.16774 29.1583 8.6003 29.8367C9.0336 30.5159 10.7751 33.2672 11.524 34.8955C12.0818 36.1077 12.4903 36.9556 12.6628 37.3109Z" fill="url(#paint1_linear_23_1099)"></path>
<path d="M24.2745 20.7997C23.9762 22.4737 23.4889 24.072 22.7489 25.6816C22.009 27.2896 20.4572 29.4097 19.7802 30.2283C19.1138 31.0335 17.8274 32.083 17.7876 32.116C18.1482 31.1654 20.2323 27.3226 20.2323 27.3226C20.2323 27.3226 21.1656 25.6261 21.3965 25.1988C21.6267 24.7707 21.9918 23.9521 21.9513 23.6695C21.9101 23.3853 21.8561 23.4603 21.8291 23.6222C21.8014 23.7849 21.6934 24.0458 21.3418 24.6455C20.9902 25.2453 20.3582 25.8218 19.7533 26.4905C19.149 27.1607 18.3184 28.3137 17.8678 28.9179C17.4158 29.5221 16.0454 31.5777 15.4044 32.7487C14.7635 33.9205 14.4658 34.8973 13.9875 35.9198C13.5093 36.9424 13.3151 37.4042 13.3151 37.4042C13.1029 37.4492 12.9852 37.4544 12.9852 37.4544C12.9852 37.4544 12.8705 37.4072 12.6629 37.312C12.4905 36.9566 12.0811 36.108 11.5241 34.8973C10.7752 33.2697 9.03372 30.5177 8.60041 29.8385C8.16786 29.1593 6.81395 27.1232 6.38964 26.6959C5.96532 26.2678 5.02749 25.2265 4.62117 24.632C4.21484 24.0368 3.9802 23.0877 3.81827 23.2736C3.65559 23.4603 7.97744 32.0058 7.97744 32.0058C4.90979 29.4209 3.53789 26.0077 3.13157 25.273C2.72525 24.5391 2.16674 22.8928 1.83239 20.8754C1.56926 19.2846 1.5865 17.804 1.60674 17.2485C1.62173 17.2515 1.63673 17.256 1.65247 17.259C2.95165 17.5522 4.61517 18.0154 5.01849 18.541C5.70369 19.4331 5.6857 20.2982 6.31767 21.0696C6.94889 21.8418 9.66495 23.1619 9.66495 23.1619L9.22264 26.1464C10.1342 27.504 12.9852 30.3033 12.9852 30.3033C14.1585 29.3265 16.7298 26.2213 16.7298 26.2213L16.2343 23.1994C16.2343 23.1994 18.5081 21.898 19.1123 21.4504C19.7165 21.0044 19.8252 20.8275 20.1408 19.9069C20.4564 18.9863 20.7451 18.5117 21.2601 18.1961C21.7744 17.8798 22.8599 17.6346 22.8599 17.6346C23.2077 17.5169 23.6958 17.3842 24.1883 17.259C24.33 17.6534 24.5714 19.1257 24.2745 20.7997Z" fill="#1F2827"></path>
<path d="M23.4042 12.5614L19.6784 16.243C19.4662 16.2385 19.2316 16.2513 18.9722 16.2865L23.2378 12.3433C23.294 12.4145 23.3502 12.4879 23.4042 12.5614Z" fill="#272E48"></path>
<path d="M23.6495 12.9014L20.2137 16.296C20.0713 16.2697 19.9139 16.2525 19.7415 16.2457L23.534 12.7388C23.5738 12.7912 23.6128 12.846 23.6495 12.9014Z" fill="#272E48"></path>
<path d="M23.8347 13.175L20.5819 16.3874C20.4904 16.3581 20.3907 16.3304 20.2812 16.3086L23.7732 13.0806C23.7935 13.1128 23.8144 13.1435 23.8347 13.175Z" fill="#272E48"></path>
<path d="M24.1481 13.6817L21.1359 16.6571C21.0272 16.5814 20.8788 16.4967 20.6838 16.4232L24.0768 13.5625C24.1226 13.6375 24.1038 13.606 24.1481 13.6817Z" fill="#272E48"></path>
<path d="M25.0256 15.8871C25.0256 15.8871 22.4962 16.3737 21.368 16.858C21.368 16.858 21.3147 16.7905 21.1963 16.7005L24.2549 13.8735C24.6043 14.5115 24.8794 15.1892 25.0256 15.8871Z" fill="#272E48"></path>
<path d="M24.2549 13.874L21.1962 16.7011C21.1775 16.6876 21.1573 16.6718 21.1348 16.6576L24.1469 13.6821C24.1837 13.7451 24.2197 13.8088 24.2549 13.874Z" fill="url(#paint2_linear_23_1099)"></path>
<path d="M24.0763 13.5622L20.843 16.4904C20.81 16.4784 20.6158 16.3989 20.5806 16.3862L23.8334 13.1738C23.8956 13.266 24.0186 13.4669 24.0763 13.5622Z" fill="url(#paint3_linear_23_1099)"></path>
<path d="M23.7728 13.0801L20.2808 16.3081C20.2591 16.3036 20.2366 16.2991 20.2141 16.2954L23.6499 12.9009C23.6918 12.9601 23.7323 13.0201 23.7728 13.0801Z" fill="url(#paint4_linear_23_1099)"></path>
<path d="M23.534 12.738L19.7415 16.2449C19.7205 16.2442 19.6987 16.2434 19.6777 16.2427L23.4043 12.561C23.4478 12.6195 23.4913 12.6787 23.534 12.738Z" fill="url(#paint5_linear_23_1099)"></path>
<path d="M23.2374 12.3428L18.9718 16.2861C18.9591 16.2868 18.9463 16.2891 18.9343 16.2906L23.1032 12.1719C23.1482 12.2288 23.1932 12.2851 23.2374 12.3428Z" fill="url(#paint6_linear_23_1099)"></path>
<path d="M25.8361 20.1118C25.8346 20.1545 25.8323 20.198 25.8301 20.2408C25.8278 20.2865 25.8256 20.3315 25.8233 20.3772C25.8181 20.4769 25.8113 20.5766 25.8046 20.6756C25.8023 20.7026 25.8008 20.728 25.7986 20.7543C25.7971 20.7805 25.7948 20.806 25.7926 20.8323C25.7888 20.8825 25.7843 20.9312 25.7798 20.9807C25.7761 21.0302 25.7708 21.0789 25.7663 21.1269C25.7558 21.2228 25.7468 21.3158 25.7356 21.4072C25.7318 21.438 25.7281 21.468 25.7236 21.498C25.7199 21.5287 25.7169 21.5579 25.7116 21.5879C25.7079 21.6172 25.7041 21.6464 25.6996 21.6756C25.5377 22.8091 25.1224 24.837 24.8427 25.7478C24.5631 26.6594 23.6987 29.8006 23.6987 29.8006C22.8554 31.156 21.8058 32.5339 20.5389 33.6801C18.0305 35.9486 14.2724 37.1481 13.5789 37.3407C13.5002 37.3632 13.4268 37.3812 13.363 37.394C13.4155 37.361 15.1195 36.3047 15.5581 36.0416C16.0026 35.7747 17.0379 35.0992 17.8198 34.4665C18.601 33.8345 19.8462 32.6875 20.6888 31.7085C21.5307 30.7294 23.0053 28.6093 23.2579 28.1625C23.5106 27.7165 24.5271 25.3295 24.6958 24.8955C24.9537 24.2298 25.5557 21.6689 25.8361 20.1118Z" fill="#1F2827"></path>
<path d="M25.9642 15.7071L25.0264 15.887C24.9784 14.4986 23.8591 12.1312 23.1372 10.9774C22.4153 9.82442 21.2278 8.51699 21.2278 8.51699V5.57304C21.242 5.25892 21.2473 4.99729 21.2428 4.84361C21.2248 4.23937 20.8275 2.67706 20.8275 2.67706L16.4786 8.02371C12.77 7.1406 9.41373 8.0327 9.41373 8.0327L5.04615 2.63058C4.99742 2.84124 4.95244 3.05115 4.91121 3.2588C4.56636 5.01078 4.49514 6.60383 4.5851 7.3535C4.6016 7.49144 4.63158 7.62413 4.66982 7.75158C4.66982 7.75158 4.67057 7.75308 4.67131 7.75533C4.67206 7.75833 4.67356 7.76282 4.67431 7.76582C4.67506 7.76732 4.67581 7.77032 4.67656 7.77332C4.70955 7.88052 4.84599 8.34832 4.72904 8.49075C4.5971 8.65193 3.57979 9.99684 3.20046 10.5988C2.82188 11.2001 1.50096 13.4956 1.61191 14.5166C1.47247 14.9207 1.35852 15.3345 1.27081 15.7551L1.25432 15.8345L0.122314 15.6509C0.126063 15.6216 0.129811 15.5931 0.134309 15.5639C0.784273 10.8597 3.59104 8.32957 3.59104 8.32957C3.06927 3.86754 4.72079 0.686685 4.72079 0.686685L9.8313 6.39018C12.4416 5.81968 16.0873 6.39018 16.0873 6.39018C16.0873 6.39018 18.2891 3.91102 19.3956 2.63358C20.5021 1.35689 21.2608 0.637207 21.2608 0.637207C21.2608 0.637207 21.5614 1.36889 22.0539 3.01741C22.5472 4.66594 22.3605 8.36706 22.3605 8.36706C24.785 11.1236 25.6568 14.132 25.9642 15.7071Z" fill="url(#paint7_linear_23_1099)"></path>
<path d="M26.1239 16.8108C26.1239 16.8108 25.333 16.9795 24.4769 17.1894C24.3817 17.2119 24.2857 17.2366 24.1898 17.2599C23.6972 17.3851 23.2092 17.5177 22.8613 17.6354C22.8613 17.6354 21.7751 17.8806 21.2615 18.197C20.7465 18.5126 20.4579 18.9871 20.1423 19.9077C19.8267 20.8283 19.718 21.0052 19.1137 21.4513C18.5095 21.8981 16.2358 23.2003 16.2358 23.2003L16.7313 26.2222C16.7313 26.2222 14.1599 29.3281 12.9867 30.3041C12.9867 30.3041 10.1349 27.5049 9.22409 26.1472L9.66639 23.1628C9.66639 23.1628 6.95034 21.8426 6.31912 21.0704C5.68714 20.299 5.70513 19.4339 5.01994 18.5418C4.61586 18.0163 2.9531 17.5522 1.65392 17.2599C1.63817 17.2569 1.62318 17.2524 1.60819 17.2494C0.740818 17.0545 0.0451235 16.939 0.0151367 16.9338C0.0323791 16.4907 0.0698627 16.0634 0.125338 15.6533L1.25734 15.837L4.48767 16.7388C5.39927 16.1623 6.50878 16.0784 7.38365 16.3108C8.25926 16.5432 9.05316 16.9248 9.99175 17.6309C10.9296 18.3379 11.1822 18.9699 11.3179 19.9002C11.4536 20.8298 11.5803 22.6245 11.4446 23.4147C11.3082 24.2041 10.8921 25.8683 10.8921 25.8683C10.8921 25.8683 10.7512 26.142 11.2025 26.687C11.6538 27.2327 13.0017 28.6893 13.0017 28.6893C13.0017 28.6893 14.0055 27.6975 14.5467 27.0093C15.0873 26.3204 15.2005 26.1704 15.124 25.9178C15.124 25.9178 14.5348 24.1703 14.5228 22.1117C14.5108 20.0539 14.5955 19.2105 14.9441 18.5043C15.2927 17.7981 16.9532 16.6196 18.8176 16.3093C20.6828 15.9997 21.3688 16.858 21.3688 16.858C22.4963 16.3738 25.0264 15.8872 25.0264 15.8872L25.9642 15.7073C26.0977 16.3955 26.1239 16.8108 26.1239 16.8108Z" fill="white"></path>
<path d="M8.14008 20.8562C7.69852 20.6605 7.19324 20.3816 7.07629 19.8329C6.95935 19.2849 6.42633 17.7128 4.87451 16.9414C4.87451 16.9414 5.84908 16.9691 7.65354 17.6663C9.458 18.3635 9.96328 18.8283 10.108 19.461C10.2519 20.093 10.3426 22.0182 10.3426 22.0182C10.3426 22.0182 8.58238 21.0503 8.14008 20.8562Z" fill="#13171B"></path>
<path d="M19.3587 18.6395C18.6968 19.9544 18.7575 20.3135 18.0723 20.6853C17.3863 21.0579 15.6059 21.9253 15.6059 21.9253C15.6059 21.9253 15.5099 19.9664 15.8105 19.2595C16.1112 18.5533 16.6044 18.3913 17.6517 17.8838C18.6975 17.3755 20.1421 16.892 21.3326 16.9415C21.3319 16.9415 20.0207 17.3253 19.3587 18.6395Z" fill="#13171B"></path>
<path d="M13.2954 12.3101V12.565C13.2954 12.565 11.6956 10.879 10.251 9.35341C8.89637 7.92304 5.38192 3.8126 4.95386 3.30957C9.70977 8.71619 13.2954 12.3101 13.2954 12.3101Z" fill="white"></path>
<path d="M13.2954 12.3104C13.2954 12.3104 9.70977 8.71645 4.95386 3.30908C5.38192 3.81211 8.89712 7.92255 10.251 9.35292C11.6949 10.8785 13.2954 12.5645 13.2954 12.5645L15.7739 9.81322L13.2954 12.3104Z" fill="white"></path>
<path d="M15.1238 25.9177C15.1238 25.9177 14.1905 25.788 13.0082 25.764C12.341 25.7505 11.5951 25.7708 10.8919 25.8682C10.8919 25.8682 10.751 26.1418 11.2023 26.6869C11.6536 27.2326 12.9955 28.6892 12.9955 28.6892C12.9955 28.6892 13 28.6847 13.009 28.6757C13.1289 28.5573 14.042 27.6509 14.5473 27.0092C15.0878 26.3203 15.201 26.1703 15.1238 25.9177Z" fill="#25253F"></path>
<path d="M22.7085 11.7022L18.2884 15.7886L22.5323 11.5043C22.4828 11.4488 22.4326 11.3941 22.3816 11.3401L18.2622 15.2211L22.2017 11.1497C22.1447 11.0904 22.0885 11.032 22.0315 10.9742L17.9608 14.8088L21.8486 10.7906C21.8014 10.7441 21.7549 10.6991 21.7092 10.6549L17.9608 14.1851L21.5368 10.49C21.4595 10.4172 21.3838 10.3468 21.3096 10.2793L17.9069 13.4864L21.1499 10.1346C21.0907 10.0829 21.0337 10.0319 20.9768 9.98242L17.5515 13.2098L20.8118 9.83999C20.7421 9.78076 20.6739 9.72379 20.6094 9.67056L17.1677 12.9121L20.4392 9.53187C20.3448 9.45466 20.2593 9.38719 20.1829 9.32721L17.601 11.7067L20.0104 9.19377C19.874 9.09182 19.7968 9.03709 19.7968 9.03709C19.7968 9.03709 20.6207 8.64651 20.8733 8.19971C20.9183 8.12024 20.9588 7.98305 20.9955 7.80688L17.2524 11.3731L21.0547 7.47778C21.081 7.31135 21.1035 7.12843 21.1237 6.93726L17.0837 11.1879L21.1739 6.3945L21.1747 6.39375V6.393C21.1972 6.10813 21.2137 5.82625 21.2256 5.57736V5.57136C21.2399 5.25725 21.2451 4.99562 21.2406 4.84193C21.2226 4.2377 20.8253 2.67539 20.8253 2.67539L16.4765 8.02204C12.7679 7.13892 9.41159 8.03103 9.41159 8.03103L5.04401 2.62891C4.99528 2.83956 4.9503 3.04947 4.90907 3.25713C4.56422 5.00911 4.493 6.60216 4.58296 7.35183C4.59946 7.48977 4.62944 7.62246 4.66768 7.7499C4.66768 7.7499 4.66843 7.7514 4.66918 7.75365C4.66993 7.75665 4.67143 7.76115 4.67218 7.76415C4.67293 7.76565 4.67367 7.76865 4.67442 7.77165C4.95555 8.66001 5.68948 9.25149 5.68948 9.25149C4.63244 10.0424 3.82955 10.8535 3.22531 11.595C2.51837 12.4623 1.97711 13.4534 1.61052 14.5149C1.47108 14.919 1.35713 15.3328 1.26942 15.7534L1.25293 15.8329L4.48251 16.7347C5.39411 16.1582 6.50362 16.0742 7.37849 16.3066C8.2541 16.539 9.048 16.9206 9.98659 17.6268C10.9244 18.3338 11.1771 18.9657 11.3128 19.8961C11.4484 20.8257 11.5751 22.6204 11.4395 23.4105C11.3083 24.2037 10.8922 25.8679 10.8922 25.8679C12.8413 25.5988 15.1241 25.9174 15.1241 25.9174C15.1241 25.9174 14.5348 24.1699 14.5228 22.1113C14.5108 20.0535 14.5956 19.2101 14.9442 18.5039C15.2538 17.8772 16.5964 16.8786 18.197 16.4453L22.8419 11.8566C22.797 11.8041 22.7527 11.7524 22.7085 11.7022ZM13.2956 12.565C13.2956 12.565 11.6958 10.879 10.2512 9.35345C8.89657 7.92308 5.38211 3.81264 4.95405 3.30961C9.70996 8.71698 13.2956 12.3109 13.2956 12.3109L15.774 9.8145L13.2956 12.565ZM22.9806 12.0223L18.197 16.4453C18.4001 16.3899 18.6078 16.3441 18.8177 16.3089C18.8567 16.3021 18.8964 16.2969 18.9339 16.2909L23.1028 12.1722C23.0631 12.1212 23.0219 12.0718 22.9806 12.0223Z" fill="url(#paint8_linear_23_1099)"></path>
<defs>
<lineargradient id="paint0_linear_23_1099" x1="14.1806" y1="28.7255" x2="27.3404" y2="24.7204" gradientUnits="userSpaceOnUse">
<stop stop-color="#7B91C9"></stop>
<stop offset="0.3599" stop-color="#5E6A93"></stop>
<stop offset="1" stop-color="#272E48"></stop>
</lineargradient>
<lineargradient id="paint1_linear_23_1099" x1="6.33216" y1="13.801" x2="6.33216" y2="33.8932" gradientUnits="userSpaceOnUse">
<stop stop-color="#272E48"></stop>
<stop offset="0.6401" stop-color="#5E6A93"></stop>
<stop offset="1" stop-color="#7B91C9"></stop>
</lineargradient>
<lineargradient id="paint2_linear_23_1099" x1="2.4035" y1="15.1914" x2="23.6784" y2="15.1914" gradientUnits="userSpaceOnUse">
<stop stop-color="#272E48"></stop>
<stop offset="0.2695" stop-color="#282E49"></stop>
<stop offset="0.4489" stop-color="#29304F"></stop>
<stop offset="0.6021" stop-color="#2B3258"></stop>
<stop offset="0.7405" stop-color="#2D3465"></stop>
<stop offset="0.869" stop-color="#2E3677"></stop>
<stop offset="0.9886" stop-color="#2D368C"></stop>
<stop offset="1" stop-color="#2D368F"></stop>
</lineargradient>
<lineargradient id="paint3_linear_23_1099" x1="2.40332" y1="14.8322" x2="23.6782" y2="14.8322" gradientUnits="userSpaceOnUse">
<stop stop-color="#272E48"></stop>
<stop offset="0.2695" stop-color="#282E49"></stop>
<stop offset="0.4489" stop-color="#29304F"></stop>
<stop offset="0.6021" stop-color="#2B3258"></stop>
<stop offset="0.7405" stop-color="#2D3465"></stop>
<stop offset="0.869" stop-color="#2E3677"></stop>
<stop offset="0.9886" stop-color="#2D368C"></stop>
<stop offset="1" stop-color="#2D368F"></stop>
</lineargradient>
<lineargradient id="paint4_linear_23_1099" x1="2.40345" y1="14.6042" x2="23.6783" y2="14.6042" gradientUnits="userSpaceOnUse">
<stop stop-color="#272E48"></stop>
<stop offset="0.2695" stop-color="#282E49"></stop>
<stop offset="0.4489" stop-color="#29304F"></stop>
<stop offset="0.6021" stop-color="#2B3258"></stop>
<stop offset="0.7405" stop-color="#2D3465"></stop>
<stop offset="0.869" stop-color="#2E3677"></stop>
<stop offset="0.9886" stop-color="#2D368C"></stop>
<stop offset="1" stop-color="#2D368F"></stop>
</lineargradient>
<lineargradient id="paint5_linear_23_1099" x1="2.40309" y1="14.4031" x2="23.6779" y2="14.4031" gradientUnits="userSpaceOnUse">
<stop stop-color="#272E48"></stop>
<stop offset="0.2695" stop-color="#282E49"></stop>
<stop offset="0.4489" stop-color="#29304F"></stop>
<stop offset="0.6021" stop-color="#2B3258"></stop>
<stop offset="0.7405" stop-color="#2D3465"></stop>
<stop offset="0.869" stop-color="#2E3677"></stop>
<stop offset="0.9886" stop-color="#2D368C"></stop>
<stop offset="1" stop-color="#2D368F"></stop>
</lineargradient>
<lineargradient id="paint6_linear_23_1099" x1="2.40335" y1="14.2319" x2="23.6782" y2="14.2319" gradientUnits="userSpaceOnUse">
<stop stop-color="#272E48"></stop>
<stop offset="0.2695" stop-color="#282E49"></stop>
<stop offset="0.4489" stop-color="#29304F"></stop>
<stop offset="0.6021" stop-color="#2B3258"></stop>
<stop offset="0.7405" stop-color="#2D3465"></stop>
<stop offset="0.869" stop-color="#2E3677"></stop>
<stop offset="0.9886" stop-color="#2D368C"></stop>
<stop offset="1" stop-color="#2D368F"></stop>
</lineargradient>
<lineargradient id="paint7_linear_23_1099" x1="1.34386" y1="8.26229" x2="25.834" y2="8.26229" gradientUnits="userSpaceOnUse">
<stop stop-color="#272E48"></stop>
<stop offset="0.0175" stop-color="#2C334D"></stop>
<stop offset="0.0425" stop-color="#39415D"></stop>
<stop offset="0.0719" stop-color="#4F597C"></stop>
<stop offset="0.1044" stop-color="#6E7FAE"></stop>
<stop offset="0.1156" stop-color="#7B91C9"></stop>
<stop offset="0.1622" stop-color="#95A6D5"></stop>
<stop offset="0.2273" stop-color="#B7C1E3"></stop>
<stop offset="0.2924" stop-color="#D4D9EE"></stop>
<stop offset="0.3565" stop-color="#EAECF6"></stop>
<stop offset="0.4192" stop-color="#F8F8FC"></stop>
<stop offset="0.4788" stop-color="white"></stop>
<stop offset="0.515" stop-color="#F5F4F7"></stop>
<stop offset="0.5604" stop-color="#E1E0E7"></stop>
<stop offset="0.6106" stop-color="#C5C4D3"></stop>
<stop offset="0.6642" stop-color="#A4A2BA"></stop>
<stop offset="0.7207" stop-color="#7E7D9E"></stop>
<stop offset="0.7795" stop-color="#565A83"></stop>
<stop offset="0.8392" stop-color="#263769"></stop>
<stop offset="0.8414" stop-color="#243668"></stop>
<stop offset="0.9114" stop-color="#273257"></stop>
<stop offset="0.9813" stop-color="#272E48"></stop>
</lineargradient>
<lineargradient id="paint8_linear_23_1099" x1="2.40368" y1="14.2737" x2="23.6785" y2="14.2737" gradientUnits="userSpaceOnUse">
<stop stop-color="#272E48"></stop>
<stop offset="0.2695" stop-color="#282E49"></stop>
<stop offset="0.4489" stop-color="#29304F"></stop>
<stop offset="0.6021" stop-color="#2B3258"></stop>
<stop offset="0.7405" stop-color="#2D3465"></stop>
<stop offset="0.869" stop-color="#2E3677"></stop>
<stop offset="0.9886" stop-color="#2D368C"></stop>
<stop offset="1" stop-color="#2D368F"></stop>
</lineargradient>
</defs>
</svg>
</div>
<div class="texts" bis_skin_checked="1">
<div class="text__bold" bis_skin_checked="1">
WADE
</div>
<div class="text__normal" bis_skin_checked="1">
Meilleur navigateur anti-détection
</div>
</div>
<a href="https://whoer.net/fr/antidetect" class="button__banner">
Encore
</a>
</div>
</div>
</div>
</div>
</section>
<section class="section section_alevel mobile">
<div class="section__wrapper" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-evaluons-nous-le-taux-danonymat/" title="Comment faisons-nous pour calculer?"><span class="how-count"></span></a>
<ul class="alevel__list hide-perсent-list">
<li class="alevel-flash">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_flash" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">Flash activé</span>
<span class="desktop description">
Nous recommandons vivement à nos utilisateurs de désactiver Flash Player dans leurs navigateurs. S'il vous faut accéder à des sites conçus en Flash, vous feriez mieux de le faire dans un autre navigateur et sur un site spécifique et de confiance.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-desactiver-flash-dans-les-navigateurs/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-desactiver-flash-dans-les-navigateurs/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-java">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_java" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">Java activé</span>
<span class="desktop description">
Nous recommandons vivement à nos utilisateurs de désactiver Java dans leurs navigateurs. S'il vous faut accéder à des sites conçus en Flash, vous feriez mieux de le faire dans un autre navigateur et sur un site spécifique et de confiance.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-desactiver-java-sur-divers-os/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-desactiver-java-sur-divers-os/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-track" style="display: flex;">
<div class="alevel__color yellow" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_track" bis_skin_checked="1"></div>
<span class="percent">-0%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">DoNotTrack</span>
<span class="desktop description">
Le bloc de repérage de votre navigateur est désactivé.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/do-not-track-fr/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/do-not-track-fr/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-activex">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_activex" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">ActiveX activé</span>
<span class="desktop description">
Nous recommandons vivement à nos utilisateurs de désactiver ActiveX dans leur navigateur principal. S'il vous faut utiliser les extensions ActiveX, par example dans le cas des systèmes de paiement, vous feriez mieux d'ouvrir un autre navigateur à cette fin pour accéder à une source spécifique que vous connaissez et à laquelle vous avez confiance.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/pourquoi-vous-avez-besoin-dactivex-et-comment-le-desactiver/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/pourquoi-vous-avez-besoin-dactivex-et-comment-le-desactiver/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-webrtc_local_net">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_webrtc_local_net" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">WebRTC</span>
<span class="desktop description">
Nous avons repéré le réseau de classe A dans vos adresses IP locales. Vu que vous êtes actuellement sur ce site et que nous l'avons repéré, il est possible que vous utilisiez un VPN.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-desactiver-webrtc-dans-divers-navigateurs/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-desactiver-webrtc-dans-divers-navigateurs/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-proxy_ports" style="display: flex;">
<div class="alevel__color yellow" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_proxy_ports" bis_skin_checked="1"></div>
<span class="percent">-7.5%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">Ouvrez les ports proxy</span>
<span class="desktop description">
Nous avons déterminé que vous utilisez le serveur proxy avec un faible niveau d'anonymat. Les serveurs proxy visent à augmenter la vitesse de votre connexion avec l'aide de la mise en antimémoire. Le remplacement de votre IP au cours de la procédure est une action secondaire plutôt que l'objectif principal des proxies, et ceux-ci sont facilement repérables. Veuillez utiliser d'autres moyens, par exemple, le VPN.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/how-to-remain-100-anonymous-on-whoer-nets-home-page/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/how-to-remain-100-anonymous-on-whoer-nets-home-page/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-dns">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_dns" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">DNS différent</span>
<span class="desktop description">
Le pays de votre serveur DNS diffère du pays de votre adresse IP. En règle générale, cela signifie que vous essayez de cacher votre emplacement.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-cacher-votre-dns/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-cacher-votre-dns/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-tor">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_tor" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">TOR détecté</span>
<span class="desktop description">
Les addresses IP des noeuds finaux sont connues. Cela signifie qu'il est connu que vous utilisez un réseau anonyme. Par conséquent, vos actions peuvent être considérées suspectes.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/cest-quoi-le-tor/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/cest-quoi-le-tor/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-ips">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_ips" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">Adresses IP addresses différentes</span>
<span class="desktop description">
Nos vérifications intéractives ont révélé que vous n'êtes pas celui que vous prétendez être. Votre adresse IP réelle diffère de celle que vous indiquez. Veuillez utiliser le système et les paramètres VPN appropriés ou bien désactivez Flash/Java/ActiveX/WebRTC dans votre navigateur.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/comment-desactiver-webrtc-dans-divers-navigateurs/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/comment-desactiver-webrtc-dans-divers-navigateurs/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-anonymizer">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_anonymizer" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">Webproxy détecté</span>
<span class="desktop description">
La majorité des services d'anonymat sont détectables et capables d'intercepter et de contrôler votre traffic. Nous déconseillons de les utiliser à des fins de l'anonymat.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/webproxy-ou-vpn/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/webproxy-ou-vpn/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-proxy">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_proxy" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">Proxy détecté</span>
<span class="desktop description">
La majorité des proxies ne sont pas anonymes, ils sont détectables et capables d'intercepter et de contrôler votre traffic. Nous déconseillons de les utiliser à des fins de l'anonymat.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/le-parametre-mtu/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/le-parametre-mtu/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-datacenter_ip">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_datacenter_ip" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">Data Center IP</span>
<span class="desktop description">
Your IP address related to data center, you use masking tools.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/le-parametre-mtu/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/le-parametre-mtu/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-time_mismatch" style="display: flex;">
<div class="alevel__color yellow orange" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_time_mismatch" bis_skin_checked="1"></div>
<span class="percent">-7.5%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">L'heure du système différent</span>
<span class="desktop description">
L'heure réglée dans votre système diffère du fuseau horaire de vos addresses IP. Il est possible que vous essayiez de cacher votre emplacement actuel avec l'aide de moyens d'anonymat.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/changing-the-system-date-and-time/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/changing-the-system-date-and-time/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-dsbl">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_dsbl" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">Liste noire</span>
<span class="desktop description">
Votre adresse IP est mise sur la liste noire. C'est un mauvais signal.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/retirer-ladresse-ip-de-la-liste-noire-au-moyen-de-spamhaus/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/retirer-ladresse-ip-de-la-liste-noire-au-moyen-de-spamhaus/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-ua_mismatch">
<div class="alevel__color" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_ua_mismatch" bis_skin_checked="1"></div>
<span class="percent">-10%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">En-têtes du navigateur différents</span>
<span class="desktop description">
L'agent utilisateur envoyé par votre navigateur diffère de celui que nous avons détecté via JavaScript. Vous essayez de cacher votre navigateur réel.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-changer-lagent-utilisateur-dans-les-navigateurs/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-changer-lagent-utilisateur-dans-les-navigateurs/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class="alevel-langs" style="display: flex;">
<div class="alevel__color orange" bis_skin_checked="1">
<div class="desktop anon-icon anon-icon_langs" bis_skin_checked="1"></div>
<span class="percent">-15%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="desktop title">Langues différentes</span>
<span class="desktop description">
La langue configurée dans votre système ou dans votre navigateur diffère de celle du pays de votre adresse IP. Il est possible que vous essayiez de vous cacher avec l'aide de moyens d'anonymat.
</span>
<div class="desktop" bis_skin_checked="1">
<a href="https://whoer.net/blog/how-to-change-lang-in-windows-10-and-mac-os/" target="_blank">Comment réparer ?</a>
</div>
<div class="mobile" bis_skin_checked="1">
<a href="https://whoer.net/blog/how-to-change-lang-in-windows-10-and-mac-os/" class="button button_transparent" style="text-decoration: none; padding:8px">🔧</a>
</div>
</div>
</li>
<li class=" alevel-vpn_provider">
<div class="alevel__color" bis_skin_checked="1">
<div class="anon-icon anon-icon_anonym" bis_skin_checked="1"></div>
<span class="percent">0%</span>
</div>
<div class="content" bis_skin_checked="1">
<span class="title">X detected</span>
<span class="description">
It seems that you use X. But using only X does not allow to hide the fact of using anonymity means.
</span>
<div bis_skin_checked="1">
<a href="https://whoer.net/blog/how-to-change-lang-in-windows-10-and-mac-os/">Comment réparer ?</a>
</div>
</div>
</li>
</ul>
<ul class="legend-list">
<li>Niveau de danger:</li>
<li><span class="yellow"></span>Faible</li>
<li><span class="orange"></span>Moyen</li>
<li><span class="red"></span>Haut</li>
<li><a href="https://whoer.net/fr#moreInfo" onclick="hideAnonimityDescription()" class="anonimity__button button button_transparent legend-list__hide visible">Cacher</a>
</li>
</ul>
</div>
<div class="section__wrapper section__wrapper--hide-mobile" bis_skin_checked="1">
<div class="main-ip-info__anonimity" style="background-color:#1b5268; border:none; margin-top:0; margin-bottom: 35px;" bis_skin_checked="1">
<div class="anonimity__level" style="opacity:0;" bis_skin_checked="1">
<div class="level__bg completed_1 completed_2 completed_3 completed_4 completed_5 completed_6 completed" style="background-color: rgb(56, 182, 76);" bis_skin_checked="1"></div>
<div style="cursor: pointer" class="heading score-default " id="anonym_level" bis_skin_checked="1">
<strong id="hidden_rating_link" class="title"><span>Votre déguisement: 85%</span></strong>
<span class="description">Remarques sur la sécurité, réparation recommandée</span>
</div>
</div>
</div>
</div>
</section>


<section class="section section_blue section_plans" style="background:#3f93b7">
<div class="section__wrapper" bis_skin_checked="1">
<div class="section__content container" bis_skin_checked="1">
<p class="section__title--tariff section__title--tariff-main">Choisissez un tarif, <span class="subtitle">Whoer VPN vous attend!</span></p>
<link rel="stylesheet" href="./dop/plans-new.css" type="text/css">
<div class="new-plans" id="plans-one" bis_skin_checked="1">
<div onclick="onClickPlanBlock(this);" data-amount="9.9" class="plan new-plan new-plan--30 item-01 no-in-trial plan-30 " bis_skin_checked="1">
<input type="hidden" class="days" value="30">
<span class="corner-ribbon corner-ribbon--30 top-right sticky new-plan__ribbon">
-30%
</span>
<div class="new-plan__wrapper new-plan__wrapper--30 " bis_skin_checked="1">
<p class="new-plan__period new-plan__period--30">
1
mois
<svg class="new-plan__selected-icon" width="30" height="29" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="14.92" cy="14.5" r="14.5" fill="url(#paint0_linear-1)"></circle>
<path d="M8.47 13.23l5.07 5.07 7.7-7.71" stroke="#82D766" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></path>
<defs>
<lineargradient id="paint0_linear-1" x1="14.92" y1="0" x2="14.92" y2="78.62" gradientUnits="userSpaceOnUse">
<stop offset="1" stop-color="#fff"></stop>
<stop offset="1" stop-color="#fff" stop-opacity="0"></stop>
</lineargradient>
</defs>
</svg>
</p>
<p class="new-plan__monthly-cost">
<span class="new-plan__monthly-cost-currency">$</span>
<span class="new-plan__monthly-cost-value" data-cost="6.93" data-monthlycost="9.90">
9.90
</span>
<span class="new-plan__monthly-cost-period">/mois</span>
</p>
<p class="new-plan__economy">
0% sauvegarder
</p>
<p class="new-plan__base-price">
$9.90/mois
</p>
<a class="new-plan__buy new-plan__buy--not-buy button button_buy" href="https://whoer.net/fr/vpn/buy?plan=30">
<span class="new-plan__buy-text">Achetez!</span>
<svg width="19" height="14" viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M2.23114 0.375H16.769C17.564 0.375 18.2084 1.08388 18.2084 1.95833V7.5H16.6251V5.91667H2.37508V11.4583H9.50008V13.0417H2.23114C1.43619 13.0417 0.791748 12.3328 0.791748 11.4583V1.95833C0.791748 1.08388 1.43619 0.375 2.23114 0.375ZM16.6251 1.95833V4.33333H2.37508V1.95833H16.6251ZM11.0834 11.4583H14.7138L13.6903 12.4819L14.8099 13.6014L17.7447 10.6667L14.8099 7.73186L13.6903 8.85144L14.7138 9.87498H11.0834V11.4583Z" fill="white"></path>
</svg>
</a>
<p class="new-plan__cost-full-period">
<span class="new-plan__cost" data-cost="$6.93" data-dayscost="9.9">
$9.9
</span>
<span class="new-plan__interval">
chaque mois
</span>
</p>
</div>
</div>
<div onclick="onClickPlanBlock(this);" data-amount="39.0" class="plan new-plan new-plan--180 item-02 no-in-trial plan-180 " bis_skin_checked="1">
<input type="hidden" class="days" value="180">
<span class="corner-ribbon corner-ribbon--180 top-right sticky new-plan__ribbon">
-30%
</span>
<div class="new-plan__wrapper new-plan__wrapper--180 " bis_skin_checked="1">
<p class="new-plan__period new-plan__period--180">
6
mois
<svg class="new-plan__selected-icon" width="30" height="29" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="14.92" cy="14.5" r="14.5" fill="url(#paint0_linear-2)"></circle>
<path d="M8.47 13.23l5.07 5.07 7.7-7.71" stroke="#82D766" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></path>
<defs>
<lineargradient id="paint0_linear-2" x1="14.92" y1="0" x2="14.92" y2="78.62" gradientUnits="userSpaceOnUse">
<stop offset="1" stop-color="#fff"></stop>
<stop offset="1" stop-color="#fff" stop-opacity="0"></stop>
</lineargradient>
</defs>
</svg>
</p>
<p class="new-plan__monthly-cost">
<span class="new-plan__monthly-cost-currency">$</span>
<span class="new-plan__monthly-cost-value" data-cost="4.55" data-monthlycost="6.50">
6.50
</span>
<span class="new-plan__monthly-cost-period">/mois</span>
</p>
<p class="new-plan__economy">
35% sauvegarder
</p>
<p class="new-plan__base-price">
$6.50/mois
</p>
<a class="new-plan__buy new-plan__buy--not-buy button button_buy" href="https://whoer.net/fr/vpn/buy?plan=180">
<span class="new-plan__buy-text">Achetez!</span>
<svg width="19" height="14" viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M2.23114 0.375H16.769C17.564 0.375 18.2084 1.08388 18.2084 1.95833V7.5H16.6251V5.91667H2.37508V11.4583H9.50008V13.0417H2.23114C1.43619 13.0417 0.791748 12.3328 0.791748 11.4583V1.95833C0.791748 1.08388 1.43619 0.375 2.23114 0.375ZM16.6251 1.95833V4.33333H2.37508V1.95833H16.6251ZM11.0834 11.4583H14.7138L13.6903 12.4819L14.8099 13.6014L17.7447 10.6667L14.8099 7.73186L13.6903 8.85144L14.7138 9.87498H11.0834V11.4583Z" fill="white"></path>
</svg>
</a>
<p class="new-plan__cost-full-period">
<span class="new-plan__cost" data-cost="$27.3" data-dayscost="39.0">
$39.0
</span>
<span class="new-plan__interval">
tous les 6 mois
</span>
</p>
</div>
</div>
<div onclick="onClickPlanBlock(this);" data-amount="46.9" class="plan new-plan new-plan--360 item-03 no-in-trial plan-360 active" bis_skin_checked="1">
<input type="hidden" class="days" value="360">
<span class="corner-ribbon corner-ribbon--360 top-right sticky new-plan__ribbon">
-30%
</span>
<div class="new-plan__wrapper new-plan__wrapper--360 " bis_skin_checked="1">
<p class="new-plan__period new-plan__period--360">
1
an
<svg class="new-plan__selected-icon" width="30" height="29" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="14.92" cy="14.5" r="14.5" fill="url(#paint0_linear-3)"></circle>
<path d="M8.47 13.23l5.07 5.07 7.7-7.71" stroke="#82D766" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></path>
<defs>
<lineargradient id="paint0_linear-3" x1="14.92" y1="0" x2="14.92" y2="78.62" gradientUnits="userSpaceOnUse">
<stop offset="1" stop-color="#fff"></stop>
<stop offset="1" stop-color="#fff" stop-opacity="0"></stop>
</lineargradient>
</defs>
</svg>
</p>
<p class="new-plan__monthly-cost">
<span class="new-plan__monthly-cost-currency">$</span>
<span class="new-plan__monthly-cost-value" data-cost="2.73" data-monthlycost="3.90">
3.90
</span>
<span class="new-plan__monthly-cost-period">/mois</span>
</p>
<p class="new-plan__economy">
60% sauvegarder
</p>
<p class="new-plan__base-price">
$3.90/mois
</p>
<a class="new-plan__buy new-plan__buy--not-buy button button_buy" href="https://whoer.net/fr/vpn/buy?plan=360">
<span class="new-plan__buy-text">Achetez!</span>
<svg width="19" height="14" viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M2.23114 0.375H16.769C17.564 0.375 18.2084 1.08388 18.2084 1.95833V7.5H16.6251V5.91667H2.37508V11.4583H9.50008V13.0417H2.23114C1.43619 13.0417 0.791748 12.3328 0.791748 11.4583V1.95833C0.791748 1.08388 1.43619 0.375 2.23114 0.375ZM16.6251 1.95833V4.33333H2.37508V1.95833H16.6251ZM11.0834 11.4583H14.7138L13.6903 12.4819L14.8099 13.6014L17.7447 10.6667L14.8099 7.73186L13.6903 8.85144L14.7138 9.87498H11.0834V11.4583Z" fill="white"></path>
</svg>
</a>
<p class="new-plan__cost-full-period">
<span class="new-plan__cost" data-cost="$32.83" data-dayscost="46.9">
$46.9
</span>
<span class="new-plan__interval">
tous les 12 mois
</span>
</p>
</div>
</div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
      document.querySelector('.plan-360').classList.add('active');
    });

    const smoothScroll = function() {
    const firstStep = document.querySelector('#step1');
    const element = document.querySelector('#email');

    firstStep.scrollIntoView({block: "start", behavior: "smooth"});
    setTimeout(function() {
      firstStep.getBoundingClientRect().top <= 1 ? element.click() : '';
    }, 1000);
	}

	const onClickPlanBlock = (plan) => {
      const linkPlan = plan.querySelector('.new-plan__buy--not-buy');
      if (linkPlan) {
            window.location.href = linkPlan.getAttribute('href');
      } else  {
        smoothScroll();
        selectPlan(plan.querySelector('.days').value);
      }
	}
</script>
</div>
</div>
</section>
<section class="section section_ip-check section_white">
<div class="section__wrapper" bis_skin_checked="1">
<div class="section__content container" bis_skin_checked="1">
<div class="myip-tabset" bis_skin_checked="1">
<h3 class="mobile">Détails de l'adresse IP</h3>
<ul class="tab-control" id="version-switcher">
<li id="tab-lite" class="active">
<h2 class="desktop" style="color: inherit; padding: 0; margin: 0; font-size: inherit; font-weight: inherit; cursor: pointer;">
<span>Détails de l'adresse IP</span>
</h2>
<div class="mobile button__wrapper" bis_skin_checked="1">
<a class="button_toggler active" href="https://whoer.net/fr#extended">
Version intégrale
</a>
<div class="switch-block" bis_skin_checked="1">
<input type="checkbox" name="toggle" class="switch-block-dot" id="toggle-lite" checked="">
<label for="toggle-lite"></label>
</div>
</div>
</li>
<li id="tab-ext" class="">
<a class="desktop" href="https://whoer.net/fr#extended">
<span>Version intégrale</span>
</a>
<div class="mobile button__wrapper" bis_skin_checked="1">
<a class="button_toggler" href="https://whoer.net/fr#lite">
Version intégrale
</a>
<div class="switch-block" bis_skin_checked="1">
<input type="checkbox" name="toggle" class="switch-block-dot" id="toggle-ext">
<label for="toggle-ext"></label>
</div>
</div>
</li>
</ul>
<div class="tab tab_lite" style="position: static;left: 0;display:block" bis_skin_checked="1">
<div class="row" bis_skin_checked="1">
<div class="col-lg-6 col-md-12" bis_skin_checked="1">

<div class="row" bis_skin_checked="1">
<div class="col-lg-12 col-md-12" bis_skin_checked="1">
<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/le-vrai-dns-comment-le-cacher/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_language" bis_skin_checked="1">
<svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M53.4834 4.69666H6.51663C2.92333 4.69666 0 7.61998 0 11.2133V48.7867C0 52.38 2.92333 55.3033 6.51663 55.3033H53.4834C57.0767 55.3033 60 52.38 60 48.7867V11.2133C60 7.61998 57.0767 4.69666 53.4834 4.69666ZM58.2387 48.7867C58.2387 51.4088 56.1055 53.5421 53.4834 53.5421H6.51663C3.89448 53.5421 1.76125 51.4088 1.76125 48.7867V11.2133C1.76125 8.59114 3.89448 6.45791 6.51663 6.45791H53.4834C56.1055 6.45791 58.2387 8.59114 58.2387 11.2133V48.7867Z" fill="#65AAC7"></path>
<path d="M55.362 14.09H4.63795C4.15161 14.09 3.75732 14.4841 3.75732 14.9706C3.75732 15.457 4.15161 15.8512 4.63795 15.8512H55.362C55.8484 15.8512 56.2426 15.457 56.2426 14.9706C56.2426 14.4841 55.8484 14.09 55.362 14.09Z" fill="#65AAC7"></path>
<path d="M6.51637 11.1546C6.74768 11.1546 6.97547 11.0606 7.13868 10.8962C7.30306 10.733 7.39699 10.5064 7.39699 10.2739C7.39699 10.0425 7.30306 9.81484 7.13868 9.65163C6.97547 9.48724 6.74768 9.39331 6.51637 9.39331C6.28388 9.39331 6.05727 9.48724 5.89406 9.65163C5.72968 9.81484 5.63574 10.0425 5.63574 10.2739C5.63574 10.5063 5.72968 10.733 5.89406 10.8962C6.05727 11.0606 6.28388 11.1546 6.51637 11.1546Z" fill="#65AAC7"></path>
<path d="M14.0315 11.1546C14.2628 11.1546 14.4906 11.0606 14.6538 10.8962C14.8182 10.733 14.9121 10.5064 14.9121 10.2739C14.9121 10.0425 14.8182 9.81484 14.6538 9.65163C14.4906 9.48724 14.2628 9.39331 14.0315 9.39331C13.799 9.39331 13.5724 9.48724 13.4092 9.65163C13.2448 9.81484 13.1509 10.0425 13.1509 10.2739C13.1509 10.5063 13.2448 10.733 13.4092 10.8962C13.5724 11.0606 13.799 11.1546 14.0315 11.1546Z" fill="#65AAC7"></path>
<path d="M10.2737 11.1546C10.5062 11.1546 10.7328 11.0606 10.896 10.8962C11.0604 10.733 11.1543 10.5064 11.1543 10.2739C11.1543 10.0425 11.0604 9.81484 10.896 9.65163C10.7328 9.48724 10.5062 9.39331 10.2737 9.39331C10.0424 9.39331 9.81459 9.48724 9.65138 9.65163C9.487 9.81484 9.39307 10.0425 9.39307 10.2739C9.39307 10.5063 9.487 10.733 9.65138 10.8962C9.81459 11.0606 10.0424 11.1546 10.2737 11.1546Z" fill="#65AAC7"></path>
<path d="M13 39.7398H16.8538C17.0882 39.7398 17.852 39.7398 18.4335 39.6618C21.3239 39.2802 22.8255 36.6871 22.8255 33.4957C22.8255 30.3129 21.3239 27.7112 18.4335 27.3296C17.8433 27.2515 17.0968 27.2515 16.8538 27.2515H13V39.7398ZM14.5884 38.2655V28.7259H16.8538C17.2704 28.7259 17.8954 28.7432 18.3033 28.8213C20.3257 29.1855 21.185 31.1368 21.185 33.4957C21.185 35.8112 20.3517 37.7972 18.3033 38.1701C17.8954 38.2482 17.2878 38.2655 16.8538 38.2655H14.5884Z" fill="#65AAC7"></path>
<path d="M24.816 39.7398H26.3783V29.9747L32.8968 39.7398H34.4592V27.2515H32.8968V37.008L26.3783 27.2515H24.816V39.7398Z" fill="#65AAC7"></path>
<path d="M41.3216 40C43.9169 40 46 38.6731 46 36.2535C46 33.8513 43.9429 33.2355 42.8579 32.932L40.4797 32.2469C39.5509 31.9867 38.3965 31.5878 38.3965 30.4343C38.3965 29.2809 39.5857 28.4483 41.122 28.4657C42.7104 28.483 44.021 29.4196 44.2814 30.9373L45.9219 30.6511C45.4619 28.379 43.6565 27.0174 41.1393 27C38.6483 26.9914 36.7647 28.2922 36.7647 30.5037C36.7647 32.3509 38.0841 33.1575 39.4728 33.5651L42.6583 34.5104C43.5523 34.7792 44.4029 35.2475 44.4029 36.3402C44.4029 37.7018 43.0749 38.5344 41.3997 38.5344C39.6551 38.5344 38.275 37.6064 37.8758 36.028L36.2787 36.2795C36.6953 38.5777 38.6656 40 41.3216 40Z" fill="#65AAC7"></path>
</svg>
</div>
<h4 class="card__title">Test de fuite DNS</h4>
<div class="card__data" bis_skin_checked="1">
<a class="dnsleak-button-start" href="https://whoer.net/fr/dns-leak-test">début</a>
</div>
</div>
</div>
</div>

<div class="row" bis_skin_checked="1">
<div class="col-lg-12 col-md-12" bis_skin_checked="1">
<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/how-to-close-open-ports-in-windows/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_language" bis_skin_checked="1">
<svg width="56" height="56" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M2.21372 0.180883C1.11373 0.561764 0.332944 1.43035 0.0954236 2.53742C0.00967967 2.93712 -0.0152879 9.51924 0.0085846 25.4802L0.0419842 47.8624L0.272606 48.3605C0.609668 49.0887 1.12402 49.6189 1.82892 49.9649L2.45114 50.2703L9.01815 50.3009C15.9156 50.3332 16.0275 50.3263 16.3629 49.8478C16.5485 49.5828 16.5728 48.9812 16.41 48.6772C16.1211 48.1378 16.0988 48.136 9.35007 48.136C2.50622 48.136 2.5843 48.1427 2.30823 47.5371C2.20847 47.3183 2.17737 42.9358 2.17737 29.0869V10.9236H28.021H53.8646V29.0975C53.8646 48.8611 53.9009 47.7159 53.2654 48.0052C53.0665 48.0959 52.1125 48.136 50.1632 48.136H47.3482L41.7701 42.5602L36.192 36.9842L36.6446 36.0206C40.158 28.5389 37.0167 19.4881 29.5967 15.7145C28.2226 15.0155 27.132 14.6312 25.5685 14.2951C23.981 13.9538 21.1064 13.9546 19.5136 14.297C13.267 15.6396 8.64309 20.2614 7.30547 26.4994C6.98822 27.9787 6.96096 30.8428 7.25006 32.3207C7.87534 35.5171 9.29017 38.1736 11.5938 40.4758C13.844 42.725 16.3202 44.0766 19.456 44.7675C20.8937 45.0843 23.9966 45.1117 25.3928 44.8201C26.6234 44.563 28.1925 44.0475 29.201 43.5691L30.0172 43.1818L32.4957 45.6589L34.9741 48.136H29.9662H24.9583L24.6032 48.4532C24.3093 48.7157 24.2479 48.8496 24.2479 49.2305C24.2479 49.6114 24.3093 49.7453 24.6032 50.0078L24.9583 50.325H31.0565H37.1547L39.6784 52.8232C42.3236 55.4416 42.6247 55.6673 43.8143 55.9223C45.1715 56.2132 46.8918 55.6656 47.8356 54.6422C48.7629 53.6367 49.2407 52.0036 48.9604 50.7977L48.8539 50.34L51.2224 50.3052C53.5597 50.2707 53.5991 50.2662 54.2131 49.9649C54.918 49.6189 55.4323 49.0887 55.7694 48.3605L56 47.8624V25.1519V2.44132L55.6945 1.81944C55.3483 1.11492 54.8178 0.600837 54.0892 0.263954L53.5909 0.0334562L28.1853 0.00915864C4.02015 -0.013935 2.75206 -0.00550742 2.21372 0.180883ZM53.2654 2.29849C53.8255 2.55351 53.8646 2.78751 53.8646 5.88347V8.7346H28.021H2.17737L2.1812 5.86158C2.18536 2.79331 2.21416 2.61009 2.73695 2.32049C3.10292 2.11768 52.821 2.09612 53.2654 2.29849ZM6.46018 4.50946C5.51087 5.03536 5.90805 6.54564 6.99567 6.54564C7.55054 6.54564 8.09074 6.01098 8.09074 5.46177C8.09074 4.64003 7.18216 4.10942 6.46018 4.50946ZM11.2785 4.50946C10.3292 5.03536 10.7264 6.54564 11.814 6.54564C12.3688 6.54564 12.909 6.01098 12.909 5.46177C12.909 4.64003 12.0005 4.10942 11.2785 4.50946ZM16.0968 4.50946C15.1475 5.03536 15.5447 6.54564 16.6323 6.54564C17.1871 6.54564 17.7273 6.01098 17.7273 5.46177C17.7273 4.64003 16.8188 4.10942 16.0968 4.50946ZM24.8573 4.50946C24.1234 4.91595 24.1475 6.07358 24.897 6.41484C25.114 6.51368 28.124 6.54564 37.2302 6.54564C47.4418 6.54564 49.3222 6.52188 49.578 6.38967C50.3067 6.01295 50.3067 4.88935 49.578 4.51263C49.1443 4.28848 25.2617 4.28531 24.8573 4.50946ZM25.1738 16.4457C30.7347 17.6224 34.9105 22.0116 35.7472 27.5593C36.7077 33.9268 32.9076 40.1303 26.799 42.1673C22.7305 43.524 18.2939 42.8729 14.8071 40.4073C13.848 39.7292 12.3408 38.2228 11.6623 37.2642C8.64244 32.998 8.38148 27.3362 10.998 22.8534C12.9709 19.4736 16.4999 16.9993 20.1912 16.408C20.6129 16.3405 21.081 16.2642 21.2316 16.2384C21.7944 16.1421 24.3821 16.2781 25.1738 16.4457ZM20.7333 18.5186C16.1642 19.3919 12.7965 22.5391 11.6799 26.9789C11.3169 28.4224 11.3402 30.815 11.7316 32.279C13.2454 37.9412 18.6311 41.4631 24.3525 40.5323C30.7894 39.4851 34.9688 33.0963 33.3483 26.7806C32.3348 22.8304 29.2711 19.7577 25.3303 18.7391C23.9889 18.3922 21.9146 18.2928 20.7333 18.5186ZM24.3595 20.7627C26.101 21.1219 27.7156 22.0147 28.9641 23.3089C29.7747 24.1492 30.2255 24.8055 30.7051 25.8441C31.3131 27.1609 31.4598 27.8754 31.4621 29.5298C31.4645 31.3021 31.2447 32.2181 30.451 33.7436C30.0357 34.5415 29.7304 34.9374 28.8428 35.8289C27.9348 36.7407 27.5773 37.0162 26.7542 37.4381C25.2089 38.2302 24.3124 38.4439 22.5456 38.4415C20.892 38.4392 20.1753 38.2925 18.8638 37.6875C16.954 36.8066 15.4599 35.3692 14.5672 33.5539C13.8913 32.1794 13.6903 31.4414 13.6051 30.0223C13.3013 24.9657 17.3859 20.6194 22.4909 20.567C22.9727 20.5619 23.8136 20.65 24.3595 20.7627ZM35.4951 42.4709L33.936 44.0291L32.9061 43.004L31.8762 41.9788L32.4946 41.4644C33.2397 40.8447 34.9199 39.0678 34.9199 38.8996C34.9199 38.8336 35.4001 39.2595 35.9871 39.8461L37.0541 40.9127L35.4951 42.4709ZM42.6604 46.5217C46.7736 50.647 46.8535 50.7443 46.8555 51.6257C46.8592 53.189 45.1354 54.2882 43.7425 53.6109C43.4571 53.4721 41.9019 51.9987 39.4107 49.507L35.5243 45.6196L37.0549 44.0869C37.8967 43.2439 38.6123 42.5542 38.6451 42.5542C38.6779 42.5542 40.4848 44.3396 42.6604 46.5217ZM19.6754 48.4532C19.3814 48.7157 19.3201 48.8496 19.3201 49.2305C19.3201 49.6114 19.3814 49.7453 19.6754 50.0078C20.0716 50.3617 20.429 50.4058 20.9052 50.1597C21.291 49.9603 21.4506 49.6884 21.4506 49.2305C21.4506 48.7726 21.291 48.5007 20.9052 48.3013C20.429 48.0553 20.0716 48.0994 19.6754 48.4532Z" fill="#5CA5C3"></path>
</svg>
</div>
<h4 class="card__title">Scanner de ports</h4>
<div class="card__data" bis_skin_checked="1">
<a class="dnsleak-button-start" href="https://whoer.net/fr/port-scanner-online">début</a>
</div>
</div>
</div>
</div>

<div class="row" bis_skin_checked="1">
<div class="col-lg-12 col-md-12" bis_skin_checked="1">
<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/everycookie-des-cookies-intuables/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_language" bis_skin_checked="1">
<svg width="60px" height="58px">
<use xlink:href="#i-cookies"></use>
</svg>
</div>
<h4 class="card__title">Test Evercookie</h4>
<div class="card__data" bis_skin_checked="1">
<a class="dnsleak-button-start" href="https://whoer.net/fr/evercookie">début</a>
</div>
</div>
</div>
</div>
<div class="row" bis_skin_checked="1">
<div class="col-lg-12" bis_skin_checked="1">

<div class="ip-check__card ip-info location-info card_table" bis_skin_checked="1">
<div class="card__icon icon icon_location" bis_skin_checked="1">
<svg width="61px" height="60px">
<use xlink:href="#i-position"></use>
</svg>
</div>
<h4 class="card__title">Localisation</h4>
<div class="card__data" bis_skin_checked="1">
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Pays:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span style="display: flex; align-items: flex-start; line-height: 22px">
<img data-fetched="country_code" loading="lazy" class="flag flag_sm" alt="iso" src="./dop/fr.svg">
<span data-fetched="country_name" class="cont">France</span>
<span class="location-info">
&nbsp;(<span data-fetched="country_code">FR</span>)
</span>
</span>
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Région:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span data-fetched="subdivision1_name">
</span>
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Ville:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span data-fetched="city_name">
</span>
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Code postal:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span data-fetched="postal_code">
</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Nom de domaine:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span data-resolve="resolved">195-154-216-101.rev.poneytelecom.eu</span>
<br>
<a href="https://whoer.net/fr/checkwhois?ip=poneytelecom.eu#result" class="button_whois" target="_blank" data-resolve="root_domain" style="display: inline;">Whois</a>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Inversé:
</div>
<div class="card__col card__col_value" data-resolve="reversed" bis_skin_checked="1">195.154.216.101</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Plage IP:
</div>
<div data-fetched="network" class="card__col card__col_value ip-range" bis_skin_checked="1">195.154.192.0 - 195.154.255.255</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
ISP:
</div>
<div data-fetched="isp" class="card__col card__col_value" bis_skin_checked="1">Scaleway</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Organization:
</div>
<div data-fetched="organization" class="card__col card__col_value" bis_skin_checked="1">Scaleway</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
AS Organization:
</div>
<div data-fetched="as_organization" class="card__col card__col_value" bis_skin_checked="1">Scaleway S.a.s.</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
AS Number:
</div>
<div data-fetched="as_number" class="card__col card__col_value" bis_skin_checked="1">12876</div>
</div>
</div>
</div>
</div>
</div>
<div class="row" bis_skin_checked="1">
<div class="col-lg-12" bis_skin_checked="1">

<div class="ip-check__card card_table" bis_skin_checked="1">
<div class="card__icon icon icon_browser" bis_skin_checked="1">
<svg width="60px" height="60px">
<use xlink:href="#i-blowser"></use>
</svg>
</div>
<h4 class="card__title">Navigateur</h4>
<div class="card__data" bis_skin_checked="1">
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
En-têtes :
</div>
<div id="browser_headers" class="card__col card__col_value highlighted_green" bis_skin_checked="1">
Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
JavaScript:
</div>
<div id="browser_js" class="card__col card__col_value highlighted_green" bis_skin_checked="1">
<span class="js-ua-headers cont">Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-6 col-md-12" bis_skin_checked="1">
<div class="row" bis_skin_checked="1">
<div class="col-lg-12" bis_skin_checked="1">

<div class="ip-check__card time-info location-info card_table" bis_skin_checked="1">
<a href="https://whoer.net/blog/changing-the-system-date-and-time/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_time" bis_skin_checked="1">
<svg width="60px" height="60px">
<use xlink:href="#i-time"></use>
</svg>
</div>
<h4 class="card__title">Heure</h4>
<div class="card__data" bis_skin_checked="1">
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Fuseau horaire:
</div>
<div data-fetched="time_zone" class="card__col card__col_value matched highlighted_red" bis_skin_checked="1">Europe/Paris</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Local:
</div>
<div class="card__col card__col_value matched highlighted_red" bis_skin_checked="1">
Sat Nov 4 2023 15:41:27 GMT+0100 (CET)
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Système:
</div>
<div class="card__col card__col_value matched highlighted_red" bis_skin_checked="1">
<span class="js-time cont">Sat Nov 04 2023 17:42:59 GMT+0100 (GMT+01:00)</span>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="row" bis_skin_checked="1">
<div class="col-lg-12 col-md-12" bis_skin_checked="1">
<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/empreinte-digitale-sur-les-reseaux-sociaux/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_language" bis_skin_checked="1">
<svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M52.5235 29.0433C52.9487 27.4016 54.4251 26.185 56.1968 26.185C58.2991 26.185 59.9881 27.8976 59.9881 30C59.9881 32.1024 58.2755 33.815 56.1731 33.815C54.4015 33.815 52.9251 32.5984 52.4999 30.9567H47.055C46.7361 34.8898 45.0708 38.4449 42.5196 41.185L46.5826 45.248C47.1613 44.9055 47.8227 44.7047 48.5078 44.7047C49.5235 44.7047 50.4802 45.0945 51.2007 45.815C51.9094 46.5354 52.3109 47.4921 52.3109 48.5079C52.3109 49.5236 51.9212 50.4803 51.2007 51.2008C50.4802 51.9095 49.5235 52.311 48.5078 52.311C47.492 52.311 46.5353 51.9213 45.8149 51.2008C45.1062 50.4803 44.7046 49.5236 44.7046 48.5079C44.7046 47.8228 44.9054 47.1614 45.2479 46.5827L41.1613 42.4961C38.1613 45.0827 34.2637 46.6535 29.9999 46.6535C25.7361 46.6535 21.8385 45.0827 18.8385 42.4961L14.7519 46.5827C15.0944 47.1614 15.2952 47.8228 15.2952 48.5079C15.2952 49.5236 14.9054 50.4803 14.1849 51.2008C13.4645 51.9095 12.5078 52.311 11.492 52.311C10.4763 52.311 9.51959 51.9213 8.79912 51.2008C8.09046 50.4803 7.68888 49.5236 7.68888 48.5079C7.68888 47.4921 8.07865 46.5354 8.79912 45.815C9.51959 45.1063 10.4763 44.7047 11.492 44.7047C12.1771 44.7047 12.8385 44.9055 13.4172 45.248L17.4802 41.185C14.9409 38.4567 13.2755 34.9016 12.9448 30.9567H7.49991C7.07471 32.5984 5.59833 33.815 3.82668 33.815C1.72432 33.815 0.0117188 32.1024 0.0117188 30C0.0117188 27.8976 1.72432 26.185 3.82668 26.185C5.59833 26.185 7.07471 27.4016 7.49991 29.0433H12.8975C13.0038 24.9685 14.5393 21.248 17.0314 18.3543L13.4172 14.7402C12.8385 15.0827 12.1771 15.2835 11.492 15.2835C10.4763 15.2835 9.51959 14.8937 8.79912 14.1732C8.09046 13.4528 7.68888 12.4961 7.68888 11.4803C7.68888 10.4646 8.07865 9.50787 8.79912 8.7874C10.2401 7.34646 12.744 7.34646 14.1849 8.7874C14.8936 9.50787 15.2952 10.4646 15.2952 11.4803C15.2952 12.1654 15.0944 12.8268 14.7519 13.4055L18.3424 16.9961C21.1889 14.3504 24.933 12.6614 29.055 12.437V7.48819C27.4133 7.06299 26.1968 5.58661 26.1968 3.81496C26.1968 1.7126 27.9094 0 30.0117 0C32.1141 0 33.8267 1.7126 33.8267 3.81496C33.8267 5.58661 32.6101 7.06299 30.9684 7.48819V12.437C35.1023 12.6614 38.8346 14.3504 41.681 16.9961L45.2716 13.4055C44.929 12.8268 44.7283 12.1654 44.7283 11.4803C44.7283 10.4646 45.118 9.50787 45.8385 8.7874C47.2794 7.34646 49.7834 7.34646 51.2243 8.7874C51.933 9.50787 52.3346 10.4646 52.3346 11.4803C52.3346 12.4961 51.9448 13.4528 51.2243 14.1732C50.5038 14.8819 49.5472 15.2835 48.5314 15.2835C47.8464 15.2835 47.1849 15.0827 46.6062 14.7402L42.992 18.3543C45.4842 21.248 47.0078 24.9685 47.1259 29.0433H52.5235ZM48.5314 9.57874C48.0235 9.57874 47.5393 9.77953 47.1849 10.1339C46.8188 10.4882 46.6298 10.9724 46.6298 11.4803C46.6298 11.9882 46.8306 12.4724 47.1849 12.8268C47.9054 13.5472 49.1574 13.5472 49.8779 12.8268C50.2322 12.4724 50.433 11.9882 50.433 11.4803C50.433 10.9724 50.2322 10.4882 49.8779 10.1339C49.5235 9.77953 49.0393 9.57874 48.5314 9.57874ZM10.1456 12.8268C10.866 13.5472 12.118 13.5472 12.8385 12.8268C13.1928 12.4724 13.3936 11.9882 13.3936 11.4803C13.3936 10.9724 13.1928 10.4882 12.8385 10.1339C12.4842 9.77953 11.9999 9.57874 11.492 9.57874C10.9842 9.57874 10.4999 9.77953 10.1456 10.1339C9.79125 10.4882 9.59046 10.9724 9.59046 11.4803C9.59046 11.9882 9.79125 12.4724 10.1456 12.8268ZM1.9251 30C1.9251 31.0512 2.7755 31.9016 3.82668 31.9016C4.86605 31.9016 5.72825 31.0512 5.72825 30C5.72825 28.9488 4.87786 28.0984 3.82668 28.0984C2.7755 28.0984 1.9251 28.9488 1.9251 30ZM10.1456 49.8661C10.866 50.5866 12.118 50.5866 12.8385 49.8661C13.2046 49.5118 13.3936 49.0276 13.3936 48.5197C13.3936 48.0118 13.1928 47.5276 12.8385 47.1732C12.4842 46.8189 11.9999 46.6181 11.492 46.6181C10.9842 46.6181 10.4999 46.8189 10.1456 47.1732C9.79125 47.5276 9.59046 48.0118 9.59046 48.5197C9.59046 49.0276 9.79125 49.5118 10.1456 49.8661ZM48.5314 46.6181C48.0235 46.6181 47.5393 46.8189 47.1849 47.1732C46.8306 47.5276 46.6298 48.0118 46.6298 48.5197C46.6298 49.0276 46.8306 49.5118 47.1849 49.8661C47.9054 50.5866 49.1574 50.5866 49.8779 49.8661C50.2322 49.5118 50.433 49.0276 50.433 48.5197C50.433 48.0118 50.2322 47.5276 49.8779 47.1732C49.5235 46.8071 49.0393 46.6181 48.5314 46.6181ZM30.0117 1.91339C28.9605 1.91339 28.1101 2.76378 28.1101 3.81496C28.1101 4.85433 28.9605 5.71654 30.0117 5.71654C31.0629 5.71654 31.9133 4.86614 31.9133 3.81496C31.9133 2.76378 31.0629 1.91339 30.0117 1.91339ZM14.7755 29.5276C14.7755 37.9252 21.6141 44.7638 30.0117 44.7638C38.4094 44.7638 45.2479 37.9252 45.2479 29.5276C45.2479 21.1299 38.4094 14.2913 30.0117 14.2913C21.6141 14.2913 14.7755 21.1299 14.7755 29.5276ZM54.2952 30C54.2952 31.0512 55.1456 31.9016 56.1968 31.9016C57.2479 31.9016 58.0983 31.0512 58.0983 30C58.0983 28.9488 57.2479 28.0984 56.1968 28.0984C55.1456 28.0984 54.2952 28.9488 54.2952 30ZM30.0117 17.1377C23.185 17.1377 17.6338 22.6889 17.6338 29.5156C17.6338 36.3424 23.185 41.8936 30.0117 41.8936C36.8385 41.8936 42.3897 36.3424 42.3897 29.5156C42.3897 22.6889 36.8385 17.1377 30.0117 17.1377ZM30.0117 40.0038C27.933 40.0038 25.9842 39.3779 24.3543 38.3267C24.7086 35.5157 27.118 33.3306 30.0117 33.3306C32.9054 33.3306 35.3149 35.5157 35.6692 38.3267C34.0393 39.3779 32.0905 40.0038 30.0117 40.0038ZM27.1535 28.5708C27.1535 26.9999 28.4409 25.7125 30.0117 25.7125C31.5826 25.7125 32.87 26.9999 32.87 28.5708C32.87 30.1416 31.5826 31.429 30.0117 31.429C28.4409 31.429 27.1535 30.1416 27.1535 28.5708ZM37.3464 36.992C36.7322 34.8188 35.185 33.0353 33.1653 32.1141C34.1456 31.2401 34.7834 29.9881 34.7834 28.5708C34.7834 25.9487 32.6456 23.8109 30.0236 23.8109C27.4015 23.8109 25.2637 25.9487 25.2637 28.5708C25.2637 29.9881 25.9015 31.2401 26.8818 32.1141C24.8621 33.0353 23.3031 34.8188 22.7007 36.992C20.7637 35.0905 19.559 32.4448 19.559 29.5156C19.559 23.7401 24.2598 19.0393 30.0354 19.0393C35.811 19.0393 40.5117 23.7401 40.5117 29.5156C40.4881 32.4448 39.2834 35.0905 37.3464 36.992ZM30.9689 52.5117V46.6653H30.0122H29.0555V52.5117C27.4138 52.9369 26.1973 54.4133 26.1973 56.185C26.1973 58.2873 27.9099 59.9999 30.0122 59.9999C32.1146 59.9999 33.8272 58.2873 33.8272 56.185C33.8272 54.4133 32.6107 52.9369 30.9689 52.5117ZM30.0122 58.0865C28.9611 58.0865 28.1107 57.2361 28.1107 56.185C28.1107 55.1338 28.9611 54.2834 30.0122 54.2834C31.0634 54.2834 31.9138 55.1456 31.9138 56.185C31.9138 57.2361 31.0634 58.0865 30.0122 58.0865Z" fill="#5CA5C3"></path>
</svg>
</div>
<h4 class="card__title">réseaux sociaux</h4>
<div class="card__data" id="notLoggedIn" bis_skin_checked="1">Nous n'avons pas pu trouver que vous êtes connecté aux réseaux sociaux</div>
<div class="card__data" id="loggedIn" bis_skin_checked="1">
</div>
</div>
</div>
</div>
<div class="row" bis_skin_checked="1">
<div class="col-lg-12 col-md-12" bis_skin_checked="1">

<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/how-to-change-windows-system-language/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_language" bis_skin_checked="1">
<svg width="60px" height="60px">
<use xlink:href="#i-lang"></use>
</svg>
</div>
<h4 class="card__title">Langue</h4>
<div class="card__data" bis_skin_checked="1">
<span class="lang"><img class="flag flag_sm" alt="flag-fr.svg" src="./dop/fr.svg"> fr</span>
<span class="lang"><img class="flag flag_sm" alt="flag-ae.svg" src="./dop/ae.svg"> ae</span>
<span class="lang"><img class="flag flag_sm" alt="flag-us.svg" src="./dop/us.svg"> us</span>
</div>
</div>
</div>
</div>
<div id="platforms" class="row" bis_skin_checked="1">
<div class="col-lg-6 col-md-12" bis_skin_checked="1">

<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-desactiver-webrtc-dans-divers-navigateurs/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_webrtc" bis_skin_checked="1">
<svg width="60px" height="60px">
<use xlink:href="#i-ipa"></use>
</svg>
</div>
<h4 class="card__title">WebRTC</h4>
<div class="card__data card__data_webrtc" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status webrtc-status-icon disabled enabled"> </span>
<span class="cont">51.159.220.100</span>
</div>
</div>
</div>
</div>
<div class="col-lg-6 col-md-12" bis_skin_checked="1">

<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-desactiver-javascript-dans-divers-navigateurs/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_js" bis_skin_checked="1">
<svg width="52px" height="60px">
<use xlink:href="#i-js"></use>
</svg>
</div>
<h4 class="card__title">JavaScript</h4>
<div class="card__data" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status js-status-icon disabled enabled"> </span>
<span class="cont js-status">compatible</span>
</div>
</div>
</div>
</div>
<div class="col-lg-6 col-md-12" bis_skin_checked="1">

<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/wie-man-flash-in-den-browsern-deaktiviert/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_flash" bis_skin_checked="1">
<svg width="60px" height="60px">
<use xlink:href="#i-flash"></use>
</svg>
</div>
<h4 class="card__title">Flash</h4>
<div class="card__data" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status flash-status-icon disabled"> </span>
<span class="cont flash-status disabled">Désactivé</span>
</div>
</div>
</div>
</div>
<div class="col-lg-6 col-md-12" bis_skin_checked="1">

<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/pourquoi-vous-avez-besoin-dactivex-et-comment-le-desactiver/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_activex" bis_skin_checked="1">
<svg width="58px" height="59px">
<use xlink:href="#i-activex"></use>
</svg>
</div>
<h4 class="card__title">ActiveX</h4>
<div class="card__data" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status activex-status-icon disabled"> </span>
<span class="cont activex-status disabled">Désactivé</span>
</div>
</div>
</div>
</div>
<div class="col-lg-6 col-md-12" bis_skin_checked="1">

<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/article/comment-desactiver-java-sur-divers-os/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_java" bis_skin_checked="1">
<svg width="56px" height="60px">
<use xlink:href="#i-java"></use>
</svg>
</div>
<h4 class="card__title">Java</h4>
<div class="card__data" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status java-status-icon disabled"> </span>
<span class="cont java-status disabled">Désactivé</span>
</div>
</div>
</div>
</div>
<div class="col-lg-6 col-md-12" bis_skin_checked="1">

<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/how-to-clear-cache-in-browsers/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_cookies" bis_skin_checked="1">
<svg width="60px" height="58px">
<use xlink:href="#i-cookies"></use>
</svg>
</div>
<h4 class="card__title">cookies</h4>
<div class="card__data" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status java-status-icon "> </span>

<span class="cont java-status disabled">Activé</span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="btn-holder" bis_skin_checked="1">
<a href="https://whoer.net/fr#" onclick="$(&#39;#tab-ext&#39;).click();
                  $(&#39;html, body&#39;).animate({scrollTop: $(&#39;#tab-lite&#39;).offset().top}, 400);
                  event.preventDefault();" class="button button_full-width">
<span>Voulez-vous en savoir plus?&nbsp;</span>
<span>Utiliser la version intégrale</span>
</a>
</div>
</div>
<div class="tab" style="" bis_skin_checked="1">
<div class="row" bis_skin_checked="1">
<div class="col-lg-6 col-md-12" bis_skin_checked="1">
<div class="row" bis_skin_checked="1">
<div class="col-lg-12" bis_skin_checked="1">

<div id="dns-block" class="ip-check__card card_table ip-info" bis_skin_checked="1">
<div class="card__icon icon icon_address" bis_skin_checked="1">
<svg width="60px" height="60px">
<use xlink:href="#i-ip"></use>
</svg>
</div>
<h4 class="card__title">Adresse IP</h4>
<div class="card__data" bis_skin_checked="1">
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Nom de domaine:
</div>
<div class="card__col card__col_value card__col_top" bis_skin_checked="1">
<span data-resolve="resolved">195-154-216-101.rev.poneytelecom.eu</span>
<br>
<a href="https://whoer.net/fr/checkwhois?ip=poneytelecom.eu#result" class="button_whois" target="_blank" data-resolve="root_domain" style="display: inline;">Whois</a>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Inversé:
</div>
<div class="card__col card__col_value" data-resolve="reversed" bis_skin_checked="1">195.154.216.101</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param no-overflow" bis_skin_checked="1">
Serveur de messagerie:
</div>
<div class="card__col card__col_value" data-resolve="mx" bis_skin_checked="1">N/A</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Plage IP:
</div>
<div data-fetched="network" class="card__col card__col_value ip-range" bis_skin_checked="1">195.154.192.0 - 195.154.255.255</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
ISP:
</div>
<div data-fetched="isp" class="card__col card__col_value" bis_skin_checked="1">Scaleway</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Organization:
</div>
<div data-fetched="organization" class="card__col card__col_value" bis_skin_checked="1">Scaleway</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
AS Organization:
</div>
<div data-fetched="as_organization" class="card__col card__col_value" bis_skin_checked="1">Scaleway S.a.s.</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
AS Number:
</div>
<div data-fetched="as_number" class="card__col_bottom card__col card__col_value" bis_skin_checked="1">12876</div>
</div>
</div>
</div>
</div>

<div class="col-lg-12" bis_skin_checked="1">
<div class="row" bis_skin_checked="1">
<div class="col-lg-12 col-md-12" bis_skin_checked="1">
<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/empreinte-digitale-sur-les-reseaux-sociaux/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_language" bis_skin_checked="1">
<svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M52.5235 29.0433C52.9487 27.4016 54.4251 26.185 56.1968 26.185C58.2991 26.185 59.9881 27.8976 59.9881 30C59.9881 32.1024 58.2755 33.815 56.1731 33.815C54.4015 33.815 52.9251 32.5984 52.4999 30.9567H47.055C46.7361 34.8898 45.0708 38.4449 42.5196 41.185L46.5826 45.248C47.1613 44.9055 47.8227 44.7047 48.5078 44.7047C49.5235 44.7047 50.4802 45.0945 51.2007 45.815C51.9094 46.5354 52.3109 47.4921 52.3109 48.5079C52.3109 49.5236 51.9212 50.4803 51.2007 51.2008C50.4802 51.9095 49.5235 52.311 48.5078 52.311C47.492 52.311 46.5353 51.9213 45.8149 51.2008C45.1062 50.4803 44.7046 49.5236 44.7046 48.5079C44.7046 47.8228 44.9054 47.1614 45.2479 46.5827L41.1613 42.4961C38.1613 45.0827 34.2637 46.6535 29.9999 46.6535C25.7361 46.6535 21.8385 45.0827 18.8385 42.4961L14.7519 46.5827C15.0944 47.1614 15.2952 47.8228 15.2952 48.5079C15.2952 49.5236 14.9054 50.4803 14.1849 51.2008C13.4645 51.9095 12.5078 52.311 11.492 52.311C10.4763 52.311 9.51959 51.9213 8.79912 51.2008C8.09046 50.4803 7.68888 49.5236 7.68888 48.5079C7.68888 47.4921 8.07865 46.5354 8.79912 45.815C9.51959 45.1063 10.4763 44.7047 11.492 44.7047C12.1771 44.7047 12.8385 44.9055 13.4172 45.248L17.4802 41.185C14.9409 38.4567 13.2755 34.9016 12.9448 30.9567H7.49991C7.07471 32.5984 5.59833 33.815 3.82668 33.815C1.72432 33.815 0.0117188 32.1024 0.0117188 30C0.0117188 27.8976 1.72432 26.185 3.82668 26.185C5.59833 26.185 7.07471 27.4016 7.49991 29.0433H12.8975C13.0038 24.9685 14.5393 21.248 17.0314 18.3543L13.4172 14.7402C12.8385 15.0827 12.1771 15.2835 11.492 15.2835C10.4763 15.2835 9.51959 14.8937 8.79912 14.1732C8.09046 13.4528 7.68888 12.4961 7.68888 11.4803C7.68888 10.4646 8.07865 9.50787 8.79912 8.7874C10.2401 7.34646 12.744 7.34646 14.1849 8.7874C14.8936 9.50787 15.2952 10.4646 15.2952 11.4803C15.2952 12.1654 15.0944 12.8268 14.7519 13.4055L18.3424 16.9961C21.1889 14.3504 24.933 12.6614 29.055 12.437V7.48819C27.4133 7.06299 26.1968 5.58661 26.1968 3.81496C26.1968 1.7126 27.9094 0 30.0117 0C32.1141 0 33.8267 1.7126 33.8267 3.81496C33.8267 5.58661 32.6101 7.06299 30.9684 7.48819V12.437C35.1023 12.6614 38.8346 14.3504 41.681 16.9961L45.2716 13.4055C44.929 12.8268 44.7283 12.1654 44.7283 11.4803C44.7283 10.4646 45.118 9.50787 45.8385 8.7874C47.2794 7.34646 49.7834 7.34646 51.2243 8.7874C51.933 9.50787 52.3346 10.4646 52.3346 11.4803C52.3346 12.4961 51.9448 13.4528 51.2243 14.1732C50.5038 14.8819 49.5472 15.2835 48.5314 15.2835C47.8464 15.2835 47.1849 15.0827 46.6062 14.7402L42.992 18.3543C45.4842 21.248 47.0078 24.9685 47.1259 29.0433H52.5235ZM48.5314 9.57874C48.0235 9.57874 47.5393 9.77953 47.1849 10.1339C46.8188 10.4882 46.6298 10.9724 46.6298 11.4803C46.6298 11.9882 46.8306 12.4724 47.1849 12.8268C47.9054 13.5472 49.1574 13.5472 49.8779 12.8268C50.2322 12.4724 50.433 11.9882 50.433 11.4803C50.433 10.9724 50.2322 10.4882 49.8779 10.1339C49.5235 9.77953 49.0393 9.57874 48.5314 9.57874ZM10.1456 12.8268C10.866 13.5472 12.118 13.5472 12.8385 12.8268C13.1928 12.4724 13.3936 11.9882 13.3936 11.4803C13.3936 10.9724 13.1928 10.4882 12.8385 10.1339C12.4842 9.77953 11.9999 9.57874 11.492 9.57874C10.9842 9.57874 10.4999 9.77953 10.1456 10.1339C9.79125 10.4882 9.59046 10.9724 9.59046 11.4803C9.59046 11.9882 9.79125 12.4724 10.1456 12.8268ZM1.9251 30C1.9251 31.0512 2.7755 31.9016 3.82668 31.9016C4.86605 31.9016 5.72825 31.0512 5.72825 30C5.72825 28.9488 4.87786 28.0984 3.82668 28.0984C2.7755 28.0984 1.9251 28.9488 1.9251 30ZM10.1456 49.8661C10.866 50.5866 12.118 50.5866 12.8385 49.8661C13.2046 49.5118 13.3936 49.0276 13.3936 48.5197C13.3936 48.0118 13.1928 47.5276 12.8385 47.1732C12.4842 46.8189 11.9999 46.6181 11.492 46.6181C10.9842 46.6181 10.4999 46.8189 10.1456 47.1732C9.79125 47.5276 9.59046 48.0118 9.59046 48.5197C9.59046 49.0276 9.79125 49.5118 10.1456 49.8661ZM48.5314 46.6181C48.0235 46.6181 47.5393 46.8189 47.1849 47.1732C46.8306 47.5276 46.6298 48.0118 46.6298 48.5197C46.6298 49.0276 46.8306 49.5118 47.1849 49.8661C47.9054 50.5866 49.1574 50.5866 49.8779 49.8661C50.2322 49.5118 50.433 49.0276 50.433 48.5197C50.433 48.0118 50.2322 47.5276 49.8779 47.1732C49.5235 46.8071 49.0393 46.6181 48.5314 46.6181ZM30.0117 1.91339C28.9605 1.91339 28.1101 2.76378 28.1101 3.81496C28.1101 4.85433 28.9605 5.71654 30.0117 5.71654C31.0629 5.71654 31.9133 4.86614 31.9133 3.81496C31.9133 2.76378 31.0629 1.91339 30.0117 1.91339ZM14.7755 29.5276C14.7755 37.9252 21.6141 44.7638 30.0117 44.7638C38.4094 44.7638 45.2479 37.9252 45.2479 29.5276C45.2479 21.1299 38.4094 14.2913 30.0117 14.2913C21.6141 14.2913 14.7755 21.1299 14.7755 29.5276ZM54.2952 30C54.2952 31.0512 55.1456 31.9016 56.1968 31.9016C57.2479 31.9016 58.0983 31.0512 58.0983 30C58.0983 28.9488 57.2479 28.0984 56.1968 28.0984C55.1456 28.0984 54.2952 28.9488 54.2952 30ZM30.0117 17.1377C23.185 17.1377 17.6338 22.6889 17.6338 29.5156C17.6338 36.3424 23.185 41.8936 30.0117 41.8936C36.8385 41.8936 42.3897 36.3424 42.3897 29.5156C42.3897 22.6889 36.8385 17.1377 30.0117 17.1377ZM30.0117 40.0038C27.933 40.0038 25.9842 39.3779 24.3543 38.3267C24.7086 35.5157 27.118 33.3306 30.0117 33.3306C32.9054 33.3306 35.3149 35.5157 35.6692 38.3267C34.0393 39.3779 32.0905 40.0038 30.0117 40.0038ZM27.1535 28.5708C27.1535 26.9999 28.4409 25.7125 30.0117 25.7125C31.5826 25.7125 32.87 26.9999 32.87 28.5708C32.87 30.1416 31.5826 31.429 30.0117 31.429C28.4409 31.429 27.1535 30.1416 27.1535 28.5708ZM37.3464 36.992C36.7322 34.8188 35.185 33.0353 33.1653 32.1141C34.1456 31.2401 34.7834 29.9881 34.7834 28.5708C34.7834 25.9487 32.6456 23.8109 30.0236 23.8109C27.4015 23.8109 25.2637 25.9487 25.2637 28.5708C25.2637 29.9881 25.9015 31.2401 26.8818 32.1141C24.8621 33.0353 23.3031 34.8188 22.7007 36.992C20.7637 35.0905 19.559 32.4448 19.559 29.5156C19.559 23.7401 24.2598 19.0393 30.0354 19.0393C35.811 19.0393 40.5117 23.7401 40.5117 29.5156C40.4881 32.4448 39.2834 35.0905 37.3464 36.992ZM30.9689 52.5117V46.6653H30.0122H29.0555V52.5117C27.4138 52.9369 26.1973 54.4133 26.1973 56.185C26.1973 58.2873 27.9099 59.9999 30.0122 59.9999C32.1146 59.9999 33.8272 58.2873 33.8272 56.185C33.8272 54.4133 32.6107 52.9369 30.9689 52.5117ZM30.0122 58.0865C28.9611 58.0865 28.1107 57.2361 28.1107 56.185C28.1107 55.1338 28.9611 54.2834 30.0122 54.2834C31.0634 54.2834 31.9138 55.1456 31.9138 56.185C31.9138 57.2361 31.0634 58.0865 30.0122 58.0865Z" fill="#5CA5C3"></path>
</svg>
</div>
<h4 class="card__title">réseaux sociaux</h4>
<div class="card__data notLoggedIn" bis_skin_checked="1">Nous n'avons pas pu trouver que vous êtes connecté aux réseaux sociaux</div>
<div class="card__data loggedIn" bis_skin_checked="1"></div>
</div>
</div>
</div>
</div>

<div class="col-lg-12" bis_skin_checked="1">
<div class="row" bis_skin_checked="1">
<div class="col-lg-12 col-md-12" bis_skin_checked="1">
<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/le-vrai-dns-comment-le-cacher/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_language" bis_skin_checked="1">
<svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M53.4834 4.69666H6.51663C2.92333 4.69666 0 7.61998 0 11.2133V48.7867C0 52.38 2.92333 55.3033 6.51663 55.3033H53.4834C57.0767 55.3033 60 52.38 60 48.7867V11.2133C60 7.61998 57.0767 4.69666 53.4834 4.69666ZM58.2387 48.7867C58.2387 51.4088 56.1055 53.5421 53.4834 53.5421H6.51663C3.89448 53.5421 1.76125 51.4088 1.76125 48.7867V11.2133C1.76125 8.59114 3.89448 6.45791 6.51663 6.45791H53.4834C56.1055 6.45791 58.2387 8.59114 58.2387 11.2133V48.7867Z" fill="#65AAC7"></path>
<path d="M55.362 14.09H4.63795C4.15161 14.09 3.75732 14.4841 3.75732 14.9706C3.75732 15.457 4.15161 15.8512 4.63795 15.8512H55.362C55.8484 15.8512 56.2426 15.457 56.2426 14.9706C56.2426 14.4841 55.8484 14.09 55.362 14.09Z" fill="#65AAC7"></path>
<path d="M6.51637 11.1546C6.74768 11.1546 6.97547 11.0606 7.13868 10.8962C7.30306 10.733 7.39699 10.5064 7.39699 10.2739C7.39699 10.0425 7.30306 9.81484 7.13868 9.65163C6.97547 9.48724 6.74768 9.39331 6.51637 9.39331C6.28388 9.39331 6.05727 9.48724 5.89406 9.65163C5.72968 9.81484 5.63574 10.0425 5.63574 10.2739C5.63574 10.5063 5.72968 10.733 5.89406 10.8962C6.05727 11.0606 6.28388 11.1546 6.51637 11.1546Z" fill="#65AAC7"></path>
<path d="M14.0315 11.1546C14.2628 11.1546 14.4906 11.0606 14.6538 10.8962C14.8182 10.733 14.9121 10.5064 14.9121 10.2739C14.9121 10.0425 14.8182 9.81484 14.6538 9.65163C14.4906 9.48724 14.2628 9.39331 14.0315 9.39331C13.799 9.39331 13.5724 9.48724 13.4092 9.65163C13.2448 9.81484 13.1509 10.0425 13.1509 10.2739C13.1509 10.5063 13.2448 10.733 13.4092 10.8962C13.5724 11.0606 13.799 11.1546 14.0315 11.1546Z" fill="#65AAC7"></path>
<path d="M10.2737 11.1546C10.5062 11.1546 10.7328 11.0606 10.896 10.8962C11.0604 10.733 11.1543 10.5064 11.1543 10.2739C11.1543 10.0425 11.0604 9.81484 10.896 9.65163C10.7328 9.48724 10.5062 9.39331 10.2737 9.39331C10.0424 9.39331 9.81459 9.48724 9.65138 9.65163C9.487 9.81484 9.39307 10.0425 9.39307 10.2739C9.39307 10.5063 9.487 10.733 9.65138 10.8962C9.81459 11.0606 10.0424 11.1546 10.2737 11.1546Z" fill="#65AAC7"></path>
<path d="M13 39.7398H16.8538C17.0882 39.7398 17.852 39.7398 18.4335 39.6618C21.3239 39.2802 22.8255 36.6871 22.8255 33.4957C22.8255 30.3129 21.3239 27.7112 18.4335 27.3296C17.8433 27.2515 17.0968 27.2515 16.8538 27.2515H13V39.7398ZM14.5884 38.2655V28.7259H16.8538C17.2704 28.7259 17.8954 28.7432 18.3033 28.8213C20.3257 29.1855 21.185 31.1368 21.185 33.4957C21.185 35.8112 20.3517 37.7972 18.3033 38.1701C17.8954 38.2482 17.2878 38.2655 16.8538 38.2655H14.5884Z" fill="#65AAC7"></path>
<path d="M24.816 39.7398H26.3783V29.9747L32.8968 39.7398H34.4592V27.2515H32.8968V37.008L26.3783 27.2515H24.816V39.7398Z" fill="#65AAC7"></path>
<path d="M41.3216 40C43.9169 40 46 38.6731 46 36.2535C46 33.8513 43.9429 33.2355 42.8579 32.932L40.4797 32.2469C39.5509 31.9867 38.3965 31.5878 38.3965 30.4343C38.3965 29.2809 39.5857 28.4483 41.122 28.4657C42.7104 28.483 44.021 29.4196 44.2814 30.9373L45.9219 30.6511C45.4619 28.379 43.6565 27.0174 41.1393 27C38.6483 26.9914 36.7647 28.2922 36.7647 30.5037C36.7647 32.3509 38.0841 33.1575 39.4728 33.5651L42.6583 34.5104C43.5523 34.7792 44.4029 35.2475 44.4029 36.3402C44.4029 37.7018 43.0749 38.5344 41.3997 38.5344C39.6551 38.5344 38.275 37.6064 37.8758 36.028L36.2787 36.2795C36.6953 38.5777 38.6656 40 41.3216 40Z" fill="#65AAC7"></path>
</svg>
</div>
<h4 class="card__title">Test de fuite DNS</h4>
<div class="card__data" bis_skin_checked="1">
<a class="dnsleak-button-start" href="https://whoer.net/fr/dns-leak-test">début</a>
</div>
</div>
</div>
</div>
</div>

<div class="col-lg-12" bis_skin_checked="1">
<div class="row" bis_skin_checked="1">
<div class="col-lg-12 col-md-12" bis_skin_checked="1">
<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_language" bis_skin_checked="1">
<svg width="56" height="56" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M2.21372 0.180883C1.11373 0.561764 0.332944 1.43035 0.0954236 2.53742C0.00967967 2.93712 -0.0152879 9.51924 0.0085846 25.4802L0.0419842 47.8624L0.272606 48.3605C0.609668 49.0887 1.12402 49.6189 1.82892 49.9649L2.45114 50.2703L9.01815 50.3009C15.9156 50.3332 16.0275 50.3263 16.3629 49.8478C16.5485 49.5828 16.5728 48.9812 16.41 48.6772C16.1211 48.1378 16.0988 48.136 9.35007 48.136C2.50622 48.136 2.5843 48.1427 2.30823 47.5371C2.20847 47.3183 2.17737 42.9358 2.17737 29.0869V10.9236H28.021H53.8646V29.0975C53.8646 48.8611 53.9009 47.7159 53.2654 48.0052C53.0665 48.0959 52.1125 48.136 50.1632 48.136H47.3482L41.7701 42.5602L36.192 36.9842L36.6446 36.0206C40.158 28.5389 37.0167 19.4881 29.5967 15.7145C28.2226 15.0155 27.132 14.6312 25.5685 14.2951C23.981 13.9538 21.1064 13.9546 19.5136 14.297C13.267 15.6396 8.64309 20.2614 7.30547 26.4994C6.98822 27.9787 6.96096 30.8428 7.25006 32.3207C7.87534 35.5171 9.29017 38.1736 11.5938 40.4758C13.844 42.725 16.3202 44.0766 19.456 44.7675C20.8937 45.0843 23.9966 45.1117 25.3928 44.8201C26.6234 44.563 28.1925 44.0475 29.201 43.5691L30.0172 43.1818L32.4957 45.6589L34.9741 48.136H29.9662H24.9583L24.6032 48.4532C24.3093 48.7157 24.2479 48.8496 24.2479 49.2305C24.2479 49.6114 24.3093 49.7453 24.6032 50.0078L24.9583 50.325H31.0565H37.1547L39.6784 52.8232C42.3236 55.4416 42.6247 55.6673 43.8143 55.9223C45.1715 56.2132 46.8918 55.6656 47.8356 54.6422C48.7629 53.6367 49.2407 52.0036 48.9604 50.7977L48.8539 50.34L51.2224 50.3052C53.5597 50.2707 53.5991 50.2662 54.2131 49.9649C54.918 49.6189 55.4323 49.0887 55.7694 48.3605L56 47.8624V25.1519V2.44132L55.6945 1.81944C55.3483 1.11492 54.8178 0.600837 54.0892 0.263954L53.5909 0.0334562L28.1853 0.00915864C4.02015 -0.013935 2.75206 -0.00550742 2.21372 0.180883ZM53.2654 2.29849C53.8255 2.55351 53.8646 2.78751 53.8646 5.88347V8.7346H28.021H2.17737L2.1812 5.86158C2.18536 2.79331 2.21416 2.61009 2.73695 2.32049C3.10292 2.11768 52.821 2.09612 53.2654 2.29849ZM6.46018 4.50946C5.51087 5.03536 5.90805 6.54564 6.99567 6.54564C7.55054 6.54564 8.09074 6.01098 8.09074 5.46177C8.09074 4.64003 7.18216 4.10942 6.46018 4.50946ZM11.2785 4.50946C10.3292 5.03536 10.7264 6.54564 11.814 6.54564C12.3688 6.54564 12.909 6.01098 12.909 5.46177C12.909 4.64003 12.0005 4.10942 11.2785 4.50946ZM16.0968 4.50946C15.1475 5.03536 15.5447 6.54564 16.6323 6.54564C17.1871 6.54564 17.7273 6.01098 17.7273 5.46177C17.7273 4.64003 16.8188 4.10942 16.0968 4.50946ZM24.8573 4.50946C24.1234 4.91595 24.1475 6.07358 24.897 6.41484C25.114 6.51368 28.124 6.54564 37.2302 6.54564C47.4418 6.54564 49.3222 6.52188 49.578 6.38967C50.3067 6.01295 50.3067 4.88935 49.578 4.51263C49.1443 4.28848 25.2617 4.28531 24.8573 4.50946ZM25.1738 16.4457C30.7347 17.6224 34.9105 22.0116 35.7472 27.5593C36.7077 33.9268 32.9076 40.1303 26.799 42.1673C22.7305 43.524 18.2939 42.8729 14.8071 40.4073C13.848 39.7292 12.3408 38.2228 11.6623 37.2642C8.64244 32.998 8.38148 27.3362 10.998 22.8534C12.9709 19.4736 16.4999 16.9993 20.1912 16.408C20.6129 16.3405 21.081 16.2642 21.2316 16.2384C21.7944 16.1421 24.3821 16.2781 25.1738 16.4457ZM20.7333 18.5186C16.1642 19.3919 12.7965 22.5391 11.6799 26.9789C11.3169 28.4224 11.3402 30.815 11.7316 32.279C13.2454 37.9412 18.6311 41.4631 24.3525 40.5323C30.7894 39.4851 34.9688 33.0963 33.3483 26.7806C32.3348 22.8304 29.2711 19.7577 25.3303 18.7391C23.9889 18.3922 21.9146 18.2928 20.7333 18.5186ZM24.3595 20.7627C26.101 21.1219 27.7156 22.0147 28.9641 23.3089C29.7747 24.1492 30.2255 24.8055 30.7051 25.8441C31.3131 27.1609 31.4598 27.8754 31.4621 29.5298C31.4645 31.3021 31.2447 32.2181 30.451 33.7436C30.0357 34.5415 29.7304 34.9374 28.8428 35.8289C27.9348 36.7407 27.5773 37.0162 26.7542 37.4381C25.2089 38.2302 24.3124 38.4439 22.5456 38.4415C20.892 38.4392 20.1753 38.2925 18.8638 37.6875C16.954 36.8066 15.4599 35.3692 14.5672 33.5539C13.8913 32.1794 13.6903 31.4414 13.6051 30.0223C13.3013 24.9657 17.3859 20.6194 22.4909 20.567C22.9727 20.5619 23.8136 20.65 24.3595 20.7627ZM35.4951 42.4709L33.936 44.0291L32.9061 43.004L31.8762 41.9788L32.4946 41.4644C33.2397 40.8447 34.9199 39.0678 34.9199 38.8996C34.9199 38.8336 35.4001 39.2595 35.9871 39.8461L37.0541 40.9127L35.4951 42.4709ZM42.6604 46.5217C46.7736 50.647 46.8535 50.7443 46.8555 51.6257C46.8592 53.189 45.1354 54.2882 43.7425 53.6109C43.4571 53.4721 41.9019 51.9987 39.4107 49.507L35.5243 45.6196L37.0549 44.0869C37.8967 43.2439 38.6123 42.5542 38.6451 42.5542C38.6779 42.5542 40.4848 44.3396 42.6604 46.5217ZM19.6754 48.4532C19.3814 48.7157 19.3201 48.8496 19.3201 49.2305C19.3201 49.6114 19.3814 49.7453 19.6754 50.0078C20.0716 50.3617 20.429 50.4058 20.9052 50.1597C21.291 49.9603 21.4506 49.6884 21.4506 49.2305C21.4506 48.7726 21.291 48.5007 20.9052 48.3013C20.429 48.0553 20.0716 48.0994 19.6754 48.4532Z" fill="#5CA5C3"></path>
</svg>
</div>
<h4 class="card__title">Scanner de ports</h4>
<div class="card__data" bis_skin_checked="1">
<a class="dnsleak-button-start" href="https://whoer.net/fr/port-scanner-online">début</a>
</div>
</div>
</div>
</div>
</div>

<div class="col-lg-12" bis_skin_checked="1">
<div class="row" bis_skin_checked="1">
<div class="col-lg-12 col-md-12" bis_skin_checked="1">
<div class="ip-check__card" bis_skin_checked="1">
<a href="https://whoer.net/blog/fr/everycookie-des-cookies-intuables/" target="_blank" class="card__info-link"></a>
<div class="card__icon icon icon_language" bis_skin_checked="1">
<svg width="60px" height="58px">
<use xlink:href="#i-cookies"></use>
</svg>
</div>
<h4 class="card__title">Test Evercookie</h4>
<div class="card__data" bis_skin_checked="1">
<a class="dnsleak-button-start" href="https://whoer.net/fr/evercookie">début</a>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-12" bis_skin_checked="1">

<div class="ip-check__card card_table" bis_skin_checked="1">
<div class="card__icon icon icon_interactive-check" bis_skin_checked="1">
<svg width="60px" height="54px">
<use xlink:href="#i-icheck"></use>
</svg>
</div>
<h4 class="card__title">Détection interactive</h4>
<div id="run_interactive" class="btn-interactive" bis_skin_checked="1">Effectuer les tests</div>
<div id="flash_container" style="height: 1px; width: 1px;" bis_skin_checked="1"></div>
<div class="card__data location-info" bis_skin_checked="1">
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
<strong style="color: #000; font-weight: 700;">Adresse IP</strong>
</div>
<div style="display: flex;align-items: center;flex-wrap: wrap;" class="card__col card__col_value" bis_skin_checked="1">
<span style="margin-right: 12px" onclick="$(&#39;#ip-formats&#39;).toggle();return false">51.159.220.100</span>
<span class="country-holder">
<span class="ico-holder no-back">
<img alt="iso" loading="lazy" class="flag flag_sm" src="./dop/fr.svg">
</span>
<span style="white-space:nowrap" data-fetched="country_name" class="cont overdots">France</span>
</span>
<span id="ip-formats" style="display: none">
<br>
<span class="ico-holder no-back"> </span>
<span>bin: 00110011 10011111 11011100 01100100 </span>
<br>
<span class="ico-holder no-back"> </span>
<span>dec: 866114660</span>
<br>
<span class="ico-holder no-back"> </span>
<span>oct: 063 0237 0334 0144 </span>
<br>
<span class="ico-holder no-back"> </span>
<span>hex: 33 9F DC 64 </span>
</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Flash
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont" id="ip_flash_ip"><span class="disabled">N/A</span></span>
<div class="country-holder" bis_skin_checked="1">
<span class="ico-holder no-back" id="ip_flash_flag"> </span>
<span class="cont" id="ip_flash_country"></span>
</div>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
WebRTC
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="ip_webrtc"> <span class="cont"><b>169.150.196.73</b></span><div class="country-holder" bis_skin_checked="1"></div><div bis_skin_checked="1"> </div> </span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Java (TCP)
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont" id="ip_java_tcp_ip"><span class="disabled">N/A</span></span>
<div class="country-holder" bis_skin_checked="1">
<span class="ico-holder no-back" id="ip_java_tcp_flag"> </span>
<span class="cont" id="ip_java_tcp_country"></span>
</div>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Java (UDP)
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont" id="ip_java_udp_ip"><span class="disabled">N/A</span></span>
<div class="country-holder" bis_skin_checked="1">
<span class="ico-holder no-back" id="ip_java_udp_flag"> </span>
<span class="cont" id="ip_java_udp_country"></span>
</div>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Java (system)
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span id="ip_java_system"><span class="disabled">N/A</span></span>
</div>
</div>
<div class="card__subheading" bis_skin_checked="1">DNS</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Navigateur
</div>
<div class="card__col card__col_value dns-highlight" bis_skin_checked="1">
<div class="dns_br" bis_skin_checked="1">
<span class="skel">
<span class="country-holder">
<span class="ico-holder no-back dns_br_flag"> </span>
<span class="cont dns_br_country"></span>
</span>
<span class="underlined cont dns_br_ip"><span class="disabled">N/A</span></span>
</span>
<div class="result" bis_skin_checked="1"></div>
</div>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Flash
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="dns_flash">
<span class="skel">
<span class="country-holder">
<span class="ico-holder no-back" id="dns_flash_flag"> </span>
<span class="cont" id="dns_flash_country"></span>
</span>
<span class="cont" id="dns_flash_ip"><span class="disabled">N/A</span></span>
</span>
<span class="result"></span>
</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Java (request)
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="dns_java">
<span class="skel">
<span class="country-holder">
<span class="ico-holder no-back" id="dns_java_resolve_flag"> </span>
<span class="cont" id="dns_java_resolve_country"></span>
</span>
<span class="cont" id="dns_java_resolve_ip"><span class="disabled">N/A</span></span>
</span>
<span class="result"></span>
</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Java (system)
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span id="dns_java_system"><span class="disabled">N/A</span></span>
</div>
</div>
<div class="card__subheading" bis_skin_checked="1">OS</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
En-têtes :
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont">
Win10.0
</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param no-overflow" bis_skin_checked="1">
JavaScript:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont" id="os_js">Win32 | Windows NT 10.0</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Flash:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont" id="os_flash"><span class="disabled">N/A</span></span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Java:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span id="os_java"><span class="disabled">N/A</span></span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
TCP/IP:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont" id="os_mtu"><span class="disabled">N/A</span></span>
</div>
</div>
<div id="block-ports" class="card__subheading" bis_skin_checked="1">ip.ports</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param no-overflow" bis_skin_checked="1">
ip.ports.opened:
</div>
<div class="card__col card__col_value card__col_top card__col_bottom" bis_skin_checked="1">
<span id="proxy_ports">80, 443, <span class="proxy">3128</span>, <span class="proxy">8080</span></span>
</div>
</div>
<div class="card__subheading" bis_skin_checked="1">Langue</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
En-têtes :
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont">
(en-US,en;q=0.9,ar;q=0.8,fr;q=0.7
<span class="js_language"> | en-US</span>)
</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
JavaScript:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont" id="lang_js_ext"><img alt="" class="flag flag_sm" src="./dop/us.svg"> en-US</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Flash:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont" id="lang_flash"><span class="disabled">N/A</span></span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Java:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont" id="lang_java"><span class="disabled">N/A</span></span>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-12" bis_skin_checked="1">

<div id="browser-screen" class="ip-check__card card_table" bis_skin_checked="1">
<div class="card__icon icon icon_screen" bis_skin_checked="1">
<svg width="60px" height="58px">
<use xlink:href="#i-display"></use>
</svg>
</div>
<h4 class="card__title">Écran</h4>
<div class="card__data" bis_skin_checked="1">
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
colorDepth:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont colorDepth-data">24</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
pixelDepth:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont pixelDepth-data">24</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
height:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont height-data">900</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
width:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont width-data">1440</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
availHeight:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont availHeight-data">864</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
availWidth:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont availWidth-data">1440</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
top:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont disabled top-data">N/A</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
left:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont disabled left-data">N/A</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
availTop:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont availTop-data">0</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
availLeft:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont availLeft-data">0</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
window size:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span class="cont window-size-data">1423x4239 (1440x900)</span>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-12" bis_skin_checked="1">

<div class="ip-check__card card_table" bis_skin_checked="1">
<div class="card__icon icon icon_headers" bis_skin_checked="1">
<svg width="60px" height="55px">
<use xlink:href="#i-http"></use>
</svg>
</div>
<h4 class="card__title">En-têtes HTTP</h4>
<div class="card__data card__data_with-overflow" bis_skin_checked="1">
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_ACCEPT
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_ACCEPT_ENCODING
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
gzip
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_ACCEPT_LANGUAGE
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
en-US,en;q=0.9,ar;q=0.8,fr;q=0.7
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_CACHE_CONTROL
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
max-age=0
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_CDN_LOOP
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
cloudflare
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_CONNECTION
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
close
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_COOKIE
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
cf_clearance=oCZnOT01LGXRr8M57HqRWzXZnhIgqk2MDSXchjZ82W4-1699102557-0-1-fe174db2.a7775345.a9161252-0.2.1699102557
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_HOST
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
whoer.net
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_HTTPS
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
ON
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_SEC_CH_UA
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
"Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109"
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_SEC_CH_UA_MOBILE
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
?0
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_SEC_CH_UA_PLATFORM
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
"Windows"
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_SEC_FETCH_DEST
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
document
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_SEC_FETCH_MODE
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
navigate
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_SEC_FETCH_SITE
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
none
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_SEC_FETCH_USER
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
?1
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_UPGRADE_INSECURE_REQUESTS
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
1
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
HTTP_USER_AGENT
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
QUERY_STRING
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
REMOTE_ADDR
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
51.159.220.100
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
REMOTE_PORT
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
38118
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
REQUEST_METHOD
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
GET
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
REQUEST_URI
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
/
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
SERVER_PROTOCOL
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
HTTP/1.1
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-6 col-md-12" bis_skin_checked="1">
<div class="row" bis_skin_checked="1">
<div class="col-lg-12" bis_skin_checked="1">

<div class="ip-check__card card_table ip-check__card_scripts" bis_skin_checked="1">
<div class="card__icon icon icon_scripts" bis_skin_checked="1">
<svg width="60px" height="58px">
<use xlink:href="#i-scripts"></use>
</svg>
</div>
<h4 class="card__title">Scripts</h4>
<div class="card__data" bis_skin_checked="1">
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
JavaScript:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status cont js-status">compatible</span><span class="cont js-status">compatible</span>
</div>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Flash:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status cont flash-status disabled"></span><span class="cont flash-status disabled">Désactivé</span>
<span id="version_flash"></span>
</div>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Java:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status cont java-status disabled"></span><span class="cont java-status disabled">Désactivé</span>
<span id="version_java"></span>
</div>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
ActiveX:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status cont activex-status disabled"></span><span class="cont activex-status disabled">Désactivé</span>
</div>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
WebRTC:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status cont webrtc-status">compatible</span><span class="cont webrtc-status">compatible</span>
</div>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
VBScript:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status cont vbscript-status disabled"></span><span class="cont vbscript-status disabled">Désactivé</span>
</div>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
AdBlock:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<div class="enabled-status__wrapper" bis_skin_checked="1">
<span class="enabled-status cont adblock-status disabled"></span><span class="cont adblock-status disabled">Désactivé</span>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-12" bis_skin_checked="1">

<div class="ip-check__card ip-info location-info card_table" bis_skin_checked="1">
<div class="card__icon icon icon_location" bis_skin_checked="1">
<svg width="60px" height="60px">
<use xlink:href="#i-position"></use>
</svg>
</div>
<h4 class="card__title">Localisation</h4>
<div class="card__data" bis_skin_checked="1">
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Pays:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<div style="display:flex;align-items: center;" bis_skin_checked="1">
<img class="flag flag_sm" loading="lazy" data-fetched="country_code" alt="iso" src="./dop/fr.svg">
<span data-fetched="country_name" class="cont">France</span>
<span class="location-info">
&nbsp;(<span data-fetched="country_code">FR</span>)
</span>
</div>
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Register country code:
</div>
<div data-fetched="register_country_code" class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Register country name:
</div>
<div data-fetched="register_country_name" class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Represent country code:
</div>
<div data-fetched="represent_country_code" class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Represent country name:
</div>
<div data-fetched="represent_country_name" class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Continent:
</div>
<div data-fetched="continent_name" class="card__col card__col_value" bis_skin_checked="1">Europe</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Continent code:
</div>
<div data-fetched="continent_code" class="card__col card__col_value" bis_skin_checked="1">EU</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Région:
</div>
<div data-fetched="subdivision1_name" class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Subdivision 1 code:
</div>
<div data-fetched="subdivision1_code" class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Subdivision 2 name:
</div>
<div data-fetched="subdivision2_name" class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Subdivision 2 code:
</div>
<div data-fetched="subdivision2_code" class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Ville:
</div>
<div data-fetched="city_name" class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Code postal:
</div>
<div data-fetched="postal_code" class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
In European Union:
</div>
<div data-fetched="european_union" class="card__col card__col_value" bis_skin_checked="1">1</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
AS Organization:
</div>
<div data-fetched="as_organization" class="card__col card__col_value" bis_skin_checked="1">Scaleway S.a.s.</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
AS Number:
</div>
<div data-fetched="as_number" class="card__col card__col_value" bis_skin_checked="1">12876</div>
</div>
<div class="card__row" style="display: none;" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Metro code:
</div>
<div data-fetched="metro_code" class="card__col card__col_value" bis_skin_checked="1">
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Fuseau horaire:
</div>
<div data-fetched="time_zone" class="card__col card__col_value" bis_skin_checked="1">Europe/Paris</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Latitude:
</div>
<div data-fetched="latitude" class="card__col card__col_value" bis_skin_checked="1">48.8582</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Longitude:
</div>
<div data-fetched="longitude" class="card__col card__col_value" bis_skin_checked="1">2.3387</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Carte:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<script async="" defer="" src="./dop/js(2)"></script>
<script src="./dop/init_map.js.download"></script>
<span class="cont">
<script>
                                    $(document).ready(function () {
                                        $('#gmap_show').click(function (e) {
                                            $('#gmap').toggle();
                                            if ($(this).html() == 'Montrer') {
                                                $(this).html('Cacher');
                                            } else {
                                                $(this).html('Montrer');
                                            }
                                            e.preventDefault();
                                            return false;
                                        });
                                    });
                                  </script>
<a id="gmap_show" class="link" href="https://whoer.net/fr#">Montrer</a>
</span>
</div>
</div>
<div bis_skin_checked="1">
<div id="gmap" style="margin-top: 20px;display: none" bis_skin_checked="1"><div style="height: 100%; width: 100%;" bis_skin_checked="1"><div style="overflow: hidden;" bis_skin_checked="1"></div></div></div>
</div>
</div>
</div>
</div>
<div class="col-lg-12" bis_skin_checked="1">

<div class="ip-check__card time-info location-info card_table" bis_skin_checked="1">
<div class="card__icon icon icon_time" bis_skin_checked="1">
<svg width="60px" height="60px">
<use xlink:href="#i-time"></use>
</svg>
</div>
<h4 class="card__title">Heure</h4>
<div class="card__data" bis_skin_checked="1">
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Fuseau horaire:
</div>
<div data-fetched="time_zone" class="card__col card__col_value matched highlighted_red" bis_skin_checked="1">Europe/Paris</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Local:
</div>
<div class="card__col card__col_value matched highlighted_red" bis_skin_checked="1">
<span data-fetched="local_time" class="time">Sat Nov 4 2023 15:41:27 GMT+0100 (CET)</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Système:
</div>
<div class="card__col card__col_value matched highlighted_red" bis_skin_checked="1">
<span class="cont js-time">Sat Nov 04 2023 17:42:59 GMT+0100 (GMT+01:00)</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
UTC:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span data-fetched="utc_time" class="time">Sat Nov 4 2023 14:41:27 UTC</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
GMT:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span>Sat Nov 4 2023 14:41:27 GMT</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param no-overflow" bis_skin_checked="1">
DST:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span>Non</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Lever du soleil:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span>07:41:44</span>
</div>
</div>
<div class="card__row" bis_skin_checked="1">
<div class="card__col card__col_param" bis_skin_checked="1">
Coucher du soleil:
</div>
<div class="card__col card__col_value" bis_skin_checked="1">
<span>17:26:08</span>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-12" bis_skin_checked="1">

<div class="ip-check__card card_table" bis_skin_checked="1">
<div class="card__icon icon icon_plugins" bis_skin_checked="1">
<svg width="60px" height="60px">
<use xlink:href="#i-plugins"></use>
</svg>
</div>
<h4 class="card__title">Plugins</h4>
<div class="card__data card__data_with-overflow" id="plugins" bis_skin_checked="1">

<div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">PDF Viewer</div><div class="card__col card__col_value" bis_skin_checked="1">internal-pdf-viewer</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">Chrome PDF Viewer</div><div class="card__col card__col_value" bis_skin_checked="1">internal-pdf-viewer</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">Chromium PDF Viewer</div><div class="card__col card__col_value" bis_skin_checked="1">internal-pdf-viewer</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">Microsoft Edge PDF Viewer</div><div class="card__col card__col_value" bis_skin_checked="1">internal-pdf-viewer</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">WebKit built-in PDF</div><div class="card__col card__col_value" bis_skin_checked="1">internal-pdf-viewer</div></div></div>
</div>
</div>
<div class="col-lg-12" bis_skin_checked="1">

<div class="ip-check__card card_table" bis_skin_checked="1">
<div class="card__icon icon icon_navigator" bis_skin_checked="1">
<svg width="60px" height="60px">
<use xlink:href="#i-navigator"></use>
</svg>
</div>
<h4 class="card__title">Navigateur</h4>
<div class="card__data card__data_with-overflow" id="browser-navigator" bis_skin_checked="1"><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">vendorSub</div><div class="card__col card__col_value" bis_skin_checked="1"></div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">productSub</div><div class="card__col card__col_value" bis_skin_checked="1">20030107</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">vendor</div><div class="card__col card__col_value" bis_skin_checked="1">Google Inc.</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">maxTouchPoints</div><div class="card__col card__col_value" bis_skin_checked="1">0</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">pdfViewerEnabled</div><div class="card__col card__col_value" bis_skin_checked="1">true</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">hardwareConcurrency</div><div class="card__col card__col_value" bis_skin_checked="1">4</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">cookieEnabled</div><div class="card__col card__col_value" bis_skin_checked="1">true</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">appCodeName</div><div class="card__col card__col_value" bis_skin_checked="1">Mozilla</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">appName</div><div class="card__col card__col_value" bis_skin_checked="1">Netscape</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">appVersion</div><div class="card__col card__col_value" bis_skin_checked="1">5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">platform</div><div class="card__col card__col_value" bis_skin_checked="1">Win32</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">product</div><div class="card__col card__col_value" bis_skin_checked="1">Gecko</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">userAgent</div><div class="card__col card__col_value" bis_skin_checked="1">Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">language</div><div class="card__col card__col_value" bis_skin_checked="1">en-US</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">onLine</div><div class="card__col card__col_value" bis_skin_checked="1">true</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">webdriver</div><div class="card__col card__col_value" bis_skin_checked="1">false</div></div><div class="card__row" bis_skin_checked="1"><div class="card__col card__col_param" bis_skin_checked="1">deviceMemory</div><div class="card__col card__col_value" bis_skin_checked="1">8</div></div></div>
</div>
</div>
</div>
</div>
</div>
<div class="btn-holder" bis_skin_checked="1">
<a class="button button_full-width" href="https://whoer.net/fr#" onclick="$(&#39;#tab-lite&#39;).click();
                     $(&#39;html, body&#39;).animate({scrollTop: $(&#39;#tab-ext&#39;).offset().top}, 400);
                     event.preventDefault();">
<span>Trop d'informations?&nbsp;</span>
<span>Utiliser la version allégée</span>
</a>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="section section_white section_about">
<div class="section__wrapper" bis_skin_checked="1">
<div class="section__content section__content_text-right container section_about-content" bis_skin_checked="1">
<div class="img__wrapper" bis_skin_checked="1"><img alt="MrWhoer" class="about__img" loading="lazy" data-src="/images/img-02.png" src="./dop/img-02.png" width="297" height="439"></div>
<div class="logo__wrapper" bis_skin_checked="1">
<div class="section__logo" bis_skin_checked="1"></div>
<div bis_skin_checked="1">
<h2 class="section__heading">
– est un service ayant pour but de vérifier l’information que votre ordinateur envoie au web.
</h2>
<p>Il est parfait pour contrôler les serveurs proxy ou socks, fournir des renseignements sur votre réseau privé virtuel et scanner les listes noires pour votre adresse IP.
Le service vous permet de voir si votre ordinateur peut activer les applications Flash et Java et vous renseigne sur les options de langue et les paramètres du système, l’application OS et le navigateur, le réseau DNS, etc.
</p>
<p>Le côté le plus important et le plus puissant de notre service consiste en la vérification intéractive, au moyen des applications Java, Flash et WebRTC, des paramètres du système réels et en la détection de ses faiblesses susceptibles d’être utilisées par des ressources tierces dans le but d’obtenir des informations sur votre ordinateur.
</p>
<p>Pour votre commodité, nous vous proposons deux versions de notre site web, l’allégée et l’intégrale, celle-ci présentant des renseignements supplémentaires.
</p>
</div>
</div>
</div>
</div>
</section>
</div>
<script src="./dop/socialmedia-leak.js.download" async=""></script>
<script>
    const ipArray = [
        {ip: '192.71.227.44', hostname: 'ca2'},
        {ip: '192.71.227.151', hostname: 'ca2'},
        {ip: '79.141.167.41', hostname: 'ca3'},
        {ip: '5.149.253.253', hostname: 'ca3'},
        {ip: '179.43.128.10', hostname: 'ch1'},
        {ip: '179.43.128.13', hostname: 'ch1'},
        {ip: '193.36.117.109', hostname: 'ch3'},
        {ip: '193.36.117.112', hostname: 'ch3'},
        {ip: '49.12.189.248', hostname: 'de1'},
        {ip: '49.12.116.145', hostname: 'de1'},
        {ip: '5.199.143.148', hostname: 'de2'},
        {ip: '89.163.213.171', hostname: 'de2'},
        {ip: '149.154.159.208', hostname: 'de3'},
        {ip: '151.236.17.73', hostname: 'de3'},
        {ip: '45.86.229.142', hostname: 'es1'},
        {ip: '45.86.229.45', hostname: 'es1'},
        {ip: '45.128.132.130', hostname: 'es2'},
        {ip: '45.128.132.133', hostname: 'es2'},
        {ip: '45.128.132.25', hostname: 'es3'},
        {ip: '45.128.132.30', hostname: 'es3'},
        {ip: '158.255.215.112', hostname: 'fr1'},
        {ip: '151.236.21.160', hostname: 'fr1'},
        {ip: '45.128.134.158', hostname: 'fr2'},
        {ip: '45.128.134.168', hostname: 'fr2'},
        {ip: '151.80.182.86', hostname: 'fr3'},
        {ip: '151.80.182.87', hostname: 'fr3'},
        {ip: '158.255.208.59', hostname: 'hk2'},
        {ip: '151.236.20.90', hostname: 'hk2'},
        {ip: '83.136.106.115', hostname: 'it2'},
        {ip: '83.136.106.160', hostname: 'it2'},
        {ip: '45.91.95.173', hostname: 'it3'},
        {ip: '45.91.95.181', hostname: 'it3'},
        {ip: '194.68.27.43', hostname: 'jp1'},
        {ip: '194.68.27.54', hostname: 'jp1'},
        {ip: '202.182.106.7', hostname: 'jp2'},
        {ip: '45.32.58.117', hostname: 'jp2'},
        {ip: '158.247.204.187', hostname: 'kr1'},
        {ip: '141.164.50.12', hostname: 'kr1'},
        {ip: '94.140.115.236', hostname: 'lv1'},
        {ip: '141.136.0.32', hostname: 'lv1'},
        {ip: '79.141.164.133', hostname: 'nl1'},
        {ip: '185.117.91.143', hostname: 'nl1'},
        {ip: '185.158.249.223', hostname: 'nl2'},
        {ip: '194.76.225.11', hostname: 'nl2'},
        {ip: '45.128.135.12', hostname: 'nl4'},
        {ip: '45.128.135.121', hostname: 'nl4'},
        {ip: '194.36.191.82', hostname: 'nl55'},
        {ip: '194.36.191.82', hostname: 'nl55'},
        {ip: '83.138.53.11', hostname: 'nl66'},
        {ip: '83.138.53.12', hostname: 'nl66'},
        {ip: '217.12.201.194', hostname: 'nl88'},
        {ip: '5.34.180.66', hostname: 'nl88'},
        {ip: '95.211.185.9', hostname: 'nl99'},
        {ip: '95.211.185.11', hostname: 'nl99'},
        {ip: '91.193.18.13', hostname: 'pl1'},
        {ip: '91.193.18.14', hostname: 'pl1'},
        {ip: '151.236.25.15', hostname: 'pl2'},
        {ip: '151.236.25.124', hostname: 'pl2'},
        {ip: '194.68.44.48', hostname: 'ro1'},
        {ip: '194.68.44.151', hostname: 'ro1'},
        {ip: '194.14.217.52', hostname: 'ro2'},
        {ip: '194.14.217.61', hostname: 'ro2'},
        {ip: '194.68.44.232', hostname: 'ro3'},
        {ip: '194.14.217.63', hostname: 'ro3'},
        {ip: '213.183.54.29', hostname: 'ru1'},
        {ip: '213.183.54.211', hostname: 'ru1'},
        {ip: '188.127.241.178', hostname: 'ru2'},
        {ip: '188.127.241.179', hostname: 'ru2'},
        {ip: '5.8.16.36', hostname: 'ru3'},
        {ip: '5.8.16.39', hostname: 'ru3'},
        {ip: '213.183.56.135', hostname: 'ru5'},
        {ip: '213.183.57.51', hostname: 'ru5'},
        {ip: '46.246.97.192', hostname: 'se1'},
        {ip: '46.246.96.12', hostname: 'se1'},
        {ip: '185.117.89.169', hostname: 'se2'},
        {ip: '185.117.89.171', hostname: 'se2'},
        {ip: '194.68.26.153', hostname: 'sg1'},
        {ip: '194.68.26.161', hostname: 'sg1'},
        {ip: '103.122.245.144', hostname: 'th1'},
        {ip: '103.122.245.145', hostname: 'th1'},
        {ip: '45.89.52.100', hostname: 'tr1'},
        {ip: '45.89.52.184', hostname: 'tr1'},
        {ip: '185.125.33.12', hostname: 'tr2'},
        {ip: '185.125.33.243', hostname: 'tr2'},
        {ip: '31.131.18.169', hostname: 'ua1'},
        {ip: '31.131.18.173', hostname: 'ua1'},
        {ip: '176.107.182.146', hostname: 'ua2'},
        {ip: '176.107.182.144', hostname: 'ua2'},
        {ip: '185.250.150.116', hostname: 'ua4'},
        {ip: '185.250.150.117', hostname: 'ua4'},
        {ip: '85.239.62.176', hostname: 'uk1'},
        {ip: '85.239.62.177', hostname: 'uk1'},
        {ip: '37.235.54.75', hostname: 'uk2'},
        {ip: '151.236.19.73', hostname: 'uk2'},
        {ip: '37.61.229.103', hostname: 'uk3'},
        {ip: '37.61.229.140', hostname: 'uk3'},
        {ip: '85.239.52.217', hostname: 'us3'},
        {ip: '85.239.52.218', hostname: 'us3'},
        {ip: '5.161.97.42', hostname: 'us311'},
        {ip: '5.161.21.223', hostname: 'us311'},
        {ip: '194.9.176.44', hostname: 'us4'},
        {ip: '185.174.101.226', hostname: 'us4'},
        {ip: '91.193.19.65', hostname: 'us5'},
        {ip: '91.193.19.153', hostname: 'us5'}
    ];

    function getIPAddress(callback) {
        let xhr = new XMLHttpRequest();
        xhr.open('GET', 'https://api.ipify.org?format=json', true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                let response = JSON.parse(xhr.responseText);
                let ipAddress = response.ip;
                callback(ipAddress);
            }
        };
        xhr.send();
    }

    function handleMutation(mutationsList, observer) {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList') {
                const block = document.getElementById('city-name');
                if (block.innerHTML.length > 2 && !block.innerHTML.endsWith('/')) {
                    block.innerHTML += ' /';
                }
            }
        }
    }
    const observer = new MutationObserver(handleMutation);
    const config = { childList: true, subtree: true };
    const targetNode = document.getElementById('city-name');
    observer.observe(targetNode, config);

    setTimeout(() => {
        getIPAddress(function (ipAddress) {
            let isInArray = ipArray.some(item => item.ip === ipAddress);
            const isWhoerUser = document.getElementById("isWhoerUser");
            const isNotWhoerUser = document.getElementById("isNotWhoerUser");
            const checkConnection = document.getElementById("checkConnection")
            if (!isInArray) {
                checkConnection.style.display = "none";
                isNotWhoerUser.style.display = "block";
            } else {
                checkConnection.style.display = "none";
                isWhoerUser.style.display = "flex";
            }
        });
    }, 3000)
</script>
<script>
    let notNetwork = document.querySelector('#notLoggedIn');
    let inNetwork = document.querySelector('#loggedIn');
    let inNetworkClass = document.querySelector('.loggedIn');
    let notNetworkClass = document.querySelector('.notLoggedIn');

    function renderExtednsBlock(img, alt) {

        if (notNetworkClass) {
            notNetworkClass.remove();
        }
        let icon = document.createElement('img');
        icon.src = img;
        icon.alt = alt;
        icon.setAttribute('style', 'width: 24px; height: 20px; margin-right: 12px;')
        inNetworkClass.appendChild(icon);
    }

    function displayResult(network, loggedIn) {
        let icon = document.createElement('img');
        icon.src = network.icon;
        icon.alt = network.name;
        icon.setAttribute('style', 'width: 24px; height: 20px; margin-right: 12px;')

        renderExtednsBlock(network.icon, network.name);
        inNetwork.appendChild(icon);
        if (notNetwork) {
            notNetwork.remove();
        }
    }

    window.onload = function () {
        leakSocialMediaAccounts(displayResult);
    };

</script>
<script>
    const ipDsblYes = 'Oui';
    const ipDsblNo = 'Non';

    const tariffBlock = document.querySelector('.section__title--tariff');

    function showAnonimityDescription() {
        $('#enoughInfo').show();
        $('#moreInfo').hide();
        $('.section_alevel').addClass('open');
        $('html, body').animate({scrollTop: $('.alevel__list').offset().top - 93});
    }

    function hideAnonimityDescription() {
        $('#moreInfo').show();
        $('#enoughInfo').hide();
        $('.section_alevel').removeClass('open');
    }

    let pub = {
        ip_plain: {ip: "51.159.220.100", iso: "fr"},
        ip_flash: {},
        ip_java_udp: {},
        ip_java_tcp: {},

        dns: [],
        ips: [],

        dns_br: {}, //?
        dns_flash: {}, //?
        dns_java_resolve: {},//?
        dns_java_system: {}, //?

        os_java: {},
        os_flash: {},
        os_javascript: {},
        os_tcpip: {},

        lang_br: '',
        lang_js: [],
        lang_java: '',
        lang_flash: '',

        time_mismatch: 0,
        ua_mismatch: 0,
        datacenter_ip: 0,

        activex: 0,
        webrtc: 0,
        flash: 0,
        java: 0,
        firebug: 0,
        vbscript: 0,
        adblock: 0,

        langs: ['fr','ae','us' ],
        track: 1,
        anonymizer: 0,
        tor: 0,
        vpn_provider: 0,
        proxy: "1",
        proxy_ports: 0,
        dsbl: 0,
    };

    let scores = {
        // primary  [%,
        "tor": [30, 'primary'],
        "anonymizer": [30, 'primary'],
        "proxy": [30, 'primary'],
        "ua_mismatch": [20, 'primary'],
        "langs": [20, 'primary'],
        "dns": [30, 'primary'],
        "ips": [40, 'primary'],
        // secondary
        "time_mismatch": [10, 'secondary'],
        "dsbl": [10, 'secondary'],
        "flash": [10, 'secondary'],
        "java": [10, 'secondary'],
        "activex": [10, 'secondary'],
        //"webrtc": [10, 'secondary'],
        "webrtc_local_net": [10, 'secondary'],
        "proxy_ports": [10, 'secondary'],
        "track": [0, 'secondary'],
        "vpn_provider": [0, 'secondary']
        // TODO: pdf?
        // vbscript?
        // devtools?
    };

    let score_res = [
        [100, 101, "score-best", "Vos mesures d&#39;anonymat sont sûrs ou vous ne les utilisez pas"], // green
        [90, 100, "score-good", "Quelques remarques sur l&#39;anonymat et la sécurité"], // light-green
        [80, 90, "score-not-bad", "Remarques sur la sécurité, réparation recommandée"], // yellow
        [70, 80, "score-medium", "Niveau de sécurité modéré et remarques sur l&#39;anonymat"], // yellow
        [60, 70, "score-bad", "Graves failles de sécurité et d&#39;anonymat"], // orange
        [50, 60, "score-very-bad", "Vos efforts de vous cacher sont détectés, votre anonymat mis en cause"], // pink
        [30, 50, "score-nightmare", "On connaît trop de choses sur vous!"], // red
        [0, 30, "score-godless", "Toc-toc, Neo..."] // red
    ];
</script>
<script>
    async_req_timeout = 20000;
    preloaders_timeout = 25000;
    let isAdBlockEnabled = true;

    $(document).ready(function () {
        let urlParams = new URLSearchParams(window.location.search);
        let withDescription = urlParams.get('description');
        if (withDescription) {
            $('#descr').show()
        } else {
            $('#main').show()
        }
        // $('body').css('opacity',1)
        // $('header').css('opacity',1)
        // $('footer').css('opacity',1)

        scripts.js('.js-status');
        pub["flash"] = scripts.flash('.flash-status');
        pub["java"] = scripts.java('.java-status');
        pub["activex"] = scripts.activex('.activex-status');
        pub["vbscript"] = scripts.vbscript('.vbscript-status');
//    pub["firebug"] = scripts.firebug('.firebug-status');
        pub["webrtc"] = scripts.webrtc('.webrtc-status');
        pub["adblock"] = scripts.adblock('.adblock-status');

        <!-- TODO: in another script tag -->
        pub["time_mismatch"] =
            check_time_difference(
                {
                    js_time_container: '.js-time',
                    time_diff_container: '.time-diff',
                    local_timestamp: '1699112487',
                    local_timezone: 'GMT+0100'
                });

        pub["ua_mismatch"] = scripts.jsua('.js-ua-headers', '.browser-ua-headers', '.diff-ua-headers');

        if (pub["time_mismatch"] === 0 || pub["time_mismatch"] === 1) {
            $('.ip-check__card.time-info .card__col_value.matched').addClass(pub["time_mismatch"] ? 'highlighted_red' : 'highlighted_green');
        }


            pub["anonymizer"] = scripts.anonymizer( 'whoer'+ '.' +'net', '#using-anonymizer');

        scripts.languages('.js_language');

        set_lang_data('#lang_js_ext', pub['lang_js'], 'js');

        scripts.os('#os_js');
        scripts.screen('#browser-screen');
        scripts.navigator('#browser-navigator');
        display_plugins('#plugins');

        // fix height of dd's
        $('dl.myip-list dd').each(function (i) {
            let _pH = $(this).prev().height();
            $(this).css('min-height', _pH);
        });

        calc_anonym();

        try {
            run_webrtc_check(function (ip) {
                webrtc_ips.push(ip);
                set_webrtc_ips();
            });
        } catch (e) {
        }
        ;

    });
</script>
<script>

    function run_java_ext_applet() {
        if (!window.navigator.javaEnabled()) {
            return;
        }

        let app = document.createElement('applet');
        let attributes = {
            code: 'WhoerInteractiveDetection',
            width: 1,
            height: 1,
            archive: '/java/WhoerInteractiveDetection.jar',
            id: 'WhoerInteractiveDetection',
            mayscript: 'mayscript'
        };
        for (let attribute in attributes) {
            app.setAttribute(attribute, attributes[attribute]);
        }

        let parameters = {
            init_preloaders: "init_ajax_preloaders",
            ids_list: "#ip_java_system,#dns_java_system,#os_java,#version_java,#lang_java,#ip_java_tcp_ip,#ip_java_udp_ip,#dns_java_resolve_ip",

            os_id: "#os_java",
            callback_for_os: "set_os_data",

            dns_sys_id: "#dns_java_system",
            dns_sys_request: "/fr/ips2country?ips=",

            dns_resolve_id: "#dns_java_resolve",
            unique_domain: "pelap1699108.jv.whrq.whoer.net",
            dns_request: "/fr/dns?domain=pelap1699108.jv",
            callback_for_dns: "async_req",

            callback_for_version: "set_version_data",
            version_id: "#version_java",

            callback_for_lang: "set_lang_data",
            language_id: "#lang_java",

            tcp_host: "whoer.net",
            udp_host: "ns8.whdn.whoer.net",
            tcp_port: "80",
            udp_port: "53",
            request: "/fr/ip_json",
            timeout: "9000",
            not_available: "N/A",

            udp_message: "ilfht1699108.ud",
            udp_result_request: "/fr/dns?domain=ilfht1699108.ud",

            callback_for_udp: "async_req",
            udp_ip_id: "#ip_java_udp",

            callback_for_ip: "set_ip_data",
            tcp_ip_id: "#ip_java_tcp",

            callback_for_network_system: "set_java_network",
            ip_system_id: "#ip_java_system"
        };

        if (parameters != 'undefined' && parameters != null) {
            for (let parameter in parameters) {
                let param = document.createElement("param");
                param.setAttribute("name", parameter);
                param.setAttribute("value", parameters[parameter]);
                app.appendChild(param);
            }
        }
        document.getElementsByTagName('body')[0].appendChild(app);
    }
</script>

<script src="./dop/api_new.js.download"></script>
<script>
    let flash_obj = '<object width="1" height="1">   <param name="movie" value="/flash/WhoerDetection.swf?1699108887">   <param name="menu" value="false">   <param name="allowScriptAccess" value="always">   <param name="bgcolor" value="#ffffff">   <param name="flashlets"          value="callback_for_dns=async_req&dns_request=/fr/dns?domain=cplin1699108.fl&unique_domain=cplin1699108.fl.whrq.whoer.net&callback_for_version=set_version_data&host=ns8.whdn.whoer.net&port=843&send_msg=Love&os_id=#os_flash&ver_id=#version_flash&lang_id=#lang_flash&ip_id=#ip_flash&dns_id=#dns_flash&ids_list=#version_flash,#lang_flash,#os_flash,#dns_flash_ip,#ip_flash_ip&init_preloaders=init_ajax_preloaders&callback_for_os=set_os_data&callback_for_lang=set_lang_data&callback_for_ip=set_ip_data">  <embed     src="/flash/WhoerDetection.swf?1699108887" width="1" height="1"     menu="false"     loop="false"     allowScriptAccess="always"     flashlets="callback_for_dns=async_req&dns_request=/fr/dns?domain=cplin1699108.fl&unique_domain=cplin1699108.fl.whrq.whoer.net&callback_for_version=set_version_data&host=ns8.whdn.whoer.net&port=843&send_msg=Love&os_id=#os_flash&ver_id=#version_flash&lang_id=#lang_flash&ip_id=#ip_flash&dns_id=#dns_flash&ids_list=#version_flash,#lang_flash,#os_flash,#dns_flash_ip,#ip_flash_ip&init_preloaders=init_ajax_preloaders&callback_for_os=set_os_data&callback_for_lang=set_lang_data&callback_for_ip=set_ip_data">  </embed></object>';

    $("#run_interactive").on('click', function () {
        $(this).addClass("done");
        //$(this).prop("disabled",true);
        $(this).html('Exécuter');

        $('#flash_container').html(flash_obj);
        run_java_ext_applet();

//event.stopPropagation();
//event.preventDefault();
        return false;
    });

</script>
<script src="./dop/advert.js.download" async=""></script>
<script>
    $(document).ready(function () {
// TODO: enable it in the future
    });
    $.ajax({
        url: "https://gshoc1699108.eg.whrq.whoer.net/css/null.css",
        cache: false,
        async: true,
        timeout: 500
    });
    $.ajax({
        url: "https://nrheb1699108.dt.whrq.whoer.net/css/null.css",
        cache: false,
        async: true,
        timeout: 500
    });
    $.ajax({
        url: "https://viiwl1699108.em.whrq.whoer.net/css/null.css",
        cache: false,
        async: true,
        timeout: 500
    });
    $.ajax({
        url: "https://svsos1699108.ar.whrq.whoer.net/css/null.css",
        cache: false,
        async: true,
        timeout: 500
    });
    $.ajax({
        url: "https://kimhd1699108.cl.whrq.whoer.net/css/null.css",
        cache: false,
        async: true,
        timeout: 500
    });

    new Clipboard('.your-ip');
</script>
<script>
    $(document).ready(function () {
        async_req('.dns_br', '/fr/dns?domain=gshoc1699108.eg', 'dns');
        async_req('#proxy_ports', '/fr/ports', 'ports');
//async_req('.grayip', '/fr/grayip', 'grayip');
    });
</script>
<script>
        $(document).ready(function () {
            let xhr = raw_XHR();
            xhr.open("get", "https://tcp.whoer.net/catch/sfqyr1699108.mt?_=" + Math.random(), true);
            xhr.onload = function () {
                async_req('#os_mtu', '/fr/mtu?id=sfqyr1699108.mt', 'mtu')
            };
            xhr.send(null);
        });
    </script>
</div>
<footer class="footer">
<div class="footer__wrapper" bis_skin_checked="1">
<div class="container" bis_skin_checked="1">
<div class="row" bis_skin_checked="1">
<div class="column" bis_skin_checked="1">
<h1 style=" font-size: 16px;
      font-weight: bold;
      text-transform: uppercase;
      color: #fff;
      margin-bottom: 20px;">Information</h1>
<ul>
<li>
<a href="https://whoer.net/fr/affiliate">Programme d'affiliation</a>
</li>
<li>
<a href="https://whoer.net/blog/fr/">Blog</a>
</li>
<li>
<a href="https://whoer.net/fr/vpn/recovery">Récupérer le code d'accès</a>
</li>
<li>
<a href="https://whoer.net/fr/terms_of_use">Conditions d'utilisations</a>
</li>
<li>
<a href="https://whoer.net/fr/refund_policy">Politique de remboursement</a>
</li>
<li>
<a href="https://whoer.net/fr/privacy_policy">Politique de confidentialité</a>
</li>
<li>
<a href="https://whoer.net/fr/apps_privacy_policy">Politique de confidentialité des applications</a>
</li>
<li>
<a href="https://whoer.net/fr/contacts">Contacts</a>
</li>
<li>
<a href="https://whoer.net/fr/about-us">À propos de nous</a>
</li>
</ul>
</div>
<div class="column" bis_skin_checked="1">
<h1 style=" font-size: 16px;
      font-weight: bold;
      text-transform: uppercase;
      color: #fff;
      margin-bottom: 20px;">Whoer VPN</h1>
<ul>
<li>
<a href="https://whoer.net/fr/download/vpn-windows">VPN pour Windows</a>
</li>
<li>
<a href="https://whoer.net/fr/download/vpn-mac">VPN pour Mac</a>
</li>
<li>
<a href="https://whoer.net/fr/download/vpn-linux">VPN pour Linux</a>
</li>
<li>
<a href="https://whoer.net/fr/download/vpn-android">VPN pour Android</a>
</li>
<li>
<a href="https://whoer.net/fr/download/vpn-ios">VPN pour iOS</a>
</li>
<li>
<a href="https://whoer.net/fr/download/vpn-chrome">VPN pour Chrome</a>
</li>
<li>
<a href="https://whoer.net/fr/download/vpn-edge">VPN pour Edge</a>
</li>
<li>
<a href="https://whoer.net/fr/download/vpn-firefox">VPN pour Firefox</a>
</li>
<li>
<a href="https://whoer.net/fr/download/vpn-opera">VPN pour Opera</a>
</li>
<li>
<a href="https://whoer.net/fr/download/vpn-yandex">VPN pour Yandex</a>
</li>
<li>
<a href="https://whoer.net/fr/download/vpn-router">VPN pour Routeur</a>
</li>
</ul>
</div>
<div class="column" bis_skin_checked="1">
<h1 style=" font-size: 16px;
      font-weight: bold;
      text-transform: uppercase;
      color: #fff;
      margin-bottom: 20px;">Services</h1>
<ul>
<li>
<a href="https://whoer.net/fr">
Mon IP
</a>
</li>
<li>
<a href="https://whoer.net/fr/vpn">
VPN
</a>
</li>
<li>
<a href="https://whoer.net/fr/antidetect">
Navigateur anti-détection
</a>
</li>
<li>
<a href="https://whoer.net/fr/aml">
Contrôle AML
</a>
</li>
<li>
<a href="https://whoer.net/fr/vpn/trial">
VPN gratuit
</a>
</li>
<li>
<a href="https://whoer.net/fr/speedtest">
Test de vitesse
</a>
</li>
<li>
<a href="https://whoer.net/fr/ping">
Ping
</a>
</li>
<li>
<a href="https://whoer.net/fr/checkwhois">
Whois
</a>
</li>
<li>
<a href="https://whoer.net/fr/dns-leak-test">Test de fuite DNS</a>
</li>
<li>
<a href="https://whoer.net/fr/port-scanner-online">Scanner de ports</a>
</li>
<li>
<a href="https://whoer.net/fr/jabber_im_client">Jabber IM Client</a>
</li>
</ul>
</div>
<div class="column" bis_skin_checked="1">
<h1 style=" font-size: 16px;
      font-weight: bold;
      text-transform: uppercase;
      color: #fff;
      margin-bottom: 20px;">Liens utiles</h1>
<ul>
<li>
<a id="open-jivo-chat" onclick="event.preventDefault();jivoOpen();" style="color: #ff7d19; cursor: pointer;">
Сassistance client
</a>
</li>
<li>
<a href="https://whoer.net/blog/fr/comment-rester-100-anonyme-sur-la-page-daccueil-de-whoer-net/">
Comment obtenir 100% d'anonymat
</a>
</li>
<li>
<a href="https://whoer.net/blog/fr/problemes-lies-au-vpn-ainsi-que-leurs-solutions/">
Problèmes avec VPN et moyens de les résoudre
</a>
</li>
<li>
<a href="https://whoer.net/blog/fr/configurer-un-vpn-sur-votre-routeur/">
Configurer un OpenVPN sur le routeur
</a>
</li>
<li>
<a href="https://whoer.net/blog/fr/comment-desactiver-internet-lorsque-le-vpn-se-deconnecte/">
Comment désactiver Internet lors de la rupture d'une connexion VPN
</a>
</li>
<li>
<a href="https://whoer.net/fr/vpn-crimea">
VPN pour la Crimée
</a>
</li>
<li>
<a href="https://whoer.net/fr/vpn-for-games">
VPN pour le jeu
</a>
</li>
</ul>
</div>
<div class="column footer__store-links--apps" bis_skin_checked="1">
<h1 style=" font-size: 16px;
      font-weight: bold;
      text-transform: uppercase;
      color: #fff;
      margin-bottom: 20px;" class="footer__store-links-title">Applications</h1>
<div class="footer__store-links" bis_skin_checked="1">
<a href="https://apps.apple.com/us/app/whoervpn/id1369052279?l=en" class="footer__store-link footer__store-link_ios" target="_blank">
<img class="footer__store-link-badge" src="./dop/badge-ios-fr.svg" loading="lazy" alt="Télécharger VPN pour iOS">
</a>
<a href="https://play.google.com/store/apps/details?id=com.sml.t1r.whoervpn&amp;hl=en" class="footer__store-link footer__store-link_google" target="_blank">
<img class="footer__store-link-badge" src="./dop/badge-android-fr.svg" loading="lazy" alt="Télécharger VPN pour Android">
</a>
</div>
</div>
</div>
<div class="footer__copy row row_flex" bis_skin_checked="1">
<div class="column" bis_skin_checked="1">
<span>Copyright © <a href="https://whoer.net/">whoer.net</a> 2008-<span id="year">2023</span></span>
</div>
<div class="column empty" bis_skin_checked="1">
</div>
<div class="column  empty" bis_skin_checked="1">
</div>
<div class="column column_joinus" bis_skin_checked="1">
<div class="footer__joinus" bis_skin_checked="1">
<a target="_blank" rel="noopener" href="https://t.me/whoer_official">
<svg width="16" height="13" viewBox="0 0 16 13" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill="#FFF" fill-rule="evenodd" d="M15.9866 1.12245C16.1112 0.374509 15.3454 -0.215843 14.6292 0.0761387L0.364818 5.89164C-0.148772 6.10103 -0.111204 6.82338 0.421467 6.9809L3.36315 7.85077C3.92458 8.01679 4.53253 7.93095 5.02279 7.61643L11.655 3.36168C11.855 3.23338 12.073 3.49743 11.9021 3.66101L7.12811 8.23146C6.66501 8.67482 6.75693 9.42607 7.31397 9.75044L12.659 12.8628C13.2585 13.2119 14.0297 12.8612 14.1418 12.1886L15.9866 1.12245Z"></path>
</svg>
</a>
<a target="_blank" rel="noopener" href="https://www.facebook.com/WhoerNetOfficial/">
<svg xmlns="http://www.w3.org/2000/svg" width="8" height="16">
<path fill="#FFF" fill-rule="evenodd" d="M7.699.002L5.78-.002c-2.156 0-3.549 1.546-3.549 3.938v1.816H.302c-.167 0-.302.146-.302.327v2.63c0 .18.135.326.302.326h1.929v6.638c0 .18.135.326.302.326H5.05c.166 0 .301-.146.301-.326V9.035h2.256c.167 0 .302-.146.302-.326l.001-2.63a.338.338 0 0 0-.089-.231.286.286 0 0 0-.213-.096H5.351V4.213c0-.74.163-1.115 1.055-1.115l1.292-.001c.167 0 .302-.146.302-.326V.328c0-.18-.135-.326-.301-.326z"></path>
</svg>
</a>
<a target="_blank" rel="noopener" href="https://twitter.com/WhoerNet">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="13">
<path fill="#FFF" fill-rule="evenodd" d="M16 1.538a6.62 6.62 0 0 1-1.885.517A3.302 3.302 0 0 0 15.558.239a6.594 6.594 0 0 1-2.086.797A3.284 3.284 0 0 0 7.879 4.03 9.317 9.317 0 0 1 1.115.599 3.283 3.283 0 0 0 2.13 4.982a3.284 3.284 0 0 1-1.486-.413v.042A3.285 3.285 0 0 0 3.276 7.83a3.325 3.325 0 0 1-.865.115c-.211 0-.416-.021-.617-.061a3.282 3.282 0 0 0 3.065 2.28 6.586 6.586 0 0 1-4.076 1.403c-.265 0-.526-.016-.783-.045a9.276 9.276 0 0 0 5.031 1.477c6.038 0 9.338-5.002 9.338-9.34l-.011-.425A6.586 6.586 0 0 0 16 1.538z"></path>
</svg>
</a>
<a target="_blank" rel="noopener" href="https://vk.com/whoernet">
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="11">
<path fill="#FFF" fill-rule="evenodd" d="M19.894 9.934a1.236 1.236 0 0 0-.067-.125c-.347-.603-1.011-1.342-1.989-2.219l-.021-.02-.01-.01-.011-.01h-.01c-.445-.408-.726-.683-.844-.823-.215-.268-.264-.539-.146-.814.083-.207.396-.646.937-1.315.285-.354.511-.639.677-.853 1.201-1.539 1.722-2.523 1.562-2.952l-.062-.1c-.041-.06-.149-.115-.322-.165-.174-.05-.396-.059-.667-.025l-2.999.019a.412.412 0 0 0-.208.006l-.136.03-.052.025-.041.03a.448.448 0 0 0-.115.106.67.67 0 0 0-.104.175c-.326.81-.698 1.563-1.114 2.259-.257.415-.493.775-.709 1.08a5.22 5.22 0 0 1-.541.672 3.644 3.644 0 0 1-.396.346c-.118.087-.208.124-.27.111-.063-.014-.122-.027-.178-.041a.675.675 0 0 1-.234-.246 1.054 1.054 0 0 1-.119-.391 4.273 4.273 0 0 1-.037-.407 8.4 8.4 0 0 1 .005-.482c.008-.207.011-.348.011-.422 0-.253.005-.53.015-.827l.026-.708c.008-.174.011-.358.011-.552a2.24 2.24 0 0 0-.037-.457 1.483 1.483 0 0 0-.109-.321.544.544 0 0 0-.213-.241 1.252 1.252 0 0 0-.349-.136C10.66.051 10.191.007 9.622 0 8.331-.013 7.501.068 7.133.242a1.387 1.387 0 0 0-.396.301c-.125.147-.142.228-.052.241.417.06.712.204.885.431l.063.121c.049.087.097.241.146.461.048.221.08.465.093.733a7.46 7.46 0 0 1 0 1.255c-.034.348-.067.619-.098.813a1.615 1.615 0 0 1-.266.693.164.164 0 0 1-.052.05.812.812 0 0 1-.281.05c-.098 0-.215-.046-.354-.14a2.463 2.463 0 0 1-.432-.387 5.116 5.116 0 0 1-.506-.688A12.126 12.126 0 0 1 5.3 3.133l-.166-.292c-.104-.187-.246-.46-.427-.818-.181-.358-.34-.704-.479-1.039a.672.672 0 0 0-.25-.321l-.052-.03A1.126 1.126 0 0 0 3.52.482L.667.502c-.292 0-.49.064-.594.191l-.042.06A.313.313 0 0 0 0 .914c0 .074.021.164.062.271.417.944.87 1.854 1.359 2.731.49.876.915 1.582 1.276 2.117.361.536.729 1.042 1.104 1.517.375.475.623.779.744.913.122.134.217.234.287.301l.26.241c.167.161.411.353.734.577.323.224.681.445 1.073.663.392.217.849.395 1.369.532a4.905 4.905 0 0 0 1.521.166h1.197c.243-.02.427-.094.552-.221l.042-.051a.698.698 0 0 0 .078-.185c.024-.084.036-.176.036-.276a3.247 3.247 0 0 1 .067-.778c.052-.231.112-.405.178-.522a1.285 1.285 0 0 1 .401-.441.592.592 0 0 1 .083-.036c.167-.053.363-.002.589.156.225.158.437.351.635.582.198.231.435.491.713.778.278.288.521.502.729.643l.208.12c.139.081.32.154.542.221a1.2 1.2 0 0 0 .583.05l2.666-.04c.263 0 .468-.042.614-.125.146-.084.232-.176.26-.276a.751.751 0 0 0 .006-.342 1.185 1.185 0 0 0-.074-.266z"></path>
</svg>
</a>
<a target="_blank" rel="noopener" href="https://www.instagram.com/whoer_net/">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16">
<path fill="#FFF" fill-rule="evenodd" d="M13 15.999H3a3 3 0 0 1-3-3V3A3 3 0 0 1 3-.001h10A3 3 0 0 1 16 3v9.999a3 3 0 0 1-3 3zm-1.38-8.716c-.019-.097-.055-.189-.082-.284-.036-.127-.069-.256-.118-.378-.047-.115-.108-.222-.166-.332-.048-.09-.091-.183-.146-.269-.072-.111-.155-.214-.237-.316A3.671 3.671 0 0 0 8 4.307a3.668 3.668 0 0 0-2.871 1.397c-.083.103-.166.204-.237.315-.055.087-.099.181-.148.273-.057.108-.118.214-.165.329-.049.122-.081.252-.118.38-.026.094-.062.185-.081.282a3.676 3.676 0 0 0-.073.716 3.693 3.693 0 0 0 7.385 0c0-.245-.026-.484-.072-.716zM14.769 3c0-.976-.793-1.77-1.769-1.77H3c-.975 0-1.769.794-1.769 1.77v2.538h2.531C4.616 4.074 6.186 3.076 8 3.076c1.814 0 3.384.998 4.238 2.462h2.531V3zm-3.077.692V2.461c0-.339.277-.616.616-.616h1.23c.339 0 .616.277.616.616v1.231a.617.617 0 0 1-.616.615h-1.23a.617.617 0 0 1-.616-.615zm-3.691 6.654a2.345 2.345 0 0 1-2.347-2.347c0-.446.131-.859.347-1.214a1.175 1.175 0 0 0-.058.348 1.19 1.19 0 1 0 1.19-1.19c-.121 0-.236.023-.347.057A2.333 2.333 0 0 1 8 5.653a2.346 2.346 0 1 1 .001 4.693z"></path>
</svg>
</a>
<a target="_blank" rel="noopener" href="https://www.youtube.com/channel/UC27FoXl1nXiSkiZR0vHkF8Q">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="12">
<path fill="#FFF" fill-rule="evenodd" d="M14.4.299c-.48-.15-3.44-.3-6.4-.3-2.96 0-5.92.15-6.4.3-1.28.375-1.6 3-1.6 5.7s.32 5.326 1.6 5.7c.48.15 3.44.3 6.4.3 2.96 0 5.92-.15 6.4-.3 1.28-.374 1.6-3 1.6-5.7s-.32-5.325-1.6-5.7zm-8 9.076V2.624l4.8 3.375-4.8 3.376z"></path>
</svg>
</a>
</div>
</div>
<div class="footer__buttons" bis_skin_checked="1">
<div class="footer__lang-select dropdown" bis_skin_checked="1">
<div class="button-languages" bis_skin_checked="1">
<input id="list-dropdown-toggle" type="checkbox">
<label id="list-dropdown-label" for="list-dropdown-toggle" class="button-languages__button">
<img class="button-languages__flag" src="./dop/fr.svg" loading="lazy" alt="Flag France">
<span class="button-languages__text">Français</span>
</label>
<ul id="list-dropdown-collapse" class="button-languages__list-dropdown" style="z-index: 1;">
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/en">
<img class="button-languages__list-flag" src="./dop/en.svg" loading="lazy" alt="Flag country.en">
<span class="button-languages__list-name">English</span>
</a>
</li>
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/ru">
<img class="button-languages__list-flag" src="./dop/ru.svg" loading="lazy" alt="Flag Russie">
<span class="button-languages__list-name">Русский</span>
</a>
</li>
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/de">
<img class="button-languages__list-flag" src="./dop/de.svg" loading="lazy" alt="Flag Allemagne">
<span class="button-languages__list-name">Deutsch</span>
</a>
</li>
<li class="button-languages__list-item" style="background-color:rgba(92,165,195,.15);">
<a class="button-languages__list-link" href="https://whoer.net/fr">
<img class="button-languages__list-flag" src="./dop/fr.svg" loading="lazy" alt="Flag France">
<span class="button-languages__list-name">Français</span>
</a>
</li>
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/es">
<img class="button-languages__list-flag" src="./dop/es.svg" loading="lazy" alt="Flag Espagne">
<span class="button-languages__list-name">Español</span>
</a>
</li>
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/tr">
<img class="button-languages__list-flag" src="./dop/tr.svg" loading="lazy" alt="Flag Turquie">
<span class="button-languages__list-name">Türk</span>
</a>
</li>
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/zh">
<img class="button-languages__list-flag" src="./dop/zh.svg" loading="lazy" alt="Flag country.zh">
<span class="button-languages__list-name">中文</span>
</a>
</li>
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/it">
<img class="button-languages__list-flag" src="./dop/it.svg" loading="lazy" alt="Flag Italie">
<span class="button-languages__list-name">Italiano</span>
</a>
</li>
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/pl">
<img class="button-languages__list-flag" src="./dop/pl.svg" loading="lazy" alt="Flag Pologne">
<span class="button-languages__list-name">Polski</span>
</a>
</li>
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/cz">
<img class="button-languages__list-flag" src="./dop/cz.svg" loading="lazy" alt="Flag République tchèque">
<span class="button-languages__list-name">Český</span>
</a>
</li>
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/nl">
<img class="button-languages__list-flag" src="./dop/nl.svg" loading="lazy" alt="Flag Pays-Bas">
<span class="button-languages__list-name">Nederland</span>
</a>
</li>
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/pt">
<img class="button-languages__list-flag" src="./dop/pt.svg" loading="lazy" alt="Flag Portugal">
<span class="button-languages__list-name">Português</span>
</a>
</li>
<li class="button-languages__list-item">
<a class="button-languages__list-link" href="https://whoer.net/jp">
<img class="button-languages__list-flag" src="./dop/jp.svg" loading="lazy" alt="Flag Japon">
<span class="button-languages__list-name">日本</span>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
<script defer="" src="./dop/jquery.main.js.download"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const currentYear = document.querySelector('#year');
    const date = new Date();
    const year = date.getFullYear();
    currentYear.textContent = year.toString();
})
</script>
<svg width="0" height="0" class="hidden">
<symbol xmlns="http://www.w3.org/2000/svg" id="i-scripts">
<path fill="currentColor" fill-rule="evenodd" d="M49.767 57.999c-2.82 0-5.377-1.143-7.23-2.989H7.245V9.909H0V4.097A4.108 4.108 0 0 1 4.109 0h43.186c2.482 0 4.501 2.013 4.501 4.489v27.402L60 34.846v12.949c0 5.627-4.591 10.204-10.233 10.204zM7.245 4.097a2.352 2.352 0 0 0-2.351-2.345h-.785a2.352 2.352 0 0 0-2.351 2.345v1.431h2.998v1.754H1.758v.874h5.487V4.097zm42.793 5.157h-2.704V7.501h2.704V4.489a2.743 2.743 0 0 0-2.743-2.737H8.261a4.07 4.07 0 0 1 .742 2.345v44.879h9.025v1.753H9.003v2.528h24.836v-4.194h1.758v4.194h5.526a10.16 10.16 0 0 1-.872-1.71l-.018-.045a10.64 10.64 0 0 1-.134-.363l-.03-.085a7.58 7.58 0 0 1-.099-.311l-.041-.137a8.696 8.696 0 0 1-.075-.277l-.023-.093a9.403 9.403 0 0 1-.054-.228l-.021-.097a9.952 9.952 0 0 1-.113-.633l-.012-.079a12.712 12.712 0 0 1-.034-.273l-.006-.057a8.767 8.767 0 0 1-.029-.326l-.005-.067-.014-.265-.003-.089a8.875 8.875 0 0 1-.006-.327V34.846l10.233-3.686.271.097V9.254zm8.204 26.822l-8.475-3.052-8.475 3.052v11.718c0 .14.004.279.01.417l.011.149c.006.089.012.176.02.263.006.059.014.117.021.176.009.078.018.156.03.233.008.06.019.12.029.18.013.075.026.15.041.225a7.676 7.676 0 0 0 .09.402c.013.054.028.107.042.16a8.4 8.4 0 0 0 .069.24l.044.141a11.079 11.079 0 0 0 .13.372 6.73 6.73 0 0 0 .147.366c.043.102.089.203.137.302l.027.057a7.65 7.65 0 0 0 .182.352 8.483 8.483 0 0 0 7.445 4.417c4.673 0 8.475-3.791 8.475-8.451V36.076zm-8.475 18.909c-4.13 0-7.49-3.351-7.49-7.47V37.004l7.49-2.699 7.49 2.699v10.511c0 4.119-3.36 7.47-7.49 7.47zM55.5 38.234l-4.854-1.749v2.611h-1.758v-2.611l-4.854 1.749v9.281c0 2.855 2.109 5.227 4.854 5.65V40.61h1.758v12.555c2.745-.423 4.854-2.795 4.854-5.65v-9.281zm-3.043 4.822h1.757v5.024h-1.757v-5.024zm0-4.237h1.757v2.791h-1.757v-2.791zm-6.352-19.871h1.758v8.999h-1.758v-8.999zm0-4.928h1.758v2.906h-1.758V14.02zM42.472 3.569h4.206v1.753h-4.206V3.569zm-30.62 0H40.96v1.753H11.852V3.569zm6.537 29.104H12.32V30.92h6.069v1.753zm1.01 3.649h-2.127v-1.753h2.127v1.753zm0 7.301h-2.127V41.87h2.127v1.753zm3.536-10.95h-3.22V30.92h3.22v1.753zm.516-6.187l-7.262-7.242L23.451 12l1.244 1.241-6.02 6.003 6.02 6.002-1.244 1.24zm2.839 1.208l5.251-17.406 1.684.505L27.973 28.2l-1.683-.506zm4.627 8.628h-10.14v-1.753h10.14v1.753zm0 7.301h-10.14V41.87h10.14v1.753zm-7.566-5.404h13.602v1.753H23.351v-1.753zm11.468-12.973l6.02-6.002-6.02-6.003L36.062 12l7.263 7.244-7.263 7.242-1.243-1.24z"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="drop">
<path fill="currentColor" fill-rule="evenodd" d="M1.089 0h3.998c.186 0 .324.194.216.385L3.307 3.873a.247.247 0 0 1-.433 0C2.764 3.684.997.601.874.378.784.214.884 0 1.089 0z"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-activex">
<path fill="currentColor" fill-rule="evenodd" d="M57.985 57.66l-1.709.691-26.971-27.953L1.731 59.003l-1.716-.694 28.097-29.147L.636.687l1.708-.691L29.298 27.93 55.896.338l1.716.694-27.12 28.135L57.985 57.66z"></path>
</symbol>
<svg xmlns="http://www.w3.org/2000/svg" width="19" id="i-anonim" height="18">
<path fill="currentColor" fill-rule="evenodd" d="M17.983 17.625H.872A.374.374 0 0 1 .5 17.25v-.551a4.876 4.876 0 0 1 3.247-4.604l1.914-.671a.372.372 0 0 1 .396.1c.938 1.032 2.135 1.601 3.37 1.601 1.235 0 2.432-.569 3.37-1.601a.374.374 0 0 1 .397-.1l1.913.671a4.874 4.874 0 0 1 3.248 4.604v.551a.374.374 0 0 1-.372.375zm-.372-.926a4.126 4.126 0 0 0-2.748-3.896l-1.687-.592c-1.055 1.075-2.378 1.664-3.749 1.664s-2.694-.589-3.749-1.664l-1.687.592a4.126 4.126 0 0 0-2.747 3.896v.176h16.367v-.176zM9.06 12.811l-.08-.484c-1.739-.234-3.23-1.796-3.787-4.06-.004-.014.007-.026.006-.04-.002-.013-.016-.021-.017-.035l-.218-5.177a.376.376 0 0 1 .214-.355c.172-.082.36-.151.551-.217A4.31 4.31 0 0 1 9.427.375c1.577 0 2.928.819 3.699 2.068.191.066.379.135.551.217.136.064.22.205.214.355l-.218 5.177c-.001.015-.015.023-.017.037-.002.013.009.025.006.038-.558 2.264-2.049 3.826-3.788 4.06l-.08.483a.373.373 0 0 1-.367.315.373.373 0 0 1-.367-.314zm.367-11.686c-.977 0-1.846.384-2.493 1.008a15.753 15.753 0 0 1 2.49-.258c.077 0 1.252.02 2.497.258a3.567 3.567 0 0 0-2.494-1.008zm3.504 6.989l.137-3.242a3.864 3.864 0 0 0-.458-1.809c-1.414-.414-3.165-.438-3.186-.438-.015 0-1.766.024-3.18.438a3.847 3.847 0 0 0-.457 1.808l.137 3.243c.012.042.026.081.038.124.829-.031 1.565-.194 1.805-.321a.371.371 0 0 1 .502.159.376.376 0 0 1-.157.506c-.152.08-.414.159-.719.229l.263.397a.37.37 0 0 0 .309.168h.137a.374.374 0 0 0 .361-.285l.249-.61a.37.37 0 0 1 .343-.231h.744c.15 0 .285.09.343.23l.231.557c.06.221.208.338.379.338h.137c.124 0 .24-.062.31-.167l.262-.397c-.305-.07-.567-.149-.718-.229a.375.375 0 0 1 .345-.665c.239.127.975.29 1.804.321.012-.043.027-.083.039-.124zm-.286.862c-.13-.009-.257-.016-.38-.03l-.447.677a1.113 1.113 0 0 1-.929.502h-.137c-.512 0-.958-.351-1.082-.853L9.554 9h-.251l-.135.327c-.108.447-.552.798-1.066.798h-.137c-.373 0-.72-.188-.928-.501l-.448-.678c-.123.014-.25.021-.38.03.56 1.378 1.533 2.33 2.644 2.579l-.165-.994a.372.372 0 1 1 .734-.123l.005.03.005-.03a.372.372 0 1 1 .734.122l-.164.995c1.11-.249 2.083-1.201 2.643-2.579zM10.171 6.75c0-.208.167-.375.372-.375h.744c.205 0 .372.167.372.375a.374.374 0 0 1-.372.375h-.744a.374.374 0 0 1-.372-.375zm0-.75a.37.37 0 0 1-.282-.13.377.377 0 0 1 .039-.529c.31-.27 1.901-1.576 2.738-.731a.377.377 0 0 1 0 .53.37.37 0 0 1-.526 0c-.24-.241-1.168.284-1.726.769a.37.37 0 0 1-.243.091zM8.683 6a.363.363 0 0 1-.242-.092c-.558-.484-1.484-1.011-1.726-.769a.369.369 0 0 1-.526 0 .377.377 0 0 1 0-.53c.838-.844 2.427.462 2.738.732A.377.377 0 0 1 8.683 6zm-1.116.375h.744c.206 0 .372.167.372.375a.373.373 0 0 1-.372.375h-.744a.374.374 0 0 1-.372-.375c0-.208.167-.375.372-.375z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" id="i-blacklist">
<path fill="currentColor" fill-rule="evenodd" d="M14.282 18a4.034 4.034 0 0 1-2.598-.948h-7.37C2.211 17.052.5 15.328.5 13.207V3.845C.5 1.725 2.211 0 4.314 0h9.287c2.103 0 3.814 1.725 3.814 3.845v7.43c.586.711.94 1.624.94 2.62 0 2.263-1.827 4.105-4.073 4.105zm2.506-14.155c0-1.773-1.43-3.214-3.187-3.214H4.314c-1.758 0-3.188 1.441-3.188 3.214v9.362c0 1.773 1.43 3.214 3.188 3.214h6.763l-.052-.073c-.049-.067-.099-.134-.144-.203a4.145 4.145 0 0 1-.296-.541c-.009-.021-.02-.041-.03-.062a4.611 4.611 0 0 1-.084-.216c-.016-.043-.033-.087-.048-.131a4.256 4.256 0 0 1-.06-.201c-.015-.056-.03-.112-.043-.168a5.966 5.966 0 0 1-.039-.183 5.201 5.201 0 0 1-.033-.218c-.006-.05-.014-.099-.019-.149a4.378 4.378 0 0 1-.019-.381 4.1 4.1 0 0 1 .016-.316H8.957a.314.314 0 0 1-.313-.316c0-.175.14-.316.313-.316h1.367c.426-1.808 2.037-3.158 3.958-3.158.127 0 .254.008.379.02.049.005.098.012.147.019.073.009.145.02.218.033a5.785 5.785 0 0 1 .349.083c.066.019.131.038.196.06.046.015.09.032.135.05.071.026.141.052.21.083l.071.035a4.076 4.076 0 0 1 .529.293c.068.047.134.096.2.146.024.018.049.034.072.052V3.845zm.056 7.734a3.485 3.485 0 0 0-.216-.222l-.047-.043a3.441 3.441 0 0 0-.229-.19l-.051-.038a3.197 3.197 0 0 0-.298-.196c-.09-.053-.182-.1-.275-.144l-.041-.02a3.313 3.313 0 0 0-.647-.217l-.035-.01a3.739 3.739 0 0 0-.317-.052c-.014-.001-.028-.005-.042-.007a3.373 3.373 0 0 0-.364-.019c-1.899 0-3.445 1.558-3.445 3.474 0 .122.006.245.019.365l.007.044c.012.107.028.214.051.318.002.013.006.025.009.037.024.106.052.211.086.314l.013.037c.034.101.073.201.116.299l.021.044c.043.094.09.185.141.274l.031.052c.051.085.106.168.164.249l.04.055c.059.078.121.154.186.227l.046.05a3.408 3.408 0 0 0 2.515 1.108c1.9 0 3.446-1.558 3.446-3.473a3.47 3.47 0 0 0-.884-2.316zm-1.011 3.878a.31.31 0 0 1-.443 0l-1.108-1.116-1.107 1.116a.31.31 0 0 1-.443 0 .316.316 0 0 1 0-.446l1.108-1.116-1.108-1.117a.316.316 0 0 1 0-.446.31.31 0 0 1 .443 0l1.107 1.116 1.108-1.116a.31.31 0 0 1 .443 0 .317.317 0 0 1 0 .446l-1.108 1.117 1.108 1.116a.317.317 0 0 1 0 .446zm-1.237-6.615H8.957a.314.314 0 0 1-.313-.316c0-.175.14-.316.313-.316h5.639c.173 0 .313.141.313.316 0 .175-.14.316-.313.316zm0-4.421H8.957a.314.314 0 0 1-.313-.316c0-.175.14-.316.313-.316h5.639c.173 0 .313.141.313.316 0 .175-.14.316-.313.316zm-9.764 9.994a.31.31 0 0 1-.426.048L2.974 13.38a.318.318 0 0 1-.062-.442c.103-.14.3-.167.438-.063l1.197.905 1.957-2.301a.312.312 0 0 1 .442-.035.316.316 0 0 1 .034.445l-2.148 2.526zm0-4.737a.31.31 0 0 1-.426.048L2.974 8.643a.318.318 0 0 1-.062-.442.311.311 0 0 1 .438-.063l1.197.905 1.957-2.301a.312.312 0 0 1 .442-.035.316.316 0 0 1 .034.445L4.832 9.678zm0-4.421a.31.31 0 0 1-.426.048L2.974 4.222a.317.317 0 0 1-.062-.442.31.31 0 0 1 .438-.063l1.197.905 1.957-2.301a.312.312 0 0 1 .442-.035.316.316 0 0 1 .034.445L4.832 5.257z"></path>
</svg>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-blowser">
<path fill="currentColor" fill-rule="evenodd" d="M30 60C13.435 60 0 46.565 0 30 0 13.434 13.435 0 30 0c16.565 0 30 13.434 30 30 0 16.565-13.435 30-30 30zm0-57.985C14.542 2.015 2.015 14.541 2.015 30c0 15.458 12.527 27.985 27.985 27.985S57.985 45.458 57.985 30C57.985 14.541 45.458 2.015 30 2.015zm22.174 29.289h-.652A1.308 1.308 0 0 1 50.217 30c0-.718.587-1.305 1.305-1.305h.652c.717 0 1.304.587 1.304 1.305 0 .717-.587 1.304-1.304 1.304zm-6.522 15.652c-.326 0-.652-.13-.913-.391l-.456-.457a1.26 1.26 0 0 1 0-1.826 1.262 1.262 0 0 1 1.826 0l.456.457a1.26 1.26 0 0 1 0 1.826 1.287 1.287 0 0 1-.913.391zm-10.369-12.13a2.005 2.005 0 0 1-.522.521L16.304 45.456a2.283 2.283 0 0 1-.652.131c-.326 0-.652-.131-.913-.392a1.39 1.39 0 0 1-.196-1.565l10.109-18.456c.131-.196.326-.392.522-.522L43.63 14.608c.522-.326 1.174-.195 1.566.196.391.391.521 1.043.195 1.565L35.283 34.826zm-18.305 8.13L33 34l-7-7-9.022 15.956zM27 26l7 7 9.022-15.957L27 26zm3-16.218a1.307 1.307 0 0 1-1.304-1.304v-.652c0-.718.587-1.305 1.304-1.305.717 0 1.304.587 1.304 1.305v.652c0 .718-.587 1.304-1.304 1.304zm-15.196 6.326c-.326 0-.652-.13-.913-.391l-.456-.457a1.26 1.26 0 0 1 0-1.826 1.262 1.262 0 0 1 1.826 0l.456.457a1.26 1.26 0 0 1 0 1.826c-.26.261-.587.391-.913.391zM30 50.217c.717 0 1.304.587 1.304 1.304v.653c0 .717-.587 1.304-1.304 1.304a1.308 1.308 0 0 1-1.304-1.304v-.653c0-.717.587-1.304 1.304-1.304zM8.478 31.304h-.652A1.308 1.308 0 0 1 6.522 30c0-.718.587-1.305 1.304-1.305h.652c.718 0 1.305.587 1.305 1.305 0 .717-.587 1.304-1.305 1.304z"></path>
</symbol>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="25" id="i-clipboard">
<path fill="currentColor" fill-rule="evenodd" d="M13.996.955H2.095c-1.159 0-2.107.98-2.107 2.178v14.79H1.99V2.951h12.006V.955zm3.868 3.981H6.118c-1.175 0-2.136.998-2.136 2.219V22.69c0 1.221.961 2.22 2.136 2.22h11.746c1.175 0 2.136-.999 2.136-2.22V7.155c0-1.221-.961-2.219-2.136-2.219zm.135 17.978H5.992V6.944h12.007v15.97z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-dns" width="19" height="18">
<path fill="currentColor" fill-rule="evenodd" d="M17.446 17.897h-2.774a.909.909 0 0 1-.908-.908v-4.89a.91.91 0 0 1 .908-.909h2.774a.91.91 0 0 1 .909.909v4.89a.91.91 0 0 1-.909.908zm.299-5.798a.3.3 0 0 0-.299-.299h-2.774a.3.3 0 0 0-.299.299v4.213h3.372v-4.213zm0 4.823h-3.372v.067a.3.3 0 0 0 .299.299h2.774a.3.3 0 0 0 .299-.299v-.067zm-1.686-6.285a.306.306 0 0 1-.305-.305v-.801H9.732v.801a.305.305 0 1 1-.609 0v-.801H3.1v.801a.305.305 0 1 1-.609 0V9.226c0-.168.136-.305.304-.305h6.328V7.519a.305.305 0 1 1 .609 0v1.402h6.327c.168 0 .305.137.305.305v1.106a.306.306 0 0 1-.305.305zM12.4 5.917H9.732v.366h1.93a.305.305 0 0 1 0 .61H7.193a.304.304 0 1 1 0-.61h1.93v-.366H6.454a.908.908 0 0 1-.907-.907V1.175c0-.501.407-.908.907-.908H12.4c.5 0 .907.407.907.908V5.01c0 .5-.407.907-.907.907zm.298-4.742A.299.299 0 0 0 12.4.877H6.454a.298.298 0 0 0-.297.298v3.014h6.541V1.175zm0 3.624H6.157v.211c0 .164.133.298.297.298H12.4a.299.299 0 0 0 .298-.298v-.211zm-7.607 7.3v4.89a.91.91 0 0 1-.908.908H1.408a.909.909 0 0 1-.908-.908v-4.89a.91.91 0 0 1 .908-.909h2.775c.5 0 .908.408.908.909zm-3.982 4.89a.3.3 0 0 0 .299.299h2.775a.299.299 0 0 0 .298-.299v-.067H1.109v.067zm0-4.89v4.213h3.372v-4.213a.299.299 0 0 0-.298-.299H1.408a.3.3 0 0 0-.299.299zm6.931-.909h2.774a.91.91 0 0 1 .909.909v4.89a.91.91 0 0 1-.909.908H8.04a.909.909 0 0 1-.908-.908v-4.89a.91.91 0 0 1 .908-.909zm-.299 5.799a.3.3 0 0 0 .299.299h2.774a.3.3 0 0 0 .299-.299v-.067H7.741v.067zm0-.677h3.372v-4.213a.3.3 0 0 0-.299-.299H8.04a.3.3 0 0 0-.299.299v4.213z"></path>
</svg>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-drop">
<path fill="currentColor" fill-rule="evenodd" d="M.776.499h4.442c.206 0 .36.194.239.386-.096.154-2.049 3.225-2.216 3.488a.29.29 0 0 1-.481 0A733.013 733.013 0 0 1 .538.877C.438.714.549.499.776.499z" opacity=".6"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-fb">
<path fill="currentColor" fill-rule="evenodd" d="M16.483 12.45H9.225v2.41a1.493 1.493 0 0 1 1.16 1.16h7.172a.298.298 0 1 1 0 .595h-7.172a1.49 1.49 0 0 1-1.458 1.19 1.49 1.49 0 0 1-1.458-1.19H.297a.297.297 0 0 1 0-.595h7.172a1.493 1.493 0 0 1 1.161-1.16v-2.41H1.371A1.373 1.373 0 0 1 0 11.078V7.573c0-.437.209-.822.529-1.073A1.364 1.364 0 0 1 0 5.426V1.92C0 1.164.615.549 1.371.549h15.112c.756 0 1.372.615 1.372 1.371v3.506c0 .437-.21.822-.529 1.074.319.251.529.636.529 1.073v3.506c0 .756-.616 1.371-1.372 1.371zm-8.449 3.867a.894.894 0 0 0 1.786 0 .894.894 0 0 0-1.786 0zM17.259 1.92a.777.777 0 0 0-.776-.776H1.371a.777.777 0 0 0-.776.776v3.506c0 .428.348.776.776.776h15.112a.777.777 0 0 0 .776-.776V1.92zm0 5.653a.777.777 0 0 0-.776-.776H1.371a.777.777 0 0 0-.776.776v3.506c0 .428.348.776.776.776h15.112a.777.777 0 0 0 .776-.777V7.573zm-1.785 2.497a.299.299 0 0 1 0-.596.298.298 0 0 1 0 .596zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-.595.893a.298.298 0 1 1 0-.596.298.298 0 0 1 0 .596zm-.596-.893a.297.297 0 1 1 0-.594.297.297 0 0 1 0 .594zm-.595.893a.298.298 0 1 1 .002-.596.298.298 0 0 1-.002.596zm-.595-.893a.298.298 0 1 1 0-.596.298.298 0 0 1 0 .596zm-.595.893a.299.299 0 0 1 0-.596.298.298 0 0 1 0 .596zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-.595.893a.298.298 0 1 1 0-.596.298.298 0 0 1 0 .596zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-6.994 1.488a1.34 1.34 0 0 1-1.339-1.339 1.34 1.34 0 1 1 1.339 1.339zm0-2.083a.745.745 0 1 0 .001 1.489.745.745 0 0 0-.001-1.489zm12.35-4.165zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-.595.893a.298.298 0 1 1 0-.596.298.298 0 0 1 0 .596zm-.596-.893a.297.297 0 1 1 0-.594.297.297 0 0 1 0 .594zm-.595.893a.298.298 0 1 1 .002-.596.298.298 0 0 1-.002.596zm-.595-.893a.298.298 0 1 1 0-.596.298.298 0 0 1 0 .596zm-.595.893zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-.595.893a.298.298 0 1 1 0-.596.298.298 0 0 1 0 .596zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zM3.124 5.012a1.34 1.34 0 0 1-1.339-1.339 1.34 1.34 0 0 1 1.339-1.339 1.34 1.34 0 0 1 1.339 1.339c0 .738-.6 1.339-1.339 1.339zm0-2.083a.745.745 0 0 0 0 1.488.745.745 0 0 0 0-1.488z"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-fingerprint">
<path fill="currentColor" fill-rule="evenodd" d="M7.699.002L5.78-.002c-2.156 0-3.549 1.546-3.549 3.938v1.816H.302c-.167 0-.302.146-.302.327v2.63c0 .18.135.326.302.326h1.929v6.638c0 .18.135.326.302.326H5.05c.166 0 .301-.146.301-.326V9.035h2.256c.167 0 .302-.146.302-.326l.001-2.63a.338.338 0 0 0-.089-.231.286.286 0 0 0-.213-.096H5.351V4.213c0-.74.163-1.115 1.055-1.115l1.292-.001c.167 0 .302-.146.302-.326V.328c0-.18-.135-.326-.301-.326z" opacity=".6"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-flash">
<path fill="currentColor" fill-rule="evenodd" d="M51.25 60H8.75C3.925 60 0 56.075 0 51.25V8.749C0 3.925 3.925 0 8.75 0h42.5C56.075 0 60 3.925 60 8.749V51.25c0 4.825-3.925 8.75-8.75 8.75zM58 9c0-3.445-3.552-7-7-7H9C5.553 2 2 5.555 2 9v42c0 3.444 3.552 6.999 7 6.999h42c3.447 0 7-3.555 7-6.999V9zM43.75 20c-5.2 0-5.91 1.587-7.323 4.75-.04.082-.075.165-.112.25h4.935c.69 0 .75.31.75 1v8c0 .69-.06 1-.75 1H33c-2.258 7.605-8.257 15-16.75 15-.69 0-1.25-.56-1.25-1.25v-7.5c0-.69.56-1.25 1.25-1.25 5.375 0 6.775-3.69 8.785-10.208.4-1.297.812-2.632 1.29-3.962 2.387-6.681 5.662-15.831 17.425-15.831.69 0 1.25.561 1.25 1.251v7.5c0 .69-.56 1.25-1.25 1.25zM43 12c-8.285.535-11.263 5.342-14 13a211.88 211.88 0 0 0-2 6c-1.71 5.542-3.55 10.352-10 11v6c6.942-.725 12.637-7.958 14.287-14.55.138-.56 1.14-.45 1.713-.45h7v-6.001h-5c-.435 0-.772.373-1 0-.228-.372-.198-.609 0-.999.35-.68-.132-1.655.143-2.27C35.542 20.602 37.262 18.337 43 18l-.5-.465L43 12z"></path>
</symbol>
<svg xmlns="http://www.w3.org/2000/svg" id="i-host" viewBox="0 0 18 18">
<path fill="currentColor" fill-rule="evenodd" d="M16.483 12.45H9.225v2.41a1.493 1.493 0 0 1 1.16 1.16h7.172a.298.298 0 0 1 0 .595h-7.172a1.49 1.49 0 0 1-1.458 1.19 1.492 1.492 0 0 1-1.458-1.19H.297a.297.297 0 0 1 0-.595h7.172a1.494 1.494 0 0 1 1.161-1.16v-2.41H1.371A1.373 1.373 0 0 1 0 11.079V7.573c0-.437.209-.822.529-1.073A1.364 1.364 0 0 1 0 5.426V1.92C0 1.164.615.549 1.371.549h15.112c.757 0 1.372.615 1.372 1.371v3.506c0 .437-.21.822-.529 1.074.319.251.529.636.529 1.073v3.506c0 .756-.615 1.371-1.372 1.371zm-8.448 3.868a.893.893 0 1 0 1.786-.002.893.893 0 0 0-1.786.002zM17.259 1.92a.777.777 0 0 0-.776-.776H1.371a.777.777 0 0 0-.776.776v3.506c0 .428.348.776.776.776h15.112a.777.777 0 0 0 .776-.776V1.92zm0 5.653a.777.777 0 0 0-.776-.776H1.371a.777.777 0 0 0-.776.776v3.506c0 .428.348.776.776.776h15.112a.777.777 0 0 0 .776-.776V7.573zm-1.785 2.497a.298.298 0 1 1 0 0zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-.595.893a.298.298 0 1 1 0-.596.298.298 0 0 1 0 .596zm-.596-.893a.297.297 0 1 1 0-.594.297.297 0 0 1 0 .594zm-.595.893a.298.298 0 1 1 .002-.596.298.298 0 0 1-.002.596zm-.595-.893a.297.297 0 1 1 0-.594.297.297 0 0 1 0 .594zm-.595.893a.298.298 0 1 1 0 0zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-.595.893a.298.298 0 1 1 0-.596.298.298 0 0 1 0 .596zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-6.994 1.488a1.34 1.34 0 0 1-1.339-1.339 1.34 1.34 0 0 1 1.339-1.339c.739 0 1.34.601 1.34 1.339s-.601 1.339-1.34 1.339zm0-2.083a.744.744 0 1 0 .003 1.489.744.744 0 0 0-.003-1.489zm12.35-4.165a.298.298 0 1 1 0-.596.298.298 0 0 1 0 .596zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-.595.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-.596-.893a.297.297 0 1 1 0-.594.297.297 0 0 1 0 .594zm-.595.893a.297.297 0 1 1 0-.595.297.297 0 0 1 0 .595zm-.595-.893a.297.297 0 1 1 0-.594.297.297 0 0 1 0 .594zm-.595.893a.298.298 0 1 1 0-.596.298.298 0 0 1 0 .596zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-.595.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zm-.595-.893a.297.297 0 1 1-.001-.595.297.297 0 0 1 .001.595zM3.124 5.012a1.34 1.34 0 0 1-1.339-1.339 1.34 1.34 0 0 1 1.339-1.339c.739 0 1.34.601 1.34 1.339s-.601 1.339-1.34 1.339zm0-2.083a.744.744 0 1 0 .003 1.489.744.744 0 0 0-.003-1.489z"></path>
</svg>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-ig">
<path fill="currentColor" fill-rule="evenodd" d="M45.635 55.895c.065.072-.917-1.453-.973-1.708 8.277-4.874 13.844-13.884 13.844-24.17 0-15.452-12.563-28.024-28.006-28.024S2.494 14.565 2.494 30.017c0 10.345 5.631 19.398 13.987 24.254-.114.056-1.107 1.522-1.082 1.644C6.494 50.706.5 41.04.5 30c0-16.543 13.458-30 30-30s30 13.457 30 30c0 11.026-5.979 20.681-14.865 25.895zM30.5 12.5c9.649 0 17.5 7.852 17.5 17.505 0 6.343-3.39 11.909-8.453 14.979-.06-.026-1.029-1.637-1.077-1.697 4.507-2.714 7.527-7.654 7.527-13.287 0-8.546-6.952-15.498-15.497-15.498S15.002 21.454 15.002 30c0 5.624 3.012 10.558 7.507 13.274.033.017-.996 1.686-1.023 1.73C16.404 41.937 13 36.361 13 30.005 13 20.352 20.85 12.5 30.5 12.5zM20.5 30c0-5.514 4.486-10.001 10-10.001s10 4.487 10 10.001c0 4.496-2.983 8.308-7.073 9.563-.708.217 3.838 13.015 3.073 18.437-.236 1.67-5.76 1.499-6 1.499-.248 0-6.257.109-6.5-1.499-.813-5.379 4.166-18.243 3.418-18.486C23.407 38.212 20.5 34.439 20.5 30zM26 57c.143.811 4.355 1 4.5 1 .11 0 3.891-.211 4-1 .494-3.58-2.364-13.698-3-17.5-.133-.795.854-1.665.945-1.688a8.034 8.034 0 0 0 6.052-7.784c0-4.426-3.587-8.026-7.997-8.026s-7.997 3.6-7.997 8.026a8.036 8.036 0 0 0 5.506 7.626c.111.037 1.61 1.097 1.491 1.846-.586 3.69-4.14 13.86-3.5 17.5z"></path>
</symbol>
<svg xmlns="http://www.w3.org/2000/svg" id="i-js" width="52" height="60">
<path fill="currentColor" fill-rule="evenodd" d="M51.721 20.118L34.662.335a.988.988 0 0 0-.752-.345H9.895C4.964-.01.951 4.018.951 8.967v42.05c0 4.95 4.013 8.978 8.944 8.978H43.02c4.931 0 8.944-4.028 8.944-8.978V20.77a.994.994 0 0 0-.243-.652zM34.904 3.664l13.891 16.109H41.86c-3.836 0-6.956-3.132-6.956-6.983V3.664zM43.02 58H9.895c-3.836 0-6.956-3.132-6.956-6.983V8.967c0-3.85 3.12-6.982 6.956-6.982h23.022V12.79c0 4.95 4.013 8.978 8.944 8.978h8.116v29.248C49.976 54.868 46.856 58 43.02 58zM20.204 26.043l-6.488 6.512 6.488 6.513a.998.998 0 0 1-.702 1.703.988.988 0 0 1-.703-.293l-7.192-7.217a1 1 0 0 1 0-1.411l7.191-7.217a.99.99 0 0 1 1.405 0 .999.999 0 0 1 .001 1.41zm21.104 5.807a1 1 0 0 1 0 1.411l-7.191 7.217a.988.988 0 0 1-1.405 0 .998.998 0 0 1 0-1.41l6.488-6.513-6.488-6.512a.998.998 0 0 1 0-1.41.99.99 0 0 1 1.405 0l7.191 7.217z"></path>
</svg>
<svg width="60" height="60" xmlns="http://www.w3.org/2000/svg" id="i-ipa">
<g>
<title>Layer 1</title>
<path fill="currentColor" fill-rule="evenodd" d="m51.25,60l-42.5,0c-4.825,0 -8.75,-3.925 -8.75,-8.75l0,-42.501c0,-4.824 3.925,-8.749 8.75,-8.749l42.5,0c4.825,0 8.75,3.925 8.75,8.749l0,42.501c0,4.825 -3.925,8.75 -8.75,8.75zm6.75,-51c0,-3.445 -3.552,-7 -7,-7l-42,0c-3.447,0 -7,3.555 -7,7l0,42c0,3.444 3.552,6.999 7,6.999l42,0c3.447,0 7,-3.555 7,-6.999l0,-42zm-14.25,11c-5.2,0 -5.91,0 0,0" id="svg_1"></path>
<text transform="matrix(0.9776964726053452,0,0,0.9776964726053452,-4.070255626410689,0.9427384523832687) " xml:space="preserve" text-anchor="middle" font-family="Sans-serif" font-size="24" id="svg_2" y="38.35062" x="35.4819" stroke-dasharray="null" stroke-width="0" fill="currentColor" fill-rule="evenodd">IP</text>
</g>
</svg>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-java">
<path fill="currentColor" fill-rule="evenodd" d="M52.412 45.425c-1.593 1.285-3.447 2.019-5.427 2.374-1.221.218-2.473.254-3.709.392-.231.026-.515.084-.667.237-3.111 3.12-6.784 5.242-10.973 6.459-.017.005-.031.023-.063.048.26.674.56 1.342.775 2.038.319 1.03.293 1.038 1.368 1.038h3.673V60h-24.78v-1.989c1.073 0 2.141.002 3.209-.001.499-.001 1.119.168 1.461-.07.315-.221.314-.891.487-1.349.204-.543.445-1.07.694-1.66-7.365-2.239-12.821-6.815-16.136-13.898C.602 37.355-.135 33.44.019 29.327h49.95v3.05c.702.063 1.409.072 2.096.197 2.436.444 3.921 2.278 3.935 4.797.018 3.245-1.042 6.001-3.588 8.054zM1.993 31.37c.338 5.728 2.336 10.693 6.13 14.876 3.784 4.174 8.536 6.516 14.129 7.415-1.276 1.334-2.537 2.481-2.754 4.31h11.011c-.245-1.854-1.505-3.005-2.779-4.321 5.628-.856 10.391-3.216 14.175-7.4 3.78-4.181 5.804-9.144 6.09-14.88H1.993zm50.297 3.357c-.825-.24-1.712-.258-2.587-.377-.742 4.398-2.374 8.233-5.058 11.756 1.864-.177 3.512-.544 5.058-1.323 1.333-.673 2.442-1.598 3.21-2.914.846-1.45 1.187-3.031 1.097-4.699-.063-1.159-.574-2.111-1.72-2.443zM29.412 18.626c2.079 1.912 3.115 4.294 3.195 7.127.003.096-.011.191-.019.333H30.75c-.197-.982-.327-1.949-.593-2.874-.336-1.166-1.067-2.104-1.93-2.931-.895-.857-1.836-1.669-2.674-2.58-2.127-2.314-2.091-5.532.122-7.762.853-.86 1.861-1.564 2.821-2.309 1.129-.876 2.095-1.845 2.154-3.415h1.954c-.012 1.441-.451 2.709-1.441 3.668-.995.964-2.128 1.782-3.199 2.666-.793.656-1.576 1.328-1.828 2.405-.263 1.119-.173 2.2.63 3.068a46.422 46.422 0 0 0 2.646 2.604zM21.333 8.537c-1.981 2.194-2.494 4.706-1.48 7.468.318.868.937 1.648 1.527 2.377.792.978 1.718 1.842 2.537 2.799 1.388 1.622 2.07 3.525 2.039 5.737h-1.905c-.081-.577-.121-1.158-.248-1.717-.304-1.331-1.048-2.408-1.956-3.388-.922-.993-1.914-1.937-2.718-3.024-2.637-3.562-2.286-8.291.795-11.673.783-.859 1.601-1.686 2.371-2.558 1.076-1.216 1.675-2.64 1.684-4.297 0-.075.022-.15.039-.261h1.929c.058 1.692-.295 3.31-1.289 4.661-1.007 1.369-2.184 2.613-3.325 3.876z"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-cookies">
<path transform="rotate(-63.096 73.941 65.073)" d="m105.77 16.829c-0.7537 0.8212-0.29682 1.1932-1.1513 1.909s-1.1406 0.20079-2.0812 0.79894c-0.94056 0.59814-0.59554 1.0757-1.6061 1.546-1.0106 0.47026-1.1538-0.10127-2.2171 0.23306-1.0633 0.33433-0.85366 0.88495-1.9515 1.0776-1.0979 0.19268-1.0882-0.39643-2.2018-0.3487-1.1136 0.04773-1.0536 0.63385-2.1639 0.53581-1.1103-0.09804-0.94854-0.66458-2.0366-0.9067-1.088-0.24212-1.1818 0.33956-2.2289-0.04252-1.0471-0.38207-0.74421-0.88743-1.7325-1.4029-0.98829-0.51548-1.2294 0.02212-2.1419-0.61794-0.91255-0.64006-0.48917-1.0498-1.3104-1.8035-0.8212-0.7537-1.1932-0.29682-1.909-1.1513s-0.20079-1.1406-0.79893-2.0812c-0.59814-0.94056-1.0757-0.59553-1.546-1.6061-0.47026-1.0106 0.10127-1.1537-0.23306-2.2171-0.33433-1.0633-0.88494-0.85366-1.0776-1.9515-0.19268-1.0979 0.39643-1.0882 0.3487-2.2018s-0.63385-1.0536-0.53581-2.1639c0.09804-1.1103 0.66458-0.94854 0.9067-2.0366 0.24213-1.088-0.33956-1.1818 0.04252-2.2289 0.38207-1.0471 0.88743-0.74421 1.4029-1.7325 0.51548-0.98829-0.02212-1.2294 0.61794-2.1419 0.64006-0.91255 1.0498-0.48917 1.8035-1.3104 0.7537-0.8212 0.29682-1.1932 1.1513-1.909 0.85444-0.71579 1.1406-0.20079 2.0812-0.79893 0.94056-0.59814 0.59553-1.0757 1.6061-1.546 1.0106-0.47026 1.1537 0.10127 2.2171-0.23306 1.0633-0.33433 0.85366-0.88495 1.9515-1.0776 1.0979-0.19268 1.0882 0.39643 2.2018 0.3487 1.1136-0.04773 1.0536-0.63385 2.1639-0.53581 1.1103 0.09804 0.94854 0.66458 2.0366 0.9067 1.088 0.24213 1.1818-0.33956 2.2289 0.042515 1.0471 0.38207 0.74421 0.88743 1.7325 1.4029 0.98828 0.51548 1.2294-0.022122 2.1419 0.61794 0.91254 0.64006 0.48917 1.0498 1.3104 1.8035 0.8212 0.7537 1.1932 0.29682 1.909 1.1513 0.71579 0.85444 0.20079 1.1406 0.79893 2.0812 0.59815 0.94056 1.0757 0.59553 1.546 1.6061 0.47026 1.0106-0.10127 1.1537 0.23305 2.2171 0.33433 1.0633 0.88495 0.85366 1.0776 1.9515 0.19268 1.0979-0.39643 1.0882-0.3487 2.2018 0.0477 1.1136 0.63385 1.0536 0.53581 2.1639-0.098 1.1103-0.66458 0.94854-0.9067 2.0366-0.24213 1.088 0.33955 1.1818-0.0425 2.2289-0.38207 1.0471-0.88743 0.74421-1.4029 1.7325-0.51548 0.98829 0.0221 1.2294-0.61794 2.1419-0.64007 0.91255-1.0498 0.48917-1.8035 1.3104z" fill="#fff" stroke="currentColor" stroke-width="1.97"></path>
<circle transform="rotate(-63.096)" cx="-11.492" cy="43.74" r="2.0444" fill="#fff" stroke="currentColor" stroke-width="1.9"></circle>
<circle transform="rotate(-63.096)" cx="-13.007" cy="33.588" r="2.0444" fill="#fff" stroke="currentColor" stroke-width="1.9"></circle>
<circle transform="rotate(-63.096)" cx="-1.5003" cy="28.44" r="2.0444" fill="#fff" stroke="currentColor" stroke-width="1.9"></circle>
<circle transform="rotate(-63.096)" cx="3.9798" cy="37.279" r="2.0444" fill="#fff" stroke="currentColor" stroke-width="1.9"></circle>
<path d="m53.246 45.75c-0.7537 0.8212-0.29682 1.1932-1.1513 1.909-0.85444 0.71579-1.1406 0.20079-2.0812 0.79893-0.94056 0.59814-0.59553 1.0757-1.6061 1.546s-1.1537-0.10127-2.2171 0.23306c-1.0633 0.33433-0.85366 0.88494-1.9515 1.0776-1.0979 0.19268-1.0882-0.39643-2.2018-0.3487-1.1136 0.04773-1.0536 0.63385-2.1639 0.53581-1.1103-0.09804-0.94854-0.66458-2.0366-0.9067s-1.1818 0.33956-2.2289-0.04252c-1.0471-0.38207-0.74421-0.88743-1.7325-1.4029-0.98829-0.51548-1.2294 0.02212-2.1419-0.61794-0.91255-0.64006-0.48917-1.0498-1.3104-1.8035-0.8212-0.7537-1.1932-0.29682-1.909-1.1513-0.71579-0.85444-0.20079-1.1406-0.79894-2.0812-0.59814-0.94056-1.0757-0.59553-1.546-1.6061-0.47026-1.0106 0.10127-1.1537-0.23306-2.2171-0.33433-1.0633-0.88494-0.85366-1.0776-1.9515-0.19268-1.0979 0.39643-1.0882 0.3487-2.2018-0.04773-1.1136-0.63385-1.0536-0.53581-2.1639 0.09804-1.1103 0.66458-0.94854 0.9067-2.0366 0.24212-1.088-0.33956-1.1818 0.04251-2.2289 0.38207-1.0471 0.88743-0.74421 1.4029-1.7325 0.51548-0.98829-0.02212-1.2294 0.61794-2.1419 0.64006-0.91255 1.0498-0.48917 1.8035-1.3104s0.29682-1.1932 1.1513-1.909 1.1406-0.20079 2.0812-0.79894c0.94056-0.59814 0.59553-1.0757 1.6061-1.546 1.0106-0.47026 1.1537 0.10127 2.2171-0.23306 1.0633-0.33433 0.85366-0.88494 1.9515-1.0776s1.0882 0.39643 2.2018 0.3487c1.1136-0.04773 1.0536-0.63385 2.1639-0.53581 1.1103 0.09804 0.94854 0.66458 2.0366 0.9067 1.088 0.24212 1.1818-0.33956 2.2289 0.04251 1.0471 0.38207 0.74421 0.88743 1.7325 1.4029 0.98829 0.51548 1.2294-0.02212 2.1419 0.61794 0.91255 0.64006 0.48917 1.0498 1.3104 1.8035s1.1932 0.29682 1.909 1.1513 0.20079 1.1406 0.79893 2.0812c0.59814 0.94056 1.0757 0.59553 1.546 1.6061 0.47026 1.0106-0.10127 1.1537 0.23306 2.2171 0.33433 1.0633 0.88494 0.85366 1.0776 1.9515s-0.39643 1.0882-0.3487 2.2018c0.04773 1.1136 0.63385 1.0536 0.53581 2.1639-0.09804 1.1103-0.66458 0.94854-0.9067 2.0366s0.33956 1.1818-0.04251 2.2289c-0.38207 1.0471-0.88743 0.74421-1.4029 1.7325-0.51548 0.98829 0.02212 1.2294-0.61794 2.1419-0.64006 0.91255-1.0498 0.48917-1.8035 1.3104z" fill="#fff" stroke="currentColor" stroke-width="1.97"></path>
<circle cx="34.274" cy="30.192" r="2.0444" fill="#fff" stroke="currentColor" stroke-width="1.9"></circle>
<circle cx="45.997" cy="25.949" r="2.0444" fill="#fff" stroke="currentColor" stroke-width="1.9"></circle>
<circle cx="49.477" cy="36.788" r="2.0444" fill="#fff" stroke="currentColor" stroke-width="1.9"></circle>
<circle cx="43.234" cy="44.157" r="2.0444" fill="#fff" stroke="currentColor" stroke-width="1.9"></circle>
<path d="m5.3199 29.302c0.027169-0.17092 0.090106-0.36602 0.22133-0.61185 0.52488-0.98332 0.98176-0.61207 1.6305-1.5185 0.64874-0.9064 0.15012-1.2212 0.91163-2.0352 0.7615-0.81397 1.109-0.33647 1.9703-1.0441 0.86123-0.70761 0.46117-1.1411 1.4074-1.7302 0.94622-0.58914 1.1562-0.03846 2.1712-0.49906 1.015-0.46059 0.74014-0.98122 1.8066-1.3054 1.0665-0.32416 1.1298 0.26141 2.2295 0.07922s0.9677-0.75636 2.0817-0.79346c1.114-0.0371 1.0222 0.54421 2.1315 0.65284 1.1093 0.10863 1.1332-0.479 2.2189-0.22651 1.0857 0.2525 0.8459 0.78934 1.8893 1.1814 1.0434 0.39204 1.2173-0.16948 2.2006 0.3554 0.98332 0.52488 0.61207 0.98176 1.5185 1.6305 0.9064 0.64874 1.2212 0.15013 2.0352 0.91163 0.81397 0.7615 0.33647 1.109 1.0441 1.9703 0.70761 0.86123 1.1411 0.46117 1.7302 1.4074 0.58914 0.94622 0.03846 1.1562 0.49906 2.1712 0.46059 1.015 0.98122 0.74014 1.3054 1.8066 0.32416 1.0665-0.2613 1.1279-0.07911 2.2275 0.18219 1.0997 0.75626 0.96965 0.79335 2.0837 0.0371 1.114-0.54421 1.0222-0.65284 2.1315-0.10863 1.1093 0.48106 1.1313 0.22856 2.217-0.2525 1.0857-0.7914 0.84774-1.1834 1.8912-0.39204 1.0434 0.17144 1.2174-0.35345 2.2007-0.52488 0.98332-0.98372 0.61197-1.6325 1.5184-0.64874 0.9064-0.15013 1.2212-0.91163 2.0352-0.7615 0.81397-1.1071 0.33658-1.9683 1.0442-0.86123 0.70761-0.46117 1.1411-1.4074 1.7302-0.94622 0.58914-1.1581 0.03836-2.1732 0.49895-1.015 0.46059-0.74014 0.98122-1.8066 1.3054-1.0665 0.32416-1.1279-0.2613-2.2275-0.07911-1.0997 0.18219-0.96965 0.75626-2.0837 0.79335-0.93097 0.031-1.0273-0.36734-1.6787-0.56346-0.26213-0.39398-0.51402-0.86999-0.65191-1.7023-0.36033-2.1749 0.79863-2.2969 0.15751-4.4062-0.64113-2.1092-1.6727-1.5651-2.5837-3.5726-0.91096-2.0075 0.17827-2.4254-0.98692-4.2968-1.1652-1.8714-2.0216-1.08-3.4211-2.7833-1.3995-1.7033-0.45736-2.3883-2.0672-3.8944-1.6099-1.5061-2.2299-0.51995-4.0225-1.803-0.11312-0.080965-0.19014-0.15659-0.28445-0.23468-0.01125-0.25199-0.049106-0.47354-0.00616-0.74364z" fill="#fff" stroke="currentColor" stroke-width="1.97"></path>
<circle transform="matrix(-.054753 .9985 .9985 .054753 0 0)" cx="27.4" cy="17.566" r="2.0444" fill="#fff" stroke="currentColor" stroke-width="1.9"></circle>
<circle transform="matrix(-.054753 .9985 .9985 .054753 0 0)" cx="41.542" cy="27.289" r="2.0444" fill="#fff" stroke="currentColor" stroke-width="1.9"></circle>
<circle transform="matrix(-.054753 .9985 .9985 .054753 0 0)" cx="30.205" cy="28.688" r="2.0444" fill="#fff" stroke="currentColor" stroke-width="1.9"></circle>
<path d="m4.1976 45.75c0.5385 0.97593 0.9905 0.60054 1.6518 1.4978 0.19165 0.26006 0.27802 0.46657 0.33454 0.65557 4.3542-2.3945 6.9148-4.7784 5.4864-5.7839-0.54676-0.38486-3.1793-1.0056-3.848-4.3488 0.58563-1.8742 0.2679-2.7382-1.0794-3.0427-0.64226-0.14517-1.4276-0.27681-3.3904-0.5521-1.5902-0.2307-0.63064 2.2668-1.1449 2.5757-0.050176 0.15368-0.085174 0.33718-0.090042 0.58833-0.02161 1.1144 0.55835 1.0144 0.68239 2.1221 0.12404 1.1077-0.46431 1.1373-0.19675 2.2193 0.26756 1.0821 0.80298 0.8355 1.2095 1.8734 0.40651 1.0379-0.15371 1.2192 0.38479 2.1952z" fill="#fff" stroke="currentColor" stroke-width="1.97"></path>
<path d="m13.963 47.375c-1.0355 0.35563-3.2626 1.7266-7.1185 4.2192 0.32631 0.60479 0.10632 0.9545 0.78772 1.5953 0.81199 0.76361 1.128 0.26688 2.0327 0.91796 0.90472 0.65109 0.53228 1.1064 1.5142 1.6338 0.98196 0.52743 1.1581-0.03469 2.2005 0.36005 1.0424 0.39474 0.80201 0.93265 1.887 1.188 0.34305 0.08072 0.56908 0.0658 0.76785 0.02659-0.0083-0.05293-0.019-0.09873-0.019-0.09873s0.18 0.01504 0.28858 0.03012c0.28916-0.10067 0.57226-0.2243 1.1201-0.18139 0.55675-0.37702-0.44615-1.6414-2.356-4.2501-2.3023-3.1449 1.1517-6.2159-1.1054-5.4408z" fill="#fff" stroke="currentColor" stroke-width="1.97"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-lang">
<path fill="currentColor" fill-rule="evenodd" d="M51.213 51.213c-5.666 5.666-13.2 8.786-21.213 8.786a29.834 29.834 0 0 1-16.508-4.948L2.494 58.717a.957.957 0 0 1-1.212-1.211l3.667-10.998A29.827 29.827 0 0 1 0 30c0-8.014 3.12-15.547 8.787-21.213C14.453 3.12 21.987 0 30 0c8.013 0 15.547 3.12 21.213 8.787C56.879 14.453 60 21.986 60 30c0 8.013-3.121 15.547-8.787 21.213zM30 1.915C14.514 1.915 1.915 14.513 1.915 30c0 5.68 1.688 11.152 4.881 15.825a.954.954 0 0 1 .118.842l-3.209 9.628 9.627-3.209a.956.956 0 0 1 .843.118A27.933 27.933 0 0 0 30 58.085c15.486 0 28.085-12.599 28.085-28.085C58.085 14.513 45.486 1.915 30 1.915zm25.213 29.042h-9.834c-.078 4.78-.738 9.398-1.886 13.493h6.45a.958.958 0 0 1 0 1.915h-7.036c-1.024 3.085-2.339 5.812-3.901 8a.958.958 0 0 1-1.559-1.113c1.356-1.898 2.514-4.239 3.444-6.887h-9.934v8.847a.957.957 0 1 1-1.914 0v-8.847h-9.934c.929 2.648 2.088 4.989 3.444 6.887a.958.958 0 0 1-1.559 1.113c-1.562-2.188-2.877-4.915-3.901-8h-7.036a.957.957 0 0 1 0-1.915h6.45c-1.148-4.095-1.808-8.713-1.886-13.493H4.787a.956.956 0 1 1 0-1.915h9.834c.078-4.779.738-9.397 1.885-13.493h-6.449a.956.956 0 1 1 0-1.914h7.036c1.023-3.085 2.338-5.812 3.9-7.999a.959.959 0 0 1 1.559 1.113c-1.356 1.898-2.514 4.238-3.443 6.886h9.934V4.787a.956.956 0 1 1 1.914 0v8.848h9.934c-.93-2.648-2.087-4.988-3.443-6.886a.958.958 0 0 1 1.558-1.113c1.563 2.187 2.877 4.914 3.901 7.999h7.035a.957.957 0 1 1 0 1.914h-6.449c1.148 4.096 1.808 8.714 1.886 13.493h9.834a.957.957 0 0 1 0 1.915zm-26.17-15.408h-10.55c-1.189 4.045-1.876 8.676-1.957 13.493h12.507V15.549zm0 15.408H16.536c.081 4.817.768 9.449 1.957 13.493h10.55V30.957zm12.464-15.408h-10.55v13.493h12.507c-.081-4.817-.768-9.448-1.957-13.493zm-10.55 15.408V44.45h10.55c1.189-4.044 1.876-8.675 1.957-13.493H30.957z"></path>
</symbol>
<svg xmlns="http://www.w3.org/2000/svg" id="i-mac" width="14" height="18">
<path fill="currentColor" fill-rule="evenodd" d="M13.383 12.102c.308.217.52.553.586.926.317 1.165-1.867 4.015-3.176 4.755l-.032.016A2.596 2.596 0 0 1 9.744 18c-.51 0-.978-.145-1.393-.429l-.025-.019c-.01-.008-.354-.265-.937-.265-.366 0-.748.102-1.138.303a2.743 2.743 0 0 1-1.36.382c-.571 0-1.092-.2-1.548-.593-.722-.622-3.095-2.955-3.33-6.841-.108-1.77.465-3.464 1.57-4.648 1.003-1.074 2.332-1.555 3.601-1.3.029.005.973.164 1.895.693.49-.247 1.706-.783 3.03-.783 1.581 0 2.811.773 3.555 2.234l.168.332-.302.215c-.016.011-1.64 1.187-1.634 2.611.003.776.503 1.52 1.487 2.21zm-2.337-2.211c-.004-1.438 1.13-2.589 1.691-3.07-.6-.971-1.483-1.463-2.628-1.463-1.458 0-2.817.78-2.831.788l-.224.13-.218-.14c-.838-.54-1.794-.701-1.803-.703a2.727 2.727 0 0 0-.535-.054c-.819 0-1.634.39-2.295 1.099C1.271 7.475.77 8.973.861 10.485c.215 3.55 2.378 5.676 3.035 6.243a1.5 1.5 0 0 0 .995.387c.514 0 .914-.255.918-.257l.037-.022c.517-.269 1.035-.405 1.543-.405.824 0 1.342.356 1.45.438.269.181.573.273.905.273.333 0 .592-.094.654-.118 1.348-.779 2.886-3.281 2.753-3.764l-.017-.07a.582.582 0 0 0-.237-.384c-1.226-.861-1.849-1.842-1.851-2.915zM7.104 4.579a.422.422 0 0 1-.356-.08.43.43 0 0 1-.164-.327c-.003-.119-.038-2.947 3.462-4.149a.424.424 0 0 1 .56.357c.004.033.328 3.318-3.502 4.199zm.41-1.009c1.674-.594 2.114-1.781 2.221-2.501-1.549.72-2.056 1.827-2.221 2.501z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-android" width="28" height="33">
<path fill="currentColor" fill-rule="evenodd" d="M5.9 24.309c0 .801.54 1.335 1.35 1.335H8.6v4.673c0 1.068.945 2.002 2.025 2.002s2.025-.934 2.025-2.002v-4.673h2.7v4.673c0 1.068.945 2.002 2.025 2.002s2.025-.934 2.025-2.002v-4.673h1.35c.81 0 1.35-.534 1.35-1.335v-13.35H5.9v13.35zm-3.375-13.35c-1.08 0-2.025.935-2.025 2.003v9.344c0 1.069.945 2.003 2.025 2.003s2.025-.934 2.025-2.003v-9.344c0-1.068-.945-2.003-2.025-2.003zm22.95 0c-1.08 0-2.025.935-2.025 2.003v9.344c0 1.069.945 2.003 2.025 2.003s2.025-.934 2.025-2.003v-9.344c0-1.068-.945-2.003-2.025-2.003zm-6.75-7.743l1.755-1.735a.64.64 0 0 0 0-.935.658.658 0 0 0-.945 0L17.51 2.549c-.945-.668-2.16-.935-3.51-.935-1.35 0-2.565.267-3.645.801L8.465.413c-.27-.134-.81-.134-1.08 0-.135.267-.135.801 0 1.068L9.14 3.216C7.25 4.685 5.9 6.954 5.9 9.624h16.2c0-2.67-1.35-5.073-3.375-6.408zM11.3 6.954H9.95V5.619h1.35v1.335zm6.75 0H16.7V5.619h1.35v1.335z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-android-black" width="28" height="33">
<path fill="black" fill-rule="evenodd" d="M5.9 24.309c0 .801.54 1.335 1.35 1.335H8.6v4.673c0 1.068.945 2.002 2.025 2.002s2.025-.934 2.025-2.002v-4.673h2.7v4.673c0 1.068.945 2.002 2.025 2.002s2.025-.934 2.025-2.002v-4.673h1.35c.81 0 1.35-.534 1.35-1.335v-13.35H5.9v13.35zm-3.375-13.35c-1.08 0-2.025.935-2.025 2.003v9.344c0 1.069.945 2.003 2.025 2.003s2.025-.934 2.025-2.003v-9.344c0-1.068-.945-2.003-2.025-2.003zm22.95 0c-1.08 0-2.025.935-2.025 2.003v9.344c0 1.069.945 2.003 2.025 2.003s2.025-.934 2.025-2.003v-9.344c0-1.068-.945-2.003-2.025-2.003zm-6.75-7.743l1.755-1.735a.64.64 0 0 0 0-.935.658.658 0 0 0-.945 0L17.51 2.549c-.945-.668-2.16-.935-3.51-.935-1.35 0-2.565.267-3.645.801L8.465.413c-.27-.134-.81-.134-1.08 0-.135.267-.135.801 0 1.068L9.14 3.216C7.25 4.685 5.9 6.954 5.9 9.624h16.2c0-2.67-1.35-5.073-3.375-6.408zM11.3 6.954H9.95V5.619h1.35v1.335zm6.75 0H16.7V5.619h1.35v1.335z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-chrome" width="32" height="33">
<path fill="currentColor" fill-rule="evenodd" d="M9.247 12.16L6.341 3.559A15.926 15.926 0 0 1 16 .314c5.955 0 11.15 3.254 13.905 8.081H16.377a7.921 7.921 0 0 0-7.13 3.765zm14.682 4.157a7.92 7.92 0 0 1-3.351 6.473l-10.043 8.571c1.705.62 3.545.958 5.465.958 8.836 0 16-7.164 16-16.002 0-1.78-.291-3.491-.827-5.089H22.08a7.894 7.894 0 0 1 1.849 5.089zM7.739 30.024l6.906-5.895a7.936 7.936 0 0 1-6.349-5.937L4.062 5.663A15.94 15.94 0 0 0 0 16.317c0 5.814 3.101 10.904 7.739 13.707zM16 21.273a4.956 4.956 0 1 0 0-9.912 4.956 4.956 0 0 0 0 9.912z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-edge" width="32" height="32" viewBox="0 0 32 32">
<path fill="currentColor" fill-rule="evenodd" d="M16.3493 0C16.3974 0 16.4462 0.00025 16.4944 0.0006875C20.4252 0.0363125 24.3331 1.44831 27.2161 3.87444C30.2633 6.43875 31.9414 9.91813 31.9414 13.6716C31.9412 17.6061 28.1105 20.8069 23.4022 20.8069C22.2172 20.8069 21.0701 20.6076 19.9928 20.2146C19.6982 20.1071 19.4867 19.8723 19.4124 19.5704C19.3365 19.262 19.4174 18.9483 19.6344 18.7099C20.3796 17.8909 20.7899 16.8298 20.7899 15.7219C20.7899 14.6583 20.3771 13.5281 19.9635 12.5593C19.4991 11.4716 18.8431 10.4375 18.0162 9.58856C16.2397 7.76513 13.8046 6.84056 10.7782 6.84056C7.75093 6.84056 3.65011 7.59462 1.30543 11.1869C1.29743 11.1991 1.28961 11.2112 1.28174 11.2234C3.22274 4.73094 9.25349 0 16.3493 0Z"></path>
<path fill="currentColor" fill-rule="evenodd" d="M5.10092 27.3482C2.1278 24.3479 0.510859 20.3689 0.547484 16.143C0.552171 16.0504 0.642109 14.5456 1.50873 12.8876C1.77061 12.3866 2.08492 11.9101 2.4433 11.4731C4.02417 9.54512 6.42717 8.58956 8.86242 8.31968C11.2722 8.05262 13.8643 8.26106 15.9584 9.58768C15.9607 9.58912 15.9629 9.59062 15.9652 9.59206C17.1018 10.3151 18.0686 11.3943 18.7134 12.5749C18.7142 12.5764 18.715 12.5779 18.7159 12.5794C17.9909 12.1005 17.1299 11.8311 16.2205 11.8413C15.5042 11.8493 14.8169 12.0726 14.1594 12.3404C12.0683 13.192 10.4401 14.7761 9.43361 16.9459C8.44842 19.0694 8.16455 21.5632 8.63423 23.9679C9.11105 26.4091 10.353 28.5708 12.1314 30.0549C12.6004 30.4462 13.1114 30.7943 13.6464 31.0891C14.341 31.4718 15.0897 31.7717 15.8532 31.9853C15.8704 31.9901 15.8872 31.9953 15.9044 32.0001C11.8147 31.9077 7.99042 30.2641 5.10092 27.3482Z"></path>
<path fill="currentColor" fill-rule="evenodd" d="M30.1333 24.6608C27.9403 28.1359 24.4027 30.6602 20.423 31.5913C19.9898 31.6115 19.5582 31.6124 19.1252 31.5902C17.4235 31.5043 15.7256 31.0629 14.2635 30.1718C13.9051 29.9533 13.5455 29.6978 13.2179 29.4242C11.5839 28.0607 10.4414 26.0671 10.0006 23.8104C9.56385 21.5744 9.8261 19.2593 10.739 17.2916C11.0975 16.5187 11.5625 15.7928 12.1286 15.1553C12.337 14.9208 12.5597 14.6979 12.7944 14.4898C12.5206 15.0957 12.3758 15.7645 12.3895 16.4507C12.441 19.0344 13.6683 21.4523 15.8453 23.2591C18.005 25.0515 20.8594 26.0386 23.8825 26.0386C26.062 26.0386 28.1832 25.5187 30.0168 24.5352C30.0329 24.5266 30.0753 24.5039 30.1219 24.554C30.1689 24.6044 30.1431 24.6453 30.1333 24.6608Z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-chrome-black" width="32" height="33">
<path fill="black" fill-rule="evenodd" d="M9.247 12.16L6.341 3.559A15.926 15.926 0 0 1 16 .314c5.955 0 11.15 3.254 13.905 8.081H16.377a7.921 7.921 0 0 0-7.13 3.765zm14.682 4.157a7.92 7.92 0 0 1-3.351 6.473l-10.043 8.571c1.705.62 3.545.958 5.465.958 8.836 0 16-7.164 16-16.002 0-1.78-.291-3.491-.827-5.089H22.08a7.894 7.894 0 0 1 1.849 5.089zM7.739 30.024l6.906-5.895a7.936 7.936 0 0 1-6.349-5.937L4.062 5.663A15.94 15.94 0 0 0 0 16.317c0 5.814 3.101 10.904 7.739 13.707zM16 21.273a4.956 4.956 0 1 0 0-9.912 4.956 4.956 0 0 0 0 9.912z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-firefox" width="33" height="29">
<path fill="currentColor" fill-rule="evenodd" d="M32.455 8.84l-.371 2.342s-.53-4.337-1.179-5.958c-.995-2.484-1.438-2.464-1.441-2.461.667 1.669.546 2.566.546 2.566s-1.181-3.171-4.304-4.181C22.247.031 20.376.337 20.16.395h-.095l.076.006c-.002 0-.003.001-.003.002.014.016 3.822.655 4.498 1.57 0 0-1.618 0-3.228.457-.072.02 5.923.737 7.149 6.64 0 0-.657-1.351-1.47-1.58.534 1.602.397 4.642-.112 6.153-.065.194-.133-.841-1.135-1.286.321 2.268-.019 5.864-1.616 6.855-.125.077 1.001-3.55.226-2.148-4.46 6.737-9.732 3.109-12.102 1.512 1.215.261 3.521-.041 4.541-.789l.004-.002c1.108-.747 1.765-1.292 2.354-1.163.59.13.983-.454.525-.971-.459-.518-1.573-1.231-3.079-.843-1.063.275-2.38 1.433-4.389.26-1.543-.901-1.688-1.649-1.702-2.167.038-.183.086-.355.143-.511.178-.489.716-.637 1.016-.753.508.086.945.242 1.405.474.006-.151.008-.35-.001-.577.044-.086.017-.346-.053-.665a4.737 4.737 0 0 0-.212-.945h.001l.005-.002.007-.006.001-.002a.026.026 0 0 0 .006-.014c.032-.142.376-.416.804-.711a26.27 26.27 0 0 1 1.19-.762c.314-.193.553-.335.604-.373l.068-.05.014-.011.009-.007c.169-.133.422-.383.474-.911l.001-.003.004-.048.002-.033.001-.027.002-.063v-.004c.001-.051 0-.104-.003-.16a.528.528 0 0 0-.009-.085l-.001-.004-.002-.008-.004-.013v-.001a.098.098 0 0 0-.006-.014v-.001c-.054-.127-.26-.175-1.107-.189h-.003a66.36 66.36 0 0 0-1.39-.003c-1.039.004-1.614-1.001-1.797-1.39.251-1.369.977-2.344 2.17-3.005.023-.013.018-.023-.008-.031.233-.139-2.821-.003-4.225 1.756-1.247-.305-2.333-.284-3.269-.068a3.928 3.928 0 0 1-.67-.081C5.146 3.044 4.255 2.017 4.207.792l-.008.006-.002-.036S2.299 2.199 2.583 6.116c0 .063-.002.123-.003.181-.514.686-.769 1.263-.788 1.39C1.337 8.6.876 9.973.5 12.059c0 0 .263-.822.79-1.751-.388 1.17-.693 2.991-.514 5.722 0 0 .048-.605.215-1.478.131 1.694.704 3.785 2.152 6.244 2.78 4.721 7.053 7.104 11.775 7.47.839.068 1.689.069 2.545.005l.236-.017a17.852 17.852 0 0 0 2.913-.443C33.9 24.646 32.455 8.84 32.455 8.84z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-firefox-black" width="33" height="29">
<path fill="black" fill-rule="evenodd" d="M32.455 8.84l-.371 2.342s-.53-4.337-1.179-5.958c-.995-2.484-1.438-2.464-1.441-2.461.667 1.669.546 2.566.546 2.566s-1.181-3.171-4.304-4.181C22.247.031 20.376.337 20.16.395h-.095l.076.006c-.002 0-.003.001-.003.002.014.016 3.822.655 4.498 1.57 0 0-1.618 0-3.228.457-.072.02 5.923.737 7.149 6.64 0 0-.657-1.351-1.47-1.58.534 1.602.397 4.642-.112 6.153-.065.194-.133-.841-1.135-1.286.321 2.268-.019 5.864-1.616 6.855-.125.077 1.001-3.55.226-2.148-4.46 6.737-9.732 3.109-12.102 1.512 1.215.261 3.521-.041 4.541-.789l.004-.002c1.108-.747 1.765-1.292 2.354-1.163.59.13.983-.454.525-.971-.459-.518-1.573-1.231-3.079-.843-1.063.275-2.38 1.433-4.389.26-1.543-.901-1.688-1.649-1.702-2.167.038-.183.086-.355.143-.511.178-.489.716-.637 1.016-.753.508.086.945.242 1.405.474.006-.151.008-.35-.001-.577.044-.086.017-.346-.053-.665a4.737 4.737 0 0 0-.212-.945h.001l.005-.002.007-.006.001-.002a.026.026 0 0 0 .006-.014c.032-.142.376-.416.804-.711a26.27 26.27 0 0 1 1.19-.762c.314-.193.553-.335.604-.373l.068-.05.014-.011.009-.007c.169-.133.422-.383.474-.911l.001-.003.004-.048.002-.033.001-.027.002-.063v-.004c.001-.051 0-.104-.003-.16a.528.528 0 0 0-.009-.085l-.001-.004-.002-.008-.004-.013v-.001a.098.098 0 0 0-.006-.014v-.001c-.054-.127-.26-.175-1.107-.189h-.003a66.36 66.36 0 0 0-1.39-.003c-1.039.004-1.614-1.001-1.797-1.39.251-1.369.977-2.344 2.17-3.005.023-.013.018-.023-.008-.031.233-.139-2.821-.003-4.225 1.756-1.247-.305-2.333-.284-3.269-.068a3.928 3.928 0 0 1-.67-.081C5.146 3.044 4.255 2.017 4.207.792l-.008.006-.002-.036S2.299 2.199 2.583 6.116c0 .063-.002.123-.003.181-.514.686-.769 1.263-.788 1.39C1.337 8.6.876 9.973.5 12.059c0 0 .263-.822.79-1.751-.388 1.17-.693 2.991-.514 5.722 0 0 .048-.605.215-1.478.131 1.694.704 3.785 2.152 6.244 2.78 4.721 7.053 7.104 11.775 7.47.839.068 1.689.069 2.545.005l.236-.017a17.852 17.852 0 0 0 2.913-.443C33.9 24.646 32.455 8.84 32.455 8.84z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-ios" width="27" height="32">
<path fill="currentColor" fill-rule="evenodd" d="M15.485 2.705c1.154-1.338 3.1-2.328 4.698-2.391.211 1.853-.537 3.704-1.659 5.047-1.12 1.333-2.942 2.378-4.74 2.239-.239-1.82.666-3.709 1.701-4.895zm9.138 25.289c-1.339 1.927-2.715 3.851-4.899 3.884-2.134.038-2.822-1.255-5.265-1.255-2.444 0-3.211 1.222-5.231 1.293-2.1.075-3.695-2.075-5.04-4.002-2.741-3.92-4.836-11.086-2.019-15.919C3.565 9.588 6.062 8.067 8.774 8.03c2.058-.042 4.008 1.374 5.272 1.374 1.257 0 3.629-1.699 6.109-1.445 1.041.04 3.967.413 5.846 3.127-.151.094-3.492 2.017-3.456 6.022.049 4.783 4.245 6.375 4.288 6.389-.043.111-.676 2.272-2.21 4.497z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-ios-black" width="27" height="32">
<path fill="black" fill-rule="evenodd" d="M15.485 2.705c1.154-1.338 3.1-2.328 4.698-2.391.211 1.853-.537 3.704-1.659 5.047-1.12 1.333-2.942 2.378-4.74 2.239-.239-1.82.666-3.709 1.701-4.895zm9.138 25.289c-1.339 1.927-2.715 3.851-4.899 3.884-2.134.038-2.822-1.255-5.265-1.255-2.444 0-3.211 1.222-5.231 1.293-2.1.075-3.695-2.075-5.04-4.002-2.741-3.92-4.836-11.086-2.019-15.919C3.565 9.588 6.062 8.067 8.774 8.03c2.058-.042 4.008 1.374 5.272 1.374 1.257 0 3.629-1.699 6.109-1.445 1.041.04 3.967.413 5.846 3.127-.151.094-3.492 2.017-3.456 6.022.049 4.783 4.245 6.375 4.288 6.389-.043.111-.676 2.272-2.21 4.497z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-linux" width="28" height="33">
<path fill="currentColor" fill-rule="evenodd" d="M27.155 26.09c-.938-.38-1.34-.883-1.301-1.635.04-.877-.464-1.52-.703-1.773.144-.546.567-2.433 0-4.072-.609-1.755-2.468-4.434-4.387-7.068-.786-1.081-.823-2.257-.866-3.618-.041-1.299-.087-2.771-.82-4.407C18.28 1.735 16.68.714 14.688.714c-1.185 0-2.402.365-3.338 1.003-1.917 1.307-1.664 4.155-1.496 6.041.023.258.044.502.057.709.112 1.847.01 2.82-.123 3.116-.086.193-.509.743-.957 1.325-.463.603-.988 1.285-1.418 1.922-.514.765-.928 1.935-1.329 3.067-.293.828-.57 1.61-.84 2.077a2.8 2.8 0 0 0-.278 2.125c-.193.133-.473.394-.709.887-.285.601-.864.923-2.067 1.152-.553.112-.935.341-1.134.682-.29.497-.132 1.121.012 1.547.213.627.08 1.024-.161 1.743-.056.167-.119.355-.183.562-.1.328-.064.626.108.886.455.686 1.781.928 3.146 1.087.815.096 1.707.417 2.57.729.846.305 1.72.62 2.515.716.121.015.24.023.355.023 1.2 0 1.742-.786 1.914-1.109.431-.087 1.918-.365 3.45-.403 1.529-.043 3.009.256 3.428.348.132.249.48.818 1.033 1.111.305.165.729.259 1.163.259.463 0 1.344-.108 2.042-.833.696-.728 2.435-1.658 3.705-2.337.283-.151.548-.293.781-.421.713-.391 1.102-.948 1.067-1.531-.029-.483-.353-.907-.846-1.107zm-15.79-.14c-.088-.617-.893-1.23-1.825-1.939-.762-.58-1.625-1.238-1.863-1.794-.492-1.149-.104-3.168.572-4.208.334-.52.606-1.31.87-2.073.285-.825.579-1.677.909-2.05.521-.583 1.004-1.716 1.089-2.61.489.461 1.246 1.045 1.946 1.045.108 0 .213-.014.313-.042.479-.136 1.183-.538 1.864-.927.588-.335 1.312-.748 1.585-.786.467.663 3.182 6.596 3.46 8.502a8.893 8.893 0 0 1-.13 3.242 2.538 2.538 0 0 0-.323-.023c-.756 0-.956.408-1.008.651-.135.633-.149 2.655-.15 3.109-.274.343-1.657 1.96-3.642 2.25-.809.116-1.564.175-2.245.175-.581 0-.953-.045-1.107-.068l-.998-1.127c.394-.192.787-.597.683-1.327zm1.266-18.589a3.795 3.795 0 0 0-.092.043 2.02 2.02 0 0 0-.02-.203c-.109-.619-.525-1.068-.989-1.068a.655.655 0 0 0-.106.008c-.276.046-.493.25-.611.54.104-.636.469-1.108.902-1.108.509 0 .939.678.939 1.479 0 .101-.007.202-.023.309zm3.955.477c.047-.146.072-.305.072-.469 0-.727-.467-1.296-1.063-1.296-.583 0-1.057.581-1.057 1.296 0 .049.003.097.007.146l-.09-.034a1.96 1.96 0 0 1-.101-.623c0-.869.562-1.576 1.254-1.576.691 0 1.254.707 1.254 1.576 0 .361-.101.706-.276.98zm-.51 1.692c-.01.044-.031.064-.265.184a7.71 7.71 0 0 0-.451.247l-.123.074c-.495.296-1.654.99-1.969 1.031-.213.029-.346-.053-.643-.253a13.574 13.574 0 0 0-.214-.141c-.536-.347-.881-.729-.92-.879.175-.133.608-.467.83-.665.45-.413.903-.691 1.127-.691.012 0 .022.001.033.003.264.046.913.302 1.388.489.219.086.409.161.542.208.42.143.639.325.665.393zm3.772 19.313c.237-1.055.51-2.491.466-3.337-.01-.192-.028-.401-.044-.603-.031-.379-.078-.94-.03-1.108l.032-.011c.002.484.108 1.449.889 1.785.233.101.499.151.791.151.783 0 1.652-.379 2.007-.73.21-.207.386-.46.509-.66a.78.78 0 0 1 .035.311c-.046.714.305 1.66.973 2.009l.097.05c.238.124.871.451.881.607 0 0-.006.018-.041.05-.158.143-.716.424-1.255.696-.956.482-2.039 1.029-2.526 1.534-.685.712-1.46 1.191-1.928 1.191a.525.525 0 0 1-.154-.022c-.508-.156-.926-.88-.702-1.913zM2.522 26.151c-.052-.239-.093-.429-.049-.612.032-.135.711-.281 1.001-.343.407-.087.829-.178 1.104-.343.373-.222.575-.634.753-.996.128-.263.262-.534.42-.623a.09.09 0 0 1 .048-.011c.297 0 .92.616 1.278 1.167.091.139.26.417.455.74.583.963 1.381 2.283 1.798 2.725.376.398.984 1.162.835 1.818-.11.509-.693.922-.831 1.014a.866.866 0 0 1-.184.017c-.798 0-2.378-.656-3.227-1.008l-.126-.053c-.474-.196-1.247-.32-1.996-.439-.595-.095-1.41-.225-1.546-.343-.109-.121.018-.516.13-.864.081-.25.164-.509.21-.78.064-.432-.012-.783-.073-1.066z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-linux-black" width="28" height="33">
<path fill="black" fill-rule="evenodd" d="M27.155 26.09c-.938-.38-1.34-.883-1.301-1.635.04-.877-.464-1.52-.703-1.773.144-.546.567-2.433 0-4.072-.609-1.755-2.468-4.434-4.387-7.068-.786-1.081-.823-2.257-.866-3.618-.041-1.299-.087-2.771-.82-4.407C18.28 1.735 16.68.714 14.688.714c-1.185 0-2.402.365-3.338 1.003-1.917 1.307-1.664 4.155-1.496 6.041.023.258.044.502.057.709.112 1.847.01 2.82-.123 3.116-.086.193-.509.743-.957 1.325-.463.603-.988 1.285-1.418 1.922-.514.765-.928 1.935-1.329 3.067-.293.828-.57 1.61-.84 2.077a2.8 2.8 0 0 0-.278 2.125c-.193.133-.473.394-.709.887-.285.601-.864.923-2.067 1.152-.553.112-.935.341-1.134.682-.29.497-.132 1.121.012 1.547.213.627.08 1.024-.161 1.743-.056.167-.119.355-.183.562-.1.328-.064.626.108.886.455.686 1.781.928 3.146 1.087.815.096 1.707.417 2.57.729.846.305 1.72.62 2.515.716.121.015.24.023.355.023 1.2 0 1.742-.786 1.914-1.109.431-.087 1.918-.365 3.45-.403 1.529-.043 3.009.256 3.428.348.132.249.48.818 1.033 1.111.305.165.729.259 1.163.259.463 0 1.344-.108 2.042-.833.696-.728 2.435-1.658 3.705-2.337.283-.151.548-.293.781-.421.713-.391 1.102-.948 1.067-1.531-.029-.483-.353-.907-.846-1.107zm-15.79-.14c-.088-.617-.893-1.23-1.825-1.939-.762-.58-1.625-1.238-1.863-1.794-.492-1.149-.104-3.168.572-4.208.334-.52.606-1.31.87-2.073.285-.825.579-1.677.909-2.05.521-.583 1.004-1.716 1.089-2.61.489.461 1.246 1.045 1.946 1.045.108 0 .213-.014.313-.042.479-.136 1.183-.538 1.864-.927.588-.335 1.312-.748 1.585-.786.467.663 3.182 6.596 3.46 8.502a8.893 8.893 0 0 1-.13 3.242 2.538 2.538 0 0 0-.323-.023c-.756 0-.956.408-1.008.651-.135.633-.149 2.655-.15 3.109-.274.343-1.657 1.96-3.642 2.25-.809.116-1.564.175-2.245.175-.581 0-.953-.045-1.107-.068l-.998-1.127c.394-.192.787-.597.683-1.327zm1.266-18.589a3.795 3.795 0 0 0-.092.043 2.02 2.02 0 0 0-.02-.203c-.109-.619-.525-1.068-.989-1.068a.655.655 0 0 0-.106.008c-.276.046-.493.25-.611.54.104-.636.469-1.108.902-1.108.509 0 .939.678.939 1.479 0 .101-.007.202-.023.309zm3.955.477c.047-.146.072-.305.072-.469 0-.727-.467-1.296-1.063-1.296-.583 0-1.057.581-1.057 1.296 0 .049.003.097.007.146l-.09-.034a1.96 1.96 0 0 1-.101-.623c0-.869.562-1.576 1.254-1.576.691 0 1.254.707 1.254 1.576 0 .361-.101.706-.276.98zm-.51 1.692c-.01.044-.031.064-.265.184a7.71 7.71 0 0 0-.451.247l-.123.074c-.495.296-1.654.99-1.969 1.031-.213.029-.346-.053-.643-.253a13.574 13.574 0 0 0-.214-.141c-.536-.347-.881-.729-.92-.879.175-.133.608-.467.83-.665.45-.413.903-.691 1.127-.691.012 0 .022.001.033.003.264.046.913.302 1.388.489.219.086.409.161.542.208.42.143.639.325.665.393zm3.772 19.313c.237-1.055.51-2.491.466-3.337-.01-.192-.028-.401-.044-.603-.031-.379-.078-.94-.03-1.108l.032-.011c.002.484.108 1.449.889 1.785.233.101.499.151.791.151.783 0 1.652-.379 2.007-.73.21-.207.386-.46.509-.66a.78.78 0 0 1 .035.311c-.046.714.305 1.66.973 2.009l.097.05c.238.124.871.451.881.607 0 0-.006.018-.041.05-.158.143-.716.424-1.255.696-.956.482-2.039 1.029-2.526 1.534-.685.712-1.46 1.191-1.928 1.191a.525.525 0 0 1-.154-.022c-.508-.156-.926-.88-.702-1.913zM2.522 26.151c-.052-.239-.093-.429-.049-.612.032-.135.711-.281 1.001-.343.407-.087.829-.178 1.104-.343.373-.222.575-.634.753-.996.128-.263.262-.534.42-.623a.09.09 0 0 1 .048-.011c.297 0 .92.616 1.278 1.167.091.139.26.417.455.74.583.963 1.381 2.283 1.798 2.725.376.398.984 1.162.835 1.818-.11.509-.693.922-.831 1.014a.866.866 0 0 1-.184.017c-.798 0-2.378-.656-3.227-1.008l-.126-.053c-.474-.196-1.247-.32-1.996-.439-.595-.095-1.41-.225-1.546-.343-.109-.121.018-.516.13-.864.081-.25.164-.509.21-.78.064-.432-.012-.783-.073-1.066z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-macos" width="27" height="32">
<path fill="currentColor" fill-rule="evenodd" d="M14.985 2.705c1.154-1.338 3.1-2.328 4.698-2.391.211 1.853-.537 3.704-1.659 5.047-1.12 1.333-2.942 2.378-4.74 2.239-.239-1.82.666-3.709 1.701-4.895zm9.138 25.289c-1.338 1.927-2.716 3.851-4.899 3.884-2.134.038-2.822-1.255-5.265-1.255-2.444 0-3.211 1.222-5.231 1.293-2.1.075-3.695-2.075-5.04-4.002-2.741-3.92-4.836-11.086-2.019-15.919C3.065 9.588 5.562 8.067 8.274 8.03c2.058-.042 4.008 1.374 5.272 1.374 1.257 0 3.629-1.699 6.109-1.445 1.041.04 3.967.413 5.846 3.127-.151.094-3.492 2.017-3.456 6.022.049 4.783 4.245 6.375 4.288 6.389-.043.111-.676 2.272-2.21 4.497z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-macos-black" width="27" height="32">
<path fill="black" fill-rule="evenodd" d="M14.985 2.705c1.154-1.338 3.1-2.328 4.698-2.391.211 1.853-.537 3.704-1.659 5.047-1.12 1.333-2.942 2.378-4.74 2.239-.239-1.82.666-3.709 1.701-4.895zm9.138 25.289c-1.338 1.927-2.716 3.851-4.899 3.884-2.134.038-2.822-1.255-5.265-1.255-2.444 0-3.211 1.222-5.231 1.293-2.1.075-3.695-2.075-5.04-4.002-2.741-3.92-4.836-11.086-2.019-15.919C3.065 9.588 5.562 8.067 8.274 8.03c2.058-.042 4.008 1.374 5.272 1.374 1.257 0 3.629-1.699 6.109-1.445 1.041.04 3.967.413 5.846 3.127-.151.094-3.492 2.017-3.456 6.022.049 4.783 4.245 6.375 4.288 6.389-.043.111-.676 2.272-2.21 4.497z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-opera" width="32" height="33">
<path fill="currentColor" fill-rule="evenodd" d="M25.606 29.084c-.846.149-1.716.235-2.606.235-2.752 0-5.314-.752-7.48-2.031.16.011.318.03.48.03 4.97 0 9-4.924 9-11.001 0-6.078-4.03-11.002-9-11.002-.162 0-.32.02-.48.03A14.697 14.697 0 0 1 23 3.314c.89 0 1.76.086 2.606.234C29.48 6.473 32 11.1 32 16.317c0 5.217-2.52 9.843-6.394 12.767zM7.376 13.118v.068a13.206 13.206 0 0 0 0 6.261v.068c1.476 6.343 7.238 11.2 14.288 11.748A15.866 15.866 0 0 1 16 32.319c-8.822 0-16-7.179-16-16.002C0 7.493 7.178.314 16 .314c1.996 0 3.9.384 5.666 1.056-7.052.55-12.814 5.405-14.29 11.748z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-opera-black" width="32" height="33">
<path fill="black" fill-rule="evenodd" d="M25.606 29.084c-.846.149-1.716.235-2.606.235-2.752 0-5.314-.752-7.48-2.031.16.011.318.03.48.03 4.97 0 9-4.924 9-11.001 0-6.078-4.03-11.002-9-11.002-.162 0-.32.02-.48.03A14.697 14.697 0 0 1 23 3.314c.89 0 1.76.086 2.606.234C29.48 6.473 32 11.1 32 16.317c0 5.217-2.52 9.843-6.394 12.767zM7.376 13.118v.068a13.206 13.206 0 0 0 0 6.261v.068c1.476 6.343 7.238 11.2 14.288 11.748A15.866 15.866 0 0 1 16 32.319c-8.822 0-16-7.179-16-16.002C0 7.493 7.178.314 16 .314c1.996 0 3.9.384 5.666 1.056-7.052.55-12.814 5.405-14.29 11.748z"></path>
</svg>
<svg width="34" height="34" viewBox="0 0 34 34" xmlns="http://www.w3.org/2000/svg" id="i-router">
<path d="M8.03516 3.05469C8.03516 2.50484 7.58891 2.05859 7.03906 2.05859C6.48922 2.05859 6.04297 2.50484 6.04297 3.05469V17.9961H8.03516V3.05469Z" fill="currentColor" fill-rule="evenodd"></path>
<path d="M27.957 3.05469C27.957 2.50484 27.5108 2.05859 26.9609 2.05859C26.4111 2.05859 25.9648 2.50484 25.9648 3.05469V17.9961H27.957V3.05469Z" fill="currentColor" fill-rule="evenodd"></path>
<path d="M31.6758 19.9883H2.32422C1.04264 19.9883 0 21.0309 0 22.3125V27.625C0 28.9066 1.04264 29.9492 2.32422 29.9492H4.05078V30.9453C4.05078 31.4954 4.49677 31.9414 5.04688 31.9414C5.59698 31.9414 6.04297 31.4954 6.04297 30.9453V29.9492H27.957V30.9453C27.957 31.4954 28.403 31.9414 28.9531 31.9414C29.5032 31.9414 29.9492 31.4954 29.9492 30.9453V29.9492H31.6758C32.9574 29.9492 34 28.9066 34 27.625V22.3125C34 21.0309 32.9574 19.9883 31.6758 19.9883ZM5.04688 25.9648C4.49677 25.9648 4.05078 25.5189 4.05078 24.9688C4.05078 24.4186 4.49677 23.9727 5.04688 23.9727C5.59698 23.9727 6.04297 24.4186 6.04297 24.9688C6.04297 25.5189 5.59698 25.9648 5.04688 25.9648ZM13.0156 25.9648C12.4655 25.9648 12.0195 25.5189 12.0195 24.9688C12.0195 24.4186 12.4655 23.9727 13.0156 23.9727C13.5657 23.9727 14.0117 24.4186 14.0117 24.9688C14.0117 25.5189 13.5657 25.9648 13.0156 25.9648ZM17 25.9648C16.4499 25.9648 16.0039 25.5189 16.0039 24.9688C16.0039 24.4186 16.4499 23.9727 17 23.9727C17.5501 23.9727 17.9961 24.4186 17.9961 24.9688C17.9961 25.5189 17.5501 25.9648 17 25.9648ZM20.9844 25.9648C20.4343 25.9648 19.9883 25.5189 19.9883 24.9688C19.9883 24.4186 20.4343 23.9727 20.9844 23.9727C21.5345 23.9727 21.9805 24.4186 21.9805 24.9688C21.9805 25.5189 21.5345 25.9648 20.9844 25.9648ZM24.9688 25.9648C24.4186 25.9648 23.9727 25.5189 23.9727 24.9688C23.9727 24.4186 24.4186 23.9727 24.9688 23.9727C25.5189 23.9727 25.9648 24.4186 25.9648 24.9688C25.9648 25.5189 25.5189 25.9648 24.9688 25.9648Z" fill="currentColor" fill-rule="evenodd"></path>
<path d="M12.0725 10.0802C13.3913 8.76149 15.1413 8.0352 17.0001 8.0352C18.8589 8.0352 20.6089 8.76149 21.9277 10.0802C22.1222 10.2747 22.3772 10.372 22.632 10.372C22.8869 10.372 23.1419 10.2748 23.3363 10.0802C23.7253 9.69124 23.7253 9.06058 23.3363 8.67157C19.8293 5.16446 14.1715 5.16387 10.6638 8.67157C10.2748 9.06058 10.2748 9.69124 10.6638 10.0802C11.0528 10.4693 11.6836 10.4693 12.0725 10.0802Z" fill="currentColor" fill-rule="evenodd"></path>
<path d="M16.4468 15.8358C17.1188 16.2782 17.996 15.794 17.996 15.0078C17.996 14.4964 17.6076 14.0692 17.0982 14.0163C16.0584 13.9209 15.596 15.2614 16.4468 15.8358Z" fill="currentColor" fill-rule="evenodd"></path>
<path d="M20.5223 12.8942C20.9111 12.505 20.9109 11.8743 20.5217 11.4855C19.5804 10.5452 18.3298 10.0273 17 10.0273C15.6702 10.0273 14.4196 10.5452 13.4784 11.4855C13.0892 11.8743 13.0889 12.505 13.4777 12.8942C13.8665 13.2834 14.4972 13.2836 14.8864 12.8948C15.4514 12.3304 16.202 12.0195 17 12.0195C17.798 12.0195 18.5486 12.3304 19.1137 12.8949C19.5027 13.2836 20.1333 13.2835 20.5223 12.8942Z" fill="currentColor" fill-rule="evenodd"></path>
</svg>
<svg width="34" height="34" viewBox="0 0 34 34" xmlns="http://www.w3.org/2000/svg" id="i-router-black">
<path d="M8.03516 3.05469C8.03516 2.50484 7.58891 2.05859 7.03906 2.05859C6.48922 2.05859 6.04297 2.50484 6.04297 3.05469V17.9961H8.03516V3.05469Z" fill="black" fill-rule="evenodd"></path>
<path d="M27.957 3.05469C27.957 2.50484 27.5108 2.05859 26.9609 2.05859C26.4111 2.05859 25.9648 2.50484 25.9648 3.05469V17.9961H27.957V3.05469Z" fill="black" fill-rule="evenodd"></path>
<path d="M31.6758 19.9883H2.32422C1.04264 19.9883 0 21.0309 0 22.3125V27.625C0 28.9066 1.04264 29.9492 2.32422 29.9492H4.05078V30.9453C4.05078 31.4954 4.49677 31.9414 5.04688 31.9414C5.59698 31.9414 6.04297 31.4954 6.04297 30.9453V29.9492H27.957V30.9453C27.957 31.4954 28.403 31.9414 28.9531 31.9414C29.5032 31.9414 29.9492 31.4954 29.9492 30.9453V29.9492H31.6758C32.9574 29.9492 34 28.9066 34 27.625V22.3125C34 21.0309 32.9574 19.9883 31.6758 19.9883ZM5.04688 25.9648C4.49677 25.9648 4.05078 25.5189 4.05078 24.9688C4.05078 24.4186 4.49677 23.9727 5.04688 23.9727C5.59698 23.9727 6.04297 24.4186 6.04297 24.9688C6.04297 25.5189 5.59698 25.9648 5.04688 25.9648ZM13.0156 25.9648C12.4655 25.9648 12.0195 25.5189 12.0195 24.9688C12.0195 24.4186 12.4655 23.9727 13.0156 23.9727C13.5657 23.9727 14.0117 24.4186 14.0117 24.9688C14.0117 25.5189 13.5657 25.9648 13.0156 25.9648ZM17 25.9648C16.4499 25.9648 16.0039 25.5189 16.0039 24.9688C16.0039 24.4186 16.4499 23.9727 17 23.9727C17.5501 23.9727 17.9961 24.4186 17.9961 24.9688C17.9961 25.5189 17.5501 25.9648 17 25.9648ZM20.9844 25.9648C20.4343 25.9648 19.9883 25.5189 19.9883 24.9688C19.9883 24.4186 20.4343 23.9727 20.9844 23.9727C21.5345 23.9727 21.9805 24.4186 21.9805 24.9688C21.9805 25.5189 21.5345 25.9648 20.9844 25.9648ZM24.9688 25.9648C24.4186 25.9648 23.9727 25.5189 23.9727 24.9688C23.9727 24.4186 24.4186 23.9727 24.9688 23.9727C25.5189 23.9727 25.9648 24.4186 25.9648 24.9688C25.9648 25.5189 25.5189 25.9648 24.9688 25.9648Z" fill="black" fill-rule="evenodd"></path>
<path d="M12.0725 10.0802C13.3913 8.76149 15.1413 8.0352 17.0001 8.0352C18.8589 8.0352 20.6089 8.76149 21.9277 10.0802C22.1222 10.2747 22.3772 10.372 22.632 10.372C22.8869 10.372 23.1419 10.2748 23.3363 10.0802C23.7253 9.69124 23.7253 9.06058 23.3363 8.67157C19.8293 5.16446 14.1715 5.16387 10.6638 8.67157C10.2748 9.06058 10.2748 9.69124 10.6638 10.0802C11.0528 10.4693 11.6836 10.4693 12.0725 10.0802Z" fill="black" fill-rule="evenodd"></path>
<path d="M16.4468 15.8358C17.1188 16.2782 17.996 15.794 17.996 15.0078C17.996 14.4964 17.6076 14.0692 17.0982 14.0163C16.0584 13.9209 15.596 15.2614 16.4468 15.8358Z" fill="black" fill-rule="evenodd"></path>
<path d="M20.5223 12.8942C20.9111 12.505 20.9109 11.8743 20.5217 11.4855C19.5804 10.5452 18.3298 10.0273 17 10.0273C15.6702 10.0273 14.4196 10.5452 13.4784 11.4855C13.0892 11.8743 13.0889 12.505 13.4777 12.8942C13.8665 13.2834 14.4972 13.2836 14.8864 12.8948C15.4514 12.3304 16.202 12.0195 17 12.0195C17.798 12.0195 18.5486 12.3304 19.1137 12.8949C19.5027 13.2836 20.1333 13.2835 20.5223 12.8942Z" fill="black" fill-rule="evenodd"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-yab" width="33" height="33">
<ellipse cx="16" cy="16.5" rx="15.212" ry="15.222" fill="none" stroke="currentColor" stroke-width="1.551"></ellipse>
<path fill="currentColor" fill-rule="evenodd" d="m8.5674 6.0398-2.8276 2.8276 8.2655 8.2662v9.8266h3.9994v-9.8373l8.2555-8.2555-2.8276-2.8276-7.433 7.433-7.4323-7.433" stroke-width=".66658"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-yab-black" width="33" height="33">
<ellipse cx="16" cy="16.5" rx="15.212" ry="15.222" fill="none" stroke="black" stroke-width="1.551"></ellipse>
<path fill="black" fill-rule="evenodd" d="m8.5674 6.0398-2.8276 2.8276 8.2655 8.2662v9.8266h3.9994v-9.8373l8.2555-8.2555-2.8276-2.8276-7.433 7.433-7.4323-7.433" stroke-width=".66658"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-safari" width="33" height="33">
<path fill="currentColor" fill-rule="evenodd" d="M16.5.314C7.678.314.5 7.493.5 16.317c0 8.823 7.178 16.002 16 16.002s16-7.179 16-16.002c0-8.824-7.178-16.003-16-16.003zm-10 26.004l7.434-11.154 3.718 3.719L6.5 26.318zm12.566-8.849l-3.718-3.719L26.5 6.315l-7.434 11.154z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-windows" width="33" height="33">
<path fill="currentColor" fill-rule="evenodd" d="M.512 15.263L.5 4.989l12.8-1.717v11.991H.512zM15.433 2.966L32.496.513v14.75H15.433V2.966zM32.5 17.37l-.004 14.749-17.063-2.371V17.37H32.5zM13.3 29.48L.51 27.748V17.37H13.3v12.11z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-windows-black" width="33" height="33">
<path fill="black" fill-rule="evenodd" d="M.512 15.263L.5 4.989l12.8-1.717v11.991H.512zM15.433 2.966L32.496.513v14.75H15.433V2.966zM32.5 17.37l-.004 14.749-17.063-2.371V17.37H32.5zM13.3 29.48L.51 27.748V17.37H13.3v12.11z"></path>
</svg>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-plugins">
<path fill="currentColor" fill-rule="evenodd" d="M59.1 14.035a.9.9 0 0 0 .9-.9V2.417A2.414 2.414 0 0 0 57.589.006H46.802a.9.9 0 0 0-.901.9v1.667c0 .292.142.565.379.734a2.988 2.988 0 0 1 .384 4.545 2.988 2.988 0 0 1-4.221 0 2.988 2.988 0 0 1 .763-4.774.9.9 0 0 0 .493-.803V.906a.9.9 0 0 0-.9-.9h-11.28c-.57 0-1.094.199-1.507.531a2.389 2.389 0 0 0-1.491-.519L12.509.006h-.001a.9.9 0 0 0 0 1.801l16.012.011a.608.608 0 0 1 .594.475c-.002.041-.006.082-.006.123v10.303a4.8 4.8 0 0 0-1.255-1.232l-.011-.008a4.744 4.744 0 0 0-2.67-.813c-1.278 0-2.48.498-3.384 1.402a4.752 4.752 0 0 0-1.401 3.384c0 1.278.497 2.48 1.401 3.384.173.172.357.33.549.472a4.747 4.747 0 0 0 2.846.939h.003a4.757 4.757 0 0 0 3.602-1.634h.32v9.874l.002.039a.609.609 0 0 1-.582.581l-.026-.001-10.787-.008h-.001a.9.9 0 0 0-.9.9l-.001 1.667v.004c0 .292.141.565.378.735a2.99 2.99 0 0 1 1.034 3.563l-.026.06-.036.083a2.964 2.964 0 0 1-2.7 1.708h-.002a2.966 2.966 0 0 1-2.11-.876 2.966 2.966 0 0 1-.873-2.109 2.988 2.988 0 0 1 1.638-2.661.901.901 0 0 0 .495-.802l.001-1.37v-.003a.9.9 0 0 0-.9-.901l-11.28-.008-.026.001a.609.609 0 0 1-.584-.608l.007-10.312a4.759 4.759 0 0 0 3.933 2.065h.004a4.754 4.754 0 0 0 3.382-1.4 4.791 4.791 0 0 0 .004-6.768 4.79 4.79 0 0 0-6.988.231h-.331L1.84 2.41a.61.61 0 0 1 .61-.61l5.955.004h.001A.9.9 0 0 0 8.407.003L2.451 0H2.45C1.806 0 1.201.25.746.704a2.395 2.395 0 0 0-.707 1.705L.031 13.196a.9.9 0 0 0 .9.901l1.667.001h.001a.9.9 0 0 0 .733-.378 2.989 2.989 0 0 1 4.546-.381c.563.565.873 1.314.873 2.112a2.968 2.968 0 0 1-.876 2.11 2.966 2.966 0 0 1-2.109.873h-.003a2.97 2.97 0 0 1-2.11-.876 3.01 3.01 0 0 1-.552-.763.899.899 0 0 0-.803-.494L.93 16.3H.929a.9.9 0 0 0-.9.899L.021 28.48c0 .571.199 1.095.531 1.508a2.396 2.396 0 0 0-.533 1.51L0 57.569c0 .643.25 1.249.705 1.705a2.395 2.395 0 0 0 1.705.707l10.787.008a.9.9 0 0 0 .901-.9l.001-1.667a.902.902 0 0 0-.378-.734 2.99 2.99 0 0 1-.382-4.546 2.989 2.989 0 0 1 4.222.003c.563.565.873 1.314.873 2.112a2.97 2.97 0 0 1-.876 2.11 3.01 3.01 0 0 1-.763.552.9.9 0 0 0-.494.803l-.001 1.369a.9.9 0 0 0 .9.9L28.48 60h.002c.563 0 1.097-.193 1.527-.546.414.333.939.533 1.51.533h26.07A2.413 2.413 0 0 0 60 57.577V46.789a.9.9 0 0 0-.901-.9h-1.667a.9.9 0 0 0-.733.378 2.97 2.97 0 0 1-2.435 1.259c-.797 0-1.547-.31-2.111-.874a2.989 2.989 0 0 1 0-4.222 2.966 2.966 0 0 1 2.111-.874 2.99 2.99 0 0 1 2.663 1.637.9.9 0 0 0 .803.493h1.369a.9.9 0 0 0 .901-.9V31.505c0-.57-.201-1.095-.534-1.508A2.4 2.4 0 0 0 60 28.488V16.937a.9.9 0 0 0-1.801 0v11.551a.61.61 0 0 1-.584.608l-.026-.002H47.283c.234-.162.453-.344.654-.547a4.755 4.755 0 0 0 1.402-3.384v-.004c0-1.278-.498-2.48-1.402-3.384a4.791 4.791 0 0 0-6.768 0 4.754 4.754 0 0 0-1.401 3.384v.004a4.754 4.754 0 0 0 1.637 3.604v.327h-9.886l-.027.002a.608.608 0 0 1-.58-.573l.001-.021.007-10.787a.9.9 0 0 0-.264-.638.898.898 0 0 0-.648-.277h-1.667a.902.902 0 0 0-.734.379 2.968 2.968 0 0 1-2.435 1.259 2.966 2.966 0 0 1-2.098-.866 2.989 2.989 0 0 1 .003-4.222 2.967 2.967 0 0 1 2.109-.873h.002a2.964 2.964 0 0 1 2.095.865c.224.223.409.48.552.762a.899.899 0 0 0 .24.295.897.897 0 0 0 .578.211l1.369.001a.9.9 0 0 0 .901-.899l.007-11.281c0-.05-.004-.098-.007-.147a.613.613 0 0 1 .595-.478H41.83a4.791 4.791 0 0 0-.661 7.32 4.792 4.792 0 0 0 6.769 0 4.793 4.793 0 0 0-.236-6.988v-.332h9.886c.337 0 .611.275.611.611v10.718a.9.9 0 0 0 .901.9zm-28.192 21.17l.003-3.686-.002-.027a.61.61 0 0 1 .583-.594l.027.001h10.787a.9.9 0 0 0 .9-.901v-1.671a.9.9 0 0 0-.379-.734 2.965 2.965 0 0 1-1.258-2.432c0-.797.311-1.546.874-2.109a2.989 2.989 0 0 1 4.222 0c.563.563.873 1.312.874 2.109a2.988 2.988 0 0 1-1.637 2.661.901.901 0 0 0-.494.803v1.373c0 .497.403.901.901.901h11.28l.026-.001a.61.61 0 0 1 .584.607v10.312a4.692 4.692 0 0 0-.551-.66 4.75 4.75 0 0 0-3.384-1.402 4.75 4.75 0 0 0-3.384 1.402 4.791 4.791 0 0 0 0 6.768 4.755 4.755 0 0 0 3.384 1.402 4.755 4.755 0 0 0 3.604-1.638h.331v9.887a.61.61 0 0 1-.61.61h-26.07a.61.61 0 0 1-.611-.61V47.29c.161.231.342.448.543.649a4.751 4.751 0 0 0 3.383 1.404h.003a4.757 4.757 0 0 0 3.382-1.399c.47-.47.822-1.014 1.055-1.595a4.793 4.793 0 0 0-1.046-5.193 4.791 4.791 0 0 0-6.988.236h-.332v-6.187zm-.906 8.001l1.668.001a.9.9 0 0 0 .733-.378 2.963 2.963 0 0 1 2.434-1.257h.002c.797 0 1.547.312 2.11.876a2.99 2.99 0 0 1 .658 3.222 2.988 2.988 0 0 1-5.427.219.9.9 0 0 0-.803-.493h-1.369a.899.899 0 0 0-.792.472.889.889 0 0 0-.116.44l-.008 11.281a.608.608 0 0 1-.61.61h-.001l-10.311-.007c.236-.164.457-.348.661-.551a4.76 4.76 0 0 0 1.404-3.384 4.753 4.753 0 0 0-1.4-3.385 4.791 4.791 0 0 0-6.768-.004 4.791 4.791 0 0 0 .231 6.988v.331l-9.887-.006a.603.603 0 0 1-.431-.18.606.606 0 0 1-.179-.431l.018-26.071a.606.606 0 0 1 .584-.608l.027.002 10.306.007a4.612 4.612 0 0 0-.655.547 4.751 4.751 0 0 0-1.404 3.383v.004a4.756 4.756 0 0 0 1.399 3.385 4.757 4.757 0 0 0 3.383 1.404h.004a4.753 4.753 0 0 0 3.381-1.399 4.756 4.756 0 0 0 1.405-3.384v-.004a4.76 4.76 0 0 0-1.635-3.605v-.327l9.886.006h.002l.025-.001c.317.014.57.27.581.587v3.73l-.005 7.079a.9.9 0 0 0 .899.901z"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-mask">
<path fill="currentColor" fill-rule="evenodd" d="M58.997 32.578h-.02a1.002 1.002 0 0 1-.982-1.021 28.239 28.239 0 0 0-.54-6.028c-.007-.026-.023-.047-.028-.074A27.898 27.898 0 0 0 46.073 8.061a1.001 1.001 0 0 1 1.149-1.638 29.885 29.885 0 0 1 12.147 18.55c.009.03.029.053.035.083.434 2.16.633 4.359.592 6.54-.01.545-.456.982-.999.982zM42.306 5.832c-5.573-2.739-11.744-3.536-17.845-2.303A27.907 27.907 0 0 0 7.39 14.47a.997.997 0 0 1-1.398.218 1 1 0 0 1-.218-1.398A29.903 29.903 0 0 1 24.066 1.565C30.604.246 37.217 1.1 43.187 4.034a1 1 0 0 1-.881 1.798zM7.733 35.628a.87.87 0 0 1-.038-.135 23.284 23.284 0 0 1-.434-3.597 1 1 0 1 1 1.998-.082 21.19 21.19 0 0 0 .369 3.144.986.986 0 0 1 .039.137A11.925 11.925 0 0 1 5.689 46.54a.999.999 0 0 1-1.41-.116 1.003 1.003 0 0 1 .117-1.412 9.923 9.923 0 0 0 3.337-9.384zm-5.187.835c.007.024.023.042.028.066.08.403.17.802.267 1.195a1.003 1.003 0 0 1-.972 1.241c-.45 0-.858-.305-.971-.761a32.326 32.326 0 0 1-.262-1.176c-.011-.035-.032-.065-.04-.102-1.355-6.727-.423-13.505 2.695-19.6a.998.998 0 0 1 1.346-.436c.492.253.686.856.434 1.348-2.899 5.669-3.77 11.969-2.525 18.225zm11.448 7.177a1.002 1.002 0 0 1 1.866.725 19.291 19.291 0 0 1-5.736 7.919 1 1 0 0 1-1.408-.141 1.001 1.001 0 0 1 .14-1.408 17.262 17.262 0 0 0 5.138-7.095zm8.187-9.446a1 1 0 1 1 1.981-.269c1.144 8.45-1.899 16.986-8.142 22.832a.99.99 0 0 1-.683.271 1.002 1.002 0 0 1-.684-1.733c5.77-5.404 8.585-13.292 7.528-21.101zm6.837-3.005a1.002 1.002 0 0 1 1.962-.395c2.092 10.391-.721 20.924-7.719 28.898a.998.998 0 0 1-1.412.091 1.003 1.003 0 0 1-.091-1.414c6.582-7.5 9.229-17.406 7.26-27.18zm7.633 10.675c.061-.55.562-.944 1.107-.882.548.063.942.559.88 1.109a41.106 41.106 0 0 1-6.894 18.472.996.996 0 0 1-1.39.261 1.001 1.001 0 0 1-.26-1.391 39.127 39.127 0 0 0 6.557-17.569zm1.249-3.487h-.002c-.551 0-.998-.447-1-.999a39.25 39.25 0 0 0-.775-7.622 1.237 1.237 0 0 1-.017-.12 6.226 6.226 0 0 0-2.647-3.867 6.224 6.224 0 0 0-4.704-.923 6.26 6.26 0 0 0-4.895 4.868 1 1 0 1 1-1.959-.41 8.262 8.262 0 0 1 6.459-6.422 8.21 8.21 0 0 1 6.206 1.22 8.219 8.219 0 0 1 3.527 5.255c.008.043.014.086.017.129.516 2.601.781 5.254.788 7.888a1 1 0 0 1-.998 1.003zm4.685 10.983a.999.999 0 1 1 1.931.517 48.282 48.282 0 0 1-3.224 8.643 1 1 0 0 1-1.338.461 1.002 1.002 0 0 1-.461-1.339 46.331 46.331 0 0 0 3.092-8.282zm1.779-3.27a1.003 1.003 0 0 1-.826-1.152 45.96 45.96 0 0 0-.31-16.615l-.01-.064a13.433 13.433 0 0 0-5.752-8.527 13.405 13.405 0 0 0-10.143-1.992c-7.242 1.462-11.966 8.506-10.602 15.753.021.053.038.109.05.167.389 1.93.482 3.891.273 5.829a1.011 1.011 0 0 1-1.101.89 1.003 1.003 0 0 1-.888-1.104c.181-1.676.11-3.373-.211-5.045a1.074 1.074 0 0 1-.05-.17c-1.691-8.389 3.754-16.592 12.134-18.283a15.394 15.394 0 0 1 11.645 2.287 15.416 15.416 0 0 1 6.619 9.861 48.047 48.047 0 0 1 .321 17.339 1.002 1.002 0 0 1-1.149.826zm7.44-15.581a1 1 0 0 1-.989-.855 53.147 53.147 0 0 0-.464-2.674.883.883 0 0 1-.023-.092c-2.26-11.225-13.22-18.514-24.435-16.254-8.454 1.708-14.871 8.303-16.347 16.806a.998.998 0 0 1-1.157.815 1.002 1.002 0 0 1-.814-1.158c1.619-9.322 8.654-16.555 17.921-18.425 12.263-2.475 24.253 5.471 26.774 17.725.009.031.017.064.024.096.196.974.365 1.939.501 2.87a1 1 0 0 1-.991 1.146zm-.515 3.632a1.002 1.002 0 0 1 .936-1.062.993.993 0 0 1 1.061.936 55.127 55.127 0 0 1-1.749 17.675c-.12.449-.525.746-.967.746a1 1 0 0 1-.967-1.26 53.13 53.13 0 0 0 1.686-17.035z"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-openvpn">
<path fill="currentColor" fill-rule="evenodd" d="M13 15.999H3a3 3 0 0 1-3-3V3A3 3 0 0 1 3-.001h10A3 3 0 0 1 16 3v9.999a3 3 0 0 1-3 3zm-1.38-8.716c-.019-.097-.055-.189-.082-.284-.036-.127-.069-.256-.118-.378-.047-.115-.108-.222-.166-.332-.048-.09-.091-.183-.146-.269-.072-.111-.155-.214-.237-.316A3.671 3.671 0 0 0 8 4.307a3.668 3.668 0 0 0-2.871 1.397c-.083.103-.166.204-.237.315-.055.087-.099.181-.148.273-.057.108-.118.214-.165.329-.049.122-.081.252-.118.38-.026.094-.062.185-.081.282a3.676 3.676 0 0 0-.073.716 3.693 3.693 0 0 0 7.385 0c0-.245-.026-.484-.072-.716zM14.769 3c0-.976-.793-1.77-1.769-1.77H3c-.975 0-1.769.794-1.769 1.77v2.538h2.531C4.616 4.074 6.186 3.076 8 3.076c1.814 0 3.384.998 4.238 2.462h2.531V3zm-3.077.692V2.461c0-.339.277-.616.616-.616h1.23c.339 0 .616.277.616.616v1.231a.617.617 0 0 1-.616.615h-1.23a.617.617 0 0 1-.616-.615zm-3.691 6.654a2.345 2.345 0 0 1-2.347-2.347c0-.446.131-.859.347-1.214a1.175 1.175 0 0 0-.058.348 1.19 1.19 0 1 0 1.19-1.19c-.121 0-.236.023-.347.057A2.333 2.333 0 0 1 8 5.653a2.346 2.346 0 1 1 .001 4.693z" opacity=".6"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-position">
<path fill="currentColor" fill-rule="evenodd" d="M60.997 59.999H-.008L10.915 37h7.493l-3.06-4.431c-5.717-7.64-4.886-20.25 1.799-26.952C20.76 1.995 25.563-.001 30.671-.001c5.11 0 9.913 1.996 13.524 5.618 6.685 6.702 7.516 19.311 1.777 26.982l-3.039 4.4h7.141l10.923 23zm-16.642-28.57c5.208-6.962 4.465-18.35-1.569-24.399a17 17 0 0 0-12.114-5.032A16.996 16.996 0 0 0 18.559 7.03c-6.034 6.049-6.777 17.436-1.592 24.369l3.868 5.6 9.836 14.244 13.684-19.814zm-2.803 7.57L30.671 54.757 19.789 38.999h-7.613L3.152 58h54.686l-9.024-19.001h-7.262zm-17.686-20c0-3.859 3.133-7 6.982-7s6.981 3.141 6.981 7-3.132 7-6.981 7c-3.85 0-6.982-3.141-6.982-7zm6.982 5c2.749 0 4.986-2.243 4.986-5s-2.237-5-4.986-5c-2.75 0-4.987 2.243-4.987 5s2.237 5 4.987 5z"></path>
</symbol>
<svg xmlns="http://www.w3.org/2000/svg" id="i-provider">
<path fill="currentColor" fill-rule="evenodd" d="M15.367 13.456a.274.274 0 0 1-.385 0 .268.268 0 0 1 0-.381 8.304 8.304 0 0 0 0-11.814.268.268 0 0 1 0-.381.275.275 0 0 1 .385 0 8.838 8.838 0 0 1 0 12.576zm-1.809-1.79a.277.277 0 0 1-.385 0 .268.268 0 0 1 0-.381 5.75 5.75 0 0 0 1.723-4.117 5.756 5.756 0 0 0-1.723-4.117.268.268 0 0 1 0-.381.275.275 0 0 1 .385 0 6.286 6.286 0 0 1 1.883 4.498 6.288 6.288 0 0 1-1.883 4.498zm-2-1.712a.27.27 0 0 1-.193-.46 3.25 3.25 0 0 0 .974-2.325c0-.879-.346-1.706-.974-2.327a.268.268 0 0 1 0-.381.275.275 0 0 1 .385 0 3.782 3.782 0 0 1 1.133 2.708 3.783 3.783 0 0 1-1.133 2.707.273.273 0 0 1-.192.078zM9.015 8.343a1.183 1.183 0 0 1-1.187-1.176c0-.647.532-1.174 1.187-1.174.654 0 1.187.527 1.187 1.174 0 .648-.533 1.176-1.187 1.176zm0-1.811a.64.64 0 0 0-.643.636.64.64 0 0 0 .643.636.64.64 0 0 0 .642-.636.64.64 0 0 0-.642-.636zM6.664 9.876a.274.274 0 0 1-.385 0 3.784 3.784 0 0 1-1.133-2.707c0-1.024.402-1.985 1.133-2.708a.275.275 0 0 1 .385 0 .268.268 0 0 1 0 .381 3.252 3.252 0 0 0-.974 2.327c0 .878.346 1.704.974 2.325a.27.27 0 0 1 0 .382zm-1.808 1.79a.277.277 0 0 1-.385 0 6.286 6.286 0 0 1-1.883-4.498c0-1.699.669-3.296 1.883-4.498a.275.275 0 0 1 .385 0 .268.268 0 0 1 0 .381 5.751 5.751 0 0 0-1.723 4.117c0 1.555.612 3.018 1.723 4.117a.268.268 0 0 1 0 .381zm-1.809 1.409a.268.268 0 0 1 0 .381.275.275 0 0 1-.385 0 8.838 8.838 0 0 1 0-12.576.275.275 0 0 1 .385 0 .268.268 0 0 1 0 .381 8.304 8.304 0 0 0 0 11.814z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-proxy">
<path fill="currentColor" fill-rule="evenodd" d="M10.915 0C7.597 0 4.794.776 3.837 1.942 1.889 2.423.763 3.232.543 4.053A.294.294 0 0 0 .5 4.2v11.1c0 .048.013.094.035.135C.886 16.904 4.03 18 7.939 18c3.345 0 6.124-.804 7.079-1.956 1.892-.463 3.084-1.222 3.3-2.1a.302.302 0 0 0 .037-.144V2.85c0-1.382-2.608-2.85-7.44-2.85zm3.811 11.804a.958.958 0 0 1-.112.2c-.019.028-.042.055-.065.083a1.652 1.652 0 0 1-.108.118c-.024.024-.05.047-.077.071-.049.042-.1.085-.157.127l-.076.054a3.073 3.073 0 0 1-.215.139l-.063.036c-.089.05-.181.101-.281.149l-.039.018a5.834 5.834 0 0 1-.353.156l-.011.005c-.676.272-1.54.501-2.548.651l-.015.001c-.196.03-.396.055-.603.078l-.103.01c-.18.019-.362.036-.549.05-.086.006-.176.009-.263.015-.141.008-.281.017-.425.022a21.37 21.37 0 0 1-1.447-.001c-.145-.005-.285-.014-.426-.022-.087-.006-.177-.009-.262-.015-.188-.014-.37-.031-.55-.05l-.103-.01a15.003 15.003 0 0 1-.603-.077l-.015-.003c-1.007-.15-1.872-.378-2.548-.651l-.01-.004a5.914 5.914 0 0 1-.353-.155l-.039-.019a4.352 4.352 0 0 1-.282-.149l-.063-.036a3.047 3.047 0 0 1-.291-.193 2.089 2.089 0 0 1-.156-.127c-.027-.024-.054-.047-.078-.071a1.652 1.652 0 0 1-.173-.201 1.341 1.341 0 0 1-.069-.111.799.799 0 0 1-.077-.198c-.011-.047-.023-.096-.023-.144 0-.034.004-.068.009-.102a.285.285 0 0 0-.009-.133V9.088l.027.023c.065.057.131.115.206.17 1.121.855 3.362 1.519 6.611 1.519 3.236 0 5.472-.659 6.597-1.509.09-.065.171-.134.247-.203h.001v2.227a.299.299 0 0 0-.01.133c.006.034.01.068.01.102 0 .048-.013.097-.024.145a.722.722 0 0 1-.034.109zM1.274 5.639c.089.071.186.14.29.209l.069.042a5.066 5.066 0 0 0 .386.219c.109.056.223.11.343.162l.057.027c.14.059.288.116.442.172l.131.044c.123.042.249.082.381.121.047.013.093.028.142.041.174.048.354.095.542.138l.08.016a13.157 13.157 0 0 0 .699.133c.169.028.343.054.521.077l.136.019c.221.027.451.05.686.07l.177.012a20.461 20.461 0 0 0 .794.044c.257.008.519.015.789.015a25.114 25.114 0 0 0 1.005-.025c.197-.009.39-.02.578-.034l.178-.012c.235-.02.464-.043.685-.07l.136-.019c.179-.023.352-.049.521-.077l.183-.031c.177-.032.35-.065.516-.102l.08-.016c.189-.043.368-.09.542-.138l.143-.041c.131-.039.258-.079.38-.121l.131-.044c.154-.056.303-.113.442-.172l.058-.027a6.046 6.046 0 0 0 .729-.381c.022-.015.047-.028.068-.042.105-.069.201-.138.291-.209l.063-.054c.039-.032.08-.064.116-.097v2.227a.299.299 0 0 0-.01.133c.006.034.01.068.01.102 0 .048-.013.097-.024.145a.801.801 0 0 1-.146.309c-.019.028-.042.055-.065.083a1.652 1.652 0 0 1-.185.188c-.049.043-.1.086-.157.128-.024.019-.05.036-.076.054a3.073 3.073 0 0 1-.215.139c-.02.013-.042.024-.063.036-.089.05-.181.101-.281.149l-.039.019a6.543 6.543 0 0 1-.353.155l-.011.005c-.676.272-1.54.501-2.548.651l-.015.002c-.196.028-.396.054-.603.077l-.103.01c-.18.019-.362.036-.549.05-.086.006-.176.009-.263.015-.141.008-.281.017-.425.023a21.311 21.311 0 0 1-1.447-.001c-.145-.005-.285-.015-.426-.023-.087-.006-.177-.009-.262-.015-.188-.014-.37-.031-.55-.05l-.103-.01a19.782 19.782 0 0 1-.603-.077l-.015-.002c-1.007-.151-1.872-.379-2.548-.651l-.01-.005a5.914 5.914 0 0 1-.353-.155l-.039-.019a4.352 4.352 0 0 1-.282-.149c-.021-.012-.043-.023-.063-.036a3.987 3.987 0 0 1-.214-.138l-.077-.055a2.089 2.089 0 0 1-.156-.127c-.027-.024-.054-.047-.078-.071a1.461 1.461 0 0 1-.242-.312.799.799 0 0 1-.077-.198c-.011-.047-.023-.096-.023-.144 0-.034.004-.068.009-.102a.285.285 0 0 0-.009-.133V5.488c.036.033.077.065.115.097l.064.054zm14.105 6.088V8.752l.037-.012c.119-.033.235-.068.348-.104l.004-.001c.881-.281 1.553-.629 1.991-1.028v2.443a.632.632 0 0 1-.031.191l-.008.025a.95.95 0 0 1-.039.095l-.006.011c-.246.485-1.031.961-2.164 1.314l-.132.041zm2.38-7.723V6.45a.61.61 0 0 1-.01.104c-.005.029-.013.058-.021.087l-.008.025a.95.95 0 0 1-.039.095l-.006.011c-.246.485-1.031.961-2.164 1.314l-.132.041V5.151l.072-.021.202-.06.167-.052c.068-.023.133-.045.198-.069.05-.017.1-.034.148-.052.068-.025.134-.052.2-.078l.123-.05c.076-.032.148-.065.22-.099l.079-.036c.096-.047.189-.095.277-.144l.026-.015c.077-.044.152-.088.223-.134l.072-.049c.052-.035.104-.071.152-.107l.075-.06c.042-.034.084-.067.123-.102l.023-.019zM10.915.6c4.034 0 6.844 1.185 6.844 2.25 0 .04-.004.08-.011.12l-.011.039a.81.81 0 0 1-.024.08c-.006.016-.014.032-.021.047-.011.024-.021.049-.035.073-.009.017-.02.033-.031.05a.919.919 0 0 1-.087.12 1.167 1.167 0 0 1-.058.068l-.049.05a1.509 1.509 0 0 1-.07.067l-.057.05-.082.066-.065.049a3.83 3.83 0 0 1-.094.064l-.072.048c-.034.022-.07.044-.107.065-.025.015-.05.03-.077.044l-.122.066-.08.042-.141.067-.078.036a9.618 9.618 0 0 1-.196.084l-.039.016a6.699 6.699 0 0 1-.327.122l-.194.066-.106.033-.145.044V4.2a.267.267 0 0 0-.02-.097.342.342 0 0 0-.013-.034l-.002-.005c-.085-.353-.334-.683-.713-.983a.027.027 0 0 0-.006-.005c-.055-.043-.115-.084-.174-.126-1.056-.753-2.999-1.343-5.754-1.436a21.046 21.046 0 0 0-1.516 0c-.743.025-1.424.087-2.049.178C6.286 1.083 8.318.6 10.915.6zm-6.4 1.818c.075-.015.152-.028.229-.042a12.417 12.417 0 0 1 .875-.135l.264-.032c.178-.019.36-.036.545-.051l.214-.014c.144-.009.289-.018.437-.024l.21-.009a21.37 21.37 0 0 1 1.374.002c.143.005.281.015.42.022.09.005.181.009.269.016.184.013.364.03.542.049l.111.01a16.553 16.553 0 0 1 .619.08c1.002.149 1.863.377 2.537.647l.023.009a6.578 6.578 0 0 1 .664.318l.072.041c.074.044.142.089.207.134l.083.059c.055.041.104.082.151.124.028.025.057.049.082.075a1.366 1.366 0 0 1 .239.308.757.757 0 0 1 .078.198c.011.05.024.098.024.147 0 1.064-2.811 2.25-6.845 2.25-4.033 0-6.844-1.186-6.844-2.25 0-.726 1.309-1.508 3.42-1.932zM7.939 17.4c-3.879 0-6.666-1.111-6.834-2.149l-.01-.039v-2.524l.027.023c.065.057.131.115.206.17 1.121.854 3.362 1.519 6.611 1.519 3.236 0 5.472-.659 6.597-1.509.09-.066.171-.134.247-.203h.001v2.523c-.005.013-.007.026-.01.04a.768.768 0 0 1-.058.184c-.011.024-.028.048-.041.071-.538.957-3.173 1.894-6.736 1.894zm9.811-3.649c-.094.583-.986 1.167-2.372 1.577l.001-.028v-2.949l.037-.011c.119-.033.235-.068.348-.104l.004-.001c.881-.281 1.553-.629 1.991-1.028v2.504a.259.259 0 0 0-.009.04z"></path>
</svg>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-navigator">
<path fill="currentColor" fill-rule="evenodd" d="M30 59.999c-16.542 0-30-13.457-30-30C0 13.457 13.458 0 30 0s30 13.457 30 29.999c0 16.543-13.458 30-30 30zM29.999 2C14.56 2 2 14.56 2 29.999 2 45.439 14.56 58 29.999 58c15.44 0 28-12.561 28-28.001C57.999 14.56 45.439 2 29.999 2zm16.853 27.999l2.901 2.797c.25.24.363.591.3.933A20.285 20.285 0 0 1 44.42 44.42a20.277 20.277 0 0 1-10.691 5.632 1.034 1.034 0 0 1-.934-.3L30 46.852l-2.795 2.9a1.033 1.033 0 0 1-.934.3 20.185 20.185 0 0 1-7.372-2.944 1.035 1.035 0 1 1 1.128-1.736 18.136 18.136 0 0 0 6.08 2.536l3.147-3.266a1.035 1.035 0 0 1 1.491 0l3.148 3.266c6.968-1.51 12.505-7.047 14.015-14.015l-3.266-3.148a1.035 1.035 0 0 1 0-1.491l3.267-3.148a18.123 18.123 0 0 0-2.492-6.011 1.035 1.035 0 1 1 1.74-1.121 20.194 20.194 0 0 1 2.896 7.296c.063.342-.05.693-.3.934l-2.901 2.795zm-3.164-12.652c-.57 0-1.035-.465-1.035-1.036 0-.57.465-1.035 1.035-1.035.57 0 1.035.465 1.035 1.035 0 .571-.465 1.036-1.035 1.036zm-17.885 8.887a.622.622 0 0 1 .032-.056c.01-.018.021-.033.032-.05a.964.964 0 0 1 .076-.097l.043-.046a.835.835 0 0 1 .044-.04c.016-.014.031-.028.048-.041l.049-.036.051-.034.055-.031.036-.019 12.643-6.078a1.034 1.034 0 0 1 1.381 1.382l-6.077 12.643-.02.035-.031.056c-.01.017-.022.033-.033.05a.922.922 0 0 1-.118.141l-.045.042a.901.901 0 0 1-.203.141l-.035.019-12.643 6.078a1.033 1.033 0 0 1-1.18-.201 1.035 1.035 0 0 1-.202-1.18l6.078-12.643.019-.035zm11.346-3.383l-8.668 4.166 4.501 4.501 4.167-8.667zm-5.631 10.131l-2.25-2.251-2.251-2.25-4.166 8.667 8.667-4.166zm8.386-18.399a18.123 18.123 0 0 0-6.011-2.492l-3.148 3.266a1.032 1.032 0 0 1-1.49 0l-3.148-3.266c-6.969 1.511-12.505 7.047-14.016 14.016l3.266 3.147a1.032 1.032 0 0 1 0 1.491l-3.266 3.148a18.16 18.16 0 0 0 2.447 5.943 1.035 1.035 0 1 1-1.745 1.113 20.2 20.2 0 0 1-2.846-7.22 1.031 1.031 0 0 1 .299-.933l2.901-2.797-2.9-2.795a1.034 1.034 0 0 1-.3-.934 20.265 20.265 0 0 1 5.633-10.69 20.275 20.275 0 0 1 10.691-5.633c.342-.063.693.05.934.3l2.795 2.9 2.795-2.9c.241-.25.592-.363.934-.3a20.184 20.184 0 0 1 7.296 2.895 1.035 1.035 0 1 1-1.121 1.741zM16.251 42.592c.57 0 1.035.465 1.035 1.035 0 .57-.465 1.035-1.035 1.035-.57 0-1.035-.465-1.035-1.035 0-.57.465-1.035 1.035-1.035z"></path>
</symbol>
<svg xmlns="http://www.w3.org/2000/svg" id="i-safari-sm" width="18" height="19">
<path fill="currentColor" fill-rule="evenodd" d="M9 18.5a9 9 0 1 1 9-9c0 4.969-4.031 9-9 9zM9 1.282A8.217 8.217 0 0 0 .783 9.5 8.216 8.216 0 0 0 9 17.717 8.216 8.216 0 0 0 17.217 9.5 8.217 8.217 0 0 0 9 1.282zm6.652 8.609h-.196a.392.392 0 0 1-.391-.391c0-.215.176-.391.391-.391h.196c.215 0 .391.176.391.391a.392.392 0 0 1-.391.391zm-1.956 4.695a.382.382 0 0 1-.274-.117l-.137-.137a.378.378 0 0 1 0-.548.378.378 0 0 1 .547 0l.137.137a.378.378 0 0 1 0 .548.382.382 0 0 1-.273.117zm-3.111-3.638a.597.597 0 0 1-.157.156l-5.537 3.033a.71.71 0 0 1-.195.039.383.383 0 0 1-.274-.118.415.415 0 0 1-.059-.469l3.033-5.537a.597.597 0 0 1 .156-.157l5.537-3.012a.383.383 0 0 1 .47.058.383.383 0 0 1 .058.47l-3.032 5.537zm-4.892 1.839l3.913-2.133-1.76-1.761-2.153 3.894zm2.7-4.442l1.761 1.761 2.152-3.893-3.913 2.132zM9 3.435a.393.393 0 0 1-.391-.392v-.195c0-.216.176-.392.391-.392.215 0 .391.176.391.392v.195A.393.393 0 0 1 9 3.435zM4.441 5.332a.388.388 0 0 1-.274-.117l-.137-.137a.38.38 0 0 1 0-.548.38.38 0 0 1 .548 0l.137.137a.378.378 0 0 1 0 .548.386.386 0 0 1-.274.117zM9 15.565c.215 0 .391.176.391.391v.196a.392.392 0 0 1-.391.391.392.392 0 0 1-.391-.391v-.196c0-.215.176-.391.391-.391zM2.543 9.891h-.195a.393.393 0 0 1-.392-.391c0-.215.177-.391.392-.391h.195c.216 0 .392.176.392.391a.392.392 0 0 1-.392.391z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-support" width="19" height="16">
<path fill="#FFF" fill-rule="evenodd" d="M16.731 5.409l-.302.001c-.836-3.163-3.678-5.411-6.932-5.411-3.235 0-6.075 2.248-6.924 5.411h-.305C1.293 5.41.5 6.22.5 7.215v2.028c0 .995.793 1.805 1.768 1.805h.22c.283 2.274 2.19 4.037 4.492 4.037h.422c.224.537.746.914 1.353.914h1.489c.811 0 1.47-.673 1.47-1.5 0-.828-.659-1.501-1.47-1.501H8.755c-.606 0-1.128.378-1.352.914H6.98c-1.864 0-3.38-1.548-3.38-3.45v-4.4c.594-2.837 3.065-4.891 5.897-4.891 2.85 0 5.324 2.054 5.903 4.889v4.401a.58.58 0 0 0 .574.586h.758c.975 0 1.768-.809 1.768-1.804V7.215c0-.995-.793-1.806-1.769-1.806zm-7.976 8.762h1.489c.178 0 .322.147.322.328a.325.325 0 0 1-.322.328H8.755a.325.325 0 0 1-.321-.328c0-.181.144-.328.321-.328zM1.648 9.243V7.215c0-.348.278-.632.619-.632h.185v3.293h-.184a.627.627 0 0 1-.62-.633zm15.703-.001a.626.626 0 0 1-.619.633h-.184V6.582h.184c.342 0 .619.284.619.633v2.027z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-time" width="60" height="60">
<path fill="currentColor" fill-rule="evenodd" d="M30 60C13.458 60 0 46.542 0 30 0 13.457 13.458-.001 30-.001S60 13.457 60 30c0 16.542-13.458 30-30 30zm0-58C14.561 2 2 14.56 2 30c0 15.438 12.561 28 28 28s28-12.562 28-28C58 14.56 45.439 2 30 2zm22 28.878h-1a1 1 0 1 1 0-1.999h1a.999.999 0 1 1 0 1.999zm-6.444 15.556a1 1 0 0 1-.707-.292l-.707-.707a.999.999 0 1 1 1.414-1.414l.707.707a.999.999 0 0 1-.707 1.706zm0-30.699a.997.997 0 0 1-1.414 0 .999.999 0 0 1 0-1.414l.707-.706a.999.999 0 1 1 1.414 1.413l-.707.707zM30 33.878c-1.858 0-3.411-1.28-3.858-3H19a1 1 0 1 1 0-1.999h7.142A3.996 3.996 0 0 1 29 26.02V15.878a1 1 0 0 1 2 0V26.02c1.72.447 3 2 3 3.858 0 2.207-1.794 4-4 4zm0-5.999c-1.103 0-2 .897-2 1.999 0 1.103.897 2 2 2s2-.897 2-2a2.002 2.002 0 0 0-2-1.999zm0-18a1 1 0 0 1-1-1V7.878a1 1 0 0 1 2 0v1.001a1 1 0 0 1-1 1zM15.151 46.142a1 1 0 0 1-1.414-1.414l.707-.707a.999.999 0 1 1 1.414 1.414l-.707.707zm0-30.114a.997.997 0 0 1-.707-.293l-.707-.707a.998.998 0 0 1 0-1.413.997.997 0 0 1 1.414 0l.707.706a.999.999 0 0 1-.707 1.707zM30 49.879a1 1 0 0 1 1 1v.999a1 1 0 1 1-2 0v-.999a1 1 0 0 1 1-1zM9 30.878H8a1 1 0 1 1 0-1.999h1a.999.999 0 1 1 0 1.999z"></path>
</svg>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-tw">
<path fill="currentColor" fill-rule="evenodd" d="M30 60C13.458 60 0 46.542 0 30S13.458 0 30 0s30 13.458 30 30-13.458 30-30 30zm0-58C14.561 2 2 14.561 2 30c0 15.438 12.561 28 28 28s28-12.562 28-28C58 14.561 45.439 2 30 2zm22 28.879h-1a1 1 0 1 1 0-2h1a1 1 0 1 1 0 2zm-6.444 15.556a.997.997 0 0 1-.707-.293l-.707-.707a.999.999 0 1 1 1.414-1.414l.707.707a.999.999 0 0 1-.707 1.707zm0-30.699a.997.997 0 0 1-1.414 0 .999.999 0 0 1 0-1.414l.707-.707a1 1 0 1 1 1.414 1.414l-.707.707zM30 33.879c-1.858 0-3.411-1.28-3.858-3H19a1 1 0 1 1 0-2h7.142A3.995 3.995 0 0 1 29 26.021V15.879a1 1 0 1 1 2 0v10.142c1.72.447 3 1.999 3 3.857a4.004 4.004 0 0 1-4 4.001zm0-6c-1.103 0-2 .897-2 1.999 0 1.104.897 2.001 2 2.001s2-.897 2-2.001a2.002 2.002 0 0 0-2-1.999zm0-18a1 1 0 0 1-1-1v-1a1 1 0 1 1 2 0v1a1 1 0 0 1-1 1zM15.151 46.142a.997.997 0 0 1-1.414 0 .999.999 0 0 1 0-1.414l.707-.707a1 1 0 1 1 1.414 1.414l-.707.707zm0-30.113a.997.997 0 0 1-.707-.293l-.707-.707a.999.999 0 1 1 1.414-1.414l.707.707a.999.999 0 0 1-.707 1.707zM30 49.879a1 1 0 0 1 1 1v1a1 1 0 1 1-2 0v-1a1 1 0 0 1 1-1zm-21-19H8a1 1 0 1 1 0-2h1a1 1 0 1 1 0 2z"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-vk">
<path fill="currentColor" fill-rule="evenodd" d="M52.412 45.425c-1.593 1.285-3.447 2.019-5.427 2.374-1.221.218-2.473.254-3.709.392-.231.026-.515.084-.667.237-3.111 3.12-6.784 5.242-10.973 6.459-.017.005-.031.023-.063.048.26.674.56 1.342.775 2.038.319 1.03.293 1.038 1.368 1.038h3.673V60h-24.78v-1.989c1.073 0 2.141.002 3.209-.001.499-.001 1.119.168 1.461-.07.315-.221.314-.891.487-1.349.204-.543.445-1.07.694-1.66-7.365-2.239-12.821-6.815-16.136-13.898C.602 37.355-.135 33.44.019 29.327h49.95v3.05c.702.063 1.409.072 2.096.197 2.436.444 3.921 2.278 3.935 4.797.018 3.245-1.042 6.001-3.588 8.054zM1.993 31.37c.338 5.728 2.336 10.693 6.13 14.876 3.784 4.174 8.536 6.516 14.129 7.415-1.276 1.334-2.537 2.481-2.754 4.31h11.011c-.245-1.854-1.505-3.005-2.779-4.321 5.628-.856 10.391-3.216 14.175-7.4 3.78-4.181 5.804-9.144 6.09-14.88H1.993zm50.297 3.357c-.825-.24-1.712-.258-2.587-.377-.742 4.398-2.374 8.233-5.058 11.756 1.864-.177 3.512-.544 5.058-1.323 1.333-.673 2.442-1.598 3.21-2.914.846-1.45 1.187-3.031 1.097-4.699-.063-1.159-.574-2.111-1.72-2.443zM29.412 18.626c2.079 1.912 3.115 4.294 3.195 7.127.003.096-.011.191-.019.333H30.75c-.197-.982-.327-1.949-.593-2.874-.336-1.166-1.067-2.104-1.93-2.931-.895-.857-1.836-1.669-2.674-2.58-2.127-2.314-2.091-5.532.122-7.762.853-.86 1.861-1.564 2.821-2.309 1.129-.876 2.095-1.845 2.154-3.415h1.954c-.012 1.441-.451 2.709-1.441 3.668-.995.964-2.128 1.782-3.199 2.666-.793.656-1.576 1.328-1.828 2.405-.263 1.119-.173 2.2.63 3.068a46.422 46.422 0 0 0 2.646 2.604zM21.333 8.537c-1.981 2.194-2.494 4.706-1.48 7.468.318.868.937 1.648 1.527 2.377.792.978 1.718 1.842 2.537 2.799 1.388 1.622 2.07 3.525 2.039 5.737h-1.905c-.081-.577-.121-1.158-.248-1.717-.304-1.331-1.048-2.408-1.956-3.388-.922-.993-1.914-1.937-2.718-3.024-2.637-3.562-2.286-8.291.795-11.673.783-.859 1.601-1.686 2.371-2.558 1.076-1.216 1.675-2.64 1.684-4.297 0-.075.022-.15.039-.261h1.929c.058 1.692-.295 3.31-1.289 4.661-1.007 1.369-2.184 2.613-3.325 3.876z"></path>
</symbol>
<symbol xmlns="http://www.w3.org/2000/svg" id="i-webrtc">
<path fill="currentColor" fill-rule="evenodd" d="M9.039 59.985c.288 0 .568-.124.762-.351l5.607-6.59H53.36c3.667 0 6.65-2.966 6.65-6.613V6.615c0-3.647-2.983-6.614-6.65-6.614H6.655C2.986.001.005 2.968.005 6.615v39.816c0 3.647 2.984 6.613 6.65 6.613h1.389v5.95a.99.99 0 0 0 .995.991zM53.36 1.984c2.567 0 4.656 2.078 4.656 4.631v39.816c0 2.552-2.089 4.63-4.656 4.63H14.946a.996.996 0 0 0-.76.352l-4.148 4.874v-4.234a.995.995 0 0 0-.997-.992H6.655c-2.568 0-4.656-2.078-4.656-4.63V6.615c0-2.553 2.089-4.631 4.656-4.631H53.36z"></path>
</symbol>
<svg xmlns="http://www.w3.org/2000/svg" id="i-ip" width="60" height="60">
<path fill="currentColor" fill-rule="evenodd" d="M60 51.074v3.967A4.965 4.965 0 0 1 55.042 60h-29.75a4.965 4.965 0 0 1-4.958-4.959v-3.966a4.94 4.94 0 0 1 2.014-3.967 5.03 5.03 0 0 1-1.104-1.119 22.655 22.655 0 0 1-14.577-7.082l-.049-.048c-8.146-8.741-8.157-22.291-.025-31.046a.771.771 0 0 1 .075-.105c.019-.014.04-.026.06-.038a22.757 22.757 0 0 1 33.161 0c.019.015.043.021.061.038a.87.87 0 0 1 .075.105 22.72 22.72 0 0 1 6.067 14.503h8.949A4.964 4.964 0 0 1 60 27.275v3.966a4.943 4.943 0 0 1-2.014 3.967A4.943 4.943 0 0 1 60 39.175v3.966a4.943 4.943 0 0 1-2.014 3.967A4.943 4.943 0 0 1 60 51.074zm-39.648-7.752c-.002-.062-.018-.118-.018-.181v-3.966a4.935 4.935 0 0 1 1.983-3.941v-.052a4.947 4.947 0 0 1-1.819-2.736 20.33 20.33 0 0 0-6.394 1.959c1.458 4.342 3.7 7.516 6.248 8.917zm.999-19.023h-8.917c.06 2.75.433 5.483 1.112 8.148a22.322 22.322 0 0 1 6.788-1.999v-3.173a4.914 4.914 0 0 1 1.017-2.976zm-4.483 18.795a20.684 20.684 0 0 1-4.531-7.723 20.456 20.456 0 0 0-3.58 2.807 20.663 20.663 0 0 0 8.111 4.916zm-9.461-6.369a22.403 22.403 0 0 1 4.343-3.309 37.954 37.954 0 0 1-1.298-9.117H2.531a20.716 20.716 0 0 0 4.876 12.426zM2.535 22.316h7.896c.056-3.084.486-6.15 1.282-9.13a22.718 22.718 0 0 1-4.316-3.285 20.713 20.713 0 0 0-4.862 12.415zM8.746 8.447a20.736 20.736 0 0 0 3.57 2.791 20.536 20.536 0 0 1 4.471-7.694 20.824 20.824 0 0 0-8.041 4.903zm13.571-5.865c-3.398.617-6.394 4.363-8.181 9.664a20.9 20.9 0 0 0 8.181 2.111V2.582zm0 13.759a22.879 22.879 0 0 1-8.754-2.175 35.775 35.775 0 0 0-1.136 8.15v.001h9.89v-5.976zm1.984-13.759v11.775a20.9 20.9 0 0 0 8.181-2.111c-1.787-5.301-4.783-9.047-8.181-9.664zm0 13.758v5.976h9.889a35.719 35.719 0 0 0-1.135-8.15 22.86 22.86 0 0 1-8.754 2.174zm5.53-12.796a20.545 20.545 0 0 1 4.469 7.694 20.862 20.862 0 0 0 3.57-2.791 20.829 20.829 0 0 0-8.039-4.903zm9.39 6.357a22.75 22.75 0 0 1-4.316 3.285 38.055 38.055 0 0 1 1.281 9.13h7.897a20.713 20.713 0 0 0-4.862-12.415zm18.796 21.34v-3.966a2.976 2.976 0 0 0-2.976-2.976H25.292a2.976 2.976 0 0 0-2.975 2.976v3.966a2.975 2.975 0 0 0 2.975 2.975h29.749a2.975 2.975 0 0 0 2.976-2.975zm0 11.9v-3.966a2.975 2.975 0 0 0-2.976-2.975H25.292a2.975 2.975 0 0 0-2.975 2.975v3.966a2.975 2.975 0 0 0 2.975 2.975h29.749a2.975 2.975 0 0 0 2.976-2.975zm0 7.933a2.974 2.974 0 0 0-2.976-2.974H25.292a2.974 2.974 0 0 0-2.975 2.974v3.967a2.975 2.975 0 0 0 2.975 2.975h29.749a2.975 2.975 0 0 0 2.976-2.975v-3.967zm-5.95 2.975h-1.984a.99.99 0 1 1 0-1.983h1.984a.992.992 0 0 1 0 1.983zm-5.95 0h-1.984a.99.99 0 1 1 0-1.983h1.984a.992.992 0 0 1 0 1.983zm-16.858 1.984a2.975 2.975 0 1 1 0-5.95 2.975 2.975 0 0 1 0 5.95zm0-3.967a.992.992 0 1 0 0 1.984.992.992 0 0 0 0-1.984zm22.808-9.917h-1.984a.99.99 0 1 1 0-1.983h1.984a.992.992 0 0 1 0 1.983zm-5.95 0h-1.984a.99.99 0 1 1 0-1.983h1.984a.992.992 0 0 1 0 1.983zm-16.858 1.984a2.975 2.975 0 1 1 0-5.95 2.975 2.975 0 0 1 0 5.95zm0-3.967a.992.992 0 1 0 0 1.984.992.992 0 0 0 0-1.984zm22.808-9.916h-1.984a.992.992 0 0 1 0-1.984h1.984a.992.992 0 0 1 0 1.984zm-5.95 0h-1.984a.992.992 0 0 1 0-1.984h1.984a.992.992 0 0 1 0 1.984zm-16.858 1.983a2.975 2.975 0 1 1 0-5.95 2.975 2.975 0 0 1 0 5.95zm0-3.967a.992.992 0 1 0 0 1.984.992.992 0 0 0 0-1.984z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-http" width="60" height="55">
<path fill="currentColor" fill-rule="evenodd" d="M21.359 38.262a.956.956 0 0 1-1.313.334L8.893 31.923a.962.962 0 0 1 0-1.653l11.154-6.673a.956.956 0 0 1 1.312.334.964.964 0 0 1-.333 1.319l-9.772 5.847 9.772 5.847a.963.963 0 0 1 .333 1.318zm4.179.47a.963.963 0 0 1-.794-1.498l8.922-13.347a.956.956 0 0 1 1.329-.262.965.965 0 0 1 .261 1.335l-8.923 13.346a.955.955 0 0 1-.795.426zm13.103-14.801a.955.955 0 0 1 1.312-.334l11.154 6.673a.964.964 0 0 1 0 1.653l-11.154 6.673a.956.956 0 0 1-1.312-.334.963.963 0 0 1 .333-1.318l9.772-5.847-9.772-5.847a.964.964 0 0 1-.333-1.319zm20.401 18.386a.96.96 0 0 1 .958.962v10.259a.96.96 0 0 1-.958.961H.957A.959.959 0 0 1 0 53.538V.961a.96.96 0 0 1 .957-.962h58.085A.96.96 0 0 1 60 .961v38.471a.96.96 0 0 1-.958.962.96.96 0 0 1-.957-.962V9.618H1.915v42.958h56.17v-9.297a.96.96 0 0 1 .957-.962zM39.255 7.693h18.83v-5.77h-18.83v5.77zm-1.915 0v-5.77H1.915v5.77H37.34zm16.596-1.859c-.563 0-1.021-.46-1.021-1.026 0-.565.458-1.025 1.021-1.025s1.021.46 1.021 1.025c0 .566-.458 1.026-1.021 1.026zm-5.234 0c-.563 0-1.021-.46-1.021-1.026 0-.565.458-1.025 1.021-1.025s1.021.46 1.021 1.025c0 .566-.458 1.026-1.021 1.026zm-5.234 0c-.563 0-1.021-.46-1.021-1.026 0-.565.458-1.025 1.021-1.025s1.021.46 1.021 1.025c0 .566-.458 1.026-1.021 1.026z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-display" width="60" height="58">
<path fill="currentColor" fill-rule="evenodd" d="M59.062 44.903H37.705l1.5 7.484h2.045c.518 0 .937.419.937.935v2.807h1.875V58H15.937v-1.871h1.875v-2.807c0-.516.42-.935.938-.935h2.044l1.5-7.484H.937A.937.937 0 0 1 0 43.967V2.806A2.81 2.81 0 0 1 2.812-.001h54.375A2.81 2.81 0 0 1 60 2.806v41.161c0 .517-.42.936-.938.936zm-37.5 9.355h-1.875v1.871h20.625v-1.871h-18.75zm15.732-1.871l-1.5-7.484H24.205l-1.499 7.484h14.588zM58.125 2.806a.936.936 0 0 0-.938-.935H2.812a.936.936 0 0 0-.937.935v29.936h2.812V5.612c0-.516.42-.935.938-.935h48.75c.518 0 .937.419.937.935v27.13h2.813V2.806zM14.138 14.599l2.813-6.549a.94.94 0 0 1 1.723 0l2.812 6.549a.897.897 0 0 1 .076.369v2.806h-1.875v-1.872h-.937v16.84h.937v-7.484h1.875v7.484h3.75v-4.678c0-3.818-4.646-4.657-4.844-4.69a.937.937 0 0 1-.646-1.404l8.437-14.032a.975.975 0 0 1 1.607 0l8.437 14.032a.935.935 0 0 1-.649 1.404c-.195.033-4.842.872-4.842 4.69v4.678h3.75v-7.484h1.875v7.484h5.625V29h-3.75v-1.871h3.75v-4.678h-3.75V20.58h3.75v-4.678h-3.75v-1.87h3.75V10.29h-5.625v7.484h-1.875v-8.42c0-.516.42-.935.938-.935H45c.518 0 .937.419.937.935v23.388h7.5V6.548H6.562v26.194h7.5V14.968a.93.93 0 0 1 .076-.369zm2.737 1.303h-.938v16.84h.938v-16.84zm2.33-1.87l-1.393-3.243-1.392 3.243h2.785zm11.732 15.903V29h-3.75v.935h3.75zm-3.75 1.871v.936h3.75v-.936h-3.75zm3.819-4.677c.449-2.975 3-4.589 5.044-5.272L30 11.797v7.848h-1.875v-7.848l-6.05 10.06c2.042.688 4.595 2.297 5.044 5.272h3.887zm27.119 7.483H1.875v8.42h56.25v-8.42zM30 35.548a2.809 2.809 0 0 1 2.812 2.807A2.81 2.81 0 0 1 30 41.161a2.81 2.81 0 0 1-2.813-2.806A2.81 2.81 0 0 1 30 35.548zm0 3.742a.936.936 0 1 0 .002-1.872A.936.936 0 0 0 30 39.29z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-icheck" width="60" height="54">
<path fill="currentColor" fill-rule="evenodd" d="M59.908 41.281a3.011 3.011 0 0 1-2.163 2.191 2.976 2.976 0 0 1-2.937-.874L50.7 38.443a10.276 10.276 0 0 1-8.701-.085H10.985c-2.757-.003-4.99-2.261-4.993-5.047v-4.038a5.047 5.047 0 0 1 2.028-4.038 5.045 5.045 0 0 1-2.028-4.037V17.16a5.047 5.047 0 0 1 2.028-4.038 5.047 5.047 0 0 1-2.028-4.038V5.047C5.995 2.261 8.228.003 10.985-.001h37.947c2.757.004 4.99 2.262 4.994 5.048v4.038a5.048 5.048 0 0 1-2.028 4.037 5.05 5.05 0 0 1 2.028 4.038v4.038c0 .053-.012.103-.012.154 3.434 3.518 3.992 8.975 1.341 13.128l3.782 3.834a3.05 3.05 0 0 1 .871 2.967zM7.989 29.273v4.038c0 1.672 1.341 3.028 2.996 3.028h28.127a10.563 10.563 0 0 1-2.849-10.094H10.985c-1.655 0-2.996 1.356-2.996 3.028zm43.94-20.189V5.047c0-1.673-1.342-3.029-2.996-3.029H10.985c-1.655 0-2.996 1.356-2.996 3.029v4.038c0 1.672 1.341 3.028 2.996 3.028h37.948c1.654 0 2.996-1.356 2.996-3.029zm0 8.076c0-1.672-1.342-3.028-2.996-3.028H10.985c-1.655 0-2.996 1.356-2.996 3.028v4.038c0 1.672 1.341 3.028 2.996 3.028h25.992a10.476 10.476 0 0 1 6.484-5.624 10.349 10.349 0 0 1 8.468 1.155V17.16zm-5.493 3.029c-4.688 0-8.488 3.841-8.488 8.58.005 4.736 3.802 8.574 8.488 8.579 4.688 0 8.488-3.841 8.488-8.579 0-4.739-3.8-8.58-8.488-8.58zm11.19 19.554l-3.618-3.665c-.463.489-.97.932-1.515 1.325l3.724 3.764a.99.99 0 0 0 1.404 0c.19-.189.298-.448.298-.717a.99.99 0 0 0-.293-.707zm-6.519-7.886a1.014 1.014 0 0 1-.531-1.323 4.53 4.53 0 0 0 .354-1.765c0-.558.447-1.01.998-1.01.552 0 .999.452.999 1.01a6.552 6.552 0 0 1-.511 2.552.995.995 0 0 1-1.309.536zm-1.495-6.299a4.451 4.451 0 0 0-3.176-1.332c-.551 0-.999-.452-.999-1.009 0-.558.447-1.01.999-1.01a6.43 6.43 0 0 1 4.588 1.924 1.017 1.017 0 0 1-.013 1.415.989.989 0 0 1-1.399.012zm-34.633-3.351c-1.654 0-2.996-1.355-2.996-3.028s1.342-3.028 2.996-3.028c1.655 0 2.996 1.355 2.996 3.028s-1.341 3.028-2.996 3.028zm0-4.037c-.551 0-.998.452-.998 1.009 0 .557.447 1.009.998 1.009.552 0 .999-.452.999-1.009 0-.557-.447-1.009-.999-1.009zM47.934 8.075h-1.997c-.552 0-.999-.452-.999-1.009 0-.558.447-1.01.999-1.01h1.997c.552 0 .998.452.998 1.01 0 .557-.446 1.009-.998 1.009zm-5.992 0h-1.997c-.552 0-.999-.452-.999-1.009 0-.558.447-1.01.999-1.01h1.997c.552 0 .999.452.999 1.01 0 .557-.447 1.009-.999 1.009zm-26.963 2.019c-1.654 0-2.996-1.356-2.996-3.028 0-1.673 1.342-3.029 2.996-3.029 1.655 0 2.996 1.356 2.996 3.029 0 1.672-1.341 3.028-2.996 3.028zm0-4.038c-.551 0-.998.452-.998 1.01 0 .557.447 1.009.998 1.009.552 0 .999-.452.999-1.009 0-.558-.447-1.01-.999-1.01zm0 22.208c1.655 0 2.996 1.356 2.996 3.028s-1.341 3.028-2.996 3.028c-1.654 0-2.996-1.356-2.996-3.028s1.342-3.028 2.996-3.028zm0 4.037c.552 0 .999-.451.999-1.009 0-.557-.447-1.009-.999-1.009-.551 0-.998.451-.998 1.009 0 .558.447 1.009.998 1.009zm7.989 15.142h3.995v-6.057c0-.557.447-1.009.998-1.009h3.995c.551 0 .999.452.999 1.009v6.057h3.994c1.103 0 1.997.904 1.997 2.019h12.982c.552 0 .999.452.999 1.009 0 .558-.447 1.01-.998 1.01H38.946a2.007 2.007 0 0 1-1.997 2.018H22.968a2.007 2.007 0 0 1-1.997-2.018H.998c-.551 0-.998-.452-.998-1.01 0-.557.447-1.009.998-1.009h19.973c0-1.115.894-2.019 1.997-2.019zm7.989-5.047H28.96v5.047h1.997v-5.047zm-7.989 9.085h13.981v-2.019H22.968v2.019zm32.955-2.019h2.996c.551 0 .998.452.998 1.009 0 .558-.447 1.01-.998 1.01h-2.996c-.552 0-.999-.452-.999-1.01 0-.557.447-1.009.999-1.009z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-arrow" width="18" height="6">
<path fill="#FF7D19" fill-rule="evenodd" d="M.008 2.473h13.196c-.66-.975-.989-1.611-1.022-2.477 1.501 1.494 3.452 2.272 5.81 3.003-2.358.701-4.223 1.556-5.81 3.004.101-.942.374-1.51 1.042-2.547H.008v-.983z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-step-1" width="75" height="68">
<path fill="#5CA5C3" fill-rule="evenodd" d="M73.414 67.5H1.586C.986 67.5.5 67.014.5 66.415V1.585C.5.986.986.5 1.586.5h71.828c.599 0 1.086.486 1.086 1.085v64.83c0 .599-.486 1.085-1.086 1.085zm-1.087-55.568h-57.37a1.086 1.086 0 1 1 0-2.171h57.37v-7.09H2.672v7.09h7.265a1.086 1.086 0 1 1 0 2.171H2.672v53.397h69.655V11.932zm-53.363 7.09h23.17a1.086 1.086 0 1 1 0 2.171h-23.17a1.086 1.086 0 1 1 0-2.171zm0 4.631h37.072c.6 0 1.086.486 1.086 1.085v14.107l7.508 2.047c.789.215 1.062 1.235.482 1.814l-4.147 4.145 7.424 7.418a1.085 1.085 0 0 1 0 1.535l-3.277 3.274a1.097 1.097 0 0 1-1.536 0l-7.423-7.418-4.148 4.144c-.579.579-1.6.306-1.815-.482l-1.732-6.345H18.964c-.6 0-1.086-.486-1.086-1.085V24.738c0-.599.486-1.085 1.086-1.085zm32.829 29.294l3.592-3.589a1.096 1.096 0 0 1 1.536 0l7.423 7.418 1.741-1.739-7.424-7.419a1.085 1.085 0 0 1 0-1.535l3.592-3.589-14.383-3.92 3.923 14.373zM20.05 46.806h27.815l-2.591-9.493c-.217-.795.538-1.55 1.334-1.333l8.342 2.273V25.824h-34.9v20.982zm13.974 4.631h6.951a4.565 4.565 0 0 1 4.562 4.558 4.565 4.565 0 0 1-4.562 4.559h-6.951a4.565 4.565 0 0 1-4.561-4.559 4.565 4.565 0 0 1 4.561-4.558zm0 6.946h6.951a2.391 2.391 0 0 0 2.39-2.388 2.391 2.391 0 0 0-2.39-2.387h-6.951a2.391 2.391 0 0 0-2.389 2.387 2.391 2.391 0 0 0 2.389 2.388zm23.171-37.19H45.609a1.086 1.086 0 0 1 0-2.171h11.585a1.087 1.087 0 0 1 .001 2.171zm2.027-16.062h.145a1.086 1.086 0 1 1 0 2.17h-.145a1.086 1.086 0 1 1 0-2.17zm4.779 0h.144c.6 0 1.087.486 1.087 1.085s-.487 1.085-1.087 1.085h-.144a1.086 1.086 0 1 1 0-2.17zm4.634 0h.145a1.086 1.086 0 0 1 0 2.17h-.145a1.086 1.086 0 1 1 0-2.17z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-step-2" width="75" height="74">
<path fill="#5CA5C3" fill-rule="evenodd" d="M74.296 71.465a1.224 1.224 0 0 1-1.029 1.893 1.15 1.15 0 0 1-.324-.053 3.678 3.678 0 0 1-2.142.695H4.199a3.669 3.669 0 0 1-2.136-.685 1.223 1.223 0 0 1-1.357-1.85A3.672 3.672 0 0 1 .5 70.3V28.358c0-.026.015-.048.015-.073.008-.083.025-.166.051-.246.016-.073.04-.145.07-.214.035-.065.076-.127.123-.185.049-.07.105-.136.168-.194.02-.018.028-.041.049-.057l11.857-9.213V8.628a3.7 3.7 0 0 1 3.7-3.7h13.366L35.251.773a3.657 3.657 0 0 1 4.498 0l5.352 4.155h13.366a3.7 3.7 0 0 1 3.7 3.7v9.548l11.857 9.213c.021.016.03.039.05.057.062.058.118.124.167.194.047.058.088.12.124.185.029.069.053.141.07.214.026.081.043.166.051.251.001.025.014.047.014.073h.001V70.3a3.666 3.666 0 0 1-.205 1.165zm-3.802.068L38.23 46.477a1.187 1.187 0 0 0-1.47 0L4.505 71.533h65.989zM38.231 2.719a1.183 1.183 0 0 0-1.471 0l-2.837 2.209h7.153l-2.845-2.209zm33.803 27.523L51.787 45.964a1.233 1.233 0 1 1-1.514-1.949l20.57-15.974-8.677-6.742v9.531a1.233 1.233 0 1 1-2.466 0V8.628c0-.681-.552-1.233-1.234-1.233H16.532c-.681 0-1.233.552-1.233 1.233V30.83a1.233 1.233 0 1 1-2.466 0v-9.531l-8.677 6.742 20.533 15.946a1.235 1.235 0 0 1-1.512 1.95L2.966 30.241v39.365L35.252 44.53a3.658 3.658 0 0 1 4.495 0l32.287 25.076V30.242zM37.5 29.597c0-.682.552-1.234 1.233-1.234h11.1a1.234 1.234 0 0 1 0 2.467h-11.1a1.233 1.233 0 0 1-1.233-1.233zm12.333-6.168H25.166a1.233 1.233 0 1 1 0-2.466h24.667a1.234 1.234 0 1 1 0 2.466zm0-7.4H25.166a1.233 1.233 0 0 1 0-2.467h24.667a1.234 1.234 0 1 1 0 2.467z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-step-3" width="74" height="69">
<path fill="#5CA5C3" fill-rule="evenodd" d="M71.191 57.577H45.4v9.056h11.137c.653 0 1.181.53 1.181 1.183 0 .654-.528 1.184-1.181 1.184H17.462a1.183 1.183 0 0 1 0-2.367H28.6v-9.055H2.809A2.815 2.815 0 0 1 0 54.762V2.815A2.815 2.815 0 0 1 2.809 0h68.382A2.815 2.815 0 0 1 74 2.815v51.947a2.815 2.815 0 0 1-2.809 2.815zm-40.23 9.056h12.077v-9.056H30.961v9.056zM71.638 2.815a.454.454 0 0 0-.447-.448H2.809a.453.453 0 0 0-.447.448v51.947c0 .243.204.448.447.448h68.382a.454.454 0 0 0 .447-.448V2.815zm-3.703 45.133H6.065a1.183 1.183 0 1 1 0-2.367h61.87c.652 0 1.18.53 1.18 1.184 0 .653-.528 1.183-1.18 1.183zM43.5 23.089l1.438-2.589H48.5l-1.48 2.589H43.5zM41.088 33.5l-3.838-6.727L33.4 33.5l-7.4-13h3.583l3.817 6.992 3.85-6.992 3.826 6.992 1.864-3.367h3.506L41.088 33.5z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-check" width="18" height="13">
<path fill="currentColor" fill-rule="evenodd" d="M17.034 3.073L7.097 12.79-.001 5.849l2.839-2.776 4.259 4.164L14.195.296l2.839 2.777z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-crypto" width="44" height="60">
<path fill="currentColor" fill-rule="evenodd" d="M40.706 29.813c-1.939-1.456-4.701-2.038-4.701-2.038s2.337-1.351 3.292-2.701c.956-1.351 1.434-3.443 1.514-4.528.08-1.086.266-5.64-3.293-8.261-2.753-2.028-5.908-2.833-10.144-3.095V-.001h-5.683v9.082h-4.329V-.001H11.68v9.082H.5v5.884h3.286c.896 0 2.489.1 3.166.855.678.755.797 1.152.797 2.621v23.447c0 .556-.106 1.244-.584 1.694-.478.451-.956.556-2.098.556H1.668L.5 50.943h11.18V60h5.683v-9.057h4.328V60h5.683v-9.206c1.469-.085 2.839-.196 3.638-.301 1.62-.211 5.285-.635 8.711-3.018s4.195-6.117 4.275-9.877c.081-3.759-1.355-6.328-3.292-7.785zM17.362 15.489s1.806-.159 3.585-.133c1.78.027 3.346.08 5.684.795 2.336.715 3.716 2.463 3.771 4.528.052 2.065-.851 3.442-2.444 4.316-1.593.874-3.796 1.35-5.869 1.429-2.071.08-4.727 0-4.727 0V15.489zm12.72 27.087c-1.301.715-3.903 1.35-6.426 1.535-2.523.186-6.294.106-6.294.106V32.064s3.612-.185 6.427 0c2.815.186 5.178.9 6.24 1.431 1.062.529 2.922 1.693 2.922 4.474 0 2.78-1.568 3.892-2.869 4.607z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-card" width="60" height="48">
<path fill="currentColor" fill-rule="evenodd" d="M58.531 46.531c-.98.979-2.156 1.468-3.531 1.468H5c-1.375 0-2.552-.489-3.532-1.468C.489 45.552 0 44.374 0 42.999v-38c0-1.375.489-2.552 1.468-3.531C2.448.489 3.625-.001 5-.001h50c1.375 0 2.552.49 3.531 1.469C59.51 2.447 60 3.624 60 4.999v38c0 1.376-.49 2.553-1.469 3.532zM55.999 4.999a.963.963 0 0 0-.296-.703.962.962 0 0 0-.703-.297H5a.96.96 0 0 0-.703.297.957.957 0 0 0-.297.703v7h51.999v-7zm0 19H4v19c0 .271.099.505.297.704a.963.963 0 0 0 .703.296h50c.27 0 .505-.099.703-.295a.967.967 0 0 0 .296-.704V23.999zM20 35.999h12V40H20v-4.001zm-12 0h8V40H8v-4.001z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-paypal" width="60" height="60">
<path fill="currentColor" fill-rule="evenodd" d="M38.942-.001H11.956L-.001 53.43h15.835l3.879-17.705h11.314c10.822 0 19.872-6.497 22.298-17.542C56.067 5.679 46.855-.001 38.942-.001zM27.136 25.494h-5.161l3.392-14.617h7.756c2.66 0 4.675 1.543 5.337 3.809-.339-.058-.655-.157-1.025-.157h-7.756l-2.543 10.965zm11.32-7.31c-.944 3.967-4.816 7.132-8.758 7.281l1.856-8.015h7.031c-.043.244-.06.48-.129.734zm19.18 3.651c.908-4.141.487-7.517-.744-10.204 2.567 2.98 3.895 7.303 2.619 13.124-2.426 11.044-11.478 17.54-22.298 17.54H25.9l-3.878 17.704H6.186l.657-2.921h13.304l3.878-17.703h11.314c10.821 0 19.872-6.496 22.297-17.54z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-ecom" width="60" height="60">
<path fill="currentColor" fill-rule="evenodd" d="M56.453 34.755l-3.198-3.562 3.548-3.21 3.198 3.562-3.548 3.21zM48.719 20.55l3.541-3.212 3.202 3.558-3.541 3.212-3.202-3.558zM44.151 9.968l3.549-3.21 3.198 3.561-3.549 3.211-3.198-3.562zm-6.18-7.762l-6.974 6.248-4.131-4.539L13.859 15.67l8.335 9.222-3.28 2.886 8.212 9.23-3.262 2.882 11.728 13.103 6.947-6.43 6.01 6.896a32.589 32.589 0 0 1-3.931 2.622 29.557 29.557 0 0 1-14.726 3.909C13.437 59.99.011 46.517.011 29.998.011 13.474 13.437 0 29.892 0c4.686 0 9.135 1.096 13.097 3.042.624.297 1.238.626 1.852.982l-2.748 2.471-4.122-4.289zm8.707 37.653l-4.81-5.344 5.327-4.832 4.81 5.345-5.327 4.831zm.755-16.103l-5.319 4.819-4.81-5.349 5.319-4.82 4.81 5.35zm-4.908-10.761l-5.332 4.818-4.8-5.353 5.332-4.818 4.8 5.353zM26.461 9.512l6.397 7.135-7.107 6.422-6.398-7.135 7.108-6.422zm16.517 31.653l-7.105 6.42-6.397-7.135 7.104-6.419 6.398 7.134zM31.538 21.67l6.398 7.135-7.111 6.426-6.397-7.136 7.11-6.425zm20.351 18.828l4.806 5.354-5.33 4.821-4.806-5.354 5.33-4.821z"></path>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" id="i-check-ps" width="18" height="13">
<path fill="#D4E1E7" fill-rule="evenodd" d="M17.503 3.276l-9.919 9.717L.499 6.052l2.834-2.776L7.584 7.44 14.669.499l2.834 2.777z"></path>
</svg>

</svg>

<script src="./dop/whoer.notpacked.js.download"></script>
<script src="./dop/jquery-ui.min.js.download"></script>
<script src="./dop/lodash.core.min.js.download"></script>

<script src="./dop/moment.min.js.download"></script>
<script src="./dop/moment-timezone.min.js.download"></script>
<script src="./dop/api_new.js(1).download"></script>

<script>
(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
(window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

ym(21087886, "init", {
clickmap:false,
trackLinks:true,
accurateTrackBounce:true
});
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/21087886" style="position:absolute; left:-9999px;" alt="" /></div></noscript>


<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-KFCF9VP');</script>


<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KFCF9VP"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<script>
    function whatIsPage() {
        const path = window.location.pathname;
        return path.endsWith('/antidetect') || path.endsWith('/aml');
    }

    function isAMLPage() {
        const path = window.location.pathname;
        return path.endsWith('/aml');
    }

    function loadJivoScript() {
        const widget_id = 'sUhi1DSw3m';
        const d = document;
        const w = window;

        function l() {
            const s = document.createElement('script');
            s.type = 'text/javascript';
            s.async = true;
            s.src = '//code.jivosite.com/script/widget/' + widget_id;
            const ss = document.getElementsByTagName('script')[0];
            ss.parentNode.insertBefore(s, ss);
        }

        if (d.readyState === 'complete') {
            l();
        } else {
            if (w.attachEvent) {
                w.attachEvent('onload', l);
            } else {
                w.addEventListener('load', l, false);
            }
        }
    }

    const jivoOpen = document.getElementById('jivoOpen')

    if (jivoOpen) {
        jivoOpen.addEventListener('click', function() {
            if (isAMLPage()) {
                jivo_api.open();
            }
        });
    }


    if (whatIsPage()) {
        loadJivoScript();
    }

    const toggleJivoChat = () => {
        if (jivo_api.isOpen()) {
            jivo_api.close();
        } else {
            jivo_api.open();
        }
    };

    document.addEventListener('click', function(event) {
        const jivoContainer = document.querySelector('#jivo-iframe-container');
        const jivoButton = document.querySelector('.jivo_button');

        if (event.target === jivoContainer || event.target === jivoButton) {
            toggleJivoChat();
        }
    });

    console.log(whatIsPage());
</script>
<div class="cookies-info" display="block" bis_skin_checked="1">
<div class="cookies-info__wrapper" bis_skin_checked="1">
<p>
Ce site Web utilise des cookies pour améliorer votre expérience.
</p>
<button onclick="document.cookie=&#39;cookies_accept=true&#39;;$(&#39;.cookies-info&#39;).hide()" type="button" class="button_orange">
J`accepte
</button>
</div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        let isCookiesAccepted = getCookie('cookies_accept');
        const cookiesBlock = document.querySelector('.cookies-info');
        if (!isCookiesAccepted) cookiesBlock.setAttribute('display', 'block');
    })
    function getCookie(name) {
      let matches = document.cookie.match(new RegExp(
        "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
      ));
      return matches ? decodeURIComponent(matches[1]) : undefined;
    }
    </script>
</div>
<script>(function(){var js = "window['__CF$cv$params']={r:'820d9e343d843ccb',t:'MTY5OTEwODg4Ny44OTgwMDA='};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script><iframe height="1" width="1" style="position: absolute; top: 0px; left: 0px; border: none; visibility: hidden;" src="./dop/saved_resource.html"></iframe><script defer="" src="./dop/v84a3a4012de94ce1a686ba8c167c359c1696973893317" integrity="sha512-euoFGowhlaLqXsPWQ48qSkBSCFs3DPRyiwVu3FjR96cMPx+Fr+gpWRhIafcHwqwCqWS42RZhIudOvEI+Ckf6MA==" data-cf-beacon="{&quot;rayId&quot;:&quot;820d9e343d843ccb&quot;,&quot;version&quot;:&quot;2023.10.0&quot;,&quot;token&quot;:&quot;375e84ed9c7b46ff9775f9083a0311c8&quot;}" crossorigin="anonymous"></script>


</body></html>