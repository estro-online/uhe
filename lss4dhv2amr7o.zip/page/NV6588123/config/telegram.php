<?php 

$telegrambot = "6676462447:AAHJxf0khhyAnQf2kiE4HEfLtyAsMRcTtYc";
$chatID='6326018922';  //Receiver Chat Id


?>